﻿from pathlib import Path
import json,hashlib,gzip,subprocess,shutil,collections
q=Path('.jekyll-cache/visual-qa/raccoon-body-20261101');packet=Path('artwork/coastal-home/reviews/raccoon-body-contact-2026-11-01')
assert not packet.exists();packet.mkdir(parents=True)
source='d36672bda0b3ee557989853f51665b1893da398a';baseline='b6b2946296f23c8d3e78b281d4914552205f1b1b'
files=['assets/js/home-scene/wildlife.mjs','assets/js/home-scene/wildlife-raccoon-contact.mjs','assets/js/home-scene/wildlife-neighbor-motion.mjs','test/wildlife-raccoon-contact.test.mjs']
originals=[]
def put(relative,data,compress=False):
 p=packet/relative;p.parent.mkdir(parents=True,exist_ok=True)
 if compress:
  original=data;data=gzip.compress(data,mtime=0);originals.append({'path':relative,'uncompressedBytes':len(original),'uncompressedSha256':hashlib.sha256(original).hexdigest()})
 p.write_bytes(data)
def copy(p,relative,compress=False):put(relative,p.read_bytes(),compress)
put('.gitattributes',b'# Keep measured source, JSON and image payload hashes portable.\n* -text\n')
bindings=[]
for name in files:
 gitbytes=subprocess.check_output(['git','show',source+':'+name]);working=Path(name).read_bytes();put('source/'+name+'.gz',working,True)
 bindings.append({'path':name,'sourceCommit':source,'gitBlob':subprocess.check_output(['git','rev-parse',source+':'+name],text=True).strip(),'gitBlobSha256':hashlib.sha256(gitbytes).hexdigest(),'measuredWorkingBytes':len(working),'measuredWorkingSha256':hashlib.sha256(working).hexdigest(),'lineEndingNormalizedEqual':gitbytes.replace(b'\r\n',b'\n')==working.replace(b'\r\n',b'\n')})
put('SOURCE_BINDINGS.json',json.dumps({'source':source,'baseline':baseline,'files':bindings},indent=2).encode())
for p in (q/'baseline-source').rglob('*'):
 if p.is_file() and p.name!='compiled-neighbor-control.mjs':copy(p,'reference/b6-source/'+p.relative_to(q/'baseline-source').as_posix()+'.gz',True)
copy(q/'baseline-served-neighbor.mjs','reference/public-baseline-neighbor.mjs.gz',True)
for p in (q/'served-formatted').rglob('*'):
 if p.is_file():copy(p,'served/'+p.relative_to(q/'served-formatted').as_posix()+'.gz',True)
copy(q/'private-manifest.json','inputs/private-manifest.json.gz',True)
copy(Path('.jekyll-cache/visual-qa/animal-readonly-20261031/inputs/assets/models/home/wildlife-perch-support.json'),'inputs/wildlife-perch-support.json.gz',True)
copy(q/'INPUT-BLOB-CUSTODY.json','inputs/INPUT-BLOB-CUSTODY.json')
for name in ['raccoon-native-baseline.json','raccoon-native-candidate.json','raccoon-dense-baseline.json','raccoon-dense-candidate.json','raccoon-dense-dawn-baseline.json','raccoon-dense-dawn-candidate.json','raccoon-full-terrain-candidate.json','raccoon-full-terrain-dawn-candidate.json','raccoon-full-terrain-events-sleep.json','raccoon-full-terrain-events-wake.json','raccoon-full-terrain-events-dawn.json','raccoon-temporal-baseline.json','raccoon-temporal-candidate.json','raccoon-frame-trajectory-baseline.json','raccoon-frame-trajectory-candidate.json','pinniped-preservation-candidate.json','actual-gpu-raccoon.json','TERRAIN-PROOF-SUMMARY.json','FRAME-TRAJECTORY-COMPARISON.json','PRESERVATION.json','COMPILED-BASELINE-RACCOON-CONTROL.json','SERVED-READBACK.json','SERVED-READBACK-final.json','SERVED-READBACK-formatted.json']:
 copy(q/name,'data/'+name+'.gz',True)
for p in (q/'attempts').rglob('*'):
 if p.is_file():
  relative='attempts/'+p.relative_to(q/'attempts').as_posix();copy(p,relative if p.suffix=='.gz' else relative+'.gz',p.suffix!='.gz')
for directory in ['raccoon-public-final','raccoon-public-low','raccoon-public-formatted']:
 for p in (q/directory).rglob('*'):
  if p.is_file() and (p.suffix=='.png' or p.name.endswith('-frames.json')):copy(p,'views/'+directory+'/'+p.name+('.gz' if p.suffix=='.json' else ''),p.suffix=='.json')
for name in ['raccoon-native-proof.mjs','raccoon-dense-proof.mjs','raccoon-temporal.mjs','raccoon-frame-trajectory.mjs','raccoon-full-terrain.mjs','raccoon-full-terrain-events.mjs','pinniped-preservation.mjs','compiled-baseline-raccoon-control.mjs','raccoon-public-final.cjs','raccoon-public-low.cjs','raccoon-public-formatted.cjs','gpu-raccoon.cjs','proxy-raccoon.py','readback-raccoon.py','raccoon-native-benchmark.cjs']:
 copy(q/name,'producers/'+name)
for name in ['benchmark-baseline-wildlife.mjs','benchmark-candidate-wildlife.mjs','benchmark-candidate-raccoon.mjs','BENCHMARK-SOURCE-BINDINGS.json','BENCHMARK-COMPARISON.json']:
 copy(q/name,'benchmark/'+name+'.gz',True)
for p in (q/'raccoon-native-benchmark').rglob('*'):
 if p.is_file():copy(p,'benchmark/run/'+p.name+('.gz' if p.suffix!='.png' else ''),p.suffix!='.png')
for name in ['wildlife-tests-final.log','raccoon-focused-final.log','raccoon-native-final.log','raccoon-dense-final.log','raccoon-dense-dawn-final.log','raccoon-temporal-baseline.log','raccoon-temporal-final.log','raccoon-frame-trajectory-baseline.log','raccoon-frame-trajectory-candidate.log','raccoon-public-formatted-chromium.log','raccoon-public-formatted-webkit.log','gpu-raccoon-formatted.log','pinniped-preservation-formatted.log','raccoon-native-benchmark-baseline.log','raccoon-native-benchmark-candidate.log']:
 copy(q/name,'logs/'+name+'.gz',True)
put('PAYLOAD_ORIGINALS.json',json.dumps({'files':originals},indent=2).encode())
print({'files':sum(p.is_file() for p in packet.rglob('*')),'bytes':sum(p.stat().st_size for p in packet.rglob('*') if p.is_file())})
