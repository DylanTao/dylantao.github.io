from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import Request, urlopen
from urllib.error import HTTPError
import os
import socket

q = Path(__file__).parent
root = q.parents[2]
owned = {"/al-folio/assets/js/home-scene/" + name: root / "assets/js/home-scene" / name for name in ["wildlife.mjs", "wildlife-raccoon-contact.mjs", "wildlife-neighbor-motion.mjs"]}

class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *args):
        pass
    def do_GET(self):
        name = self.path.split("?", 1)[0]
        if name in owned:
            body, status, headers = owned[name].read_bytes(), 200, {"Content-Type": "text/javascript; charset=utf-8"}
        else:
            try:
                with urlopen(Request("http://127.0.0.1:4173" + self.path, headers={"Cache-Control": "no-cache"}), timeout=90) as response:
                    body, status, headers = response.read(), response.status, dict(response.headers)
            except HTTPError as error:
                body, status, headers = error.read(), error.code, {"Content-Type": "text/plain"}
        self.send_response(status)
        self.send_header("X-Visual-Owner", f"interior-finish/{os.getpid()}/raccoon4178")
        for key, value in headers.items():
            if key.lower() in ["content-type", "content-encoding", "access-control-allow-origin"]:
                self.send_header(key, value)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

class Server(ThreadingHTTPServer):
    allow_reuse_address = False
    request_queue_size = 128
    daemon_threads = True
    def server_bind(self):
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()

server = Server(("127.0.0.1", 4178), Handler)
print({"pid": os.getpid(), "address": server.server_address, "exclusive": True}, flush=True)
server.serve_forever()
