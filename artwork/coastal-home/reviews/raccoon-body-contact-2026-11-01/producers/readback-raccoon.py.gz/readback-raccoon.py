from pathlib import Path
from urllib.request import urlopen, Request
import json,hashlib
q=Path(__file__).parent;root=q.parents[2]
old=json.loads((q/'SERVED-READBACK.json').read_text());oldhash={f['path']:f['sha256'] for f in old['files']};owned={'assets/js/home-scene/'+n for n in ['wildlife.mjs','wildlife-raccoon-contact.mjs','wildlife-neighbor-motion.mjs']};names=list(oldhash)
if 'assets/js/home-scene/wildlife-neighbor-motion.mjs' not in names:names.append('assets/js/home-scene/wildlife-neighbor-motion.mjs')
receipts=[]
for name in names:
 with urlopen(Request('http://127.0.0.1:4178/al-folio/'+name,headers={'Cache-Control':'no-cache'}),timeout=120) as r:body=r.read();owner=r.headers.get('X-Visual-Owner')
 expected=hashlib.sha256((root/name).read_bytes()).hexdigest() if name in owned else oldhash[name]
 assert hashlib.sha256(body).hexdigest()==expected,name
 assert owner=='interior-finish/30528/raccoon4178',(name,owner)
 p=q/'served-formatted'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
 receipts.append({'path':name,'bytes':len(body),'sha256':expected,'owner':owner})
(q/'SERVED-READBACK-formatted.json').write_text(json.dumps({'scope':'Exclusive4178 final formatted live3source modules. Complete raw bodies of every unchanged resource match the retained pre-revision readback, including sealed4173 source modules and the native-point-only private manifest. Complete bodies retained, not headers only.','files':receipts},indent=2))
print({'matched':len(receipts),'owner':owner})
