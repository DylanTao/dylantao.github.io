const {chromium,expect}=require('@playwright/test'),fs=require('node:fs/promises'),path=require('node:path');
const {preparePage,collectRuntimeErrors}=require('../../../test/visual/helpers');
const {pauseSceneClock,useSoftwareSceneCadence}=require('../../../test/visual/scene-clock');
(async()=>{
const q=path.resolve('.jekyll-cache/visual-qa/jump-walk-20261029'),browser=await chromium.launch({args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
try{
 const page=await browser.newPage({viewport:{width:1440,height:1000},deviceScaleFactor:1});const errors=collectRuntimeErrors(page);
 await preparePage(page,'light');await page.clock.install({time:new Date('2026-10-23T13:00:00-07:00')});
 await page.goto('http://127.0.0.1:4153/al-folio/?scene-lab=1&quality=high&resolution=fixed');await page.locator('[data-home-desk-mode="3d"]').click();
 const scene=page.locator('[data-home-desk-scene]'),canvas=scene.locator('canvas'),state=()=>scene.evaluate(e=>e.getSceneEvidence());
 await expect(scene).toHaveAttribute('data-scene-state','ready',{timeout:180000});await canvas.scrollIntoViewIfNeeded();
 await page.locator('[data-world-fullscreen]').click();await page.locator('[data-world-walk]').click();
 await expect.poll(async()=>(await state()).walk?.ready,{timeout:120000}).toBe(true);
 await expect.poll(()=>scene.evaluate(e=>['clifftop-flora','coastal-hinterland'].every(n=>{let o=e.labScene.scene.getObjectByName(n);if(!o)return false;for(;o;o=o.parent)if(!o.visible)return false;return true})),{timeout:150000}).toBe(true);
 await pauseSceneClock(page);await useSoftwareSceneCadence(page,{continuousHz:30,force:true});
 async function frame(action){const before=(await state()).frames;await action();await expect.poll(async()=>{await page.clock.runFor(32);return(await state()).frames},{timeout:60000}).toBeGreaterThan(before)}
 await frame(()=>scene.evaluate(e=>{if(!e.setLabWalk({position:[-1,null,5],yaw:Math.PI,pitch:-.45}))throw Error('Supported start failed');e.setLabWalk=()=>{throw Error('No placement after supported start')}}));
 await canvas.focus();await page.keyboard.down('Shift');await page.keyboard.down('KeyW');await page.keyboard.press('Space');
 for(let i=0;i<180&&(await state()).walk.position[2]>-1.9;i++)await page.clock.runFor(33);
 await page.keyboard.up('KeyW');await page.keyboard.up('Shift');
 for(let i=0;i<240&&!(await state()).walk.waterEntries;i++)await page.clock.runFor(33);
 const entry=await state();expect(entry.walk.waterEntries).toBe(1);
 await frame(()=>scene.evaluate(e=>{e.querySelector('canvas').dispatchEvent(new KeyboardEvent('keydown',{code:'KeyV',key:'v',bubbles:true}));document.querySelector('[data-world-pause]').click();e.setLabCamera({target:[-1,-.09,-2.6],yaw:3.48,pitch:.65,radius:4,free:true})}));
 const rows=[];
 for(let index=0;index<6;index++){
  const s=await state();rows.push({phase:index,walk:s.walk,pool:s.simulation.infinityPool,frames:s.frames});
  await canvas.screenshot({path:path.join(q,`spreading-phase-${index}.png`)});
  await page.evaluate(()=>document.querySelector('[data-world-pause]').click());await page.clock.runFor(index<3?100:250);
  await frame(()=>page.evaluate(()=>document.querySelector('[data-world-pause]').click()));
 }
 await fs.writeFile(path.join(q,'spreading-phases.json'),JSON.stringify({scope:'Controlled-clock material witness after one actual roof-to-pool jump; free observer camera only after entry, no body placement afterward;30Hz functional cadence, not performance proof',entry:{walk:entry.walk,pool:entry.simulation.infinityPool},rows,errors},null,2));
 expect(errors).toEqual([]);process.stdout.write(JSON.stringify(rows.map(r=>({phase:r.phase,seconds:r.pool.impacts.seconds,spray:r.pool.spray}))));
}finally{await browser.close()}
})().catch(e=>{process.stderr.write(e.stack+'\n');process.exitCode=1});
