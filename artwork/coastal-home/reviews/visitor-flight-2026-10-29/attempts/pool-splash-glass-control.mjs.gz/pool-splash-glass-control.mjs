import * as THREE from "../three.module.min.js";
import { sprayDrop, sprayPosition, crownSection } from "./pool-impact.mjs";

export function createPoolSplash(parent, bounds, { heightAt = () => 0 } = {}) {
  const capacity = 144,
    crownRows = 6,
    geometry = new THREE.SphereGeometry(1, 8, 6),
    material = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      roughness: 0.05,
      metalness: 0,
      clearcoat: 0.8,
      transparent: true,
      opacity: 0.6,
      depthWrite: false,
    }),
    drops = new THREE.InstancedMesh(geometry, material, capacity),
    group = new THREE.Group(),
    matrix = new THREE.Matrix4(),
    dropColor = new THREE.Color(0x8fcdd4),
    foamColor = new THREE.Color(0xe4f3ed),
    particles = [],
    crownGeometry = new THREE.BufferGeometry(),
    crownVertices = new Float32Array(65 * crownRows * 3),
    crownMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xc9ecf3,
      roughness: 0.045,
      ior: 1.333,
      transmission: 0.94,
      thickness: 0.004,
      clearcoat: 0.4,
      transparent: true,
      opacity: 1,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
    crownMesh = new THREE.Mesh(crownGeometry, crownMaterial),
    indices = [];
  for (let i = 0; i < 64; i++)
    for (let row = 0; row < crownRows - 1; row++) {
      const a = i * crownRows + row,
        b = a + crownRows;
      indices.push(a, a + 1, b, a + 1, b + 1, b);
    }
  crownGeometry.setAttribute("position", new THREE.BufferAttribute(crownVertices, 3).setUsage(THREE.DynamicDrawUsage));
  crownGeometry.setIndex(indices);
  crownMesh.frustumCulled = false;
  crownMesh.visible = false;
  parent.updateWorldMatrix(true, false);
  group.matrix.copy(parent.matrixWorld).invert();
  group.matrixAutoUpdate = false;
  group.matrixWorldNeedsUpdate = true;
  group.name = "Visitor pool spray";
  group.userData.walk = "through";
  group.userData.noOcclusion = true;
  drops.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  drops.frustumCulled = false;
  drops.count = 0;
  group.add(drops);
  group.add(crownMesh);
  parent.add(group);
  let emitted = 0,
    seconds = 0,
    crown = null;
  function impact({ x, y, z, speed }) {
    const count = Math.min(72, Math.max(18, Math.round(speed * 4)));
    for (let i = 0; i < count; i++) {
      const drop = sprayDrop(speed, i, count),
        tx = drop.x + drop.vx * drop.lifetime,
        tz = drop.z + drop.vz * drop.lifetime;
      // Choose launch velocities that return inside the actual water footprint. This is a spray
      // proxy with ballistic gravity; it does not pretend to solve wall/sheet fluid collisions.
      const fit = Math.min(
        1,
        tx ? (tx > 0 ? bounds.max.x - x : x - bounds.min.x) / Math.abs(tx) : 1,
        tz ? (tz > 0 ? bounds.max.z - z : z - bounds.min.z) / Math.abs(tz) : 1
      );
      drop.vx *= Math.max(0, fit * 0.95);
      drop.vz *= Math.max(0, fit * 0.95);
      drop.x *= Math.max(0, fit * 0.95);
      drop.z *= Math.max(0, fit * 0.95);
      particles.push({ ...drop, originX: x, originY: y, originZ: z, born: seconds });
    }
    // Small, flat entrainment flecks share the spray's one instanced draw. They follow the
    // actual surface height, disperse briefly and shrink away; they are an appearance proxy.
    for (let i = 0; i < 32; i++) {
      const variation = ((i * 17 + 7) % 31) / 31;
      particles.push({
        foam: true,
        angle: i * 2.399963,
        radius: 0.008 + variation * 0.014,
        radial: 0.35 + variation * 0.3,
        lifetime: 1.1 + variation * 0.6,
        originX: x,
        originY: y,
        originZ: z,
        born: seconds,
      });
    }
    if (particles.length > capacity) particles.splice(0, particles.length - capacity);
    emitted += count;
    crown = { x, y, z, speed, born: seconds, life: crownSection(speed, 0, 0).lifetime };
    group.visible = true;
  }
  function advance(dt) {
    seconds += dt;
    let count = 0;
    for (let i = particles.length - 1; i >= 0; i--) {
      const drop = particles[i],
        age = seconds - drop.born;
      if (age >= drop.lifetime) {
        particles.splice(i, 1);
        continue;
      }
      if (drop.foam) {
        const radius = 0.16 + drop.radial * (1 - Math.exp(-age * 1.8)),
          x = Math.max(bounds.min.x + 0.01, Math.min(bounds.max.x - 0.01, drop.originX + radius * Math.cos(drop.angle))),
          z = Math.max(bounds.min.z + 0.01, Math.min(bounds.max.z - 0.01, drop.originZ + radius * Math.sin(drop.angle))),
          size = drop.radius * Math.sqrt(Math.sin((Math.PI * age) / drop.lifetime));
        matrix.makeScale(size, 0.0008, size);
        matrix.setPosition(x, drop.originY + heightAt(x, z) + 0.0025, z);
      } else {
        const [x, y, z] = sprayPosition(drop, age);
        matrix.makeScale(drop.radius, drop.radius * 1.35, drop.radius);
        matrix.setPosition(drop.originX + x, drop.originY + y, drop.originZ + z);
      }
      drops.setColorAt(count, drop.foam ? foamColor : dropColor);
      drops.setMatrixAt(count++, matrix);
    }
    drops.count = count;
    drops.instanceMatrix.needsUpdate = true;
    if (drops.instanceColor) drops.instanceColor.needsUpdate = true;
    crownMesh.visible = Boolean(crown && seconds - crown.born < crown.life);
    if (crownMesh.visible) {
      const age = seconds - crown.born,
        fit = Math.max(
          0,
          Math.min(1, (Math.min(crown.x - bounds.min.x, bounds.max.x - crown.x, crown.z - bounds.min.z, bounds.max.z - crown.z) - 0.01) / 1.2)
        );
      for (let i = 0; i <= 64; i++) {
        const angle = (i * Math.PI * 2) / 64,
          section = crownSection(crown.speed, angle, age),
          cos = Math.cos(angle),
          sin = Math.sin(angle);
        for (let row = 0; row < crownRows; row++) {
          const u = row / (crownRows - 1),
            radius = section.base + (section.rim - section.base) * u,
            x = crown.x + radius * cos * fit,
            z = crown.z + radius * sin * fit;
          crownVertices.set(
            [x, crown.y + heightAt(x, z) * (1 - u) + Math.max(0.003, section.height * Math.sin((u * Math.PI) / 2)), z],
            (i * crownRows + row) * 3
          );
        }
      }
      crownGeometry.attributes.position.needsUpdate = true;
      crownGeometry.computeVertexNormals();
    }
    group.visible = count > 0 || crownMesh.visible;
  }
  group.visible = false;
  return {
    impact,
    advance,
    get busy() {
      return particles.length > 0 || crownMesh.visible;
    },
    evidence: () => ({
      active: particles.length,
      emitted,
      capacity,
      crown: crownMesh.visible,
      gravity: 9.80665,
      method: "bounded ballistic spray and attached crown proxies; footprint-fitted launch velocities",
    }),
    dispose() {
      group.removeFromParent();
      geometry.dispose();
      material.dispose();
      crownGeometry.dispose();
      crownMaterial.dispose();
      drops.dispose();
    },
  };
}
