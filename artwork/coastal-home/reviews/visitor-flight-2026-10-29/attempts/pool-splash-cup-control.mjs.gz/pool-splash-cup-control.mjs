import * as THREE from "../three.module.min.js";
import { sprayDrop, sprayPosition, crownSection } from "./pool-impact.mjs";

export function createPoolSplash(parent, bounds) {
  const capacity = 144,
    geometry = new THREE.SphereGeometry(1, 8, 6),
    material = new THREE.MeshPhysicalMaterial({
      color: 0x71b6ba,
      roughness: 0.05,
      metalness: 0,
      clearcoat: 0.8,
      transparent: true,
      opacity: 0.6,
      depthWrite: false,
    }),
    drops = new THREE.InstancedMesh(geometry, material, capacity),
    group = new THREE.Group(),
    matrix = new THREE.Matrix4(),
    particles = [],
    crownGeometry = new THREE.BufferGeometry(),
    crownVertices = new Float32Array(65 * 2 * 3),
    crownMaterial = new THREE.MeshPhysicalMaterial({
      color: 0x4a969b,
      roughness: 0.045,
      clearcoat: 0.9,
      transparent: true,
      opacity: 0.42,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
    crownMesh = new THREE.Mesh(crownGeometry, crownMaterial),
    indices = [];
  for (let i = 0; i < 64; i++) indices.push(i * 2, i * 2 + 1, i * 2 + 2, i * 2 + 1, i * 2 + 3, i * 2 + 2);
  crownGeometry.setAttribute("position", new THREE.BufferAttribute(crownVertices, 3).setUsage(THREE.DynamicDrawUsage));
  crownGeometry.setIndex(indices);
  crownMesh.frustumCulled = false;
  crownMesh.visible = false;
  parent.updateWorldMatrix(true, false);
  group.matrix.copy(parent.matrixWorld).invert();
  group.matrixAutoUpdate = false;
  group.matrixWorldNeedsUpdate = true;
  group.name = "Visitor pool spray";
  group.userData.walk = "through";
  group.userData.noOcclusion = true;
  drops.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  drops.frustumCulled = false;
  drops.count = 0;
  group.add(drops);
  group.add(crownMesh);
  parent.add(group);
  let emitted = 0,
    seconds = 0,
    crown = null;
  function impact({ x, y, z, speed }) {
    const count = Math.min(72, Math.max(18, Math.round(speed * 4)));
    for (let i = 0; i < count; i++) {
      const drop = sprayDrop(speed, i, count),
        tx = drop.x + drop.vx * drop.lifetime,
        tz = drop.z + drop.vz * drop.lifetime;
      // Choose launch velocities that return inside the actual water footprint. This is a spray
      // proxy with ballistic gravity; it does not pretend to solve wall/sheet fluid collisions.
      const fit = Math.min(
        1,
        tx ? (tx > 0 ? bounds.max.x - x : x - bounds.min.x) / Math.abs(tx) : 1,
        tz ? (tz > 0 ? bounds.max.z - z : z - bounds.min.z) / Math.abs(tz) : 1
      );
      drop.vx *= Math.max(0, fit * 0.95);
      drop.vz *= Math.max(0, fit * 0.95);
      drop.x *= Math.max(0, fit * 0.95);
      drop.z *= Math.max(0, fit * 0.95);
      particles.push({ ...drop, originX: x, originY: y, originZ: z, born: seconds });
    }
    if (particles.length > capacity) particles.splice(0, particles.length - capacity);
    emitted += count;
    crown = { x, y, z, speed, born: seconds, life: crownSection(speed, 0, 0).lifetime };
    group.visible = true;
  }
  function advance(dt) {
    seconds += dt;
    let count = 0;
    for (let i = particles.length - 1; i >= 0; i--) {
      const drop = particles[i],
        age = seconds - drop.born;
      if (age >= drop.lifetime) {
        particles.splice(i, 1);
        continue;
      }
      const [x, y, z] = sprayPosition(drop, age);
      matrix.makeScale(drop.radius, drop.radius * 1.35, drop.radius);
      matrix.setPosition(drop.originX + x, drop.originY + y, drop.originZ + z);
      drops.setMatrixAt(count++, matrix);
    }
    drops.count = count;
    drops.instanceMatrix.needsUpdate = true;
    crownMesh.visible = Boolean(crown && seconds - crown.born < crown.life);
    if (crownMesh.visible) {
      const age = seconds - crown.born,
        fit = Math.max(
          0,
          Math.min(1, (Math.min(crown.x - bounds.min.x, bounds.max.x - crown.x, crown.z - bounds.min.z, bounds.max.z - crown.z) - 0.01) / 1.2)
        );
      for (let i = 0; i <= 64; i++) {
        const angle = (i * Math.PI * 2) / 64,
          section = crownSection(crown.speed, angle, age),
          cos = Math.cos(angle),
          sin = Math.sin(angle),
          at = i * 6;
        crownVertices.set(
          [
            crown.x + section.base * cos * fit,
            crown.y + 0.003,
            crown.z + section.base * sin * fit,
            crown.x + section.rim * cos * fit,
            crown.y + section.height,
            crown.z + section.rim * sin * fit,
          ],
          at
        );
      }
      crownGeometry.attributes.position.needsUpdate = true;
      crownGeometry.computeVertexNormals();
    }
    group.visible = count > 0 || crownMesh.visible;
  }
  group.visible = false;
  return {
    impact,
    advance,
    get busy() {
      return particles.length > 0 || crownMesh.visible;
    },
    evidence: () => ({
      active: particles.length,
      emitted,
      capacity,
      crown: crownMesh.visible,
      gravity: 9.80665,
      method: "bounded ballistic spray and attached crown proxies; footprint-fitted launch velocities",
    }),
    dispose() {
      group.removeFromParent();
      geometry.dispose();
      material.dispose();
      crownGeometry.dispose();
      crownMaterial.dispose();
      drops.dispose();
    },
  };
}
