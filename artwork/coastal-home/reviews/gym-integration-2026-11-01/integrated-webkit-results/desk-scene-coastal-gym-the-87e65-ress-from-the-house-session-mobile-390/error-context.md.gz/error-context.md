# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: desk-scene.spec.js >> coastal gym: the digital screen separates recorded progress from the house session
- Location: test\visual\desk-scene.spec.js:3469:1

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  locator('[data-training-dialog]').locator('[data-training-day="3"]')
Expected: focused
Received: inactive
Timeout:  15000ms

Call log:
  - Expect "toBeFocused" locator('[data-training-dialog]').locator('[data-training-day="3"]') with timeout 15000ms
  - waiting for locator('[data-training-dialog]').locator('[data-training-day="3"]')
    33 × locator resolved to <button type="button" aria-pressed="true" data-training-day="3">…</button>
       - unexpected value "inactive"

```

```yaml
- button "Day 4 lower" [pressed]
```

# Test source

```ts
  3419 |   return {
  3420 |     gym,
  3421 |     scene,
  3422 |     canvas,
  3423 |     ui,
  3424 |     stage,
  3425 |     activate,
  3426 |     touch,
  3427 |     fixture: { dateKey: "2026-10-15", pinnedTimestamp: Math.trunc(pinned), sessionSeconds: working.start + 0.5 },
  3428 |   };
  3429 | }
  3430 | 
  3431 | async function trainingPanelFits(dialog, page) {
  3432 |   const fit = await dialog.evaluate((element) => {
  3433 |     const panel = element.querySelector(".home-training-panel"),
  3434 |       old = panel.scrollTop;
  3435 |     panel.scrollTop = panel.scrollHeight;
  3436 |     const last = panel.lastElementChild.getBoundingClientRect(),
  3437 |       bounds = panel.getBoundingClientRect();
  3438 |     const result = {
  3439 |       dialog: element.getBoundingClientRect().toJSON(),
  3440 |       panel: bounds.toJSON(),
  3441 |       last: last.toJSON(),
  3442 |       background: getComputedStyle(element).backgroundColor.match(/\d+/g).slice(0, 3).map(Number),
  3443 |     };
  3444 |     panel.scrollTop = old;
  3445 |     return result;
  3446 |   });
  3447 |   expect(fit.dialog.y).toBeGreaterThanOrEqual(0);
  3448 |   expect(fit.dialog.bottom).toBeLessThanOrEqual(page.viewportSize().height + 1);
  3449 |   expect(fit.last.bottom).toBeLessThanOrEqual(fit.panel.bottom + 1);
  3450 |   expect(fit.last.bottom).toBeGreaterThan(fit.panel.top);
  3451 |   return fit;
  3452 | }
  3453 | 
  3454 | function trainingPanelPixelFit(buffer, fit, viewport) {
  3455 |   const png = PNG.sync.read(buffer),
  3456 |     scale = png.width / viewport.width;
  3457 |   const y = Math.round((fit.dialog.y + 4) * scale),
  3458 |     left = Math.round((fit.dialog.x + fit.dialog.width * 0.2) * scale),
  3459 |     right = Math.round((fit.dialog.x + fit.dialog.width * 0.8) * scale);
  3460 |   let matching = 0;
  3461 |   for (let x = left; x < right; x++) {
  3462 |     const i = (y * png.width + x) * 4;
  3463 |     if (fit.background.every((v, c) => Math.abs(png.data[i + c] - v) <= 1)) matching++;
  3464 |   }
  3465 |   expect(matching / (right - left), "the panel must paint at its measured viewport location").toBeGreaterThan(0.8);
  3466 |   return { y, left, right, matching, expected: fit.background };
  3467 | }
  3468 | 
  3469 | test("coastal gym: the digital screen separates recorded progress from the house session", async ({ page }, testInfo) => {
  3470 |   test.setTimeout(600000);
  3471 |   const errors = collectRuntimeErrors(page),
  3472 |     { scene, canvas, ui, stage, activate, touch, fixture } = await openTrainingScreenHome(page, testInfo);
  3473 |   const beforeClock = await page.evaluate(() => ({ dateNow: Date.now(), performanceNow: performance.now() }));
  3474 |   const before = await evidence(scene),
  3475 |     target = before.targets.find((p) => p.type === "training-screen"),
  3476 |     box = await canvas.boundingBox();
  3477 |   expect(before.gym.screen).toMatchObject({ width: 2048, height: 1392, selfLit: true, emissiveOnlyAppearance: true });
  3478 |   expect(before.gym.screen.diffuse.every((v) => v < 0.004)).toBe(true);
  3479 |   expect(target.x).toBeGreaterThan(0);
  3480 |   expect(target.x).toBeLessThan(1);
  3481 |   expect(target.y).toBeGreaterThan(0);
  3482 |   expect(target.y).toBeLessThan(1);
  3483 |   const point = { x: box.x + target.x * box.width, y: box.y + target.y * box.height };
  3484 |   if (touch) await page.touchscreen.tap(point.x, point.y);
  3485 |   else await page.mouse.click(point.x, point.y);
  3486 |   const dialog = page.locator("[data-training-dialog]");
  3487 |   await expect(dialog).toBeVisible();
  3488 |   const embeddedFit = await trainingPanelFits(dialog, page);
  3489 |   await expect(dialog.getByRole("tab", { name: "Today", exact: true })).toBeFocused();
  3490 |   await expect(dialog.locator(".home-training-eyebrow").last()).toContainText("House session");
  3491 |   await expect(dialog.locator(".home-training-sets [data-done=true]")).toHaveCount(2);
  3492 |   await expect(dialog.locator(".home-training-sets [aria-current=step]")).toHaveCount(1);
  3493 |   expect(await dialog.locator("h2").evaluate((e) => getComputedStyle(e).color)).toBe("rgb(237, 245, 244)");
  3494 |   await capture(testInfo, "training-today", await dialog.screenshot());
  3495 |   await activate(dialog.getByRole("tab", { name: "Progress", exact: true }));
  3496 |   await activate(dialog.locator('[data-training-lift="bench"]'));
  3497 |   await expect(dialog.locator('[data-training-lift="bench"]')).toContainText("235 lb");
  3498 |   await activate(dialog.locator('[data-training-unit="kg"]'));
  3499 |   await expect(dialog.locator('[data-training-lift="bench"]')).toContainText("106.6 kg");
  3500 |   await expect(dialog.locator(".home-training-cycles")).toContainText("85 / 99");
  3501 |   await activate(dialog.locator(".home-training-history summary"));
  3502 |   await expect(dialog.locator(".home-training-history tbody tr")).toHaveCount(10);
  3503 |   await capture(testInfo, "training-progress", await dialog.screenshot());
  3504 |   // A large texture remains unchanged while real subsequent animation frames run.
  3505 |   await page.emulateMedia({ reducedMotion: "no-preference" });
  3506 |   const active = await evidence(scene);
  3507 |   await expect.poll(async () => (await evidence(scene)).frames, { timeout: 60000 }).toBeGreaterThan(active.frames + 5);
  3508 |   const animated = await evidence(scene);
  3509 |   expect(animated.gym.screen.uploads).toBe(active.gym.screen.uploads);
  3510 |   await page.emulateMedia({ reducedMotion: "reduce" });
  3511 |   await page.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  3512 |   const contactBefore = await evidence(scene),
  3513 |     contactBeforeClock = await page.evaluate(() => ({ dateNow: Date.now(), performanceNow: performance.now() }));
  3514 |   await dialog.getByRole("tab", { name: "Progress", exact: true }).focus();
  3515 |   await page.keyboard.press("ArrowRight");
  3516 |   await expect(dialog.getByRole("tab", { name: "Program", exact: true })).toBeFocused();
  3517 |   await activate(dialog.locator('[data-training-template="deadlift"]'));
  3518 |   await activate(dialog.locator('[data-training-day="3"]'));
> 3519 |   await expect(dialog.locator('[data-training-day="3"]')).toBeFocused();
       |                                                           ^ Error: expect(locator).toBeFocused() failed
  3520 |   await expect(dialog.locator('[data-training-day="3"]')).toHaveAttribute("aria-pressed", "true");
  3521 |   await capture(testInfo, "training-program", await dialog.screenshot());
  3522 |   await page.keyboard.press("Escape");
  3523 |   await expect(dialog).not.toBeVisible();
  3524 |   await expect(canvas).toBeFocused();
  3525 |   const after = await evidence(scene);
  3526 |   const afterClock = await page.evaluate(() => ({ dateNow: Date.now(), performanceNow: performance.now() }));
  3527 |   expect(beforeClock.dateNow).toBe(fixture.pinnedTimestamp);
  3528 |   expect(afterClock.dateNow).toBe(beforeClock.dateNow);
  3529 |   expect(after.currentRoom).toBe(before.currentRoom);
  3530 |   // Compare UI actions at matched paused physical/session times. The deliberate
  3531 |   // live interval above also advances the authored finger clip; retain it separately.
  3532 |   const contactDelta = { bars: {}, joints: {} };
  3533 |   expect(after.animationSeconds).toBe(contactBefore.animationSeconds);
  3534 |   for (const [station, bar] of Object.entries(contactBefore.gym.bars)) {
  3535 |     const next = after.gym.bars[station];
  3536 |     expect(next.weight).toBe(bar.weight);
  3537 |     expect(next.held).toBe(bar.held);
  3538 |     contactDelta.bars[station] = Math.hypot(...next.position.map((v, i) => v - bar.position[i]));
  3539 |     expect(contactDelta.bars[station]).toBeLessThan(0.000001);
  3540 |   }
  3541 |   expect(after.gym.incline).toBe(contactBefore.gym.incline);
  3542 |   expect(after.actorPosition).toEqual(contactBefore.actorPosition);
  3543 |   for (const [joint, position] of Object.entries(contactBefore.joints)) {
  3544 |     contactDelta.joints[joint] = Math.hypot(...after.joints[joint].map((v, i) => v - position[i]));
  3545 |     expect(contactDelta.joints[joint]).toBeLessThan(0.000001);
  3546 |   }
  3547 |   // The keyboard/touch alternative works in the same full-screen stage.
  3548 |   await activate(ui.locator("[data-world-fullscreen]"));
  3549 |   await activate(ui.locator("[data-world-training]"));
  3550 |   await expect(dialog).toBeVisible();
  3551 |   const fullscreenFit = await trainingPanelFits(dialog, page);
  3552 |   const fullscreenPicture = await page.screenshot(),
  3553 |     fullscreenPixels = trainingPanelPixelFit(fullscreenPicture, fullscreenFit, page.viewportSize());
  3554 |   await capture(testInfo, "training-fullscreen", fullscreenPicture);
  3555 |   await page.keyboard.press("Escape");
  3556 |   await expect(dialog).not.toBeVisible();
  3557 |   await expect(stage).toHaveClass(/is-world-immersive/);
  3558 |   await expect(ui.locator("[data-world-training]")).toBeFocused();
  3559 |   await page.locator("[data-world-exit]").click();
  3560 |   expect(errors).toEqual([]);
  3561 |   fs.writeFileSync(
  3562 |     testInfo.outputPath("training-screen.json"),
  3563 |     JSON.stringify(
  3564 |       {
  3565 |         fixture,
  3566 |         beforeClock,
  3567 |         contactBeforeClock,
  3568 |         afterClock,
  3569 |         before,
  3570 |         active,
  3571 |         animated,
  3572 |         contactBefore,
  3573 |         after,
  3574 |         contactDelta,
  3575 |         embeddedFit,
  3576 |         fullscreenFit,
  3577 |         fullscreenPixels,
  3578 |         errors,
  3579 |       },
  3580 |       null,
  3581 |       2
  3582 |     )
  3583 |   );
  3584 | });
  3585 | 
  3586 | test("coastal gym: the training dialog releases held walk input while gravity continues", async ({ page }, testInfo) => {
  3587 |   test.setTimeout(600000);
  3588 |   const errors = collectRuntimeErrors(page),
  3589 |     { scene, canvas, ui, stage, activate } = await openTrainingScreenHome(page, testInfo);
  3590 |   await activate(ui.locator("[data-world-fullscreen]"));
  3591 |   await expect.poll(async () => (await evidence(scene)).walk?.ready, { timeout: 90000 }).toBe(true);
  3592 |   await activate(page.locator("[data-world-walk]"));
  3593 |   await expect.poll(async () => (await evidence(scene)).walk?.active).toBe(true);
  3594 |   await expect.poll(async () => (await evidence(scene)).walk?.transition).toBe(false);
  3595 |   const dialog = page.locator("[data-training-dialog]"),
  3596 |     rows = [];
  3597 |   await canvas.focus();
  3598 |   await page.keyboard.down("KeyW");
  3599 |   await expect.poll(async () => (await evidence(scene)).walk.keys).toContain("KeyW");
  3600 |   await activate(ui.locator("[data-world-training]"));
  3601 |   await expect(dialog).toBeVisible();
  3602 |   const held = await evidence(scene);
  3603 |   rows.push({ phase: "held-key-open", walk: held.walk });
  3604 |   expect(held.walk).toMatchObject({ active: true, inputSuspended: true, keys: [], velocity: [0, 0], locked: false });
  3605 |   await page.keyboard.press("Escape");
  3606 |   await expect(stage).toHaveClass(/is-world-immersive/);
  3607 |   await canvas.focus();
  3608 |   await page.keyboard.down("KeyW"); // still held: this is an actual repeat, not a fresh press
  3609 |   expect((await evidence(scene)).walk.keys).toEqual([]);
  3610 |   await page.keyboard.up("KeyW");
  3611 |   await page.keyboard.down("KeyW");
  3612 |   await expect.poll(async () => (await evidence(scene)).walk.keys).toContain("KeyW");
  3613 |   await page.keyboard.up("KeyW");
  3614 |   await page.waitForTimeout(100);
  3615 |   // Date is pinned, but a real Space jump still follows native RAF gravity under the dialog.
  3616 |   await canvas.focus();
  3617 |   await page.keyboard.press("Space");
  3618 |   await expect.poll(async () => (await evidence(scene)).walk.grounded).toBe(false);
  3619 |   await page.keyboard.press("t");
```