const fs=require('node:fs'),path=require('node:path');
const q=__dirname,apis={chromium:require('C:/dev/dylantao.github.io/node_modules/playwright-core'),webkit:require('C:/dev/dylantao.github.io/.jekyll-cache/visual-qa/takeover-archives/walk-audit-20261028-cache/visual-qa/walk-audit-20261028/pw165/node_modules/playwright-core')};
(async()=>{const rows=[];for(const engine of [process.env.ANIMAL_ENGINE||'chromium']){
 const browser=await apis[engine][engine].launch({headless:true});try{
  const context=await browser.newContext(),page=await context.newPage();await page.goto('http://127.0.0.1:4166/al-folio/',{waitUntil:'domcontentloaded'});
  const inspect=()=>page.evaluate(()=>{const steps=[];let previous=performance.now();for(let i=0;i<100000;i++){const current=performance.now();if(current>previous)steps.push(current-previous);previous=current}return{playwrightClockPresent:!!globalThis.__pwClock,dateFake:!!Date.isFake,performanceNow:performance.now.toString(),requestAnimationFrame:requestAnimationFrame.toString(),crossOriginIsolated,positiveSteps:steps,minimumObservedPositiveStepMs:steps.length?Math.min(...steps):null,userAgent:navigator.userAgent}});
  const native=await inspect();await page.clock.setFixedTime(new Date('2026-10-31T13:20:00-07:00'));const shim=await inspect();
  rows.push({engine,native,shim,scope:'Separate clock diagnostic on the actual origin without activating 3D. Native observation precedes the explicitly installed controlled-clock comparison; it is not the no-clock scene/performance run.'});await context.close();
 }finally{await browser.close()}}
 fs.writeFileSync(path.join(q,'clock-runtime-control-'+rows[0].engine+'.json'),JSON.stringify(rows,null,2));console.log(JSON.stringify(rows.map(r=>({engine:r.engine,nativeStep:r.native.minimumObservedPositiveStepMs,shimStep:r.shim.minimumObservedPositiveStepMs,nativeHasClock:r.native.playwrightClockPresent,shimHasClock:r.shim.playwrightClockPresent}))));
})().catch(e=>{console.error(e);process.exitCode=1});
