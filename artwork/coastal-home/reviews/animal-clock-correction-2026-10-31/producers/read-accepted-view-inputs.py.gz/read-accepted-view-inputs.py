import gzip
import hashlib
import json
from pathlib import Path
from urllib.request import urlopen
q=Path(__file__).parent
root=q.parents[2]
def fetch(port,path):
    with urlopen(f'http://127.0.0.1:{port}/al-folio/'+path,timeout=30)as response:return response.read()
original=json.loads((q/'INPUT_BINDINGS.json').read_text())
rows=[]
for item in original['files']:
    body=fetch(4158,item['path']);assert len(body)==item['bytes']and hashlib.sha256(body).hexdigest()==item['sha256'],item['path']
    rows.append({'port':4158,**item,'matched':True})
for port,packet,binding_key in [(4162,'rabbit-contact-2026-10-31','candidateServedBindings'),(4163,'raccoon-tail-2026-10-31','actualServedModuleBindings')]:
    binding=json.loads((root/'artwork/coastal-home/reviews'/packet/'SOURCE_BINDINGS.json').read_text())
    for item in binding[binding_key]:
        body=fetch(port,item['path']);assert len(body)==item['bytes']and hashlib.sha256(body).hexdigest()==item['sha256'],(port,item['path'])
        rows.append({'port':port,'path':item['path'],'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'matched':True})
    for name in ['manifest.json','home-shell.glb','coast.glb','static-light-field.json']:
        path='assets/models/home/'+name;expected=next(r for r in original['files']if r['path']==path);body=fetch(port,path)
        assert hashlib.sha256(body).hexdigest()==expected['sha256'];rows.append({'port':port,**expected,'matched':True})
profile=fetch(4166,'assets/js/home-scene/wildlife-resting-contact.mjs');assert profile==(q/'profiled-tail.mjs').read_bytes()
prefix=profile.decode().replace('\r\n','\n').split('// Private passive measurement wrapper')[0].replace('function createProfiledTailImplementation(','export function createRestingTailFit(')
accepted=(q/'sealed-tail/assets/js/home-scene/wildlife-resting-contact.mjs').read_text();assert prefix==accepted+'\n'
rows.append({'port':4166,'path':'assets/js/home-scene/wildlife-resting-contact.mjs','bytes':len(profile),'sha256':hashlib.sha256(profile).hexdigest(),'acceptedImplementationByteExactAfterUndoingWrapperNameAndOneTrailingNewline':True,'acceptedImplementationSha256':hashlib.sha256(accepted.encode()).hexdigest()})
report={'scope':'Readback after the unclocked runs; full response bodies compared with sealed accepted input/module hashes. No geometry or light/cache products changed. The private profiling wrapper restores the exact accepted implementation after removing only its function rename/recorder.','rows':rows}
(q/'unclocked-served-input-readback.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'responsesVerified':len(rows),'fullBaselineControls':len(original['files']),'profileImplementationExact':True}))
