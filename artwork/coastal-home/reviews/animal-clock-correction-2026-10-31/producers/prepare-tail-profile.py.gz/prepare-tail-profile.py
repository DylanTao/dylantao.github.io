from pathlib import Path
q=Path(__file__).parent
source=(q/'sealed-tail/assets/js/home-scene/wildlife-resting-contact.mjs').read_text()
source=source.replace('export function createRestingTailFit(', 'function createProfiledTailImplementation(')
source+='''
// Private passive measurement wrapper; the accepted implementation above is unchanged.
export function createRestingTailFit(options) {
  const fit=createProfiledTailImplementation(options);
  return {...fit,update(...args){
    const start=performance.now(),result=fit.update(...args),end=performance.now();
    (globalThis.__tailProfile??=[]).push({milliseconds:end-start,now:end,state:options.group.userData.state,iterations:result.iterations,samples:result.samples,rotation:result.rotation,gap:result.gap,supported:result.supported});
    return result;
  }};
}
'''
(q/'profiled-tail.mjs').write_text(source,encoding='utf-8')
proxy=(q/'proxy-frozen-tail.py').read_text().replace('4163','4166')
proxy=proxy.replace('class Handler(BaseHTTPRequestHandler):','OWNED["/al-folio/assets/js/home-scene/wildlife-resting-contact.mjs"]=q/"profiled-tail.mjs"\nclass Handler(BaseHTTPRequestHandler):')
(q/'proxy-tail-profile.py').write_text(proxy,encoding='utf-8')
