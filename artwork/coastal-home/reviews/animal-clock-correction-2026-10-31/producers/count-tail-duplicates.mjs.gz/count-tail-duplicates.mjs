import fs from 'node:fs';
import {loadNativeModel}from '../../../test/helpers/coastal-native-avatar.mjs';
const master=await loadNativeModel('Raccoon.glb',new URL('./inputs/assets/models/home/',import.meta.url)),rows=[],keys=new Map(),bits=new DataView(new ArrayBuffer(4));
const bit=v=>{bits.setFloat32(0,v);return bits.getUint32(0).toString(16)};
master.scene.traverse(mesh=>{if(!mesh.isSkinnedMesh)return;const p=mesh.geometry.attributes.position,s=mesh.geometry.attributes.skinIndex,w=mesh.geometry.attributes.skinWeight;for(let i=0;i<p.count;i++){
 let tail=0;for(let k=0;k<4;k++)if(/^Tail/.test(mesh.skeleton.bones[s.getComponent(i,k)].name))tail+=w.getComponent(i,k);if(tail<=.0001)continue;
 const tuple=[mesh.uuid,bit(p.getX(i)),bit(p.getY(i)),bit(p.getZ(i)),Array.from({length:4},(_,k)=>[mesh.skeleton.bones[s.getComponent(i,k)].name,bit(w.getComponent(i,k))])],key=JSON.stringify(tuple);(keys.get(key)||keys.set(key,[]).get(key)).push({mesh:mesh.name,index:i});
}});
for(const group of keys.values())if(group.length>1)rows.push(group);
const report={total:[...keys.values()].reduce((n,r)=>n+r.length,0),unique:keys.size,duplicates:rows,criterion:'Exact Float32 position bits, ordered joint names and Float32 weight bits within the same delivered mesh/bind transform; no geometry approximation.'};fs.writeFileSync(new URL('./tail-exact-duplicates.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify(report));
