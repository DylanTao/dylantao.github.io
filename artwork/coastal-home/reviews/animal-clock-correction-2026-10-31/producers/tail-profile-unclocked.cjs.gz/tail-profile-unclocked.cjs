const fs=require('node:fs'),path=require('node:path');
const engine=process.env.ANIMAL_ENGINE||'chromium';
const api=require(engine==='webkit'?'C:/dev/dylantao.github.io/.jekyll-cache/visual-qa/takeover-archives/walk-audit-20261028-cache/visual-qa/walk-audit-20261028/pw165/node_modules/@playwright/test':'C:/dev/dylantao.github.io/node_modules/@playwright/test');
const {expect}=api,{preparePage,collectRuntimeErrors}=require('../../../test/visual/helpers.js'),q=__dirname,out=path.join(q,'tail-profile-unclocked');fs.mkdirSync(out,{recursive:true});
(async()=>{
 const browser=engine==='webkit'?await api.webkit.launch({headless:true}):await api.chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
 try{
  const context=await browser.newContext({viewport:{width:engine==='webkit'?390:2560,height:engine==='webkit'?1000:1440},deviceScaleFactor:1,reducedMotion:'no-preference',hasTouch:engine==='webkit',isMobile:engine==='webkit',timezoneId:'America/Los_Angeles'}),page=await context.newPage(),errors=collectRuntimeErrors(page);
  page.setDefaultTimeout(60000);await preparePage(page,'light');
  await page.goto('http://127.0.0.1:4166/al-folio/?quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});
  const activate=l=>engine==='webkit'?l.tap():l.click();await activate(page.locator('[data-theme-toggle]:visible').first());await activate(page.locator('[data-theme-mode-option="noon"]:visible').first());await activate(page.locator('[data-theme-toggle]:visible').first());await activate(page.locator('[data-home-desk-mode="3d"]'));
  const clockProof=await page.evaluate(()=>({playwrightClockPresent:!!globalThis.__pwClock,dateFake:!!Date.isFake,performanceNow:performance.now.toString(),requestAnimationFrame:requestAnimationFrame.toString(),timeOrigin:performance.timeOrigin}));expect(clockProof.playwrightClockPresent||clockProof.dateFake).toBe(false);expect(clockProof.performanceNow).toContain('[native code]');expect(clockProof.requestAnimationFrame).toContain('[native code]');
  const host=page.locator('[data-home-desk-scene]'),canvas=host.locator('canvas'),ui=page.locator('[data-home-world-controls]');
  await host.scrollIntoViewIfNeeded();await expect(host).toHaveAttribute('data-scene-state','ready',{timeout:120000});await activate(ui.locator('[data-world-fullscreen]'));await canvas.focus();
  async function select(){for(let i=0;i<28;i++){await canvas.press('n');if(await host.evaluate(e=>e.getSceneEvidence().inspection?.id)==='raccoon-0')break}await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().inspection?.id)).toBe('raccoon-0');await page.waitForTimeout(2000)}
  await select();
  async function collect(label,state,count,budget){
   await page.evaluate(()=>{globalThis.__tailProfile=[]});const start=Date.now();let calls=[],lastProgress=Date.now();
   while(Date.now()-start<budget){await page.waitForTimeout(250);calls=await page.evaluate(()=>globalThis.__tailProfile||[]);if(Date.now()-lastProgress>5000){console.log(JSON.stringify({engine,label,calls:calls.length,states:[...new Set(calls.map(r=>r.state))],frames:await host.evaluate(e=>e.getSceneEvidence().frames)}));lastProgress=Date.now()}if(calls.filter(r=>r.state===state).length>=count+60)break}
   fs.writeFileSync(path.join(out,engine+'-'+label+'-raw-attempt.json'),JSON.stringify({calls,clockProof,evidence:await host.evaluate(e=>e.getSceneEvidence()),errors},null,2));console.log(JSON.stringify({label,allStates:[...new Set(calls.map(r=>r.state))],calls:calls.length}));const selected=calls.filter(r=>r.state===state).slice(60);expect(selected.length).toBeGreaterThanOrEqual(count);
   const values=selected.map(r=>r.milliseconds).sort((a,b)=>a-b),record={engine,label,state,warmupDiscarded:60,calls,selected,medianMs:values[Math.floor(values.length*.5)],p95Ms:values[Math.floor(values.length*.95)],elapsedWallMs:Date.now()-start,evidence:await host.evaluate(e=>e.getSceneEvidence()),backend:await canvas.evaluate(c=>{const gl=c.getContext('webgl2'),d=gl.getExtension('WEBGL_debug_renderer_info');return{renderer:gl.getParameter(d?.UNMASKED_RENDERER_WEBGL||gl.RENDERER),buffer:[gl.drawingBufferWidth,gl.drawingBufferHeight],userAgent:navigator.userAgent}}),errors:[...errors],clockProof,scope:'No Playwright clock calls. Noon is prepared and Evening selected using the public theme control. Private passive wrapper around the unchanged accepted update; actual public N inspection and native RAF/performance. Date, performance and RAF are native; exact source strings retained. Per-call CPU wall time includes timer precision/preemption and excludes the recorder after the stop time. Not whole-frame FPS or physical-phone performance.'};
   fs.writeFileSync(path.join(out,engine+'-'+label+'.json'),JSON.stringify(record,null,2));console.log(JSON.stringify({engine,label,samples:selected.length,medianMs:record.medianMs,p95Ms:record.p95Ms,backend:record.backend,errors:errors.length}));
  }
  await collect('sleep','sleep',300,60000);
  await activate(page.locator('[data-world-exit]:visible'));await activate(page.locator('[data-theme-toggle]:visible').first());await activate(page.locator('[data-theme-mode-option="evening"]:visible').first());await activate(page.locator('[data-theme-toggle]:visible').first());await activate(ui.locator('[data-world-fullscreen]'));await canvas.focus();await select();
  await collect('walk','walk',180,120000);
  expect(errors).toEqual([]);await context.close();
 }finally{await browser.close()}
})().catch(e=>{fs.writeFileSync(path.join(out,engine+'-failure.txt'),String(e.stack||e));console.error(e);process.exitCode=1});
