import { accumulateL1, deringL1, evaluateL1, dot, normalize } from './light-trace-core.mjs';
import { coastalDaylight } from './daylight.mjs';

const azimuthCount=24, elevationCount=12;
const directions=[];
for(let elevation=0;elevation<elevationCount;elevation++) {
  const altitude=elevation/elevationCount*Math.PI/2;
  for(let azimuth=0;azimuth<azimuthCount;azimuth++) {
    const angle=azimuth/azimuthCount*Math.PI*2;
    directions.push([Math.cos(altitude)*Math.cos(angle),Math.sin(altitude),Math.cos(altitude)*Math.sin(angle)]);
  }
}
directions.push([0,1,0]);

function weights(direction,azimuthStride=1,elevationStride=1) {
  const d=normalize(direction);
  if(d[1]<0)return[];
  const altitude=Math.asin(Math.min(1,d[1]))/(Math.PI/2)*elevationCount/elevationStride;
  const latitude=Math.min(elevationCount/elevationStride-1,Math.floor(altitude));
  const v=altitude-latitude;
  const azimuth=((Math.atan2(d[2],d[0])/(Math.PI*2)+1)%1)*azimuthCount/azimuthStride;
  const longitude=Math.floor(azimuth),u=azimuth-longitude;
  return [
    [latitude*elevationStride*azimuthCount+longitude*azimuthStride,(1-u)*(1-v)],
    [latitude*elevationStride*azimuthCount+((longitude+1)*azimuthStride)%azimuthCount,u*(1-v)],
    [latitude*elevationStride+elevationStride===elevationCount?directions.length-1:(latitude*elevationStride+elevationStride)*azimuthCount+longitude*azimuthStride,(1-u)*v],
    [latitude*elevationStride+elevationStride===elevationCount?directions.length-1:(latitude*elevationStride+elevationStride)*azimuthCount+((longitude+1)*azimuthStride)%azimuthCount,u*v],
  ];
}

export async function runSolarExperiment({bvh,probes,rays,maxTraceDistance,regions,yielding}) {
  const started=performance.now(),count=probes.length,transfer=new Float64Array(count*directions.length*12),hits=[];
  let hitCount=0,task=performance.now(),raysBefore=bvh.evidence().rays;
  for(let p=0;p<count;p++) {
    const row=[];hits.push(row);if(!probes[p].valid)continue;
    for(const ray of rays) {
      const hit=bvh.ray(probes[p].position,ray.direction,maxTraceDistance);
      if(!hit)continue;
      row.push({...hit,origin:hit.point.map((x,a)=>x+hit.normal[a]*.002-ray.direction[a]*.002),direction:ray.direction,weight:ray.weight});hitCount++;
    }
    for(let s=0;s<directions.length;s++) {
      const output=(p*directions.length+s)*12,light=directions[s];
      for(const hit of row) {
        const cosine=Math.max(0,dot(hit.normal,light));
        if(!cosine||bvh.ray(hit.origin,light,maxTraceDistance,.001,true))continue;
        accumulateL1(transfer,output,[...hit.albedo].map(x=>x*cosine/Math.PI),hit.direction,hit.weight);
      }
      if(performance.now()-task>6){await yielding();task=performance.now();}
    }
  }
  const bakeMs=performance.now()-started;
  const sample=(p,direction,illuminance=[1,1,1],azimuthStride=1,elevationStride=1)=>{
    const output=new Float64Array(12);
    for(const[s,weight]of weights(direction,azimuthStride,elevationStride))for(let k=0;k<12;k++)output[k]+=transfer[(p*directions.length+s)*12+k]*weight*illuminance[k%3];
    return output;
  };
  const normals=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];
  const references=[];
  for(let minute=7*60+7;minute<18*60;minute+=23) {
    const direction=coastalDaylight('2026-11-03',minute).direction;
    if(direction[1]<=0)continue;
    const exact=new Float64Array(count*12);
    for(let p=0;p<count;p++)for(const hit of hits[p]) {
      const cosine=Math.max(0,dot(hit.normal,direction));
      if(!cosine||bvh.ray(hit.origin,direction,maxTraceDistance,.001,true))continue;
      accumulateL1(exact,p*12,[...hit.albedo].map(x=>x*cosine/Math.PI),hit.direction,hit.weight);
      if(performance.now()-task>6){await yielding();task=performance.now();}
    }
    references.push({minute,direction,exact});
  }
  const controls=[];
  for(const[azimuthStride,elevationStride]of[[2,2],[1,2],[1,1]]) {
    const byRegion=[];
    for(let r=0;r<regions.length;r++) {
      let squared=0,referenceSquared=0,maxAbsolute=0,maxReference=0,samples=0;
      for(const reference of references)for(let p=r*8;p<(r+1)*8;p++) {
        const target=reference.exact.slice(p*12,p*12+12),candidate=sample(p,reference.direction,[1,1,1],azimuthStride,elevationStride);
        deringL1(target);deringL1(candidate);
        for(const n of normals) {
          const exact=evaluateL1(target,n),approx=evaluateL1(candidate,n);
          for(let c=0;c<3;c++){squared+=(approx[c]-exact[c])**2;referenceSquared+=exact[c]**2;maxAbsolute=Math.max(maxAbsolute,Math.abs(approx[c]-exact[c]));maxReference=Math.max(maxReference,exact[c]);samples++;}
        }
      }
      byRegion.push({id:regions[r].id,normalizedRms:Math.sqrt(squared/Math.max(referenceSquared,1e-30)),maxAbsolute,maxReference,samples});
    }
    controls.push({azimuths:azimuthCount/azimuthStride,elevationSteps:elevationCount/elevationStride,directions:(azimuthCount/azimuthStride)*(elevationCount/elevationStride)+1,byRegion});
  }
  const report={kind:'private single-bounce solar directional transfer prototype; no public admission',azimuthCount,elevationCount,directions:directions.length,probeCount:count,primaryHits:hitCount,bakeMs,referenceMs:performance.now()-started-bakeMs,totalMs:performance.now()-started,traceRays:bvh.evidence().rays-raysBefore,retainedBytes:transfer.byteLength,referenceDirections:references.map(({minute,direction})=>({minute,direction})),controls};
  globalThis.__solarPrototypeReport=report;
  globalThis.__solarPrototypeBytes=new Uint8Array(transfer.buffer);
  return{sample,report};
}
