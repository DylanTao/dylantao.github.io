import {accumulateL1,cosineDirections,dot,normalize,pointAttenuation,practicalEmission} from './light-trace-core.mjs';
const hash=x=>{x=Math.imul(x^(x>>>16),0x7feb352d);x=Math.imul(x^(x>>>15),0x846ca68b);return(x^(x>>>16))>>>0;};
function pathDirection(normal,seed){
 const u=(hash(seed)+.5)/4294967296,v=(hash(seed^0x9e3779b9)+.5)/4294967296,n=normalize(normal),t=normalize(Math.abs(n[1])<.9?[n[2],0,-n[0]]:[0,-n[2],n[1]]),b=[n[1]*t[2]-n[2]*t[1],n[2]*t[0]-n[0]*t[2],n[0]*t[1]-n[1]*t[0]],r=Math.sqrt(u),a=2*Math.PI*v;
 return n.map((x,k)=>x*Math.sqrt(1-u)+r*(Math.cos(a)*t[k]+Math.sin(a)*b[k]));
}
function basis(d){if(d[1]<0)return[0,0,1];const t=Math.max(0,d[1])**.45;return[t,1-t,0];}
const originAt=(hit,d)=>hit.point.map((x,a)=>x+hit.normal[a]*.002-d[a]*.002);
export async function runMultibounceExperiment({bvh,probes,rays,maxTraceDistance,regions,practicalSources,skyRaysPerHit,directional,yielding}){
 const started=performance.now(),sourceCount=3+practicalSources.length,count=probes.length,extra=new Float64Array(count*sourceCount*12),solar=new Float64Array(count*12),before=bvh.evidence(),stats={primary:0,second:0,third:0,backfaceAbsorbed:0,escaped:[0,0,0]};let task=performance.now();
 function sunAt(hit,origin,throughput,probe,direction,weight){if(!directional)return;const cosine=Math.max(0,dot(hit.normal,directional.direction));if(!cosine||bvh.ray(origin,directional.direction,maxTraceDistance,.001,true))return;accumulateL1(solar,probe*12,throughput.map((x,c)=>x*directional.illuminance[c]*cosine/Math.PI),direction,weight);}
 function lampsAt(hit,origin,throughput,probe,direction,weight){practicalSources.forEach((source,s)=>{if(source.region&&!hit.point.every((v,a)=>v>=source.region.min[a]&&v<=source.region.max[a]))return;const v=source.position.map((x,a)=>x-origin[a]),distance=Math.hypot(...v);if(distance<1e-5||(source.distance&&distance>=source.distance))return;const l=v.map(x=>x/distance),cosine=Math.max(0,dot(hit.normal,l)),emission=practicalEmission(l,source.emission);if(!cosine||!emission)return;const far=Math.max(0,distance-source.emitterRadius);if(far>.001&&bvh.ray(origin,l,far,.001,true))return;const scale=cosine*emission*pointAttenuation(distance,source.distance)/Math.PI;accumulateL1(extra,(probe*sourceCount+s+3)*12,throughput.map((x,c)=>x*source.color[c]*scale),direction,weight);});}
 for(let p=0;p<count;p++){
  if(!probes[p].valid)continue;
  for(let ri=0;ri<rays.length;ri++){
   const {direction,weight}=rays[ri],first=bvh.ray(probes[p].position,direction,maxTraceDistance);if(!first)continue;stats.primary++;if(first.backface){stats.backfaceAbsorbed++;continue;}
   const origin=originAt(first,direction),rho=[...first.albedo];sunAt(first,origin,rho,p,direction,weight);
   const samples=cosineDirections(first.normal,skyRaysPerHit);
   for(let si=0;si<samples.length;si++){
    let d=samples[si],o=origin,throughput=rho.map(x=>x/skyRaysPerHit);
    for(let bounce=2;bounce<=3;bounce++){
     const hit=bvh.ray(o,d,maxTraceDistance,.001);if(!hit)break;if(hit.backface){stats.backfaceAbsorbed++;break;}stats[bounce===2?'second':'third']++;
     throughput=throughput.map((x,c)=>x*hit.albedo[c]);o=originAt(hit,d);lampsAt(hit,o,throughput,p,direction,weight);sunAt(hit,o,throughput,p,direction,weight);
     const seed=Math.imul(p+1,73856093)^Math.imul(ri+1,19349663)^Math.imul(si+1,83492791)^Math.imul(bounce,2654435761);d=pathDirection(hit.normal,seed);
     const following=bvh.ray(o,d,maxTraceDistance,.001);if(!following){const boundary=basis(d);for(let s=0;s<3;s++)accumulateL1(extra,(p*sourceCount+s)*12,throughput.map(x=>x*boundary[s]),direction,weight);stats.escaped[bounce-1]++;break;}
     // The next loop recomputes the same hit so the estimator stays simple and independent of the primary collector.
    }
   }
   if(performance.now()-task>6){await yielding();task=performance.now();}
  }
 }
 const after=bvh.evidence(),report={scope:'Private three-diffuse-surface sky/practical plus exact-current-direction solar NEE experiment. No angular interpolation. Fixed deterministic independent deeper-bounce samples. The original direct sky and first practical bounce remain separate.',date:new Date().toISOString(),maxDiffuseSurfaces:3,skyRaysPerHit,probeCount:count,sourceCount,stats,bakeMs:performance.now()-started,extraBytes:extra.byteLength,solarBytes:solar.byteLength,extraTraceRays:after.rays-before.rays,regions:regions.map(r=>r.id),directional};
 globalThis.__multiPrototypeReport=report;
 return{extra,solar,report,mode:'all'};
}
