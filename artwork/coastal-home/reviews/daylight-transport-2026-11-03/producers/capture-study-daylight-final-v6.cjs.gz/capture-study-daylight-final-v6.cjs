const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const root = process.cwd(), q = __dirname, preset = process.argv[2];
if (!['2k', '4k', 'phone-webkit'].includes(preset)) throw Error('Select capture preset');
const phone = preset === 'phone-webkit';
const sdk = phone ? require(path.join(q, 'webkit-1.65-alpha-20261028/node_modules/@playwright/test')) : require('@playwright/test');
const { expect } = sdk, preview = path.join(q, 'daylight-checkpoint-v4'), built = path.join(preview, 'site/al-folio');
const server = JSON.parse(fs.readFileSync(path.join(preview, 'server.json'))), base = server.url;
const out = path.join(q, 'study-daylight-final-v6-' + preset);
if (fs.existsSync(out)) throw Error('Fresh evidence required');
fs.mkdirSync(out);
const hash = b => crypto.createHash('sha256').update(b).digest('hex'), errors = [], failed = [], responses = [], pending = [], rows = [];
const state = p => p.evaluate(() => document.querySelector('[data-home-desk-scene]').getSceneEvidence());
async function settle(p) {
  let prior;
  for (let i = 0; i < 100; i++) {
    const e = await state(p);
    if (prior && !e.traveling && Math.hypot(...e.camera.map((v, n) => v - prior[n])) < 1e-5) return e;
    prior = e.camera;
    await p.waitForTimeout(120);
  }
  throw Error('Camera did not settle');
}
(async () => {
  const browser = await sdk[phone ? 'webkit' : 'chromium'].launch({headless: true, ...(phone ? {} : {args: ['--use-angle=d3d11', '--ignore-gpu-blocklist']})});
  try {
    const viewport = phone ? {width: 390, height: 1000} : preset === '4k' ? {width: 3840, height: 2160} : {width: 2560, height: 1440};
    const context = await browser.newContext({...phone ? sdk.devices['iPhone 13'] : {}, viewport, deviceScaleFactor: 1, timezoneId: 'America/Los_Angeles', colorScheme: 'light', reducedMotion: 'reduce'});
    const p = await context.newPage(); p.setDefaultTimeout(45000);
    // Observe exact delivered streaming bytes separately from DevTools' body
    // retention. Return the original response untouched; clone three fixed
    // streams only. No substitution and no performance claim from this run.
    await p.addInitScript(() => {
      const fetch = window.fetch.bind(window);
      window.__daylightStreamBodies = [];
      window.fetch = async (...args) => {
        const response = await fetch(...args);
        if (/\/(?:(?:home-shell|coast)\.glb|static-light-field\.json)(?:\?|$)/.test(response.url)) {
          const row = {url: response.url, status: response.status};
          window.__daylightStreamBodies.push(row);
          response.clone().arrayBuffer().then(async bytes => {
            row.bytes = bytes.byteLength;
            row.sha256 = [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(x => x.toString(16).padStart(2,'0')).join('');
          }).catch(e => row.error = String(e));
        }
        return response;
      };
    });
    const protocol = [];
    if (!phone) {
      const cdp = await context.newCDPSession(p);
      await cdp.send('Network.enable');
      const streamIds = new Set();
      for (const event of ['requestWillBeSent','responseReceived','loadingFailed','loadingFinished']) cdp.on('Network.'+event, data => {
        if (event === 'requestWillBeSent' && /\/(?:(?:home-shell|coast)\.glb|static-light-field\.json)(?:\?|$)/.test(data.request.url)) streamIds.add(data.requestId);
        if (streamIds.has(data.requestId)) protocol.push({event,data});
      });
    }

    await p.clock.setFixedTime(new Date('2026-10-23T14:00:00-07:00'));
    await p.route(/https:\/\/(?:analytics\.google\.com|www\.google-analytics\.com|www\.googletagmanager\.com|plausible\.io)\//, r => r.fulfill({status: 204, body: ''}));
    const modules = JSON.parse(fs.readFileSync(path.join(built, 'assets/js/module-build.json'))).modules;
    expect(Object.keys(modules)).toHaveLength(192);
    for (const [rel, row] of Object.entries(modules)) {
      expect(hash(fs.readFileSync(path.join('C:/dev/dqa1103', rel)).toString().replaceAll('\r\n', '\n'))).toBe(row.sourceSha256);
      expect(hash(fs.readFileSync(path.join(built, rel)))).toBe(row.outputSha256);
    }
    p.on('pageerror', e => errors.push(e.message));
    p.on('console', m => {if (m.type() === 'error') errors.push(m.text());});
    p.on('requestfailed', r => failed.push({url: r.url(), failure: r.failure()}));
    p.on('response', r => {
      if (!r.url().startsWith(base) || !/\.(?:mjs|glb|json)(?:\?|$)/.test(r.url())) return;
      pending.push((async () => {
        try {
          const body = await r.body(), rel = decodeURIComponent(new URL(r.url()).pathname.slice(new URL(base).pathname.length));
          responses.push({path: rel, status: r.status(), bytes: body.length, sha256: hash(body), exact: body.equals(fs.readFileSync(path.join(built, rel))), owner: r.headers()['x-sirui-preview']});
        } catch (e) { responses.push({url: r.url(), error: String(e)}); }
      })());
    });
    const click = async locator => phone ? locator.tap() : locator.click();
    const theme = async mode => {await click(p.locator('[data-theme-toggle]:visible').first()); await click(p.locator(`[data-theme-mode-option="${mode}"]:visible`).first()); await click(p.locator('[data-theme-toggle]:visible').first());};
    await p.goto(base + (phone ? '' : '?quality=high&resolution=fixed'), {waitUntil: 'domcontentloaded'});
    await p.evaluate(() => document.fonts.ready);
    await theme('noon');
    await click(p.locator('[data-home-desk-mode="3d"]'));
    const scene = p.locator('[data-home-desk-scene]'), canvas = scene.locator('canvas:not(.home-world-sketch)');
    await scene.scrollIntoViewIfNeeded();
    await expect(scene).toHaveAttribute('data-scene-state', 'ready', {timeout: 180000});
    for (const mode of preset === '4k' ? ['noon'] : ['noon', 'evening']) {
      if (mode === 'evening') {await click(p.locator('[data-world-exit]')); await theme(mode);}
      await click(p.locator('[data-world-places]>summary'));
      await click(p.locator('[data-world-destination="study"]'));
      expect((await settle(p)).currentRoom).toBe('study');
      const embed = await state(p);
      await canvas.screenshot({path: path.join(out, mode + '-embed.png')});
      await click(p.locator('[data-world-fullscreen]'));
      for (const [label, dx, dy] of [['default', 0, 0], ...preset === '4k' ? [] : [['side', phone ? -60 : -140, phone ? 30 : 60]]]) {
        if (dx || dy) {
          const b = await canvas.boundingBox(), x = b.x + b.width * .5, y = b.y + b.height * .48;
          await p.mouse.move(x, y); await p.mouse.down(); await p.mouse.move(x + dx, y + dy, {steps: 16}); await p.mouse.up();
        }
        const e = await settle(p);
        expect(e.simulation.lightField.cacheHit).toBe(true);
        const image = await canvas.screenshot({path: path.join(out, mode + '-' + label + '-canvas.png')});
        expect(image.length).toBeGreaterThan(phone ? 30000 : 150000);
        const backend = await canvas.evaluate(c => {const g = c.getContext('webgl2'), ext = g?.getExtension('WEBGL_debug_renderer_info'); return g ? {renderer: g.getParameter(ext?.UNMASKED_RENDERER_WEBGL || g.RENDERER), buffer: [g.drawingBufferWidth, g.drawingBufferHeight]} : null;});
        rows.push({mode, label, embed, evidence: e, backend, pngSha256: hash(image)});
        console.log(JSON.stringify({preset, mode, label, backend}));
      }
    }
    await Promise.all(pending);
    const streamed = await p.evaluate(() => window.__daylightStreamBodies);
    for (const row of streamed) {
      const rel = decodeURIComponent(new URL(row.url).pathname.slice(new URL(base).pathname.length));
      const actual = fs.readFileSync(path.join(built, rel));
      expect(row.status).toBe(200); expect(row.bytes).toBe(actual.length); expect(row.sha256).toBe(hash(actual)); expect(row.error).toBeUndefined();
    }
    const streamDelivered = url => streamed.some(row => row.url === url && row.status === 200 && row.sha256 && !row.error && rows.every(view => /static-light-field\.json/.test(url) ? view.evidence.simulation.lightField.cacheHit && view.evidence.loading.lightCache.url === url && view.evidence.loading.lightCache.state === 'restored' : view.evidence.loading.models.some(model => model.asset === new URL(url).pathname.split('/').pop() && model.bytes === row.bytes && model.parsedMilliseconds > 0)));
    const qualifiedProtocolLoss = failed.filter(row => row.failure?.errorText === 'net::ERR_ABORTED' && streamDelivered(row.url));
    const unknownFailed = failed.filter(row => !qualifiedProtocolLoss.includes(row));
    const unknownBodies = responses.filter(row => row.error ? !streamDelivered(row.url) : !row.exact || row.status >= 400 || row.owner !== server.header);

    fs.writeFileSync(path.join(out, 'CAPTURE.json'), JSON.stringify({scope: 'Complete daylight production candidate: selected sky/ground transport, bounded interior exposure, official v5 cache and unchanged public native models; actual deployment CSS postprocessing applied. Public theme, Rooms and fullscreen controls with trusted input; fixed Date, otherwise normal animation clocks. Native desktop high/fixed detail is disclosed; phone WebKit uses its automatic tier. No Lab, Pause or model/module response substitutions. This is visual evidence, not frame-rate or physical-phone acceptance. Three fixed streamed resources are cloned solely to hash their actual delivered bytes; the original responses are returned untouched. DevTools body-loss/abort diagnostics remain recorded and qualify only when independent exact bytes and actual parsed-model completion both pass. This evidence does not measure startup or frame speed. Same date, clock, actual public controls, camera and output sizes as the retained old-production daylight baseline. This is the selected candidate, with no runtime module or model substitution.', at: new Date().toISOString(), preset, server, browserVersion: browser.version(), rows, errors, failed, qualifiedProtocolLoss, streamed, protocol, responses}, null, 2) + '\n');
    expect(errors).toEqual([]); expect(unknownFailed).toEqual([]);
    expect(unknownBodies).toEqual([]);
    await context.close();
  } finally {await browser.close();}
})().catch(e => {fs.writeFileSync(path.join(out, 'FAILURE.json'), JSON.stringify({error: String(e), stack: e.stack, rows, errors, failed, responses}, null, 2)); console.error(e); process.exitCode = 1;});
