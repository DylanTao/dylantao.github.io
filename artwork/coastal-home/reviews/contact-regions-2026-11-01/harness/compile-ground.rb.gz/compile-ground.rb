require 'jekyll'
require_relative '../../../_plugins/site_module_assets'
require 'fileutils'
root=Dir.pwd
q=File.dirname(__FILE__)
rel='assets/js/home-scene/wildlife-ground-contact.mjs'
source=File.read(File.join(root,rel),encoding:'UTF-8')
compiled=SiruiSite::ModuleAssets.compile(source)
File.binwrite(File.join(q,'compiled/wildlife-ground-contact.mjs'),compiled)
receipt=JSON.parse(File.read(File.join(q,'site/al-folio/assets/js/module-build.json')))
receipt['modules'][rel]={'sourceSha256'=>Digest::SHA256.hexdigest(source.gsub("\r\n","\n")),'outputSha256'=>Digest::SHA256.hexdigest(compiled),'bytes'=>compiled.bytesize}
File.binwrite(File.join(q,'compiled/module-build-candidate.json'),JSON.generate(receipt)+"\n")
puts JSON.pretty_generate(receipt['modules'][rel])
