import crypto from "node:crypto";
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { THREE, loadNativeModel } from "file:///C:/dev/site-takeover-worktrees/contact-cpu-next-20261101/test/helpers/coastal-native-avatar.mjs";
import { nativeGeometry } from "file:///C:/dev/site-takeover-worktrees/contact-cpu-next-20261101/test/helpers/coastal-native-geometry.mjs";
const {createWildlife}=await import(process.argv.includes("--baseline")?new URL("./baseline-source/assets/js/home-scene/wildlife.mjs",import.meta.url).href:"file:///C:/dev/site-takeover-worktrees/contact-cpu-next-20261101/assets/js/home-scene/wildlife.mjs");
import { createGroundPatch } from "./baseline-source/assets/js/home-scene/wildlife-ground-contact.mjs";
import { rabbitActing, rabbitSchedule } from "file:///C:/dev/site-takeover-worktrees/contact-cpu-next-20261101/assets/js/home-scene/wildlife-motion.mjs";

const models = new URL("file:///C:/dev/site-takeover-worktrees/contact-cpu-next-20261101/assets/models/home/");
const config = JSON.parse(fs.readFileSync(new URL("manifest.json", models)));
const perches = JSON.parse(fs.readFileSync(new URL("wildlife-perch-support.json", models)));
const species = ["BrushRabbit", "CaliforniaSeaLion", "HarborSeal", "Raccoon", "WesternGull", "Sandpiper", "BrownPelican", "BrandtsCormorant"];
const masters = await Promise.all(species.map((name) => loadNativeModel(name + ".glb", models)));
async function world(manifest, grounds) {
  const scene = new THREE.Group(), environment = new THREE.Group(); scene.add(environment, ...grounds);
  const wildlife = createWildlife(environment, manifest, {
    createModelLoader: () => ({ loader: { loadAsync: async (url) => masters[species.indexOf(url.split("/").at(-1).replace(".glb", ""))] }, decoder: { dispose() {} } }),
    loadPerchSupport: async () => perches,
  });
  for (let i = 0; i < 100 && !wildlife.evidence().modelsReady; i++) await new Promise(setImmediate);
  assert.equal(wildlife.evidence().modelsReady, true);
  wildlife.captureGround(grounds); scene.updateMatrixWorld(true);
  const paws = [0, 1].map((index) => {
    const list=[];
    scene.traverse((mesh) => {
      if (!mesh.isSkinnedMesh || mesh.userData.action?.id !== `rabbit-${index}`) return;
      const skin=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight;
      for(let i=0;i<skin.count;i++) {
        const names=new Map();
        for(let k=0;k<4;k++){const name=mesh.skeleton.bones[skin.getComponent(i,k)].name;names.set(name,(names.get(name)||0)+weights.getComponent(i,k));}
        for(const [name,weight]of names)if(/^(Front|Hind)Paw[LR]$/.test(name)&&weight>=.999)list.push({mesh,index:i,name});
      }
    });
    assert.ok(list.length>1000);return list;
  });
  const patches=["rabbitWest","rabbitEast"].map((key)=>{const p=createGroundPatch(manifest.terrain.habitats[key].path,1);p.capture(grounds);assert.ok(p.evidence().ready);return p});
  function measure(index) {
    scene.updateMatrixWorld(true);
    for(const mesh of new Set(paws[index].map(p=>p.mesh)))mesh.skeleton.update();
    const feet=Object.fromEntries(["FrontPawL","FrontPawR","HindPawL","HindPawR"].map(n=>[n,{minimum:Infinity,missing:0,points:[]} ]));
    for(const p of paws[index]){
      const v=p.mesh.getVertexPosition(p.index,new THREE.Vector3()).applyMatrix4(p.mesh.matrixWorld),hit=patches[index].sample(v.x,v.z,v.y+.5),foot=feet[p.name];
      foot.points.push(v.toArray());if(!hit)foot.missing++;else foot.minimum=Math.min(foot.minimum,v.y-hit.height);
    }
    return feet;
  }
  return {scene,wildlife,paws,measure};
}

const grounds=await Promise.all([nativeGeometry("home-shell.glb",models),nativeGeometry("coast.glb",models)]),manifest=structuredClone(config);assert.deepEqual(manifest.terrain.habitats.seaLion.path[0],[-9.7,-6.6382,-14.8115]);
const runtime=await world(manifest,grounds),subjects=[],patches={};for(const key of ["seaLion","seal"]){patches[key]=createGroundPatch(manifest.terrain.habitats[key].path,3);patches[key].capture(grounds);for(let index=0;index<3;index++){const id=key+"-"+index,meshes=[];runtime.scene.traverse(o=>{if(o.isSkinnedMesh&&o.userData.action?.id===id)meshes.push(o)});let group=meshes[0];while(group.parent&&group.parent.name!=="Coastal neighbours")group=group.parent;subjects.push({key,index,id,group,meshes})}}
const digest=b=>crypto.createHash("sha256").update(JSON.stringify(b)).digest("hex"),rows=[],otherRows=[];
for(let time=0;time<=180;time+=.5){
 runtime.wildlife.update(time,"noon",{force:true});runtime.scene.updateMatrixWorld(true);const evidence=runtime.wildlife.evidence();
 for(const subject of subjects){
  const {key,index,id,group,meshes}=subject,byPart={},all=[];let minimum=null,missing=0,total=0;
  for(const mesh of meshes){const skin=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight;for(let i=0;i<skin.count;i++){
   const v=mesh.getVertexPosition(i,new THREE.Vector3()).applyMatrix4(mesh.matrixWorld),hit=patches[key].sample(v.x,v.z,v.y+.5);all.push(...v.toArray());total++;if(!hit){missing++;continue}let dominant=0;for(let k=1;k<4;k++)if(weights.getComponent(i,k)>weights.getComponent(i,dominant))dominant=k;const bone=mesh.skeleton.bones[skin.getComponent(i,dominant)].name,part=byPart[bone]||(byPart[bone]={vertices:0,minimum:Infinity});part.vertices++;const gap=v.y-hit.height;part.minimum=Math.min(part.minimum,gap);if(!minimum||gap<minimum.gap)minimum={gap,mesh:mesh.name,vertex:i,bone,point:v.toArray(),support:{height:hit.height,mesh:hit.mesh,triangle:hit.triangle,visible:hit.visible,normal:hit.normal.toArray()}};
  }}
  const record=evidence.contacts.filter(r=>r.habitat===key)[index];rows.push({time,id,state:group.userData.state,rootPosition:group.position.toArray(),rootQuaternion:group.quaternion.toArray(),total,missing,minimum,byPart,worldVerticesSha256:digest(all),surfaceContact:record.surfaceContact||null});
 }
 const others={};runtime.scene.traverse(o=>{const id=o.userData.action?.id;if(!o.isSkinnedMesh||!id||/^(seaLion|seal)-/.test(id)||others[id])return;others[id]=o.skeleton.bones.map(b=>[b.name,...b.matrixWorld.elements])});otherRows.push({time,sha256:digest(others),count:Object.keys(others).length});
}
const label=process.argv.includes("--reference")?"reference":process.argv.includes("--baseline")?"baseline":"candidate";fs.writeFileSync(new URL("./pinniped-preservation-"+label+".json",import.meta.url),JSON.stringify({scope:"Frozen published321a source/model/cache. Baseline is the unmodified 321a dependency graph; candidate changes only ground-region keying and immutable plane tolerance. Every actual deformed vertex is independently measured; the canonical seaLion0 authoring point is asserted, not changed.",proposedPoint:manifest.terrain.habitats.seaLion.path[0],rows,otherRows},null,2));
console.log(JSON.stringify({label,rows:rows.length,times:otherRows.length,minimum:Math.min(...rows.map(r=>r.minimum.gap)),unsupported:rows.filter(r=>r.surfaceContact&&!r.surfaceContact.supported).map(r=>({id:r.id,time:r.time,state:r.state,contact:r.surfaceContact})),worst:rows.toSorted((a,b)=>a.minimum.gap-b.minimum.gap).slice(0,3).map(r=>({id:r.id,time:r.time,state:r.state,minimum:r.minimum}))}));
