import crypto from "node:crypto";
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { THREE, loadNativeModel } from "file:///C:/dev/site-takeover-worktrees/contact-cpu-next-20261101/test/helpers/coastal-native-avatar.mjs";
import { nativeGeometry } from "file:///C:/dev/site-takeover-worktrees/contact-cpu-next-20261101/test/helpers/coastal-native-geometry.mjs";
const {createWildlife}=await import(process.argv.includes("--baseline")?new URL("./baseline-source/assets/js/home-scene/wildlife.mjs",import.meta.url).href:"file:///C:/dev/site-takeover-worktrees/contact-cpu-next-20261101/assets/js/home-scene/wildlife.mjs");
import { createGroundPatch } from "./baseline-source/assets/js/home-scene/wildlife-ground-contact.mjs";
import { rabbitActing, rabbitSchedule } from "file:///C:/dev/site-takeover-worktrees/contact-cpu-next-20261101/assets/js/home-scene/wildlife-motion.mjs";

const models = new URL("file:///C:/dev/site-takeover-worktrees/contact-cpu-next-20261101/assets/models/home/");
const config = JSON.parse(fs.readFileSync(new URL("manifest.json", models)));
const perches = JSON.parse(fs.readFileSync(new URL("wildlife-perch-support.json", models)));
const species = ["BrushRabbit", "CaliforniaSeaLion", "HarborSeal", "Raccoon", "WesternGull", "Sandpiper", "BrownPelican", "BrandtsCormorant"];
const masters = await Promise.all(species.map((name) => loadNativeModel(name + ".glb", models)));
async function world(manifest, grounds) {
  const scene = new THREE.Group(), environment = new THREE.Group(); scene.add(environment, ...grounds);
  const wildlife = createWildlife(environment, manifest, {
    createModelLoader: () => ({ loader: { loadAsync: async (url) => masters[species.indexOf(url.split("/").at(-1).replace(".glb", ""))] }, decoder: { dispose() {} } }),
    loadPerchSupport: async () => perches,
  });
  for (let i = 0; i < 100 && !wildlife.evidence().modelsReady; i++) await new Promise(setImmediate);
  assert.equal(wildlife.evidence().modelsReady, true);
  wildlife.captureGround(grounds); scene.updateMatrixWorld(true);
  const paws = [0, 1].map((index) => {
    const list=[];
    scene.traverse((mesh) => {
      if (!mesh.isSkinnedMesh || mesh.userData.action?.id !== `rabbit-${index}`) return;
      const skin=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight;
      for(let i=0;i<skin.count;i++) {
        const names=new Map();
        for(let k=0;k<4;k++){const name=mesh.skeleton.bones[skin.getComponent(i,k)].name;names.set(name,(names.get(name)||0)+weights.getComponent(i,k));}
        for(const [name,weight]of names)if(/^(Front|Hind)Paw[LR]$/.test(name)&&weight>=.999)list.push({mesh,index:i,name});
      }
    });
    assert.ok(list.length>1000);return list;
  });
  const patches=["rabbitWest","rabbitEast"].map((key)=>{const p=createGroundPatch(manifest.terrain.habitats[key].path,1);p.capture(grounds);assert.ok(p.evidence().ready);return p});
  function measure(index) {
    scene.updateMatrixWorld(true);
    for(const mesh of new Set(paws[index].map(p=>p.mesh)))mesh.skeleton.update();
    const feet=Object.fromEntries(["FrontPawL","FrontPawR","HindPawL","HindPawR"].map(n=>[n,{minimum:Infinity,missing:0,points:[]} ]));
    for(const p of paws[index]){
      const v=p.mesh.getVertexPosition(p.index,new THREE.Vector3()).applyMatrix4(p.mesh.matrixWorld),hit=patches[index].sample(v.x,v.z,v.y+.5),foot=feet[p.name];
      foot.points.push(v.toArray());if(!hit)foot.missing++;else foot.minimum=Math.min(foot.minimum,v.y-hit.height);
    }
    return feet;
  }
  return {scene,wildlife,paws,measure};
}


const {createHabitatRoute,raccoonMotion}=await import('file:///C:/dev/site-takeover-worktrees/contact-cpu-next-20261101/assets/js/home-scene/wildlife-neighbor-motion.mjs');
const grounds=await Promise.all([nativeGeometry('home-shell.glb',models),nativeGeometry('coast.glb',models)]);assert.deepEqual(config.terrain.habitats.seaLion.path[0],[-9.7,-6.6382,-14.8115]);
const route=createHabitatRoute(config.terrain.habitats.raccoon.path.map(([x,y,z])=>[x,y-.025,z])),label=process.argv.includes('--baseline')?'baseline':'candidate',rows=[],poses=[];
function maxDistance(a,b,scale=1){let maximum=0,vertex=0;for(let i=0;i<a.length;i+=3){const distance=Math.hypot(a[i]-b[i],a[i+1]-b[i+1],a[i+2]-b[i+2])*scale;if(distance>maximum){maximum=distance;vertex=i/3}}return{maximum,vertex}}
function maxSecond(a,b,c,scale){let maximum=0,vertex=0;for(let i=0;i<a.length;i+=3){const distance=Math.hypot(a[i]+c[i]-2*b[i],a[i+1]+c[i+1]-2*b[i+1],a[i+2]+c[i+2]-2*b[i+2])*scale;if(distance>maximum){maximum=distance;vertex=i/3}}return{maximum,vertex}}
for(const scenario of ['sleep','wake','dawn']){
 const runtime=await world(structuredClone(config),grounds),meshes=[];runtime.scene.traverse(o=>{if(o.isSkinnedMesh&&o.userData.action?.id==='raccoon-0')meshes.push(o)});const vertices=meshes.flatMap(m=>Array.from({length:m.geometry.attributes.position.count},(_,i)=>({mesh:m.name,index:i}))),cache=new Map(),events=new Map();
 runtime.wildlife.update(0,'noon',{force:true});if(scenario!=='sleep')runtime.wildlife.update(0,'evening',{force:true});if(scenario==='dawn'){runtime.wildlife.update(95,'evening',{force:true});runtime.wildlife.update(95,'noon',{force:true})}
 const palette=scenario==='wake'?'evening':'noon',start=scenario==='dawn'?95:0,finish=scenario==='sleep'?30:scenario==='wake'?30:125;
 const acting=t=>raccoonMotion(t,palette==='evening',route.length,scenario==='sleep'?{night:false,nightStart:-2e4,dayStart:-1e4}:scenario==='wake'?{night:true,nightStart:0,dayStart:-1e4}:{night:false,nightStart:0,dayStart:95});
 const add=(time,kind)=>{if(time<=start+1e-4||time>=finish-1e-4)return;const key=time.toFixed(8),r=events.get(key);if(r)r.kinds.push(kind);else events.set(key,{time,kinds:[kind]})};
 for(const t of [0,.6,1,2.2,3,3.4,3.8,5.6,5.8,6.6,7.2,14.4167,18.8007,23.5357])if(scenario!=='dawn')add(t,'retained pose/mode witness');
 const signals=(t)=>{const p=acting(t);return{sleepHalf:p.sleep-.5,curlStart:p.curl,curlEnd:p.curl-1}};let previous=signals(start);
 for(let i=1;i<=(finish-start)*100;i++){const t=start+i*.01,current=signals(t);for(const n of Object.keys(current)){const a=previous[n],b=current[n];if(a*b<0){let lo=t-.01,hi=t;for(let j=0;j<32;j++){const m=(lo+hi)/2;if(Math.sign(signals(m)[n])===Math.sign(a))lo=m;else hi=m}add((lo+hi)/2,n)}else if(a===0&&b!==0)add(t-.01,n+':leaves bound');else if(a!==0&&b===0)add(t,n+':reaches bound')}previous=current}
 // Refine measured active lift/support and discrete sole witness transfers from
 // the original half-second survey. These finite events add controls; they are
 // not a proof of all-time dynamics.
 const dense=JSON.parse(fs.readFileSync(new URL('./raccoon-dense-'+(scenario==='dawn'?'dawn-':'')+label+'.json',import.meta.url))).rows.filter(r=>r.night===(scenario==='wake')&&r.time>=start&&r.time<=finish),key=r=>r.bodyContact?.evaluated&&r.bodyContact.lift>1e-12?JSON.stringify(r.bodyContact.witness):'none';
 const fitAt=t=>{runtime.wildlife.update(t,palette,{force:true});return runtime.wildlife.evidence().raccoon.bodyContact};
 for(let i=1;i<dense.length;i++){const a=dense[i-1],b=dense[i],from=key(a);if(from!==key(b)){let lo=a.time,hi=b.time;for(let j=0;j<25;j++){const m=(lo+hi)/2,f=fitAt(m),k=f?.evaluated&&f.lift>1e-12?JSON.stringify(f.witness):'none';if(k===from)lo=m;else hi=m}add((lo+hi)/2,'measured torso support-feature transfer')}}
 let checks=0,snapshots=0;
 function snapshot(t){const k=t.toFixed(10);if(cache.has(k))return cache.get(k);runtime.wildlife.update(t,palette);meshes[0].onBeforeRender();runtime.scene.updateMatrixWorld(true);const points=new Float64Array(vertices.length*3);let n=0;const p=new THREE.Vector3();for(const mesh of meshes)for(let i=0;i<mesh.geometry.attributes.position.count;i++){mesh.getVertexPosition(i,p).applyMatrix4(mesh.matrixWorld);points[n++]=p.x;points[n++]=p.y;points[n++]=p.z}const sha256=crypto.createHash('sha256').update(Buffer.from(points.buffer)).digest('hex'),record={time:t,sha256,points,evidence:runtime.wildlife.evidence().raccoon};if(snapshots++%25===0){runtime.wildlife.update(t,palette,{force:true});runtime.scene.updateMatrixWorld(true);const control=new Float64Array(points.length);let n=0;for(const mesh of meshes)for(let i=0;i<mesh.geometry.attributes.position.count;i++){mesh.getVertexPosition(i,p).applyMatrix4(mesh.matrixWorld);control[n++]=p.x;control[n++]=p.y;control[n++]=p.z}assert.equal(crypto.createHash('sha256').update(Buffer.from(control.buffer)).digest('hex'),sha256,'actual draw catch-up equals full forced pose');checks++}cache.set(k,record);if(cache.size>60)cache.delete(cache.keys().next().value);poses.push({scenario,palette,time:t,sha256});return record}
 const extract=(a,i)=>Array.from(a.slice(i*3,i*3+3));

 const frameRows=[];
 for(const hz of [30,60]){const first=scenario==='dawn'?95:0,last=scenario==='sleep'?12:scenario==='wake'?8:102,window=[];
  for(let tick=0;tick<=Math.round((last-first)*hz);tick++){const t=first+tick/hz,s=snapshot(t);window.push(s);if(window.length>3)window.shift();if(window.length===3){const [a,b,c]=window,v=maxDistance(b.points,c.points,hz),dv=maxSecond(a.points,b.points,c.points,hz);frameRows.push({scenario,hz,time:t,maximumVelocityMps:v.maximum,velocityWitness:vertices[v.vertex],maximumVelocityDifferenceMps:dv.maximum,changeWitness:vertices[dv.vertex],state:s.evidence.state,lift:s.evidence.bodyContact?.lift??null,bodyFitResolved:s.evidence.bodyContact?.supportResolved??null})}}
 }
 rows.push(...frameRows);continue;
 for(const event of [...events.values()].sort((a,b)=>a.time-b.time)){
  const t=event.time,h=1e-5,a=snapshot(t-h),b=snapshot(t+h),motion=maxDistance(a.points,b.points),vh=1e-4,left=snapshot(t-vh),centre=snapshot(t),right=snapshot(t+vh),velocity=maxSecond(left.points,centre.points,right.points,1/vh),cadences=[];
  for(const hz of [30,60]){const samples=Array.from({length:7},(_,i)=>snapshot(t+(i-3)/hz)),steps=[],changes=[];for(let i=1;i<samples.length;i++){const x=maxDistance(samples[i-1].points,samples[i].points,hz);steps.push({from:samples[i-1].time,to:samples[i].time,speed:x.maximum,witness:vertices[x.vertex]})}for(let i=1;i<samples.length-1;i++){const x=maxSecond(samples[i-1].points,samples[i].points,samples[i+1].points,hz);changes.push({at:samples[i].time,velocityDifference:x.maximum,witness:vertices[x.vertex]})}cadences.push({hz,samples:samples.map(s=>({time:s.time,sha256:s.sha256,state:s.evidence.state,lift:s.evidence.bodyContact?.lift??null})),steps,changes})}
  rows.push({scenario,time:t,kinds:event.kinds,vertices:vertices.length,forcedChecksSoFar:checks,microstep:{h,maximum:motion.maximum,witness:vertices[motion.vertex],points:[extract(a.points,motion.vertex),extract(b.points,motion.vertex)]},velocity:{h:vh,maximum:velocity.maximum,witness:vertices[velocity.vertex],points:[extract(left.points,velocity.vertex),extract(centre.points,velocity.vertex),extract(right.points,velocity.vertex)]},cadences});
 }
 console.log(JSON.stringify({scenario,events:events.size,checks,poses:snapshots}));
}
fs.writeFileSync(new URL('./raccoon-frame-trajectory-'+label+'.json',import.meta.url),JSON.stringify({scope:'Exact delivered all-7024-vertex active-time paths through finite curled/sleep/wake/return support events. Real actor onBeforeRender catch-up with periodic forced-pose hash checks. Microsteps and 30/60Hz trajectories are numeric continuity controls, not browser FPS or a physical phone claim.',label,rows,poses},null,2));console.log(JSON.stringify({label,frames:rows.length,poses:poses.length,maximumVelocityMps:Math.max(...rows.map(r=>r.maximumVelocityMps)),maximumVelocityDifferenceMps:Math.max(...rows.map(r=>r.maximumVelocityDifferenceMps)),worst:rows.toSorted((a,b)=>b.maximumVelocityDifferenceMps-a.maximumVelocityDifferenceMps).slice(0,6)}));
