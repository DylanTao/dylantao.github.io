﻿from pathlib import Path
import unittest,sys
root=Path('\\\\?\\'+str(Path.cwd()))
suite=unittest.defaultTestLoader.discover(str(root/'test'),pattern='test_*.py')
result=unittest.TextTestRunner(verbosity=1).run(suite)
sys.exit(not result.wasSuccessful())
