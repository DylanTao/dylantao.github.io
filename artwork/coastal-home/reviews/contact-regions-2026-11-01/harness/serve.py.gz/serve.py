﻿from pathlib import Path
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from urllib.parse import urlsplit, unquote
import os,socket,mimetypes,json
q=Path(__file__).parent;site=(q/'site').resolve()
class Handler(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_HEAD(self):self.reply(False)
 def do_GET(self):self.reply(True)
 def reply(self,includeBody):
  cookie=SimpleCookie();cookie.load(self.headers.get('Cookie',''));variant=cookie.get('contact_variant');variant=variant.value if variant and variant.value in ['baseline','candidate'] else 'candidate'
  name=unquote(urlsplit(self.path).path).lstrip('/');p=(site/name).resolve()
  if p.is_dir():p=p/'index.html'
  if site not in p.parents or not p.is_file():self.send_error(404);return
  if variant=='candidate' and name=='al-folio/assets/js/home-scene/wildlife-ground-contact.mjs':p=q/'compiled/wildlife-ground-contact.mjs'
  if variant=='candidate' and name=='al-folio/assets/js/module-build.json':p=q/'compiled/module-build-candidate.json'
  body=p.read_bytes();self.send_response(200);self.send_header('Content-Type',mimetypes.guess_type(p.name)[0] or 'application/octet-stream');self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store');self.send_header('X-Visual-Owner',f'interior-finish/contactCPU4197/{os.getpid()}');self.send_header('X-Visual-Variant',variant);self.end_headers()
  if includeBody:self.wfile.write(body)
class Server(ThreadingHTTPServer):
 allow_reuse_address=False
 request_queue_size=128
 daemon_threads=True
 def server_bind(self):
  if hasattr(socket,'SO_EXCLUSIVEADDRUSE'):self.socket.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
  super().server_bind()
server=Server(('127.0.0.1',4197),Handler);print(json.dumps({'pid':os.getpid(),'port':4197,'exclusive':True,'backlog':128,'root':str(site)}),flush=True);server.serve_forever()
