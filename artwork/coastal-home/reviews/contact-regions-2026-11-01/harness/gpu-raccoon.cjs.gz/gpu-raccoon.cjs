const fs=require('node:fs'),path=require('node:path');
const {chromium,expect}=require('C:/dev/dylantao.github.io/node_modules/@playwright/test');
const {preparePage,collectRuntimeErrors}=require('../../../test/visual/helpers.js');
const q=__dirname;
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
 try{
  const context=await browser.newContext({viewport:{width:2560,height:1440},deviceScaleFactor:1,reducedMotion:'no-preference'}),page=await context.newPage(),errors=collectRuntimeErrors(page);
  await preparePage(page,'light');
  await page.goto('http://127.0.0.1:4197/al-folio/?scene-lab=1&quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});const inventory=JSON.parse(fs.readFileSync(path.join(q,'SERVED-BINDING.json'))).variants.find(r=>r.variant==='candidate'),bindings=[];for(const expected of inventory.files){const r=await page.request.get('http://127.0.0.1:4197/al-folio/'+expected.path),body=await r.body();expect(r.status()).toBe(200);expect(r.headers()['x-visual-owner']).toBe(expected.owner);expect(r.headers()['x-visual-variant']).toBe('candidate');expect(body.length).toBe(expected.bytes);expect(require('node:crypto').createHash('sha256').update(body).digest('hex')).toBe(expected.sha256);bindings.push(expected)}
  await page.locator('[data-theme-toggle]:visible').first().click();await page.locator('[data-theme-mode-option="noon"]:visible').first().click();await page.locator('[data-theme-toggle]:visible').first().click();await page.locator('[data-home-desk-mode="3d"]').click();const host=page.locator('[data-home-desk-scene]'),canvas=host.locator('canvas');
  await host.scrollIntoViewIfNeeded();await expect(host).toHaveAttribute('data-scene-state','ready',{timeout:240000});for(let i=0;i<28;i++){await canvas.press('n');if(await host.evaluate(e=>e.getSceneEvidence().inspection?.id)==='raccoon-0')break}
  await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().inspection?.id)).toBe('raccoon-0');
  const previous=await host.evaluate(async(e)=>{
   const THREE=await import(new URL('assets/js/three.module.min.js',document.baseURI));
   const probe=window.__raccoonGPU={saved:[],rows:[],seen:new Set()};
   e.labScene.scene.traverse(mesh=>{
    if(!mesh.isSkinnedMesh||! /^raccoon-/.test(mesh.userData.action?.id||''))return;
    const old=mesh.onAfterRender;
    const observer=function(renderer,scene,camera,geometry,material,...rest){
     old.call(this,renderer,scene,camera,geometry,material,...rest);
     if(!material.name||probe.seen.has(this.skeleton.uuid))return;
     probe.seen.add(this.skeleton.uuid);
     const gl=renderer.getContext(),program=renderer.properties.get(material).currentProgram;
     const draw=gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING),read=gl.getParameter(gl.READ_FRAMEBUFFER_BINDING),active=gl.getParameter(gl.ACTIVE_TEXTURE);
     let fbo=null,row={id:this.userData.action.id,mesh:this.name,material:material.name,currentProgramMatches:!!program&&gl.getParameter(gl.CURRENT_PROGRAM)===program.program};
     try{
      if(!program)throw Error('No actual draw program');
      const loc=gl.getUniformLocation(program.program,'boneTexture');if(loc===null)throw Error('No skin sampler in actual beauty program');
      const unit=gl.getUniform(program.program,loc),texture=this.skeleton.boneTexture,handle=renderer.properties.get(texture).__webglTexture;
      gl.activeTexture(gl.TEXTURE0+unit);row.actualSamplerMatchesSkeletonTexture=gl.getParameter(gl.TEXTURE_BINDING_2D)===handle;gl.activeTexture(active);
      gl.getExtension('EXT_color_buffer_float');fbo=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,fbo);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,handle,0);
      row.framebufferStatus=gl.checkFramebufferStatus(gl.FRAMEBUFFER);if(row.framebufferStatus!==gl.FRAMEBUFFER_COMPLETE)throw Error('Skin texture not readable');
      const width=texture.image.width,height=texture.image.height,pixels=new Float32Array(width*height*4);gl.readPixels(0,0,width,height,gl.RGBA,gl.FLOAT,pixels);
      row.textureSize=[width,height];row.glError=gl.getError();row.bones=[];
      for(let i=0;i<this.skeleton.bones.length;i++){
       const bone=this.skeleton.bones[i],expected=Float32Array.from(new THREE.Matrix4().multiplyMatrices(bone.matrixWorld,this.skeleton.boneInverses[i]).elements),actual=pixels.slice(i*16,i*16+16);
       row.bones.push({name:bone.name,matrixAutoUpdate:bone.matrixAutoUpdate,maximumAbsoluteError:Math.max(...actual.map((v,j)=>Math.abs(v-expected[j]))),actual:Array.from(actual),expected:Array.from(expected)});
      }
     }catch(error){row.error=String(error.stack||error)}finally{
      gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,draw);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,read);gl.activeTexture(active);if(fbo)gl.deleteFramebuffer(fbo);
      row.drawFramebufferRestored=gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING)===draw;row.readFramebufferRestored=gl.getParameter(gl.READ_FRAMEBUFFER_BINDING)===read;row.activeTextureRestored=gl.getParameter(gl.ACTIVE_TEXTURE)===active;
     }
     probe.rows.push(row);
    };
    mesh.onAfterRender=observer;probe.saved.push({mesh,old,observer});
   });e.labScene.requestFrame();return e.getSceneEvidence().frames;
  });
  for(const id of ['raccoon-0']){for(let i=0;i<28;i++){if(await host.evaluate(e=>e.getSceneEvidence().inspection?.id)===id)break;await canvas.press('n')}await expect.poll(()=>host.evaluate((e,id)=>window.__raccoonGPU.rows.some(r=>r.id===id),id)).toBe(true)}
  await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().frames)).toBeGreaterThan(previous);
  const result=await host.evaluate(e=>{
   const p=window.__raccoonGPU;let restored=true;
   for(const{mesh,old,observer}of p.saved){if(mesh.onAfterRender!==observer)throw Error('Observer ownership lost');mesh.onAfterRender=old;restored&&=mesh.onAfterRender===old}
   const result={clockProof:{playwrightClockPresent:!!globalThis.__pwClock,dateFake:!!Date.isFake,performanceNow:performance.now.toString(),requestAnimationFrame:requestAnimationFrame.toString()},rows:p.rows,callbacksRestored:restored,evidence:e.getSceneEvidence(),method:'Passive actual-draw skin-sampler readback through a temporary float framebuffer; all raw framebuffer/texture state and callbacks restored.'};delete window.__raccoonGPU;return result;
  });
  fs.writeFileSync(path.join(q,'actual-gpu-raccoon.json'),JSON.stringify({bindings,...result,errors},null,2));
  expect(new Set(result.rows.map(r=>r.id)).size).toBe(1);expect(result.clockProof.playwrightClockPresent||result.clockProof.dateFake).toBe(false);expect(result.clockProof.performanceNow).toContain('[native code]');expect(result.clockProof.requestAnimationFrame).toContain('[native code]');expect(result.callbacksRestored).toBe(true);expect(errors).toEqual([]);
  for(const r of result.rows){expect(r.error).toBeUndefined();expect(r.currentProgramMatches&&r.actualSamplerMatchesSkeletonTexture&&r.drawFramebufferRestored&&r.readFramebufferRestored&&r.activeTextureRestored).toBe(true);expect(r.glError).toBe(0);expect(Math.max(...r.bones.map(b=>b.maximumAbsoluteError))).toBeLessThan(2e-5)}
  console.log(JSON.stringify({draws:result.rows.length,maximumError:Math.max(...result.rows.flatMap(r=>r.bones.map(b=>b.maximumAbsoluteError))),callbacksRestored:result.callbacksRestored,errors:errors.length}));
  await context.close();
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
