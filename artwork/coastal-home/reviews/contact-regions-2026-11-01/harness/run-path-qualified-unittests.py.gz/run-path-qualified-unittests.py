﻿from pathlib import Path
import unittest,sys,json,hashlib,subprocess
root=Path.cwd();q=root/'.jekyll-cache/visual-qa/contact-cpu-next-20261101';suite=unittest.defaultTestLoader.discover('test',pattern='test_*.py');module=sys.modules['test_resting_review_custody'];original=module.REVIEWS;extended=Path('\\\\?\\'+str(original));records=[]
for folder in original.iterdir():
 if not folder.is_dir() or not(folder/'MANIFEST.json').exists():continue
 index=json.loads((folder/'MANIFEST.json').read_text('utf8'));files=index.get('files',[])
 if not isinstance(files,list):continue
 for row in files:
  rel=row.get('path',row.get('file'))
  if not rel:continue
  p=folder/rel
  if p.exists():continue
  ep=Path('\\\\?\\'+str(p));b=ep.read_bytes();rp=p.relative_to(root).as_posix();head=subprocess.check_output(['git','show','HEAD:'+rp]);assert b==head;records.append({'path':rp,'fullPathLength':len(str(p)),'HEADBytesExact':True,'sha256':hashlib.sha256(b).hexdigest()})
module.REVIEWS=extended
result=unittest.TextTestRunner(verbosity=1).run(suite)
(q/'PYTHON-PATH-QUALIFICATION.json').write_text(json.dumps({'ordinaryDiscovery':True,'testsRun':result.testsRun,'success':result.wasSuccessful(),'onlyFilesystemRootChanged':{'module':'test_resting_review_custody','name':'REVIEWS','original':str(original),'extended':str(extended)},'testSourceUnchanged':True,'assertionsUnchanged':True,'longPayloadsBoundToHEAD':records},indent=2)+'\n','utf8')
sys.exit(not result.wasSuccessful())
