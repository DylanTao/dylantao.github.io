from pathlib import Path
import json,os,subprocess,time
root=Path.cwd();q=Path(__file__).parent;out=q/'gym-checkpoint';server=json.loads((out/'server.json').read_bytes())
env=dict(os.environ,NO_WEBSERVER='1',VISUAL_BASE_URL=server['url'],PLAYWRIGHT_JSON_OUTPUT_FILE=str(out/'VIEWPORTS.json'))
for name in ['COASTAL_MODELS_ROOT','COASTAL_RUNTIME_ROOT','VISUAL_SCENE_GROUP']:env.pop(name,None)
command=['node',str(root/'node_modules/playwright/cli.js'),'test','--config','test/visual/public.config.js','test/visual/architecture-finish.spec.js','--grep','finished house: public gym visits keep the existing task lights on in the embed and full screen','--workers','1','--max-failures','1','--reporter','json','--output',str(out/'viewport-results')]
start=time.monotonic()
with(out/'viewport.log').open('wb')as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={'command':command,'server':server,'exitCode':r.returncode,'seconds':time.monotonic()-start,'sourceOrModelResponseReplacements':False}
(out/'VIEWPORT-PROCESS.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');print(json.dumps(receipt,indent=2));assert r.returncode==0
