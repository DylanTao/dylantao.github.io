from pathlib import Path
import json,subprocess,sys,time
root=Path.cwd();q=Path(__file__).parent;out=q/'directed-gym-node-gates';assert not out.exists();out.mkdir()
commands=[('node',['node','--test',*[str(p.relative_to(root))for p in sorted((root/'test').glob('*.test.mjs'))]]),('style',['node','test/style_contract.js'])]
rows=[]
for name,command in commands:
    start=time.monotonic()
    with(out/(name+'.log')).open('wb')as log:r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
    row={'name':name,'command':command,'exitCode':r.returncode,'seconds':time.monotonic()-start};rows.append(row)
    (out/'GATES.json').write_text(json.dumps({'processes':rows},indent=2)+'\n',encoding='utf8');print(json.dumps({k:row[k]for k in ['name','exitCode','seconds']}),flush=True)
    if r.returncode:raise SystemExit(r.returncode)
