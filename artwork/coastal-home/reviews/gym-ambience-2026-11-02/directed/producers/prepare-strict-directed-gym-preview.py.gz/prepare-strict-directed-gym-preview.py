from pathlib import Path
q=Path(__file__).parent
s=(q/'prepare-directed-gym-preview.py').read_text(encoding='utf8').replace("'directed-gym-preview-v1'","'directed-gym-preview-v2'").replace("'public-gym-official-bake-v2/PROCESS.json'","'public-gym-official-bake-v3/PROCESS.json'")
s=s.replace('current directed gym runtime','current strict-directed gym runtime').replace('V4full production is retained separately with its rejected phone-ceiling glare.','V4full production and V5directed-preview remain retained with phone glare: the remaining source self-light was admitted by the general5cm floor tolerance. This successor uses a strict emitter half-space with identical powers and bloom/exposure.')
p=q/'execute-strict-directed-gym-preview.py';assert not p.exists();p.write_text(s,encoding='utf8',newline='\n');exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
