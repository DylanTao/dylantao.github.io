from pathlib import Path
import hashlib,json,shutil
q=Path(__file__).parent
root=Path.cwd();rel='test/visual/architecture-finish.spec.js';target=Path('C:/dev/cqa1102')/rel
before=target.read_bytes();after=(root/rel).read_bytes();shutil.copyfile(root/rel,target)
(q/'gym-checkpoint/TEST-CORRECTION.json').write_text(json.dumps({'path':rel,'beforeSha256':hashlib.sha256(before).hexdigest(),'afterSha256':hashlib.sha256(after).hexdigest(),'reason':'The public fullscreen evidence is the string native or pseudo, not a Boolean. V1retains the literal-true fixture failure; the corrected assertion tests truthiness and retains full scene/pixel/light gates. Runtime/build unchanged.'},indent=2)+'\n',encoding='utf8')
s=(q/'run-gym-viewport-checkpoint.py').read_text(encoding='utf8').replace("'VIEWPORTS.json'","'VIEWPORTS-V2.json'").replace("'viewport-results'","'viewport-results-v2'").replace("'viewport.log'","'viewport-v2.log'").replace("'VIEWPORT-PROCESS.json'","'VIEWPORT-PROCESS-V2.json'")
p=q/'execute-gym-viewport-v2.py';assert not p.exists();p.write_text(s,encoding='utf8',newline='\n');exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
