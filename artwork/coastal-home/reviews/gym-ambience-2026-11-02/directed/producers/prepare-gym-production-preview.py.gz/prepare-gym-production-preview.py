from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time,urllib.request
root=Path.cwd();q=Path(__file__).parent;out=q/'gym-checkpoint';built=out/'site/al-folio'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert json.loads((out/'BUILD-GATES.json').read_bytes())['processes'][0]['exitCode']==0
module=json.loads((built/'assets/js/module-build.json').read_bytes());assert len(module['modules'])==189
for rel,row in module['modules'].items():assert hashlib.sha256((root/rel).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==row['sourceSha256']and sha(built/rel)==row['outputSha256']
private=q/'private-visit-lighting-v4/site/al-folio'
compiled_differences=[rel for rel in module['modules']if(built/rel).read_bytes()!=(private/rel).read_bytes()]
assert not compiled_differences,compiled_differences
for p in(root/'assets/models/home').rglob('*.glb'):assert p.read_bytes()==(built/p.relative_to(root)).read_bytes()
assert(root/'assets/models/home/static-light-field.json').read_bytes()==(built/'assets/models/home/static-light-field.json').read_bytes()
assert json.loads((root/'assets/models/home/manifest.json').read_bytes())==json.loads((built/'assets/models/home/manifest.json').read_bytes())
cache=json.loads((built/'assets/models/home/static-light-field.json').read_bytes());control=json.loads((private/'assets/models/home/static-light-field.json').read_bytes())
assert cache['configuration']==control['configuration']
receipt={'compiledModules':189,'allRootSourceBindingsExact':True,'allOutputHashesExact':True,'allCompiledBodiesEqualReviewedV4':True,'allCanonicalHomeGLBsExact':True,'cacheResponseBytesExact':True,'manifestSemanticsExact':True,'lightConfigurationEqualReviewedV4':True,'signature':cache['signature'],'nativeSha256':sha(root/'artwork/coastal-home/coastal-home.blend')}
(out/'COMPILED-CUSTODY.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
shutil.copyfile(q/'private-serve-template.py',out/'serve.py')
with(out/'server.log').open('wb')as log:child=subprocess.Popen([sys.executable,str(out/'serve.py')],cwd=root,stdout=log,stderr=subprocess.STDOUT,creationflags=0x08000000)
for _ in range(100):
    if(out/'server.json').exists():break
    assert child.poll()is None;time.sleep(.1)
server=json.loads((out/'server.json').read_bytes());assert server['pid']==child.pid
with urllib.request.urlopen(server['url'],timeout=10)as response:assert response.headers['X-Sirui-Preview']==server['header']
print(json.dumps({'server':server,'custody':receipt},indent=2))
