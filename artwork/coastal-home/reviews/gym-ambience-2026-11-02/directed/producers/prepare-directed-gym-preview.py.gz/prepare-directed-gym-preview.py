from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time,urllib.request
root=Path.cwd();q=Path(__file__).parent;out=q/'directed-gym-preview-v1';assert not out.exists();out.mkdir()
source=out/'source';built=out/'site/al-folio';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
proof=json.loads((q/'public-gym-official-bake-v2/PROCESS.json').read_bytes());assert proof['exitCode']==0
shutil.copytree(q/'gym-checkpoint/site',out/'site');shutil.copytree(root/'assets/js',source/'assets/js')
for rel in ['_plugins/site_module_assets.rb','Gemfile.lock']:
    target=source/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,target)
for p in(root/'assets/models/home').rglob('*.glb'):assert p.read_bytes()==(built/p.relative_to(root)).read_bytes()
for name in ['manifest.json','static-light-field.json']:shutil.copyfile(root/'assets/models/home'/name,built/'assets/models/home'/name)
env=dict(os.environ,BUNDLE_PATH='C:/tools/site-gems-ruby33')
command=['C:/tools/Ruby33/bin/ruby.exe','C:/tools/Ruby33/bin/bundle','exec','ruby',str(q/'compile-private-modules.rb'),str(source),str(built)]
with(out/'compile.log').open('wb')as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
modules=json.loads((built/'assets/js/module-build.json').read_bytes())['modules'];assert len(modules)==189
for rel,row in modules.items():assert hashlib.sha256((root/rel).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==row['sourceSha256']and sha(built/rel)==row['outputSha256']
files={p.relative_to(source).as_posix():sha(p)for p in source.rglob('*')if p.is_file()}
(out/'SOURCE.json').write_text(json.dumps({'scope':'Complete canonical geometry plus current directed gym runtime. The189source/output bindings are exact; fresh canonical cache including downward emission is copied without modification. No response replacement, shader omission, phone viewport reduction or tier override. V4full production is retained separately with its rejected phone-ceiling glare.','files':files,'cache':proof},indent=2)+'\n',encoding='utf8')
shutil.copyfile(q/'private-serve-template.py',out/'serve.py')
with(out/'server.log').open('wb')as log:child=subprocess.Popen([sys.executable,str(out/'serve.py')],cwd=root,stdout=log,stderr=subprocess.STDOUT,creationflags=0x08000000)
for _ in range(100):
    if(out/'server.json').exists():break
    assert child.poll()is None;time.sleep(.1)
server=json.loads((out/'server.json').read_bytes());assert server['pid']==child.pid
with urllib.request.urlopen(server['url'],timeout=10)as response:assert response.headers['X-Sirui-Preview']==server['header']
print(json.dumps({'server':server,'modules':len(modules),'cacheSignature':proof['signature']},indent=2))
