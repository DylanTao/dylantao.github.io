from pathlib import Path
q=Path(__file__).parent
s=(q/'capture-directed-gym-phone.cjs').read_text(encoding='utf8')
s=s.replace("'directed-gym-phone-'+kind+'-v1'","'directed-gym-phone-'+kind+'-v2'").replace("'directed-gym-preview-v1'","'directed-gym-preview-v2'")
needle=" for(const [label,dy]of [['default',0],['look-a',130],['look-b',-260]]){"
replacement=" for(const destination of ['sleep','gym']) { await p.locator('[data-world-places]>summary').tap(); await p.locator(`[data-world-destination=\"${destination}\"]`).tap(); await expect.poll(async()=>(await state(p)).currentRoom).toBe(destination); }\n"+needle
assert s.count(needle)==1;s=s.replace(needle,replacement)
s=s.replace('No Lab, Pause, tier override','Default views reset through public Sleep→Gym visits before each theme; V1retains its carried-over second-theme camera. Strict emission-plane tolerance removes the source self-light witness, preserving all powers and bloom/exposure. No Lab, Pause, tier override')
p=q/'capture-strict-directed-gym-phone.cjs';assert not p.exists();p.write_text(s,encoding='utf8',newline='\n')
s=(q/'run-directed-gym-phone.py').read_text(encoding='utf8').replace("'directed-gym-phone-'+kind+'.log'","'directed-gym-phone-'+kind+'-v2.log'").replace("'capture-directed-gym-phone.cjs'","'capture-strict-directed-gym-phone.cjs'")
p=q/'run-strict-directed-gym-phone.py';assert not p.exists();p.write_text(s,encoding='utf8',newline='\n')
