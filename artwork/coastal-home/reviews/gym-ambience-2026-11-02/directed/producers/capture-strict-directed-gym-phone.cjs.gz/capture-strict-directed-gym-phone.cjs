const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=process.cwd(),q=__dirname,kind=process.argv[2];
if(!['chromium','webkit'].includes(kind))throw Error('Select an isolated browser');
const sdk=kind==='webkit'?require(path.join(q,'webkit-1.65-alpha-20261028/node_modules/@playwright/test')):require('@playwright/test');
const {expect,devices}=sdk,out=path.join(q,'directed-gym-phone-'+kind+'-v2'),preview=path.join(q,'directed-gym-preview-v2'),server=JSON.parse(fs.readFileSync(path.join(preview,'server.json'))),base=server.url,built=path.join(preview,'site/al-folio');
if(fs.existsSync(out))throw Error('Fresh capture required');fs.mkdirSync(out);
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),errors=[],failed=[],responses=[],pending=[],rows=[];
const state=p=>p.locator('[data-home-desk-scene]').evaluate(e=>e.getSceneEvidence());
async function settle(p){let last;for(let k=0;k<90;k++){const e=await state(p);if(last&&!e.traveling&&Math.hypot(...e.camera.map((v,i)=>v-last[i]))<1e-5)return e;last=e.camera;await p.waitForTimeout(150);}throw Error('camera settle budget');}
(async()=>{const browser=await sdk[kind].launch({headless:true,...(kind==='chromium'?{args:['--use-angle=d3d11','--ignore-gpu-blocklist']}: {})});try{
const context=await browser.newContext({...devices[kind==='webkit'?'iPhone 13':'Pixel 5'],viewport:{width:390,height:1000},deviceScaleFactor:1,timezoneId:'America/Los_Angeles',colorScheme:'light',reducedMotion:'reduce'}),p=await context.newPage();p.setDefaultTimeout(45000);
await p.clock.setFixedTime(new Date('2026-10-23T14:00:00-07:00'));
await p.route(/https:\/\/(?:analytics\.google\.com|www\.google-analytics\.com|www\.googletagmanager\.com|plausible\.io)\//,r=>r.fulfill({status:204,body:''}));
const modules=JSON.parse(fs.readFileSync(path.join(built,'assets/js/module-build.json'))).modules;expect(Object.keys(modules)).toHaveLength(189);
for(const [rel,row]of Object.entries(modules))expect(hash(fs.readFileSync(path.join(root,rel)).toString().replaceAll('\r\n','\n'))).toBe(row.sourceSha256);
p.on('pageerror',e=>errors.push(e.message));p.on('console',m=>{if(m.type()==='error')errors.push(m.text());});p.on('requestfailed',r=>failed.push({url:r.url(),failure:r.failure()}));
p.on('response',r=>{if(!r.url().startsWith(base)||!/\.(?:mjs|glb|json)(?:\?|$)/.test(r.url()))return;pending.push((async()=>{try{const body=await r.body(),rel=decodeURIComponent(new URL(r.url()).pathname.slice(new URL(base).pathname.length)),expected=fs.readFileSync(path.join(built,rel));responses.push({path:rel,status:r.status(),bytes:body.length,sha256:hash(body),exact:body.equals(expected),owner:r.headers()['x-sirui-preview']});}catch(e){responses.push({url:r.url(),error:String(e)});}})());});
const theme=async mode=>{await p.locator('[data-theme-toggle]:visible').first().tap();await p.locator(`[data-theme-mode-option="${mode}"]:visible`).first().tap();await p.locator('[data-theme-toggle]:visible').first().tap();};
await p.goto(base,{waitUntil:'domcontentloaded'});await p.evaluate(()=>document.fonts.ready);await theme('noon');await p.locator('[data-home-desk-mode="3d"]').tap();const scene=p.locator('[data-home-desk-scene]');await scene.scrollIntoViewIfNeeded();await expect(scene).toHaveAttribute('data-scene-state','ready',{timeout:180000});
await p.locator('[data-world-places]>summary').tap();await p.locator('[data-world-destination="gym"]').tap();await expect.poll(async()=>(await state(p)).currentRoom).toBe('gym');await p.locator('[data-world-fullscreen]').tap();const canvas=scene.locator('canvas:not(.home-world-sketch)');
for(const mode of ['noon','evening']){
 if(mode==='evening'){await p.locator('[data-world-exit]').tap();await theme(mode);await p.locator('[data-world-fullscreen]').tap();}
 for(const destination of ['sleep','gym']) { await p.locator('[data-world-places]>summary').tap(); await p.locator(`[data-world-destination="${destination}"]`).tap(); await expect.poll(async()=>(await state(p)).currentRoom).toBe(destination); }
 for(const [label,dy]of [['default',0],['look-a',130],['look-b',-260]]){
  if(dy){const b=await canvas.boundingBox();await p.mouse.move(b.x+b.width*.48,b.y+b.height*.46);await p.mouse.down();await p.mouse.move(b.x+b.width*.48,b.y+b.height*.46+dy,{steps:12});await p.mouse.up();}
  const e=await settle(p);expect(e.currentRoom).toBe('gym');expect(e.simulation.practicals.pointLights).toBe(7);expect(e.simulation.practicals.spotLights).toBe(1);expect(e.simulation.practicals.levels.gym).toBe(1);expect(e.simulation.lightField.cacheHit).toBe(true);
  await p.screenshot({path:path.join(out,mode+'-'+label+'-page.png')});await canvas.screenshot({path:path.join(out,mode+'-'+label+'-canvas.png')});
  const backend=await canvas.evaluate(c=>{const g=c.getContext('webgl2'),ext=g?.getExtension('WEBGL_debug_renderer_info');return g?{renderer:g.getParameter(ext?.UNMASKED_RENDERER_WEBGL||g.RENDERER),buffer:[g.drawingBufferWidth,g.drawingBufferHeight]}:null;});
  rows.push({mode,label,evidence:e,backend});console.log(JSON.stringify({kind,mode,label,camera:e.camera,backend}));
 }
}
await Promise.all(pending);const receipt={scope:'Complete directed-gym product at390x1000, normal fixed date, public touch navigation/theme/fullscreen and trusted mouse drags in a phone-sized layout. Default views reset through public Sleep→Gym visits before each theme; V1retains its carried-over second-theme camera. Strict emission-plane tolerance removes the source self-light witness, preserving all powers and bloom/exposure. No Lab, Pause, tier override or source/model/module response replacement. PC WebKit and its AppleGPU label are not physical iPhone performance. Source/output inventory and every observed scene body are exact.',kind,browserVersion:browser.version(),server,at:new Date().toISOString(),rows,errors,failed,responses};fs.writeFileSync(path.join(out,'CAPTURE.json'),JSON.stringify(receipt,null,2)+'\n');expect(errors).toEqual([]);expect(failed).toEqual([]);expect(responses.filter(r=>r.error||!r.exact||r.status>=400||r.owner!==server.header)).toEqual([]);await context.close();
}finally{await browser.close();}})().catch(e=>{fs.writeFileSync(path.join(out,'FAILURE.json'),JSON.stringify({error:String(e),rows,errors,failed,responses},null,2));console.error(e);process.exitCode=1;});
