from pathlib import Path
import json,subprocess,sys,time,shutil
q=Path(__file__).parent;kind=sys.argv[1];assert kind in ['chromium','webkit']
start=time.monotonic()
with(q/('directed-gym-phone-'+kind+'.log')).open('wb')as log:r=subprocess.run([shutil.which('node'),str(q/'capture-directed-gym-phone.cjs'),kind],cwd=Path.cwd(),stdout=log,stderr=subprocess.STDOUT)
print(json.dumps({'kind':kind,'exitCode':r.returncode,'seconds':time.monotonic()-start}));assert r.returncode==0
