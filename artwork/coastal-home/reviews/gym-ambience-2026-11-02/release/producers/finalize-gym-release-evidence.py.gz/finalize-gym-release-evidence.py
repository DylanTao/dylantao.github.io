from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,os,re
root=Path.cwd();q=Path(__file__).parent;packet=root/'artwork/coastal-home/reviews/gym-ambience-2026-11-02';manifest=json.loads((packet/'MANIFEST.json').read_bytes());rows=manifest['files'];seen={r['path']for r in rows};sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return Path('\\\\?\\'+str(p.absolute())).read_bytes()if os.name=='nt'else p.read_bytes()
def deposit(rel,p,compressed=True):
    raw=read(p);body=gzip.compress(raw,mtime=0)if compressed else raw;target=packet/(rel+('.gz'if compressed else''));key=target.relative_to(packet).as_posix();assert key not in seen and not target.exists();target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body);seen.add(key);rows.append({'path':key,'bytes':len(body),'sha256':sha(body),'encoding':'gzip'if compressed else'raw','bodyBytes':len(raw),'bodySha256':sha(raw)})
out=q/'gym-directed-checkpoint';build=json.loads((out/'BUILD-GATES.json').read_bytes());py=json.loads((out/'PYTHON-GATES.json').read_bytes());viewport=json.loads((out/'VIEWPORTS-V2.json').read_bytes());process=json.loads((out/'VIEWPORT-PROCESS-V2.json').read_bytes());custody=json.loads((out/'COMPILED-CUSTODY.json').read_bytes());node=json.loads((q/'directed-gym-node-gates/GATES.json').read_bytes());cache=json.loads((q/'public-gym-official-bake-v3/PROCESS.json').read_bytes())
assert all(r['exitCode']==0 for d in [build,py,node]for r in d['processes'])and process['exitCode']==0
assert viewport['stats']['expected']==4 and all(viewport['stats'][k]==0 for k in ['skipped','unexpected','flaky'])
for name in ['BUILD-GATES.json','PYTHON-GATES.json','COMPILED-CUSTODY.json','VALIDATION-SOURCE.json','VIEWPORTS-V2.json','VIEWPORT-PROCESS-V2.json','production-build.log','python.log']:
    deposit('release/'+name,out/name)
phone=[]
for kind in ['chromium','webkit']:
    record=json.loads((q/f'directed-gym-phone-{kind}-v2/CAPTURE.json').read_bytes());assert len(record['rows'])==6 and not record['errors']and not record['failed']and all(r['exact']and r['owner']==record['server']['header']for r in record['responses'])
    phone.append({'kind':kind,'version':record['browserVersion'],'states':len(record['rows']),'viewport':[390,1000],'dpr':1,'physicalDevice':False})
attachments=[]
for suite in viewport['suites']:
    for spec in suite.get('specs',[]):
        for test in spec['tests']:
            assert len(test['results'])==1 and test['results'][0]['status']=='passed'
            for a in test['results'][0]['attachments']:
                if a['contentType']not in ['image/png','application/json']:continue
                suffix='.png'if a['contentType']=='image/png'else'.json'
                rel='release/views/'+test['projectName']+'/'+a['name']+suffix
                deposit(rel,Path(a['path']),a['contentType']=='application/json');attachments.append({'project':test['projectName'],'name':a['name'],'path':rel})
for name in ['prepare-directed-final-validation.py','run-directed-final-validation.py','prepare-directed-final-preview.py','run-directed-final-viewports.py','append-directed-gym-evidence.py','finalize-gym-release-evidence.py']:
    deposit('release/producers/'+name,q/name)
privacy=[]
pattern=re.compile(rb'(?:ghp_[A-Za-z0-9]{36}|github_pat_[A-Za-z0-9_]{60,}|sk-proj-[A-Za-z0-9_-]{24,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)')
for folder in [packet,root/'artwork/coastal-home/reviews/pavilion-breakfast-source-2026-11-02',root/'artwork/coastal-home/reviews/pavilion-breakfast-decoded-2026-11-02']:
    for p in folder.rglob('*'):
        if not p.is_file():continue
        body=read(p)
        if p.suffix=='.gz':body=gzip.decompress(body)
        assert not pattern.search(body),p
    privacy.append(folder.relative_to(root).as_posix())
for r in rows:
    stored=(packet/r['path']).read_bytes();assert len(stored)==r['bytes']and sha(stored)==r['sha256'];body=gzip.decompress(stored)if r['encoding']=='gzip'else stored;assert len(body)==r['bodyBytes']and sha(body)==r['bodySha256']
for name in ['pavilion-breakfast-source-2026-11-02','pavilion-breakfast-decoded-2026-11-02']:
    folder=root/'artwork/coastal-home/reviews'/name;index=json.loads((folder/'ARCHIVE-INDEX.json').read_bytes())
    for r in index:
        body=read(folder/r['file']);assert sha(body)==r['storedSHA256'];raw=gzip.decompress(body)if r['file'].endswith('.gz')else body;assert len(raw)==r['rawBytes']and sha(raw)==r['rawSHA256']
for source in json.loads((root/'artwork/coastal-home/reviews/pavilion-breakfast-source-2026-11-02/CHECKPOINT.json').read_bytes())['sourceFiles']:
    body=(root/source['path']).read_bytes();assert len(body)==source['bytes']and sha(body)==source['sha256']
release={'schema':'sirui-gym-release-gates-v1','at':datetime.now(timezone.utc).isoformat(),'python':{'passed':416,'process':py['processes'][0]},'node':{'passed':1013,'skipped':7,'total':1020,'process':node['processes'][0]},'styleContract':node['processes'][1],'productionBuild':build['processes'][0],'compiledCustody':custody,'cache':cache,'fourWidthStats':viewport['stats'],'fourWidthProcess':process,'phoneSizedBrowsers':phone,'retainedViewportAttachments':attachments,'packetPrivacyChecks':privacy,'allArchiveBodiesAndSixRecipeSourceHashesExact':True,'limitations':'This verifies the gym runtime and preserves disabled pavilion construction recipes. The native master/GLBs remain1e10public, so private crown/arrival/garden and breakfast carry/entry are still open. PCWebKit is not a physicaliPhone benchmark. Prior fixture, glare, and archive-long-path failures remain retained; only byte-identical unpublished archive deposits resumed.'}
(packet/'RELEASE-GATES.json').write_text(json.dumps(release,indent=2)+'\n',encoding='utf8');manifest['scope']='Verified strict-directed gym runtime, current production/four-width/Chromium+PCWebKit phone-size evidence, retained superseded controls and exact original archive/source bytes. Whole-house native/appearance work and final device/performance/CI/live checks remain separate.'
(packet/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8');print(json.dumps({'payloads':len(rows),'storedBytes':sum(r['bytes']for r in rows),'phoneStates':sum(p['states']for p in phone),'fourWidthsPassed':4}))
