from pathlib import Path
import gzip,hashlib,json,os
root=Path.cwd();q=Path(__file__).parent;packet=root/'artwork/coastal-home/reviews/gym-ambience-2026-11-02';manifest=json.loads((packet/'MANIFEST.json').read_bytes());rows=manifest['files'];seen={r['path']for r in rows};sha=lambda b:hashlib.sha256(b).hexdigest()
def deposit(relative,path,compressed=True):
    readable=Path('\\\\?\\'+str(path.absolute()))if os.name=='nt'else path
    raw=readable.read_bytes();stored=gzip.compress(raw,mtime=0)if compressed else raw;target=packet/(relative+('.gz'if compressed else''));rel=target.relative_to(packet).as_posix();assert rel not in seen;target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():assert target.read_bytes()==stored,'Only byte-identical unpublished interrupted deposits may resume'
    else:target.write_bytes(stored)
    seen.add(rel)
    rows.append({'path':rel,'bytes':len(stored),'sha256':sha(stored),'encoding':'gzip'if compressed else'raw','bodyBytes':len(raw),'bodySha256':sha(raw)})
for name in ['witness-gym-self-light.cjs','prepare-directed-gym-preview.py','prepare-strict-directed-gym-preview.py','capture-directed-gym-phone.cjs','capture-strict-directed-gym-phone.cjs','prepare-strict-directed-phone-capture.py','run-directed-gym-phone.py','run-strict-directed-gym-phone.py','run-directed-node-gates.py','prepare-gym-production-preview.py','run-gym-viewport-checkpoint.py','run-gym-viewport-checkpoint-v2.py']:
    deposit('directed/producers/'+name,q/name)
deposit('directed/GYM-SELF-LIGHT-WITNESS.json',q/'GYM-SELF-LIGHT-WITNESS.json')
for version in [2,3]:
    for name in ['PROCESS.json','BAKE.log']:deposit(f'directed/official-bake-v{version}/'+name,q/f'public-gym-official-bake-v{version}'/name)
for version in [1,2]:deposit(f'directed/source-v{version}.json',q/f'directed-gym-preview-v{version}/SOURCE.json')
for folder in ['directed-gym-phone-chromium-v1','directed-gym-phone-chromium-v2','directed-gym-phone-webkit-v2']:
    deposit('directed/'+folder+'/CAPTURE.json',q/folder/'CAPTURE.json')
for name in ['BUILD-GATES.json','UNIT-GATES.json','COMPILED-CUSTODY.json','VALIDATION-SOURCE.json','VIEWPORTS.json','VIEWPORT-PROCESS.json','VIEWPORTS-V2.json','VIEWPORT-PROCESS-V2.json','TEST-CORRECTION.json']:
    deposit('superseded-v4-gates/'+name,q/'gym-checkpoint'/name)
for name in ['GATES.json','node.log','style.log']:deposit('directed/current-node/'+name,q/'directed-gym-node-gates'/name)
for name in ['package.json','package-lock.json']:deposit('directed/qa-sdk/'+name,q/'webkit-1.65-alpha-20261028'/name)
viewport=json.loads((q/'gym-checkpoint/VIEWPORTS-V2.json').read_bytes())
mobile=next(t for s in viewport['suites']for spec in s.get('specs',[])for t in spec['tests']if t['projectName']=='mobile-390')
before=next(a['path']for a in mobile['results'][0]['attachments']if a['name']=='gym-evening-fullscreen')
deposit('views/phone-before-self-light.png',Path(before),False)
for relative,p in [
    ('views/phone-after-strict-plane.png',q/'directed-gym-phone-chromium-v2/evening-default-canvas.png'),
    ('views/phone-after-strict-plane-angle.png',q/'directed-gym-phone-chromium-v2/evening-look-b-page.png'),
    ('views/webkit-after-strict-plane.png',q/'directed-gym-phone-webkit-v2/evening-default-page.png')]:deposit(relative,p,False)
manifest['scope']='Retained V1–V5 controls include rejected phone diffuser self-glare. Current strict-directed V6 changes source emission, preserving bloom/exposure and lamp output below the fixtures. Exact new phone/Node/cache evidence is included; final production/four-width/Python gates are added before first publication.'
(packet/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
print(json.dumps({'payloads':len(rows),'storedBytes':sum(r['bytes']for r in rows)}))
