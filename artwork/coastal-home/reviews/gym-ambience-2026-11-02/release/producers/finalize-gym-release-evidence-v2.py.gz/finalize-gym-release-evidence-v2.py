"""Resume only identical unpublished deposits; honor already-gzip source records."""
from pathlib import Path
q=Path(__file__).parent
s=(q/'finalize-gym-release-evidence.py').read_text(encoding='utf8')
before="assert key not in seen and not target.exists();target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body);seen.add(key);rows.append("
after="assert key not in seen;target.parent.mkdir(parents=True,exist_ok=True)\n    if target.exists():assert target.read_bytes()==body,'Only byte-identical unpublished interrupted deposits may resume'\n    else:target.write_bytes(body)\n    seen.add(key);rows.append("
assert s.count(before)==1;s=s.replace(before,after)
before="raw=gzip.decompress(body)if r['file'].endswith('.gz')else body"
after="raw=gzip.decompress(body)if r['file'].endswith('.gz')and not r['source'].endswith('.gz')else body"
assert s.count(before)==1;s=s.replace(before,after)
s=s.replace("'finalize-gym-release-evidence.py']","'finalize-gym-release-evidence.py','finalize-gym-release-evidence-v2.py']")
s=s.replace('only byte-identical unpublished archive deposits resumed.','only byte-identical unpublished archive deposits resumed. The initial archive verifier incorrectly decompressed13already-gzip original sources when comparing raw-source hashes; the corrected verifier follows the source extension and preserves every archive/index byte.')
exec(compile(s,str(Path(__file__)),'exec'),{'__file__':str(Path(__file__)),'__name__':'__main__'})
