from pathlib import Path
q=Path(__file__).parent
s=(q/'prepare-gym-validation.py').read_text(encoding='utf8').replace("'gym-checkpoint'","'gym-directed-checkpoint'").replace("'run-gym-validation.py'","'run-directed-final-validation.py'")
s=s.replace("s=(q/'run-surface-role-validation.py').read_text(encoding='utf8').replace(\"'surface-role-checkpoint'\",\"'gym-directed-checkpoint'\")", "s=(q/'run-surface-role-validation.py').read_text(encoding='utf8').replace(\"'surface-role-checkpoint'\",\"'gym-directed-checkpoint'\")")
needle="p=q/'run-directed-final-validation.py';assert not p.exists();compile(s,str(p),'exec');p.write_text(s,encoding='utf8',newline='\\n')"
replace="s=s.replace(\"choices=['build','unit']\",\"choices=['build','unit','python']\")\n"+needle+"\n"
assert s.count(needle)==1;s=s.replace(needle,replace)
exec(compile(s,str(q/'prepare-gym-validation.py'),'exec'),{'__file__':str(q/'prepare-gym-validation.py'),'__name__':'__main__'})
p=q/'run-directed-final-validation.py';s=p.read_text(encoding='utf8');needle='rows=[]';s=s.replace(needle,"if args.mode=='python':commands=commands[:1]\n"+needle);p.write_text(s,encoding='utf8',newline='\n')
