from pathlib import Path
q=Path(__file__).parent
s=(q/'prepare-gym-production-preview.py').read_text(encoding='utf8').replace("'gym-checkpoint'","'gym-directed-checkpoint'").replace("'private-visit-lighting-v4/site/al-folio'","'directed-gym-preview-v2/site/al-folio'").replace('allCompiledBodiesEqualReviewedV4','allCompiledBodiesEqualReviewedStrictEmission').replace('lightConfigurationEqualReviewedV4','lightConfigurationEqualReviewedStrictEmission')
p=q/'execute-directed-final-preview.py';assert not p.exists();p.write_text(s,encoding='utf8',newline='\n');exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
s=(q/'execute-gym-viewport-v2.py').read_text(encoding='utf8').replace("'gym-checkpoint'","'gym-directed-checkpoint'")
p=q/'run-directed-final-viewports.py';assert not p.exists();p.write_text(s,encoding='utf8',newline='\n')
