from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();q=Path(__file__).parent;control=q/'private-visit-lighting-v4/source'
head='4f325d2e6ec33781793c4e8534697b85d6f273f3'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
paths=['assets/js/home-scene/warm-practicals.mjs','assets/js/home-scene/controller.mjs','assets/js/home-scene/light-installations.mjs','assets/js/home-scene/realism.mjs']
sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for rel in paths:
    before=(root/rel).read_bytes().replace(b'\r\n',b'\n');assert before==subprocess.check_output(['git','show',head+':'+rel])
    after=(control/rel).read_bytes();assert before!=after
    rows.append({'path':rel,'beforeSHA256':sha(before),'privateV4SHA256':sha(after)})
for row in rows:(root/row['path']).write_bytes((control/row['path']).read_bytes())
(q/'GYM-SOURCE-INTEGRATION.json').write_text(json.dumps({'head':head,'changedFiles':rows,'nativeModelsAndManifestNotCopied':True,'scope':'Copies only the four reviewed privateV4runtime modules. Coordinator owns the two released controller lighting sections; optional coffee WIP remains separate. Cache must be freshly baked after source formatting.'},indent=2)+'\n',encoding='utf8')
print(json.dumps({'files':len(rows)}))
