from pathlib import Path
import hashlib,json
import bpy
root=Path.cwd();q=Path(__file__).parent;source=root/'artwork/coastal-home/coastal-home.blend'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='1e10b25d5cf0eec87d7001acbf9d938d65ba33af6076380d5a8e5d45cf3d23e7'
bpy.ops.wm.open_mainfile(filepath=str(source));rows=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH':continue
 names=[m.name if m else None for m in o.data.materials]
 if not(o.name.startswith('gym')or 'gym light diffuser'in names or o.name.startswith('core_gym')):continue
 p=[o.matrix_world@v.co for v in o.data.vertices]
 rows.append({'name':o.name,'materials':names,'boundsWorld':[[min(v[k]for v in p)for k in (0,2,1)],[max(v[k]for v in p)for k in (0,2,1)]],'boundsNative':[[min(v[k]for v in p)for k in range(3)],[max(v[k]for v in p)for k in range(3)]],'properties':dict(o.items())})
config=json.loads((root/'assets/models/home/manifest.json').read_bytes())
result={'scope':'Read-only actual saved public gym fixture/room extents. Native axes mapped separately; world third coordinate is minus nativeY, not direct nativeY bounds. No light/mood/performance claim.','sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'gymRoom':next(r for r in config['rooms']if r['id']=='gym'),'meshes':rows}
(q/'PUBLIC-GYM-NATIVE-FIXTURES.json').write_text(json.dumps(result,indent=2,default=str)+'\n',encoding='utf8')
print(json.dumps({'meshes':[{k:r[k]for k in ['name','materials','boundsNative']}for r in rows if'light'in r['name']or'light'in ' '.join(m or''for m in r['materials'])]},indent=2))
