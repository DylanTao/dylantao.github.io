from pathlib import Path
import hashlib,json,os,subprocess,time,urllib.request,shutil
root=Path.cwd();q=Path(__file__).parent;out=q/'public-gym-official-bake-v1';assert not out.exists();out.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base='http://127.0.0.1:8080/'
for attempt in range(60):
    with urllib.request.urlopen(base+'assets/js/module-build.json',timeout=30)as response:modules=json.load(response)['modules']
    mismatches=[rel for rel,row in modules.items()if hashlib.sha256((root/rel).read_bytes().replace(b'\r\n',b'\n')).hexdigest()!=row['sourceSha256']]
    if not mismatches:break
    time.sleep(.5)
assert not mismatches and len(modules)==189,mismatches
native=sha(root/'artwork/coastal-home/coastal-home.blend');assert native=='1e10b25d5cf0eec87d7001acbf9d938d65ba33af6076380d5a8e5d45cf3d23e7'
models={p.relative_to(root).as_posix():sha(p)for p in(root/'assets/models/home').rglob('*.glb')}
env=dict(os.environ,COASTAL_CACHE_URL=base);command=[shutil.which('node'),'bin/bake_coastal_static_light.cjs'];start=time.monotonic()
with(out/'BAKE.log').open('wb')as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
cache=json.loads((root/'assets/models/home/static-light-field.json').read_bytes());configuration=json.loads(cache['configuration']);stats=cache['statistics']
receipt={'command':command,'base':base,'exitCode':r.returncode,'seconds':time.monotonic()-start,'signature':cache['signature'],'preROITriangles':stats['triangles']+stats['skippedTriangles'],'cacheBytes':(root/'assets/models/home/static-light-field.json').stat().st_size,'regions':len(configuration['regions']),'probes':len(cache['probes']),'practicals':len(configuration['practicalSources']),'compiledModules':len(modules),'nativeUnchanged':sha(root/'artwork/coastal-home/coastal-home.blend')==native,'allModelsUnchanged':all(sha(root/rel)==h for rel,h in models.items())}
(out/'PROCESS.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps(receipt,indent=2));assert r.returncode==0 and receipt['nativeUnchanged']and receipt['allModelsUnchanged']and receipt['preROITriangles']<=750000 and receipt['cacheBytes']<=800000 and[receipt[k]for k in ['regions','probes','practicals']]==[16,128,28]
