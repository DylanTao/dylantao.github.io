"""Private complete-product control: visit-aware gym practical, no native edits."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time,urllib.request

root=Path.cwd();q=Path(__file__).parent;out=q/'private-visit-lighting-v4'
assert not out.exists();out.mkdir()
source=out/'source';built=out/'site/al-folio'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
canonical={p.relative_to(root).as_posix():sha(p)for folder in ['assets/js','assets/models/home']for p in(root/folder).rglob('*')if p.is_file()}
shutil.copytree(q/'surface-role-checkpoint/site',out/'site')
for rel in ['assets/js','assets/models/home']:shutil.copytree(root/rel,source/rel)
for rel in ['_plugins/site_module_assets.rb','Gemfile.lock','bin/coastal_static_light_inputs.cjs','bin/bake_coastal_static_light.cjs']:
    target=source/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,target)
changes={
'assets/js/home-scene/warm-practicals.mjs':[
 ('{ id: "gym", position: [8.6, 2.3, -0.4], night: 3, day: 0.5, distance: 3.5 }','{ id: "gym", position: [8.7, 2.9448975324630737, -0.9], night: 6, day: 0.5, distance: 3.5, emitterRadius: 0.04, anyHour: true }'),
 ('gym: ({ activity }) => (activity === "workout" ? 1 : 0.15)','gym: ({ activity, visit }) => (activity === "workout" || visit === "gym" ? 1 : 0.15)'),
 ('update(daylight, routine = null) {','update(daylight, routine = null, visit = null) {'),
 ('activity: routine.id, ...sleepWindow','activity: routine.id, visit, ...sleepWindow')],
'assets/js/home-scene/controller.mjs':[
 ('if (routine && daylight) {\n      const levels = lightInstallations?.update','if (routine && daylight) {\n      warmPracticals?.update(lightDaylight, { ...routine, schedule: routine.weekend ? config.weekend : config.weekday }, visit);\n      const levels = lightInstallations?.update'),
 ('    warmPracticals?.update(daylight.daylight, { ...routine, schedule: routine.weekend ? config.weekend : config.weekday });\n    updateInstallations();','    updateInstallations();')]
}
changes['assets/js/home-scene/light-installations.mjs']=[
 ('a: legacyPoint([6.55, 2.45, -2.2]), b: legacyPoint([7.8, 2.45, -2.2]), intensity: 1.1','a: legacyPoint([6.55, 2.45, -2.2]), b: legacyPoint([7.8, 2.45, -2.2]), intensity: 3.3'),
 ('a: legacyPoint([7.02, 2.935, -0.9]), b: legacyPoint([10.38, 2.935, -0.9]), intensity: 1.15','a: legacyPoint([7.02, 2.935, -0.9]), b: legacyPoint([10.38, 2.935, -0.9]), intensity: 3.45'),
 ('b: legacyPoint([10.78, 2.552, -2.65]),\n      intensity: 0.92','b: legacyPoint([10.78, 2.552, -2.65]),\n      intensity: 2.76')]
changes['assets/js/home-scene/realism.mjs']=[('  shareVertexColorProgram(m, mesh);','  shareVertexColorProgram(m, mesh);\n  // Opaque powder coat is a dielectric finish over metal.\n  if (name === "powder coated gym steel") { m.metalness = 0; m.roughness = 0.55; }')]
for rel,replacements in changes.items():
    p=source/rel;s=p.read_text(encoding='utf8')
    for before,after in replacements:
        assert s.count(before)==1,(rel,before,s.count(before));s=s.replace(before,after)
    p.write_text(s,encoding='utf8',newline='\n')
files={p.relative_to(source).as_posix():sha(p)for p in source.rglob('*')if p.is_file()}
(out/'SOURCE.json').write_text(json.dumps({'scope':'Complete current public geometry/runtime except four private visit-aware gym practical/task-light/finish modules. The single existing gym practical moves to the measured native long pendant midpoint[8.7,2.9448975324630737,7.1], emitterRadius0.04; the three existing neutral line-emitter powers are3times original and the opaque powder coating uses dielectric metalness0/roughness0.55; the existing long-pendant point peak is6 rather than3; unchanged3.5m cutoff, fixture count, native, extra pass, emitter shape or region changes. V1old-anchor mood remains too dark. Not an accepted mood or performance result.','rootHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'changes':changes,'files':files},indent=2)+'\n',encoding='utf8')
env=dict(os.environ,BUNDLE_PATH='C:/tools/site-gems-ruby33',NODE_PATH=str(root/'node_modules'))
command=['C:/tools/Ruby33/bin/ruby.exe','C:/tools/Ruby33/bin/bundle','exec','ruby',str(q/'compile-private-modules.rb'),str(source),str(built)]
with(out/'compile.log').open('wb')as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
shutil.copyfile(q/'private-serve-template.py',out/'serve.py')
with(out/'server.log').open('wb')as log:child=subprocess.Popen([sys.executable,str(out/'serve.py')],cwd=root,stdout=log,stderr=subprocess.STDOUT,creationflags=0x08000000)
for _ in range(100):
    if(out/'server.json').exists():break
    assert child.poll()is None;time.sleep(.1)
server=json.loads((out/'server.json').read_bytes());assert server['pid']==child.pid
with urllib.request.urlopen(server['url'],timeout=10)as response:assert response.headers['X-Sirui-Preview']==server['header']
env['COASTAL_CACHE_URL']=server['url'];command=[shutil.which('node'),str(source/'bin/bake_coastal_static_light.cjs')];start=time.monotonic()
with(out/'official-bake.log').open('wb')as log:r=subprocess.run(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'PROCESS.json').write_text(json.dumps({'exitCode':r.returncode,'seconds':time.monotonic()-start,'command':command,'server':server},indent=2)+'\n',encoding='utf8');assert r.returncode==0
cache=json.loads((source/'assets/models/home/static-light-field.json').read_bytes());stats=cache['statistics'];config=json.loads(cache['configuration'])
for name in ['manifest.json','static-light-field.json']:shutil.copyfile(source/'assets/models/home'/name,built/'assets/models/home'/name)
modules=json.loads((built/'assets/js/module-build.json').read_bytes())
for rel,row in modules['modules'].items():assert hashlib.sha256((source/rel).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==row['sourceSha256']and sha(built/rel)==row['outputSha256']
receipt={'server':server,'preROITriangles':stats['triangles']+stats['skippedTriangles'],'cacheBytes':(source/'assets/models/home/static-light-field.json').stat().st_size,'signature':cache['signature'],'regions':len(config['regions']),'probes':len(cache['probes']),'practicals':len(config['practicalSources']),'compiledModules':len(modules['modules']),'canonicalAllUnchanged':all(sha(root/rel)==h for rel,h in canonical.items())}
assert receipt['preROITriangles']<=750000 and receipt['cacheBytes']<=800000 and [receipt[k]for k in ['regions','probes','practicals']]==[16,128,28]and receipt['canonicalAllUnchanged']
(out/'CAPACITY-AND-CUSTODY.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');print(json.dumps(receipt,indent=2))
