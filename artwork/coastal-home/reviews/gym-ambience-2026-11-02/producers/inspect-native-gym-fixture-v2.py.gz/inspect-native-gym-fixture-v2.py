from pathlib import Path
import hashlib,json,sys,subprocess,time
q=Path(__file__).parent;root=Path.cwd();source=root/'artwork/coastal-home/coastal-home.blend'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
expected='1e10b25d5cf0eec87d7001acbf9d938d65ba33af6076380d5a8e5d45cf3d23e7'
if '--fixture-child' not in sys.argv:
    command=['D:/tools/blender-4.5.9-windows-x64/blender.exe','--background','--factory-startup','--python-exit-code','1','-t','4','--python',str(Path(__file__).resolve()),'--','--fixture-child']
    start=time.monotonic()
    with(q/'inspect-native-gym-fixture-v2.log').open('wb')as log:r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
    assert r.returncode==0
    print(json.dumps({'exitCode':r.returncode,'seconds':time.monotonic()-start}));sys.exit()
import bpy
from mathutils import Vector
from mathutils.bvhtree import BVHTree
assert bpy.app.version==(4,5,9)and sha(source)==expected
bpy.ops.wm.open_mainfile(filepath=str(source));deps=bpy.context.evaluated_depsgraph_get()
obj=bpy.data.objects['gym_pan_station__gym light diffuser']
point=Vector((7.175,-5.8,2.45));old=Vector((8.6,-7.6,2.3))
mesh=obj.data;mesh.calc_loop_triangles()
vertices=[obj.matrix_world@v.co for v in mesh.vertices]
triangles=[tuple(t.vertices)for t in mesh.loop_triangles]
bvh=BVHTree.FromPolygons(vertices,triangles,all_triangles=True)
edge_count={}
for triangle in triangles:
    for a,b in zip(triangle,triangle[1:]+triangle[:1]):
        key=tuple(sorted((a,b)));edge_count[key]=edge_count.get(key,0)+1
rays=[]
for axis in range(3):
    for sign in (-1,1):
        direction=Vector((0,0,0));direction[axis]=sign
        location,normal,index,distance=bvh.ray_cast(point,direction,2)
        assert location is not None and distance>0 and distance<1
        rays.append({'axis':axis,'sign':sign,'distance':distance,'triangle':index,'normal':list(normal)})
world=lambda p:[p[0],p[2],-p[1]]
points_world=[world(p)for p in vertices]
result={'scope':'Read-only canonical source fixture. Correct signed world axes supersede the mislabeled boundsWorld in V1; V1 remains retained. Six finite native rays and the closed source fixture establish this selected midpoint inside the actual thin LED. This is anchor proof, not a rendered lighting acceptance or performance result.','sourceSha256':expected,'producerSha256':sha(Path(__file__)),'owner':obj.name,'materials':[m.name if m else None for m in mesh.materials],'boundsNative':[[min(v[k]for v in vertices)for k in range(3)],[max(v[k]for v in vertices)for k in range(3)]],'boundsWorld':[[min(v[k]for v in points_world)for k in range(3)],[max(v[k]for v in points_world)for k in range(3)]],'closedEdges':all(count==2 for count in edge_count.values()),'chosenWorld':world(point),'oldWorld':world(old),'midpointToSurface':bvh.find_nearest(point)[3],'oldPointToFixture':bvh.find_nearest(old)[3],'sixFiniteRays':rays,'sourceUnchanged':sha(source)==expected}
assert result['closedEdges']and result['sourceUnchanged']
(q/'PUBLIC-GYM-NATIVE-FIXTURE-V2.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,indent=2))
