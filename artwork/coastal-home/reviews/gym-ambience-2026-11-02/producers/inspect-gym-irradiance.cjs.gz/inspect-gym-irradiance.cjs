const fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url');
(async()=>{
const root=process.cwd(),T=await import(pathToFileURL(path.join(root,'assets/js/three.module.min.js'))),{createLightInstallations}=await import(pathToFileURL(path.join(root,'assets/js/home-scene/light-installations.mjs')));
const config=JSON.parse(fs.readFileSync(path.join(root,'assets/models/home/manifest.json'))),lights=createLightInstallations(config),rows=[];
for(const daylight of [0,1]){lights.update({minute:1200,daylight,activity:'lounge',visit:'gym'});for(const p of [[8.5,.01,6.8],[8.5,.01,4.5],[9.2,1.1,6.5]])rows.push({daylight,position:p,normal:[0,1,0],irradiance:lights.irradianceAt(new T.Vector3(...p),new T.Vector3(0,1,0),'gym').toArray()});}
const receipt={scope:'CPU evaluation of actual existing gym line-emitter irradiance; no rendered-mood or performance claim.',rows};fs.writeFileSync(path.join(__dirname,'GYM-IRRADIANCE.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt,null,2));lights.dispose();
})().catch(e=>{console.error(e);process.exitCode=1;});
