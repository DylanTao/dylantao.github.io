const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {chromium,expect}=require('@playwright/test');
const root=process.cwd(),out=path.join(__dirname,'visit-lighting-capture-v3'),base="http://127.0.0.1:61417/al-folio/";
if(fs.existsSync(out))throw Error('Fresh evidence required');fs.mkdirSync(out);
const sourceRoot=path.join(__dirname,'private-visit-lighting-v3/source');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const errors=[],failed=[],responses=[],pending=[],rows=[];
const state=p=>p.locator('[data-home-desk-scene]').evaluate(e=>e.getSceneEvidence());
async function settle(p){let last;for(let k=0;k<90;k++){const e=await state(p);if(last&&!e.traveling&&Math.hypot(...e.camera.map((v,i)=>v-last[i]))<1e-5)return e;last=e.camera;await p.waitForTimeout(100);}throw Error('camera settling budget');}
(async()=>{const browser=await chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']});try{
const context=await browser.newContext({viewport:{width:2560,height:1440},deviceScaleFactor:1,timezoneId:'America/Los_Angeles',reducedMotion:'no-preference'}),p=await context.newPage();p.setDefaultTimeout(30000);
await p.route(/https:\/\/(?:analytics\.google\.com|www\.google-analytics\.com|www\.googletagmanager\.com|plausible\.io)\//,r=>r.fulfill({status:204,body:''}));
const mod=await(await context.request.get(base+'assets/js/module-build.json')).json();
for(const [rel,row]of Object.entries(mod.modules))expect(hash(fs.readFileSync(path.join(sourceRoot,rel)).toString().replaceAll('\r\n','\n'))).toBe(row.sourceSha256);
p.on('pageerror',e=>errors.push(e.message));p.on('console',m=>{if(m.type()==='error')errors.push(m.text());});p.on('requestfailed',r=>failed.push({url:r.url(),failure:r.failure()}));
p.on('response',r=>{if(!r.url().startsWith(base)||!/\.(?:mjs|glb|json)(?:\?|$)/.test(r.url()))return;pending.push((async()=>{try{const b=await r.body(),rel=decodeURIComponent(new URL(r.url()).pathname.slice(new URL(base).pathname.length));let exact;
if(mod.modules[rel])exact=hash(b)===mod.modules[rel].outputSha256;
else if(rel==='assets/js/module-build.json')exact=JSON.stringify(JSON.parse(b))===JSON.stringify(mod);
else {const expectedPath=path.join(sourceRoot,rel); const expected=fs.readFileSync(fs.existsSync(expectedPath)?expectedPath:path.join(root,rel));exact=rel.endsWith('.json')?JSON.stringify(JSON.parse(b))===JSON.stringify(JSON.parse(expected)):hash(b)===hash(expected);}
responses.push({path:rel,status:r.status(),bytes:b.length,sha256:hash(b),exact});}catch(e){responses.push({url:r.url(),error:String(e)});}})());});
await p.goto(base+'?quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});await p.evaluate(()=>document.fonts.ready);
await p.locator('[data-theme-toggle]:visible').first().click();await p.locator('[data-theme-mode-option="noon"]:visible').first().click();await p.locator('[data-theme-toggle]:visible').first().click();
await p.locator('[data-home-desk-mode="3d"]').click();const scene=p.locator('[data-home-desk-scene]');await scene.scrollIntoViewIfNeeded();await expect(scene).toHaveAttribute('data-scene-state','ready',{timeout:180000});await p.locator('[data-world-fullscreen]').click();
for(const mode of ['noon','evening']){
if(mode==='evening'){await p.locator('[data-world-exit]').click();await p.locator('[data-theme-toggle]:visible').first().click();await p.locator('[data-theme-mode-option="evening"]:visible').first().click();await p.locator('[data-theme-toggle]:visible').first().click();await p.locator('[data-world-fullscreen]').click();}
for(const room of ['gym','sleep']){await p.locator('[data-world-places]>summary').click();await p.locator(`[data-world-destination="${room}"]`).click();await expect.poll(async()=>(await state(p)).currentRoom).toBe(room);const e=await settle(p);await p.screenshot({path:path.join(out,mode+'-'+room+'.png')});rows.push({mode,room,evidence:e});console.log(JSON.stringify({mode,room,camera:e.camera}));
if(room==='gym') { let previous=e.camera; const canvas=scene.locator('canvas:not(.home-world-sketch)');
 for(const [index,dx,dy] of [[0,110,45],[1,-220,-45]]) { const b=await canvas.boundingBox(); expect(b).toBeTruthy();
 await p.mouse.move(b.x+b.width*.48,b.y+b.height*.46); await p.mouse.down();
 await p.mouse.move(b.x+b.width*.48+dx,b.y+b.height*.46+dy,{steps:12}); await p.mouse.up();
 const rotated=await settle(p); expect(Math.hypot(...rotated.camera.map((v,i)=>v-previous[i]))).toBeGreaterThan(.01); previous=rotated.camera;
 await p.screenshot({path:path.join(out,mode+'-'+room+'-turn-'+index+'.png')}); rows.push({mode,room,turn:index,evidence:rotated});
 }
}}}
await Promise.all(pending);const receipt={scope:'Actual complete private visit-aware gym control at native2K/high/fixed, unchanged canonical geometry and all189 compiled modules. Normal clocks, no authoring lab or Pause. Public theme/Rooms/fullscreen only; startup is not a performance measure. Exact source/module inventory and all requested scene bodies checked. Exactly four private runtime modules are changed: visited lamp/three existing task lines/opaque powder-coat dielectric finish; cache is an official new bake. The existing gym point is at its actual modeled short pendant midpoint. No Lab, Pause, source/model/module response replacements or reduced fixture. V1capture failed only its missing local pip-source expected-body lookup; all original files remain retained. Non-home model bodies are checked against their unchanged canonical source.',base,at:new Date().toISOString(),rows,errors,failed,responses};fs.writeFileSync(path.join(out,'CAPTURE.json'),JSON.stringify(receipt,null,2)+'\n');expect(errors).toEqual([]);expect(failed).toEqual([]);expect(responses.filter(r=>r.error||!r.exact||r.status>=400)).toEqual([]);await context.close();
}finally{await browser.close();}})().catch(e=>{fs.writeFileSync(path.join(out,'FAILURE.json'),JSON.stringify({error:String(e),rows,errors,failed,responses},null,2));console.error(e);process.exitCode=1;});
