from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,urllib.request
root=Path.cwd();q=Path(__file__).parent;out=q/'daylight-live-v1';assert not out.exists();out.mkdir()
head='116bcc675df26fc0e287ce80088d50f1f58ebddc';pages='024533714bdf426dc3a7abedee8abd28d04f995c'
run=lambda args:subprocess.check_output(args,cwd=root);sha=lambda b:hashlib.sha256(b).hexdigest();subject=run(['git','log','-1','--format=%s',pages]).decode().strip();assert head in subject
rows=[]
for rel in ['index.html','blog/index.html','assets/css/main.css','assets/js/brand-orange.js','assets/js/module-build.json','assets/img/favicon.svg','assets/models/home/manifest.json','assets/models/home/static-light-field.json','assets/models/home/room-kitchen.glb','assets/js/home-scene/controller.mjs','assets/js/home-scene/diffuse-paths.mjs','assets/js/home-scene/interior-exposure.mjs']:
    expected=run(['git','show',pages+':'+rel]);url='https://dylantao.github.io/'+(''if rel=='index.html'else rel)+'?delivery='+head
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Sirui-site-deployment-verification'}),timeout=45)as response:body=response.read();status=response.status
    row={'path':rel,'url':url,'status':status,'bytes':len(body),'sha256':sha(body),'expectedSha256':sha(expected),'exact':body==expected};rows.append(row)
    (out/'PROGRESS.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8');assert status==200 and row['exact'],row
    if rel=='assets/js/module-build.json':
        modules=json.loads(body)['modules'];assert len(modules)==192
        for name,record in modules.items():
            assert sha(run(['git','show',head+':'+name]).replace(b'\r\n',b'\n'))==record['sourceSha256'],name
            assert sha(run(['git','show',pages+':'+name]))==record['outputSha256'],name
    if rel=='assets/models/home/static-light-field.json':assert row['sha256']=='c6bca92a56e27fc2ba88b91331b959c0ccedfb8efb07beb4e946cdfdd02f0cb9'
record={'at':datetime.now(timezone.utc).isoformat(),'sourceHead':head,'pagesHead':pages,'pagesSubject':subject,'compiledSourceAndOutputBindings':len(modules),'responses':rows,'scope':'Exact current published study daylight readback against pinned main/Pages commits, independently of later dirty subject-metering work. CI and actual UI acceptance are separate receipts.'}
(out/'DELIVERY.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');print(json.dumps({'responses':len(rows),'compiledModules':len(modules),'pages':pages,'source':head}))
