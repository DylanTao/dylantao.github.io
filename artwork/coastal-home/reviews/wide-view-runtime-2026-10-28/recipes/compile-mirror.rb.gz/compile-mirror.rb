require 'jekyll'
require 'json'
require 'digest'
require 'fileutils'
load './_plugins/site_module_assets.rb'
q=File.join(Dir.pwd,'.jekyll-cache/visual-qa/wide-view-20261028')
site=File.join(q,'site/al-folio')
files=%w[assets/js/home-scene/controller.mjs assets/js/home-scene/realism.mjs assets/js/home-scene/reflection.mjs assets/js/home-scene/environment.mjs]
receipt_path=File.join(site,'assets/js/module-build.json')
receipt=JSON.parse(File.read(receipt_path,encoding:'UTF-8'))
files.each do |name|
  base=File.join(q,'base-modules',name)
  FileUtils.mkdir_p(File.dirname(base))
  FileUtils.cp(File.join(site,name),base) if File.exist?(File.join(site,name)) && !File.exist?(base)
  source=File.read(name,encoding:'UTF-8').gsub("\r\n","\n")
  content=SiruiSite::ModuleAssets.compile(source)
  File.binwrite(File.join(site,name),content)
  receipt['modules'][name]={'sourceSha256'=>Digest::SHA256.hexdigest(source),'outputSha256'=>Digest::SHA256.hexdigest(content),'bytes'=>content.bytesize}
end
receipt['modules'].delete('assets/js/home-scene/static-batching.mjs')
FileUtils.rm_f(File.join(site,'assets/js/home-scene/static-batching.mjs'))
File.binwrite(receipt_path,JSON.generate(receipt)+"\n")
puts files.join("\n")
