const {chromium,expect}=require('@playwright/test');
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=process.cwd(),q=__dirname,h=b=>crypto.createHash('sha256').update(b).digest('hex');
const{preparePage}=require('../../../test/visual/helpers.js');
const models=path.join(root,'.jekyll-cache/visual-qa/house-final-2026-10-28/f6-v183-arrival-control-20261101/models');
(async()=>{const browser=await chromium.launch({args:['--use-angle=d3d11','--ignore-gpu-blocklist']});try{
 const page=await browser.newPage({viewport:{width:2560,height:1440},deviceScaleFactor:1,reducedMotion:'no-preference'}),errors=[],bindings=[];
 page.on('pageerror',e=>errors.push(e.message));page.setDefaultTimeout(240000);
 await preparePage(page,'noon');
 const raw=fs.readFileSync(path.join(root,'assets/js/home-scene/controller.mjs'),'utf8');
 const anchor='    pacific?.invalidateReflection?.();\n    return root;';
 if(raw.split(anchor).length!==2)throw Error('Prepare-model anchor changed');
 const productionCall='    configureStaticModelIndices(root, style);';
 const observed=raw.includes(productionCall)?raw.replace(productionCall,''):raw;
 const controller='import { controlRoot } from "./triangle-index-control.mjs";\n'+observed.replace(anchor,'    controlRoot(root, style);\n'+anchor);
 const light=fs.readFileSync(path.join(root,'assets/js/home-scene/static-light-field.mjs'),'utf8'),needle='    if (potential > maxTriangles)';
 if(light.split(needle).length!==2)throw Error('Collector anchor changed');
 const observer=light.replace(needle,'    globalThis.__indexCollector={potential,maxTriangles,meshes:meshes.map(({mesh,groups})=>({name:mesh.name,triangles:groups.reduce((n,g)=>n+Math.floor(g.count/3),0)}))};\n'+needle);
 fs.writeFileSync(path.join(q,'controller-observer.mjs'),controller);fs.writeFileSync(path.join(q,'field-observer.mjs'),observer);
 for(const [name,body] of [['controller.mjs',controller],['static-light-field.mjs',observer],['triangle-index-control.mjs',fs.readFileSync(path.join(q,'production-control-wrapper.mjs'))],['static-triangle-index.mjs',fs.readFileSync(path.join(root,'assets/js/home-scene/static-triangle-index.mjs'))]])
  await page.route('**/assets/js/home-scene/'+name+'*',r=>r.fulfill({body,contentType:'text/javascript'}));
 await page.route('**/assets/models/home/**',async r=>{const name=decodeURIComponent(new URL(r.request().url()).pathname).split('/').pop();if(!/^[a-zA-Z0-9_.-]+$/.test(name))return r.continue();const file=path.join(models,name);if(!fs.existsSync(file))return r.continue();let body=fs.readFileSync(file);bindings.push({name,bytes:body.length,sha256:h(body)});if(name==='manifest.json'){const m=JSON.parse(body);delete m.staticLightFieldCache;body=Buffer.from(JSON.stringify(m));}await r.fulfill({body,contentType:name.endsWith('.json')?'application/json':'model/gltf-binary'});});
 await page.goto('http://127.0.0.1:4202/al-folio/?scene-lab=1&quality=high&resolution=fixed&weather=clear',{waitUntil:'domcontentloaded'});
 await page.locator('[data-home-desk-mode="3d"]').click();const scene=page.locator('[data-home-desk-scene]');await scene.scrollIntoViewIfNeeded();
 await page.waitForFunction(()=>globalThis.__indexCollector);
 await expect(scene).toHaveAttribute('data-scene-state','ready',{timeout:240000});
 const ui=page.locator('[data-home-world-controls]');
 await ui.locator('[data-world-fullscreen]').click();
 const more=ui.locator('details').filter({has:page.locator('[data-world-pause]')});
 if(!await more.evaluate(e=>e.open))await more.locator(':scope > summary').click();
 if(!await ui.locator('[data-world-pause]').evaluate(e=>e.getAttribute('aria-pressed')==='true'))await ui.locator('[data-world-pause]').click({timeout:10000});
 if(await more.evaluate(e=>e.open))await more.locator(':scope > summary').click();
 await scene.evaluate(e=>e.setLabCamera({target:[0,1.5,6],yaw:3.48,pitch:.15,radius:35,free:true}));
 await page.waitForTimeout(2500);
 const pose=await scene.evaluate(e=>e.getSceneEvidence());
 const capture=async(name)=>{await scene.evaluate((e,p)=>e.setLabCamera(p),{target:pose.target,...pose.cameraOrbit,free:true});await page.waitForTimeout(350);return scene.locator('canvas').screenshot({path:path.join(q,name+'.png')})};
 await page.evaluate(()=>{for(const {mesh,source}of globalThis.__filledTriangleMeshes)mesh.geometry=source;});
 const originalPixels=await capture('original-indices-paused-2k');
 const originalRepeat=await capture('original-indices-repeat-paused-2k');
 await page.evaluate(()=>{for(const {mesh,control}of globalThis.__filledTriangleMeshes)mesh.geometry=control.geometry;});
 const filteredPixels=await capture('filtered-indices-paused-2k');
 const{PNG}=require('pngjs'),a=PNG.sync.read(originalPixels),b=PNG.sync.read(filteredPixels),repeat=PNG.sync.read(originalRepeat);let pixelDifferences=0,maxChannelDifference=0,baselineRepeatDifferences=0,baselineRepeatMax=0;
 for(let i=0;i<a.data.length;i++)if(a.data[i]!==b.data[i]){pixelDifferences++;maxChannelDifference=Math.max(maxChannelDifference,Math.abs(a.data[i]-b.data[i]));}
 for(let i=0;i<a.data.length;i++)if(a.data[i]!==repeat.data[i]){baselineRepeatDifferences++;baselineRepeatMax=Math.max(baselineRepeatMax,Math.abs(a.data[i]-repeat.data[i]));}
 // A separate diagnostic forces already loaded candidates into the render traversal solely to
 // record each actual linked shader. It is not an appearance or navigation acceptance frame.
 await page.evaluate(async()=>{const THREE=await import('/al-folio/assets/js/three.module.min.js'),renderer=globalThis.__indexRenderer,target=renderer.getRenderTarget(),probe=new THREE.WebGLRenderTarget(8,8),scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(45,1,.01,1000);camera.position.set(0,10,40);camera.lookAt(0,1,0);for(const{mesh,control}of globalThis.__filledTriangleMeshes){const clone=new THREE.Mesh(control.geometry,mesh.material);clone.matrixAutoUpdate=false;clone.matrix.copy(mesh.matrixWorld);clone.frustumCulled=false;clone.onAfterRender=mesh.onAfterRender;scene.add(clone);}renderer.setRenderTarget(probe);renderer.render(scene,camera);renderer.setRenderTarget(target);probe.dispose();});
 const result=await page.evaluate(()=>({collector:globalThis.__indexCollector,evidence:document.querySelector('[data-home-desk-scene]').getSceneEvidence(),controls:(globalThis.__filledTriangleMeshes||[]).map(({mesh,source,control})=>({name:mesh.name,removed:control.removed,sourceTriangles:control.sourceTriangles,originalIndexCount:source.index.count,triangles:control.geometry.index.count/3,attributesUnchanged:Object.keys(source.attributes).every(k=>source.attributes[k]===control.geometry.attributes[k]),attributes:Object.entries(source.attributes).map(([name,a])=>({name,type:a.array.constructor.name,count:a.count,itemSize:a.itemSize,normalized:a.normalized})),programs:[...(control.programs?.values()||[])]}))}));
 fs.writeFileSync(path.join(q,'actual-production-control.json'),JSON.stringify({scope:'Private actual decoded183+arrival complete product using exact production index module. No native/cache admission or timing claim. Separate8x8diagnostic draws bind linked shader sources for hidden roofs/LODs; they are not appearance captures.',pixelDifferences,maxChannelDifference,baselineRepeatDifferences,baselineRepeatMax,originalPixelsSha256:h(originalPixels),originalRepeatSha256:h(originalRepeat),filteredPixelsSha256:h(filteredPixels),pose,controllerOriginalSha256:h(raw),controllerObserverSha256:h(controller),helperSha256:h(fs.readFileSync(path.join(root,'assets/js/home-scene/static-triangle-index.mjs'))),wrapperSha256:h(fs.readFileSync(path.join(q,'production-control-wrapper.mjs'))),bindings,errors,...result},null,2));
 await scene.locator('canvas').screenshot({path:path.join(q,'control-2k.png')});
 console.log(JSON.stringify({collector:result.collector.potential,budget:result.collector.maxTriangles,removed:result.controls.reduce((n,r)=>n+r.removed,0),controls:result.controls.length,drawn:result.controls.filter(r=>r.programs.length).length,attributesUnchanged:result.controls.every(r=>r.attributesUnchanged),pixelDifferences,maxChannelDifference,baselineRepeatDifferences,baselineRepeatMax,errors}));
 expect(errors).toEqual([]);expect(result.collector.potential).toBeLessThanOrEqual(result.collector.maxTriangles);expect(result.controls.every(r=>r.attributesUnchanged)).toBe(true);
}finally{await browser.close()}})().catch(e=>{console.error(e);process.exitCode=1});
