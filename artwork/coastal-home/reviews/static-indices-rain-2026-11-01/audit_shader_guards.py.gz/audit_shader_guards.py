import json, re, hashlib
from pathlib import Path

q = Path(__file__).resolve().parent
proof = json.loads((q / 'actual-production-control.json').read_text(encoding='utf-8'))
disabled = {'USE_MORPHTARGETS', 'USE_MORPHNORMALS', 'USE_MORPHCOLORS', 'USE_INSTANCING', 'USE_INSTANCING_MORPH', 'USE_BATCHING'}
def condition_value(expression):
    # Three-valued boolean evaluation. Only the explicitly disabled features are known false;
    # every other macro stays unknown. Unsupported expressions also remain unknown, never false.
    expression = re.sub(r'\bdefined\s*(?:\(\s*(\w+)\s*\)|(\w+))', lambda m: '0' if (m[1] or m[2]) in disabled else '?', expression)
    tokens = re.findall(r'&&|\|\||[01?!()]', expression)
    if re.sub(r'&&|\|\||[01?!()\s]', '', expression):
        return None
    cursor = 0
    def atom():
        nonlocal cursor
        if cursor >= len(tokens): raise ValueError()
        t=tokens[cursor]; cursor+=1
        if t=='!':
            value=atom(); return None if value is None else not value
        if t=='(':
            value=disjunction()
            if cursor>=len(tokens) or tokens[cursor]!=')': raise ValueError()
            cursor+=1; return value
        if t not in ('0','1','?'): raise ValueError()
        return {'0':False,'1':True,'?':None}[t]
    def conjunction():
        nonlocal cursor
        value=atom()
        while cursor<len(tokens) and tokens[cursor]=='&&':
            cursor+=1; right=atom(); value=False if value is False or right is False else True if value is True and right is True else None
        return value
    def disjunction():
        nonlocal cursor
        value=conjunction()
        while cursor<len(tokens) and tokens[cursor]=='||':
            cursor+=1; right=conjunction(); value=True if value is True or right is True else False if value is False and right is False else None
        return value
    try:
        result=disjunction()
        return result if cursor==len(tokens) else None
    except ValueError:
        return None
assert condition_value('defined(USE_MORPHCOLORS) && defined(TEXTURE)') is False
assert condition_value('defined(TEXTURE) || defined(USE_MORPHTARGETS)') is None
assert condition_value('!defined(USE_INSTANCING)') is True
shader_rows = {}
for control in proof['controls']:
    assert control['programs'], control['name']
    assert control['attributesUnchanged'], control['name']
    for program in control['programs']:
        for shader in program:
            source = shader['source']
            digest = hashlib.sha256(source.encode()).hexdigest()
            if digest in shader_rows:
                continue
            defines = set(re.findall(r'^\s*#\s*define\s+(\w+)', source, re.M))
            assert not defines.intersection(disabled), sorted(defines.intersection(disabled))
            frames = []
            witnesses = []
            for line_number, line in enumerate(source.splitlines(), 1):
                directive = re.match(r'\s*#\s*(ifdef|ifndef|if|else|elif|endif)\b\s*(.*)', line)
                if directive:
                    kind, condition = directive.groups()
                    if kind in ('ifdef', 'ifndef'):
                        known = condition.strip() in disabled
                        inactive = known and kind == 'ifdef'
                        frames.append({'known': known, 'inactive': inactive, 'condition': kind + ' ' + condition})
                    elif kind == 'if':
                        value = condition_value(condition)
                        frames.append({'known': value is not None, 'inactive': value is False, 'condition': 'if ' + condition})
                    elif kind == 'else':
                        assert frames
                        frames[-1]['inactive'] = frames[-1]['known'] and not frames[-1]['inactive']
                    elif kind == 'elif':
                        assert frames
                        frames[-1]['known'] = False
                        frames[-1]['inactive'] = False
                    else:
                        assert frames
                        frames.pop()
                if re.search(r'\bgl_(VertexID|InstanceID|DrawID|PrimitiveID)\b', line):
                    guards = [frame['condition'] for frame in frames if frame['inactive']]
                    assert guards, (control['name'], line_number, line)
                    witnesses.append({'line': line_number, 'text': line.strip(), 'inactiveGuards': guards})
            assert not frames
            shader_rows[digest] = {'type': shader['type'], 'sha256': digest, 'inactiveIndexBuiltinWitnesses': witnesses}
assert proof['pixelDifferences'] == proof['maxChannelDifference'] == 0
assert proof['baselineRepeatDifferences'] == proof['baselineRepeatMax'] == 0
assert proof['errors'] == []
report = {'scope': 'Actual static mesh linked vertex/fragment shader sources, including separately qualified hidden roof/LOD diagnostic draws. Every index builtin is inside an undefined morph/instancing/batching branch; no active index dependence. This is a current pinned shader-family proof, not a future arbitrary-shader guarantee.', 'productionModuleSha256': proof['helperSha256'], 'sourceProofSha256': hashlib.sha256((q / 'actual-production-control.json').read_bytes()).hexdigest(), 'meshes': len(proof['controls']), 'uniqueLinkedShaders': len(shader_rows), 'shaders': list(shader_rows.values()), 'pixelDifferences': 0, 'budget': proof['collector']['maxTriangles'], 'actualPreRoiTriangles': proof['collector']['potential']}
(q / 'production-shader-guards.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({key: report[key] for key in ('meshes', 'uniqueLinkedShaders', 'pixelDifferences', 'actualPreRoiTriangles', 'budget')}))
