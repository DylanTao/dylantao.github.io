import { configureStaticTriangleIndices } from "./static-triangle-index.mjs";
export function controlRoot(root, style) {
  root.traverse(mesh => {
    if (!mesh.isMesh) return;
    const beforeGeometry = mesh.geometry;
    const result = configureStaticTriangleIndices(mesh, style, {indexIndependentShaders:true});
    if (!result || mesh.userData.productionIndexObserver) return;
    mesh.userData.productionIndexObserver=true;
    const source=beforeGeometry, control={geometry:mesh.geometry,...result,programs:new Map()};
    globalThis.__filledTriangleMeshes ||= [];
    globalThis.__filledTriangleMeshes.push({mesh,source,control});
    const before=mesh.onAfterRender;
    mesh.onAfterRender=function(renderer,...args){
      before?.call(this,renderer,...args);globalThis.__indexRenderer=renderer;
      const gl=renderer.getContext(),program=gl.getParameter(gl.CURRENT_PROGRAM);
      if(!control.programs.has(program))control.programs.set(program,gl.getAttachedShaders(program).map(shader=>({type:gl.getShaderParameter(shader,gl.SHADER_TYPE),source:gl.getShaderSource(shader)})));
    };
  });
}
