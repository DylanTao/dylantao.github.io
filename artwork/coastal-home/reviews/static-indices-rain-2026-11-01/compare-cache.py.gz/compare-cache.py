import hashlib, json
from pathlib import Path
q=Path(__file__).resolve().parent
root=q.parents[2]
a=json.loads((q/'cache-before-official.json').read_text(encoding='utf-8'))
b=json.loads((root/'assets/models/home/static-light-field.json').read_text(encoding='utf-8'))
same={key:a[key]==b[key] for key in ('version','configuration','probes','transport','moments')}
assert all(same.values()),same
m=json.loads((q/'manifest-before-official.json').read_text(encoding='utf-8'))
n=json.loads((root/'assets/models/home/manifest.json').read_text(encoding='utf-8'))
m.pop('staticLightFieldCache',None);n.pop('staticLightFieldCache',None)
assert m==n
proof={'same':same,'nativeMasterSha256':hashlib.sha256((root/'artwork/coastal-home/coastal-home.blend').read_bytes()).hexdigest(),'cacheSha256':hashlib.sha256((root/'assets/models/home/static-light-field.json').read_bytes()).hexdigest(),'signature':b['signature'],'dependencies':len(b['inputs']['dependencies']),'statisticsBefore':a['statistics'],'statisticsAfter':b['statistics'],'manifestOutsideDescriptorExact':True}
(q/'cache-preservation.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(proof))
