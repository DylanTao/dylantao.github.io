from pathlib import Path
import hashlib
import json
import math
from urllib.parse import urlparse

q = Path(__file__).resolve().parent
root = Path.cwd()
before = json.loads((q / 'before-v3/CAPTURE.json').read_bytes())
after = json.loads((q / 'candidate-v3/CAPTURE.json').read_bytes())
assert len(before['rows']) == len(after['rows']) == 12
def models(capture):
    return {urlparse(row['url']).path: row['sha256'] for row in capture['responses'] if urlparse(row['url']).path.endswith('.glb')}
left, right = models(before), models(after)
before_avatar = before['rows'][0]['evidence']['avatarId']
after_avatar = after['rows'][0]['evidence']['avatarId']
assert set(left)-set(right) == {f'/al-folio/assets/models/home/sirui-{before_avatar}.glb'}
assert set(right)-set(left) == {f'/al-folio/assets/models/home/sirui-{after_avatar}.glb'}
assert all(left[key] == right[key] for key in set(left)&set(right))
for bodies in [left, right]:
    for url, digest in bodies.items():
        source = root / url.removeprefix('/al-folio/')
        assert hashlib.sha256(source.read_bytes()).hexdigest() == digest
rows = []
for old, new in zip(before['rows'], after['rows']):
    assert old['id'] == new['id']
    assert old['paused'] == new['paused'] == 'true'
    delta = max(abs(a-b) for a,b in zip(old['evidence']['camera'], new['evidence']['camera']))
    assert delta <= .00001
    for capture in [old, new]:
        assert capture['evidence']['canvasWidth'] == 2560
        assert capture['evidence']['canvasHeight'] == 1440
        assert capture['evidence']['quality']['tier'] == 'high'
        assert capture['evidence']['simulation']['lightField']['cacheHit']
        assert capture['clocks']['pwClock'] is False
        assert '[native code]' in capture['clocks']['Date']
        assert '[native code]' in capture['clocks']['performance']
        assert '[native code]' in capture['clocks']['raf']
    rows.append({'id': old['id'], 'cameraDifferenceMaxM': delta,
                 'beforePngSha256': hashlib.sha256((q / 'before-v3' / (old['id']+'.png')).read_bytes()).hexdigest(),
                 'afterPngSha256': hashlib.sha256((q / 'candidate-v3' / (new['id']+'.png')).read_bytes()).hexdigest()})
for capture in [before, after]:
    for prefix in ['noon-lounge', 'noon-library-upper', 'evening-lounge', 'evening-library-upper']:
        yaws = [row['evidence']['cameraOrbit']['yaw'] for row in capture['rows'] if row['id'].startswith(prefix)]
        assert len(yaws) == 3
        assert min(abs(math.remainder(a-b, 2*math.pi)) for i,a in enumerate(yaws) for b in yaws[i+1:]) > .1
    assert not capture['errors'] and not capture['requests']
material_rows = []
for name in before['names']:
    old = [draw for row in before['rows'] for draw in row['draws'] if draw['material'] == name]
    new = [draw for row in after['rows'] for draw in row['draws'] if draw['material'] == name]
    assert old and new
    assert all(draw['woodGrowth'] for draw in old)
    assert all(not draw['woodGrowth'] for draw in new)
    material_rows.append({'name': name, 'beforeRoughness': sorted(set(draw['roughness'] for draw in old)),
                          'afterRoughness': sorted(set(draw['roughness'] for draw in new)),
                          'beforeObservedDraws': len(old), 'afterObservedDraws': len(new)})
result = {'scope': 'Matched native cameras, actual2K buffers/high tier, native clocks, public controls, unchanged complete served model family and actual paper shader change. The live clock/actor/wildlife are not pixel-frozen; there is no pixel-parity or performance claim.',
          'sourceCommit': '7953d0e2c4509f53d8dc20c4d9d3885c8a994470', 'identicalSharedModelResponses': len(set(left)&set(right)),
          'selectedAvatars': {'before': before_avatar, 'after': after_avatar, 'limit': 'The ordinary per-visit avatar choice was not pinned. Shared house models are exact; each selected rig matches its current authored body. No avatar/pose/pixel parity is claimed.'},
          'materials': material_rows, 'rows': rows}
(q / 'NATIVE-COMPARISON.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf8')
print(json.dumps({'matchedViews': len(rows), 'identicalSharedModelResponses': len(set(left)&set(right)), 'avatars': [before_avatar, after_avatar], 'materials': material_rows}))
