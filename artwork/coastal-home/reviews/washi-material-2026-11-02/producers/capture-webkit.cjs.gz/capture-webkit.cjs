const http=require('node:http');
globalThis.__washiProxyErrors=[];
const proxy=http.createServer((req,res)=>{const upstream=http.request({host:'host.docker.internal',port:63447,path:req.url,method:req.method,headers:req.headers},response=>{res.writeHead(response.statusCode,response.headers);response.pipe(res);});upstream.on('error',e=>{globalThis.__washiProxyErrors.push(String(e));res.writeHead(502);res.end('Preview proxy failed');});req.pipe(upstream);});
globalThis.__washiProxy=proxy;
proxy.listen(8424,'127.0.0.1',()=>{proxy.unref();process.env.WASHI_BASE_URL='http://127.0.0.1:8424/al-folio/';require('./capture-webkit-inner.cjs');});
