from pathlib import Path
import hashlib
import json
import shutil
import subprocess

root = Path.cwd()
q = Path(__file__).resolve().parent
for relative in ['assets/models/home/static-light-field.json', 'assets/models/home/manifest.json']:
    shutil.copyfile(root / relative, q / ('before-' + Path(relative).name))
receipt = {'sourceCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
           'nativeSourceSha256': hashlib.sha256((root / 'artwork/coastal-home/coastal-home.blend').read_bytes()).hexdigest(),
           'before': [], 'candidate': []}
for relative in ['assets/js/home-scene/materials.mjs', 'assets/js/home-scene/realism.mjs']:
    before = subprocess.check_output(['git', 'show', 'HEAD:' + relative])
    candidate = (root / relative).read_bytes()
    (q / ('before-' + Path(relative).name)).write_bytes(before)
    (q / ('candidate-' + Path(relative).name)).write_bytes(candidate)
    receipt['before'].append({'path': relative, 'sha256': hashlib.sha256(before).hexdigest()})
    receipt['candidate'].append({'path': relative, 'sha256': hashlib.sha256(candidate).hexdigest()})
(q / 'SOURCE.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
shutil.copyfile(root / '.jekyll-cache/visual-qa/final-house-integration-20261102/WASH-MATERIAL-SURVEY.json', q / 'WASH-MATERIAL-SURVEY.json')
