from pathlib import Path
import hashlib
import json
from urllib.parse import urlparse
from urllib.request import urlopen, Request

q = Path(__file__).resolve().parent
root = Path.cwd()
build = q / 'site/al-folio'
capture = json.loads((q / 'candidate-webkit-v3/FAILURE.json').read_bytes())
assert capture['error'] == 'Error: Runtime or response errors'
assert capture['errors'] == [] and capture['requests'] == []
assert len(capture['rows']) == 4
bad = [row for row in capture['responses'] if row.get('error') or row.get('status', 0) >= 400]
assert len(bad) == 1
assert urlparse(bad[0]['url']).path == '/al-folio/assets/img/publication_preview/physion.mp4'
assert 'Missing content of resource for given requestId' in bad[0]['error']
rows = []
names = set()
for row in capture['rows']:
    e = row['evidence']
    assert e['canvasWidth'] == 390 and e['canvasHeight'] == 1000
    assert e['quality']['tier'] == 'high' and e['quality']['pinned']
    assert e['roomCount'] == 10 and e['actorCount'] == 1
    assert row['paused'] == 'true' and row['clocks']['pwClock'] is False
    assert all('[native code]' in row['clocks'][key] for key in ['Date', 'performance', 'raf'])
    assert e['simulation']['lightField']['cacheHit']
    assert row['draws']
    for draw in row['draws']:
        assert draw['woodGrowth'] is False
        assert draw['viewport'][2:] == draw['buffer'] == [390, 1000]
        names.add(draw['material'])
    rows.append({'id': row['id'], 'rooms': e['roomCount'], 'actors': e['actorCount'], 'buffer': [390, 1000],
                 'msaaSamples': e['rendering']['msaaSamples'], 'resolutionFactor': e['resolution']['factor'],
                 'actualPaperDraws': len(row['draws'])})
assert names == {'washi lantern paper', 'private living washi diffuser'}
bindings = []
text_decodings = []
whole_response_bindings = []
for response in capture['responses']:
    if response in bad:
        continue
    relative = urlparse(response['url']).path.removeprefix('/al-folio/')
    file = (build / relative).resolve()
    assert file.is_relative_to(build.resolve())
    if not file.is_file():
        continue
    raw = file.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if digest != response['sha256']:
        assert raw.startswith(b'\xef\xbb\xbf')
        assert len(raw)-3 == response['bytes']
        assert hashlib.sha256(raw[3:]).hexdigest() == response['sha256'], relative
        text_decodings.append({'path': relative, 'rawBytes': len(raw), 'observedBodyBytes': response['bytes'],
                               'rawSha256': digest, 'observedBodySha256': response['sha256'], 'transform': 'Exactly one leading UTF8 BOM omitted by the browser body protocol'})
    else:
        whole_response_bindings.append({'path': relative, 'sha256': digest})
    if relative.endswith(('.mjs', '.glb', '.json')):
        assert hashlib.sha256(file.read_bytes()).hexdigest() == response['sha256'], relative
        bindings.append({'path': relative, 'sha256': response['sha256']})
video = 'assets/img/publication_preview/physion.mp4'
with urlopen(Request('http://127.0.0.1:63447/al-folio/' + video, headers={'Cache-Control': 'no-cache'}), timeout=45) as response:
    body = response.read()
    media = {'status': response.status, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
assert body == (build / video).read_bytes() == (root / video).read_bytes()
assert media['status'] == 200
result = {'scope': 'Four completed modern WebKit software phone renders, actual full-buffer paper beauty shaders, normal public touch/fullscreen/Rooms/Pause and full house. This post-capture qualification does not change the original strict collector exit1. The sole body-observer failure is an offscreen streaming MP4; independent full HTTP read verifies exact served media. It does not establish the bytes delivered into that browser media stream or physical-phone performance.',
          'rawCaptureSha256': hashlib.sha256((q / 'candidate-webkit-v3/FAILURE.json').read_bytes()).hexdigest(),
          'pageErrors': [], 'failedRequests': [], 'unresolvedObserverResponses': bad,
          'independentMediaRead': media, 'exactSceneResponseObservations': len(bindings), 'sceneResponseBindings': bindings,
          'wholeResponseBindings': whole_response_bindings, 'textBodyDecodings': text_decodings, 'views': rows}
(q / 'WEBKIT-QUALIFICATION.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf8')
print(json.dumps({'completedViews': len(rows), 'pageErrors': [], 'requestFailures': [], 'exactSceneObservations': len(bindings), 'strictCollectorExit': 1, 'independentMedia': media}))
