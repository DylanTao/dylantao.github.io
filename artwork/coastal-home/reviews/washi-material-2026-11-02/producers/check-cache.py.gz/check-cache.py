from pathlib import Path
import hashlib
import json

root = Path.cwd()
q = Path(__file__).resolve().parent
before_manifest = json.loads((q / 'before-manifest.json').read_bytes())
after_manifest = json.loads((root / 'assets/models/home/manifest.json').read_bytes())
before_manifest.pop('staticLightFieldCache')
descriptor = after_manifest.pop('staticLightFieldCache')
assert before_manifest == after_manifest
before = json.loads((q / 'before-static-light-field.json').read_bytes())
after_bytes = (root / 'assets/models/home/static-light-field.json').read_bytes()
after = json.loads(after_bytes)
keys = sorted(set(before) | set(after))
changed = [key for key in keys if before.get(key) != after.get(key)]
assert set(changed) <= {'inputs', 'signature', 'statistics'}, changed
assert hashlib.sha256(after_bytes).hexdigest() == descriptor['sha256']
assert len(after_bytes) <= 800000
assert after['signature'] == descriptor['signature']
assert hashlib.sha256((root / 'artwork/coastal-home/coastal-home.blend').read_bytes()).hexdigest() == '1e10b25d5cf0eec87d7001acbf9d938d65ba33af6076380d5a8e5d45cf3d23e7'
result = {'scope': 'Official producer only; all authored geometry metadata and native source exact. Every cached transport and moment value unchanged; only inputs/signature/statistics differ.',
          'cacheBytes': len(after_bytes), 'cacheSha256': descriptor['sha256'], 'signature': descriptor['signature'],
          'changedSnapshotKeys': changed, 'statistics': after['statistics']}
(q / 'CACHE.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf8')
print(json.dumps({'bytes': len(after_bytes), 'changed': changed, 'signature': descriptor['signature']}))
