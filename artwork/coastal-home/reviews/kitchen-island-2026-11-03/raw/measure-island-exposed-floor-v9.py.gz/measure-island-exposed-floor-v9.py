import bpy, gzip, hashlib, json, math
from pathlib import Path
from mathutils import Vector
Q=Path(r'C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/coffee-contact-v6/pavilion-breakfast-v1');old=json.loads(gzip.decompress((Q/'ISLAND-AISLE-NATIVE-CENSUS-V2.json.gz').read_bytes()));r=json.loads((Q/'island-width-control-v3/REPLAY.json').read_text());candidate=Path(r['output']);assert hashlib.sha256(candidate.read_bytes()).hexdigest()==r['outputSha256'];bpy.ops.wm.open_mainfile(filepath=str(candidate));bpy.context.view_layer.update()
def planes(points,triangles):
 return [[Vector(points[i])for i in tri]for tri in triangles]
old_solids=[];new_solids=[]
for item in old['rows']:
 lo,hi=item['bounds']
 if lo[1]>.005:continue
 ps={v['id']:v['worldP']for v in item['vertices']};ts=[t['vertices']for t in item['triangles']];old_solids.append({'owner':item['owner'],'component':item['component'],'planes':planes(ps,ts)})
 o=bpy.data.objects[item['owner']];split=next((s for s in r['propSplits']if s['source']==o.name),None);maps={old:i for i,old in enumerate(split['retainedMapping']['POINT'])}if split else None
 def point(i):
  p=o.matrix_world@o.data.vertices[maps[i]if maps else i].co;return[p.x,p.z,-p.y]
 new_solids.append({'owner':item['owner'],'component':item['component'],'planes':planes({i:point(i)for i in ps},ts)})
def inside(p,solid):
 total=0.0
 for triangle in solid['planes']:
  a,b,c=[v-p for v in triangle];la,lb,lc=a.length,b.length,c.length
  total+=2*math.atan2(a.dot(b.cross(c)),la*lb*lc+a.dot(b)*lc+b.dot(c)*la+c.dot(a)*lb)
 return abs(total)>3*math.pi
rows=[];ids={}
for o in bpy.context.scene.objects:
 if o.type!='MESH':continue
 m=o.data;normal_matrix=o.matrix_world.to_3x3().inverted().transposed()
 for f in m.polygons:
  for j in f.loop_indices:
   p=o.matrix_world@m.vertices[m.loops[j].vertex_index].co;p=Vector((p.x,p.z,-p.y));n=normal_matrix@m.corner_normals[j].vector
   if not(-3.1<p.x< -1.8 and -.03<p.y<.03 and 5.9<p.z<8.6 and n.z>.5):continue
   before=[s for s in old_solids if inside(p,s)];after=[s for s in new_solids if inside(p,s)]
   if before and not after:
    color=m.color_attributes.get('COLOR_0');rgb=list(color.data[j if color.domain=='CORNER'else m.loops[j].vertex_index].color)if color else None
    rows.append({'owner':o.name,'corner':j,'polygon':f.index,'vertex':m.loops[j].vertex_index,'worldP':list(p),'sourceRGB':rgb,'removedSupport':[{k:v for k,v in s.items()if k!='planes'}for s in before]});ids.setdefault(o.name,set()).add(j)
out={'scope':'READONLY exact native floor CORNER receivers newly exposed from inside old closed finite plinth/waterfalls to outside new supports. Actual original RGB retained. This is a narrow optional AO-refresh proposal, no floor/data edits, no claim every shadow-affected floor corner is covered. Root controls AO/export decision.','sourceSHA256':old['sourceSHA256'],'candidateSHA256':r['outputSha256'],'producerSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'insideMethod':'All finite oriented triangles: signed solid-angle winding, strict interior abs(total)>3pi; boundary/control caveat remains explicit. Predecessor convex shortcut rejected, not threshold-expanded.','rows':rows,'ownedCornerProposal':{o:sorted(v)for o,v in ids.items()}}
p=Q/'ISLAND-NEWLY-EXPOSED-FLOOR-V9.json';assert not p.exists();p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'receivers':{o:len(v)for o,v in ids.items()},'corners':len(rows),'RGBRange':[min((min(x['sourceRGB'][:3])for x in rows if x['sourceRGB']),default=None),max((max(x['sourceRGB'][:3])for x in rows if x['sourceRGB']),default=None)]}))
