import fs from "node:fs";import path from "node:path";import{pathToFileURL}from"node:url";
const root=process.cwd(),q=path.resolve(".jekyll-cache/visual-qa/breakfast-nook-20261101/coffee-contact-v6/pavilion-breakfast-v1"),base="C:/dev/dylantao.github.io/.jekyll-cache/visual-qa/final-house-integration-20261102/public-pavilion-chair-export-v1/models/";
const{THREE:T,loadNativeModel}=await import("../bound-native-avatar-v1.mjs"),{nativeGeometry}=await import("../bound-native-geometry-v1.mjs"),{createTriangleParity}=await import(pathToFileURL(path.join(root,"test/helpers/coastal-triangle-parity.mjs")));
const configBytes=fs.readFileSync(path.join(q,"PAVILION-COFFEE-ROUTE-ONLY-LOW-CARRY-V5.json")),config=JSON.parse(configBytes),scene=new T.Group(),region=new T.Box3(new T.Vector3(-4.8,-.65,-2.5),new T.Vector3(8,2.6,14.2)),solids=[],surfaces=[],unresolved=[];
for(const file of new Set(["home-shell.glb","coast.glb","flora.glb","hinterland.glb",...config.rooms.map(r=>r.file)])){const g=await nativeGeometry(file,pathToFileURL(file==="hinterland.glb"?"C:/dev/dylantao.github.io/assets/models/home/":base));g.userData.sourceFile=file;scene.add(g);}
// Native proxies remain. Add every actual furniture geometry level for each
// relevant room as additional conservative physical targets, not a render.
const furnitureInputs=[],furnitureIndex=JSON.parse(fs.readFileSync(base+"furniture/index.json"));
for(const anchor of config.furniture.filter(a=>["kitchen","lounge"].includes(a.room))){for(const lod of furnitureIndex.items[anchor.item].lods){
 const g=await nativeGeometry("furniture/"+lod.file,pathToFileURL(base));g.position.fromArray(anchor.position);g.rotation.y=anchor.yaw||0;
 g.traverse(o=>{o.name="furniture::"+anchor.id+"::"+lod.file+"::"+o.name;});scene.add(g);furnitureInputs.push({anchor:anchor.id,item:anchor.item,file:lod.file,position:anchor.position,yaw:anchor.yaw||0});}}
scene.updateMatrixWorld(true);
const doorControl=[];scene.traverse(o=>{if(o.userData.facadeDoor){doorControl.push({name:o.name,id:o.userData.facadeDoor,slideX:o.userData.slideX,closed:o.position.toArray()});o.position.x+=o.userData.slideX;}});
const{createEstateDoors}=await import(pathToFileURL(path.join(root,"assets/js/home-scene/estate-doors.mjs")));const estateDoors=createEstateDoors(scene,config.estateDoors);estateDoors.update(.6,{visitors:config.equipment.coffee.walkPath.map(position=>({active:true,position}))});scene.updateMatrixWorld(true);const estateControl=estateDoors.evidence();
// Reconnect exact coincident decoded position seams for COMPONENT identification only.
// Every original finite triangle remains in the parity surface; no geometry is simplified.
scene.traverse((mesh) => {
  if (!mesh.isMesh) return;
  const a = mesh.geometry.attributes.position, index = mesh.geometry.index, points = [], canonical = new Map(), ids = [], uf = [];
  const find = (i) => { while (uf[i] !== i) { uf[i] = uf[uf[i]]; i = uf[i]; } return i; };
  const join = (a, b) => { uf[find(a)] = find(b); };
  for (let i = 0; i < a.count; i++) {
    const p = new T.Vector3().fromBufferAttribute(a, i).applyMatrix4(mesh.matrixWorld), key = p.toArray().join(",");
    if (!canonical.has(key)) { const id = points.length; canonical.set(key, id); points.push(p); uf.push(id); }
    ids.push(canonical.get(key));
  }
  const faces = [];
  for (let i = 0; i < (index?.count ?? a.count); i += 3) {
    const vi = [0, 1, 2].map((k) => ids[index ? index.getX(i + k) : i + k]); join(vi[0], vi[1]); join(vi[1], vi[2]); faces.push({ id: i / 3, vi });
  }
  const components = new Map();
  for (const face of faces) { const id = find(face.vi[0]); if (!components.has(id)) components.set(id, []); components.get(id).push(face); }
  let island = 0;
  for (const faces of components.values()) {
    const bounds = new T.Box3(); for (const f of faces) for (const i of f.vi) bounds.expandByPoint(points[i]);
    const id = island++; if (!bounds.intersectsBox(region)) continue;
    const nonzero = faces.filter((f) => new T.Triangle(...f.vi.map((i) => points[i])).getArea() > 0), edges = new Map();
    for (const f of nonzero) for (let k = 0; k < 3; k++) { const a = f.vi[k], b = f.vi[(k + 1) % 3], key = [Math.min(a, b), Math.max(a, b)].join(","); const list = edges.get(key) || []; list.push([a, b]); edges.set(key, list); }
    const bad = [...edges.values()].filter((list) => list.length !== 2 || list[0][0] !== list[1][1] || list[0][1] !== list[1][0]);
    const record = { owner: mesh.parent.name, material: mesh.material.name, island: id, originalFaces: faces.length, nonzeroFaces: nonzero.length, badOrientedEdges: bad.length, bounds: [bounds.min.toArray(), bounds.max.toArray()] };
    surfaces.push({ ...record, closed: !bad.length && Boolean(nonzero.length), box: bounds,
      triangles: faces.map((f) => ({ id: f.id, zeroArea: new T.Triangle(...f.vi.map((v) => points[v])).getArea() === 0, triangle: new T.Triangle(...f.vi.map((v) => points[v])) })) });
    if (bad.length || !nonzero.length) { unresolved.push(record); continue; }
    const p = new Float64Array(nonzero.length * 9);
    nonzero.forEach((f, i) => f.vi.forEach((v, k) => points[v].toArray(p, i * 9 + k * 3)));
    const geometry = new T.BufferGeometry(); geometry.setAttribute("position", new T.BufferAttribute(p, 3));
    solids.push({ ...record, box: bounds, contains: createTriangleParity(T, geometry), triangles: nonzero.map((f) => ({ id: f.id, triangle: new T.Triangle(...f.vi.map((v) => points[v])) })) });
  }
});
const room=config.rooms.find(r=>r.id==="kitchen"),kitchenFile=path.join(base,"room-kitchen.glb"),kitchen=scene.children.find(g=>g.userData.sourceFile==="room-kitchen.glb");
const{activityPose,createHandContacts}=await import(pathToFileURL(path.join(root,"assets/js/home-scene/activities.mjs"))),{resolveWristTargets}=await import(pathToFileURL(path.join(root,"assets/js/home-scene/grip-targets.mjs")));
export{T,root,q,base,configBytes,config,room,kitchenFile,kitchen,scene,solids,surfaces,unresolved,loadNativeModel,activityPose,createHandContacts,resolveWristTargets,furnitureInputs,doorControl,estateControl};
