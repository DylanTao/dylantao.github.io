// Read-only QA acceleration. Cache identical boneWorld*inverseBind products;
// retain Three's point, weight, inverse-bind and world operation order exactly.
export function createExactSkinReader(T,mesh){
 const position=mesh.geometry.attributes.position,indices=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight,
   source=Array.from({length:position.count},(_,i)=>new T.Vector3().fromBufferAttribute(position,i)),
   rows=source.map((_,i)=>Array.from({length:4},(_,k)=>({bone:indices.getComponent(i,k),weight:weights.getComponent(i,k)}))),
   used=[...new Set(rows.flatMap(r=>r.filter(v=>v.weight!==0).map(v=>v.bone)))],matrices=new Map(used.map(id=>[id,new T.Matrix4()])),
   points=source.map(()=>new T.Vector3()),base=new T.Vector3(),part=new T.Vector3();
 const fallback=Boolean(mesh.morphTargetInfluences?.some(v=>v!==0));
 return()=>{
  if(fallback||mesh.morphTargetInfluences?.some(v=>v!==0))return points.map((p,i)=>mesh.getVertexPosition(i,p).applyMatrix4(mesh.matrixWorld));
  for(const id of used)matrices.get(id).multiplyMatrices(mesh.skeleton.bones[id].matrixWorld,mesh.skeleton.boneInverses[id]);
  for(let i=0;i<source.length;i++){
   base.copy(source[i]).applyMatrix4(mesh.bindMatrix);const out=points[i].set(0,0,0);
   for(const {bone,weight}of rows[i])if(weight!==0)out.addScaledVector(part.copy(base).applyMatrix4(matrices.get(bone)),weight);
   out.applyMatrix4(mesh.bindMatrixInverse).applyMatrix4(mesh.matrixWorld);
  }
  return points;
 };
}
