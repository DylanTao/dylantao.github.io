import bpy, gzip, hashlib, json, math
from pathlib import Path
from mathutils import Vector

Q=Path(r'C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/coffee-contact-v6/pavilion-breakfast-v1')
control=Q/'island-width-control-v2';receipt=json.loads((control/'REPLAY.json').read_text());old=json.loads(gzip.decompress((Q/'ISLAND-AISLE-NATIVE-CENSUS-V2.json.gz').read_bytes()))
source=control/'candidate.blend';assert hashlib.sha256(source.read_bytes()).hexdigest()==receipt['outputSha256'];bpy.ops.wm.open_mainfile(filepath=str(source));bpy.context.view_layer.update()
splits={r['source']:r for r in receipt['propSplits']};rows=[];all_floor=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH':continue
 m=o.data;m.calc_loop_triangles()
 for t in m.loop_triangles:
  native=[o.matrix_world@m.vertices[i].co for i in t.vertices];p=[Vector((v.x,v.z,-v.y))for v in native]
  if min(v.y for v in p)<-.08 or max(v.y for v in p)>.04 or min(v.x for v in p)>-1.7 or max(v.x for v in p)<-3.2 or min(v.z for v in p)>8.7 or max(v.z for v in p)<5.8:continue
  if (p[1]-p[0]).cross(p[2]-p[0]).y>0:all_floor.append((o.name,t.index,p))
def floor(x,z):
 best=None
 for owner,face,p in all_floor:
  a,b,c=p;den=(b.z-c.z)*(a.x-c.x)+(c.x-b.x)*(a.z-c.z)
  if den==0:continue
  u=((b.z-c.z)*(x-c.x)+(c.x-b.x)*(z-c.z))/den;v=((c.z-a.z)*(x-c.x)+(a.x-c.x)*(z-c.z))/den;w=1-u-v
  if min(u,v,w)<-1e-12:continue
  h=u*a.y+v*b.y+w*c.y
  if best is None or h>best['height']:best={'height':h,'owner':owner,'face':face}
 return best
max_position=max_uv=max_color=max_prop_normal=max_shape_normal=0;source_vertices=0;points_mapped=0
for r in old['rows']:
 owner=r['owner'];lo,hi=r['bounds'];prop=owner in['kitchen__meyer lemon','kitchen__oatmeal glaze']or owner=='kitchen__honey ash'and lo[1]>.97
 split=splits.get(owner);detached=split and(prop)
 target=split['created']if detached else owner;o=bpy.data.objects[target];m=o.data
 if split:
  domains=split['sourceSelection']if detached else split['retainedMapping'];maps={d:{old:i for i,old in enumerate(ids)}for d,ids in domains.items()}
 else:maps={}
 pointmap=lambda i:maps['POINT'][i]if maps else i;facemap=lambda i:maps['FACE'][i]if maps else i;cornermap=lambda i:maps['CORNER'][i]if maps else i
 ids=[pointmap(v['id'])for v in r['vertices']];bounds=[];residual=0
 for v in r['vertices']:
  p=o.matrix_world@m.vertices[pointmap(v['id'])].co;world=[p.x,p.z,-p.y];wanted=v['worldP'].copy()
  delta=.075 if prop else .15 if hi[0]-lo[0]<.1 and sum([lo[0],hi[0]])/2< -2.45 else 0 if hi[0]-lo[0]<.1 else .15 if wanted[0]< -2.45 else 0;wanted[0]+=delta
  residual=max(residual,math.dist(world,wanted));bounds.append(world);source_vertices+=1;points_mapped+=1
  if prop:assert list(m.vertices[pointmap(v['id'])].co)==v['localP']
 for f in r['faces']:
  actual=m.polygons[facemap(f['id'])];assert list(actual.vertices)==[pointmap(i)for i in f['vertices']];assert actual.material_index==f['materialIndex']and actual.use_smooth==f['smooth']
  for c in f['corners']:
   j=cornermap(c['loop']);nd=math.dist(list(m.corner_normals[j].vector),c['N']);max_prop_normal=max(max_prop_normal,nd)if prop else max_prop_normal;max_shape_normal=max(max_shape_normal,nd)if not prop else max_shape_normal
   for name,rgb in c.get('colors',{}).items():
    color=m.color_attributes[name];at=j if color.domain=='CORNER'else m.loops[j].vertex_index;max_color=max(max_color,math.dist(list(color.data[at].color),rgb))
   for uv,xy in c['UV'].items():max_uv=max(max_uv,math.dist(list(m.uv_layers[uv].data[j].uv),xy))
   # The original census retains primary COLOR_0 explicitly; all raw attribute
   # equality is separately sealed by the recipe's subset/outside field guards.
   if 'RGB'in c and c['RGB']is not None:
    color=m.color_attributes.get('COLOR_0');max_color=max(max_color,math.dist(list(color.data[j].color),c['RGB']))
 idsset=set(ids);faces={facemap(f['id'])for f in r['faces']};tri=[t for t in m.loop_triangles if t.polygon_index in faces];edges={};volume6=0;zeros=0
 for t in tri:
  p=[o.matrix_world@m.vertices[i].co for i in t.vertices];normal=(p[1]-p[0]).cross(p[2]-p[0]);zeros+=normal.length_squared==0;volume6+=p[0].dot(p[1].cross(p[2]))
  for a,b in zip(t.vertices,(*t.vertices[1:],t.vertices[0])):edges.setdefault(tuple(sorted((a,b))),[]).append((a,b))
 bad=[k for k,v in edges.items()if len(v)!=2 or v[0]!=(v[1][1],v[1][0])]
 assert not bad,(owner,r['component'],len(bad));assert volume6>0,(owner,r['component'],volume6);assert len(tri)==len(r['triangles']);max_position=max(max_position,residual)
 rows.append({'sourceOwner':owner,'sourceComponent':r['component'],'target':target,'sourceFingerprint':r['componentSHA256'],'rigidProp':bool(prop),'vertices':len(ids),'polygons':len(faces),'triangles':len(tri),'bounds':[[min(p[k]for p in bounds)for k in range(3)],[max(p[k]for p in bounds)for k in range(3)]],'positionResidual':residual,'badDirectedEdges':len(bad),'zeroTriangles':zeros,'positiveVolume':volume6/6})
assert max_position<3e-6 and max_uv==0 and max_color==0 and max_prop_normal==0
bearing=[]
for r in rows:
 lo,hi=r['bounds']
 if lo[1]>.005:continue
 samples=[]
 for xi in range(9):
  for zi in range(9):
   x=lo[0]+(.01+.98*xi/8)*(hi[0]-lo[0]);z=lo[2]+(.01+.98*zi/8)*(hi[2]-lo[2]);support=floor(x,z);samples.append({'x':x,'z':z,'support':support,'bottomGap':lo[1]-support['height']if support else None})
 bearing.append({'owner':r['target'],'component':r['sourceComponent'],'samples':samples,'missing':sum(s['support']is None for s in samples),'contact6mm':sum(s['support']is not None and abs(s['bottomGap'])<=.006 for s in samples)})
out={'scope':'INDEPENDENT saved native island audit. Exact old component point/face/corner mapping; all props localP/effectiveN, owned RGB/UV, all83positive directed closed components and actual floor samples. P translation residual measured against requested world shift. No final decoded/body/cup/Walk/render admission.', 'sourceSHA256':old['sourceSHA256'],'candidateSHA256':receipt['outputSha256'],'producerSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows,'floorBearing':bearing,'maxPositionResidual':max_position,'maxUVDelta':max_uv,'maxPrimaryRGBDelta':max_color,'maxRigidPropNormalDelta':max_prop_normal,'maxOwnedShapeNormalChange':max_shape_normal,'components':len(rows),'triangles':sum(r['triangles']for r in rows),'mappedVertices':points_mapped,'pass':True}
p=Q/'ISLAND-NATIVE-INDEPENDENT-V7.json';assert not p.exists();p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in['rows','floorBearing']}));print(json.dumps([{'owner':r['owner'],'samples':len(r['samples']),'missing':r['missing'],'contact6mm':r['contact6mm']}for r in bearing]))
