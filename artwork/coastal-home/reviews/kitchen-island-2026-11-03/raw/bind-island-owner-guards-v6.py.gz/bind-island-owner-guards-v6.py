import bpy, gzip, hashlib, json, sys
from pathlib import Path
sys.path.insert(0,r'C:/dev/site-takeover-worktrees/breakfast-nook-20261101/bin')
import coastal_pavilion_chair as custody
q=Path(r'C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/coffee-contact-v6/pavilion-breakfast-v1')
p=Path(r'C:/dev/dylantao.github.io/artwork/coastal-home/coastal-home.blend');assert hashlib.sha256(p.read_bytes()).hexdigest()=='1e10b25d5cf0eec87d7001acbf9d938d65ba33af6076380d5a8e5d45cf3d23e7'
bpy.ops.wm.open_mainfile(filepath=str(p));bpy.context.view_layer.update()
data=json.loads(gzip.decompress((q/'ISLAND-AISLE-NATIVE-CENSUS-V2.json.gz').read_bytes()));rows=[]
for owner in sorted({r['owner']for r in data['rows']}):
 items=[r for r in data['rows']if r['owner']==owner];ids={v['id']for r in items for v in r['vertices']};o=bpy.data.objects[owner];m=o.data;faces=[f.index for f in m.polygons if all(i in ids for i in f.vertices)];selected={'POINT':sorted(ids),'EDGE':[e.index for e in m.edges if all(i in ids for i in e.vertices)],'FACE':faces,'CORNER':[i for f in faces for i in m.polygons[f].loop_indices]};bounds=[[min(r['bounds'][0][k]for r in items)for k in range(3)],[max(r['bounds'][1][k]for r in items)for k in range(3)]];h,record=custody.selection_fingerprint(o,selected,bounds);rows.append({'owner':owner,'selectionSHA256':h,'parts':len(items),'triangles':sum(len(r['triangles'])for r in items),'selected':selected,'bounds':bounds,'allOwnerSelected':len(selected['POINT'])==len(m.vertices)and len(faces)==len(m.polygons),'record':record})
out={'sourceSHA256':data['sourceSHA256'],'helperSHA256':hashlib.sha256(Path(custody.__file__).read_bytes()).hexdigest(),'rows':rows};dest=q/'ISLAND-OWNER-GUARDS-V6.json';assert not dest.exists();dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps([{k:r[k]for k in ['owner','selectionSHA256','parts','triangles','allOwnerSelected']}for r in rows]))
