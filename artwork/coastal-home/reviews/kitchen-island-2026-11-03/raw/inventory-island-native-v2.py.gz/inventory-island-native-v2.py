import bpy, gzip, hashlib, json
from pathlib import Path

Q=Path(r'C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/coffee-contact-v6/pavilion-breakfast-v1')
source=Path(r'C:/dev/dylantao.github.io/artwork/coastal-home/coastal-home.blend')
sha=lambda b:hashlib.sha256(b).hexdigest()
source_sha=sha(source.read_bytes())
assert source_sha=='1e10b25d5cf0eec87d7001acbf9d938d65ba33af6076380d5a8e5d45cf3d23e7'
bpy.ops.wm.open_mainfile(filepath=str(source));bpy.context.view_layer.update()
rows=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH' or not o.name.startswith('kitchen__'):continue
 m=o.data;m.calc_loop_triangles();adj=[[]for _ in m.vertices]
 for e in m.edges:
  a,b=e.vertices;adj[a].append(b);adj[b].append(a)
 seen=set();component=0
 for start in range(len(m.vertices)):
  if start in seen:continue
  todo=[start];seen.add(start);ids=[]
  while todo:
   i=todo.pop();ids.append(i)
   for j in adj[i]:
    if j not in seen:seen.add(j);todo.append(j)
  current=component;component+=1
  def world(v):
   p=o.matrix_world@v;return[p.x,p.z,-p.y]
  pts=[world(m.vertices[i].co)for i in ids];lo=[min(p[k]for p in pts)for k in range(3)];hi=[max(p[k]for p in pts)for k in range(3)]
  if not(lo[0]>-3.1 and hi[0]<-1.8 and lo[1]>=-.001 and hi[1]<1.2 and lo[2]>5.9 and hi[2]<8.6):continue
  s=set(ids);faces=[p for p in m.polygons if all(v in s for v in p.vertices)];fids={p.index for p in faces};normals=m.corner_normals
  row={'owner':o.name,'component':current,'bounds':[lo,hi],'matrix':[list(r)for r in o.matrix_world],
   'vertices':[{'id':i,'localP':list(m.vertices[i].co),'worldP':world(m.vertices[i].co)}for i in sorted(ids)],
   'edges':[{'id':e.index,'vertices':list(e.vertices),'sharp':e.use_edge_sharp,'seam':e.use_seam}for e in m.edges if all(i in s for i in e.vertices)],
   'faces':[{'id':p.index,'vertices':list(p.vertices),'loops':list(p.loop_indices),'materialIndex':p.material_index,'smooth':p.use_smooth,
    'corners':[{'loop':j,'N':list(normals[j].vector),'colors':{c.name:list(c.data[j if c.domain=='CORNER' else m.loops[j].vertex_index].color)for c in m.color_attributes},'UV':{u.name:list(u.data[j].uv)for u in m.uv_layers}}for j in p.loop_indices]}for p in faces],
   'triangles':[{'id':t.index,'face':t.polygon_index,'vertices':list(t.vertices),'loops':list(t.loops)}for t in m.loop_triangles if t.polygon_index in fids],
   'materialSlots':[x.name if x else None for x in m.materials]}
  row['componentSHA256']=sha(json.dumps(row,sort_keys=True,separators=(',',':')).encode());rows.append(row)
out={'scope':'READ ONLY complete connected-island census of current native freestanding kitchen island and all its authored props. No stool exists in this roster; prior stool wording corrected. No scene changes or save.', 'source':str(source),'sourceSHA256':source_sha,'producerSHA256':sha(Path(__file__).read_bytes()),'rows':rows,'summary':[{'owner':r['owner'],'component':r['component'],'bounds':r['bounds'],'vertices':len(r['vertices']),'polygons':len(r['faces']),'triangles':len(r['triangles']),'componentSHA256':r['componentSHA256']}for r in rows]}
dest=Q/'ISLAND-AISLE-NATIVE-CENSUS-V2.json.gz';assert not dest.exists();dest.write_bytes(gzip.compress(json.dumps(out,separators=(',',':')).encode(),mtime=0))
assert sha(source.read_bytes())==source_sha
print(json.dumps({'components':len(rows),'vertices':sum(len(r['vertices'])for r in rows),'triangles':sum(len(r['triangles'])for r in rows),'owners':sorted({r['owner']for r in rows}),'output':str(dest)}))
