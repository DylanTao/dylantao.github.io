// QA only. Exact dyadic SAT for the full Minkowski sweep of one finite
// triangle by one translation segment against another finite triangle.
// No production cadence/sample optimization; zero/flat cases fail conservatively.
const bytes=new DataView(new ArrayBuffer(8));
function dyadic(n){if(!Number.isFinite(n))throw Error('nonfinite coordinate');if(n===0)return[0n,0];bytes.setFloat64(0,n,false);const bits=bytes.getBigUint64(0,false),negative=(bits>>63n)!==0n,e=Number((bits>>52n)&2047n),fraction=bits&((1n<<52n)-1n);let m=e?fraction+(1n<<52n):fraction;return[negative?-m:m,e?e-1075:-1074];}
const sub=(a,b)=>a.map((v,i)=>v-b[i]),add=(a,b)=>a.map((v,i)=>v+b[i]),cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2],zero=a=>a.every(v=>v===0n);
function range(points,axis){const values=points.map(p=>dot(p,axis));return values.reduce(([lo,hi],v)=>[v<lo?v:lo,v>hi?v:hi],[values[0],values[0]]);}
export function exactSweptTriangle(a,delta,b,marginM=0){
 if(!Number.isFinite(marginM)||marginM<0)throw Error('nonnegative finite conservative margin required');
 if(!Array.isArray(a)||a.length!==3||!Array.isArray(b)||b.length!==3||!Array.isArray(delta)||delta.length!==3||[...a,...b].some(p=>!Array.isArray(p)||p.length!==3))throw Error('finite triangle/translation required');
 const values=[...a.flat(),...delta,...b.flat(),marginM].map(dyadic),nonzero=values.filter(([m])=>m!==0n),e=Math.min(0,...nonzero.map(([,e])=>e)),ints=values.map(([m,x])=>m===0n?0n:m<<BigInt(x-e)),point=i=>ints.slice(i,i+3),A=[point(0),point(3),point(6)],D=point(9),B=[point(12),point(15),point(18)],P=[...A,...A.map(p=>add(p,D))],ae=[sub(A[1],A[0]),sub(A[2],A[1]),sub(A[0],A[2])],be=[sub(B[1],B[0]),sub(B[2],B[1]),sub(B[0],B[2])],an=cross(ae[0],ae[1]),bn=cross(be[0],be[1]),axes=[an,bn,...ae.map(v=>cross(v,D)),...ae.flatMap(v=>be.map(w=>cross(v,w))),...be.map(w=>cross(D,w)),...ae.map(v=>cross(an,v)),...be.map(v=>cross(bn,v)),...be.map(v=>cross(an,v)),...ae.map(v=>cross(bn,v)),[1n,0n,0n],[0n,1n,0n],[0n,0n,1n]];
 let checked=0;for(let i=0;i<axes.length;i++){const axis=axes[i];if(zero(axis))continue;checked++;const[alo,ahi]=range(P,axis),[blo,bhi]=range(B,axis);const pad=ints[21]*axis.reduce((n,v)=>n+(v<0n?-v:v),0n);if(ahi+pad<blo||bhi+pad<alo)return{intersects:false,separatingAxis:i,checkedAxes:checked,marginM,exact:'IEEE754 inputs and conservative L-infinity margin as exact dyadic rationals'};}
 return{intersects:true,separatingAxis:null,checkedAxes:checked,marginM,exact:'IEEE754 inputs and conservative L-infinity margin as exact dyadic rationals',degenerate:zero(an)||zero(bn)||dot(an,D)===0n};
}
