// An optional, source-measured breakfast setting. The kitchen remains the
// preparation room; lunch, dinner and old manifests keep their original seat.
const AVATARS = Object.freeze(["lizard", "south-park", "simpsons", "ghibli", "rick-and-morty"]);
const plans = new WeakMap();
const record = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
const keys = (value, allowed) => record(value) && Object.keys(value).every((key) => allowed.includes(key));
const vector = (value, count) => Array.isArray(value) && value.length === count && value.every(Number.isFinite);
const between = (value, low, high) => Number.isFinite(value) && value >= low && value <= high;
const unit = (value, count) => vector(value, count) && Math.abs(Math.hypot(...value) - 1) <= 1e-4;
const samePoint = (a, b) => vector(a, 3) && vector(b, 3) && a.every((value, i) => Math.abs(value - b[i]) < 1e-6);
const copy = (value) => {
  if (Array.isArray(value)) return Object.freeze(value.map(copy));
  if (record(value)) return Object.freeze(Object.fromEntries(Object.entries(value).map(([key, item]) => [key, copy(item)])));
  return value;
};

// Shorten the actual final north/south cooking aisle at its docking point.
// Each machine gets its own approach, without visiting the grinder on the
// brewer's return leg or cutting a new diagonal through the island.
function dockPath(path, station) {
  if (!Array.isArray(path) || !vector(station, 3)) return null;
  const z = station[2] + 0.35;
  for (let i = path.length - 2; i >= 0; i--) {
    const a = path[i], b = path[i + 1];
    if (!vector(a, 3) || !vector(b, 3) || Math.abs(a[0] - b[0]) > 1e-6 || Math.abs(a[1] - b[1]) > 1e-6 ||
      Math.abs(a[1] - station[1]) > 1e-6 || Math.abs(a[0] - station[0]) > 0.3 ||
      a[2] <= b[2] || z < b[2] || z > a[2]) continue;
    const points = [...path.slice(0, i + 1), [a[0], a[1], z], [station[0],station[1],station[2]+.15], [...station]];
    return points.filter((point, j) => !j || !samePoint(point, points[j - 1]));
  }
  return null;
}

export function coffeeVenue(coffee) {
  if (!record(coffee)) return null;
  if (plans.has(coffee)) return plans.get(coffee);
  const invalid = () => {
    plans.set(coffee, null);
    return null;
  };
  const venue = coffee.venue;
  if (
    !keys(venue, ["version", "id", "seat", "facing", "table", "fits"]) ||
    venue.version !== 1 ||
    venue.id !== "pavilion" ||
    !vector(venue.seat, 3) ||
    !vector(coffee.seat, 3) ||
    !between(venue.seat[0], 6.5, 6.7) ||
    !between(venue.seat[1], 0, 0.04) ||
    !between(venue.seat[2], -1.3, -1.1) ||
    !between(venue.facing, Math.PI - 0.2, Math.PI + 0.2) ||
    !keys(venue.table, ["owner", "surface", "probe", "plate"]) ||
    venue.table.owner !== "core_estate_pavilion__travertine paving stone" ||
    !between(venue.table.surface, 0.74, 0.82) ||
    [venue.table.probe, venue.table.plate].some(
      (point) => !vector(point, 2) || !between(point[0], -0.3, 0.3) || !between(point[1], 0.55, 0.86)
    ) ||
    !keys(venue.fits, AVATARS) ||
    AVATARS.some((id) => !Object.hasOwn(venue.fits, id))
  )
    return invalid();
  if (!keys(coffee.stations, ["grinder", "brewer"]) ||
    ["grinder", "brewer"].some((id) => !vector(coffee.stations[id], 3) || !between(coffee.stations[id][0], -3.8, -3.2) ||
      !between(coffee.stations[id][1], -0.02, 0.02) || !between(coffee.stations[id][2], 6.5, 7.8)) ||
    !keys(coffee.walkDurations, ["approach", "carry", "returnCup", "return"]) ||
    ["approach", "carry", "returnCup", "return"].some((id) => !between(coffee.walkDurations[id], 6, 48)) ||
    !Array.isArray(coffee.walkPath) || coffee.walkPath.length < 2 || coffee.walkPath.length > 64 ||
    coffee.walkPath.some((point, i) => !vector(point, 3) || (i > 0 && samePoint(point, coffee.walkPath[i - 1]))) ||
    !samePoint(coffee.walkPath[0], venue.seat) || !samePoint(coffee.walkPath.at(-1), coffee.stations.grinder) ||
    !dockPath(coffee.walkPath, coffee.stations.grinder) || !dockPath(coffee.walkPath, coffee.stations.brewer)) return invalid();
  for (const fit of Object.values(venue.fits)) {
    if (
      !keys(fit, ["offset", "feet", "knees"]) ||
      !vector(fit.offset, 3) ||
      !between(fit.offset[0], -0.08, 0.08) ||
      !between(fit.offset[1], -0.02, 0.08) ||
      !between(fit.offset[2], -0.1, 0.1) ||
      Math.hypot(...fit.offset) > 0.15 ||
      !keys(fit.feet, ["L", "R"]) ||
      !keys(fit.knees, ["L", "R"]) ||
      ["L", "R"].some(
        (side) =>
          !keys(fit.feet[side], ["position", "quaternion"]) ||
          !vector(fit.feet[side].position, 3) ||
          !between(fit.feet[side].position[0], 5.95, 6.9) ||
          !between(fit.feet[side].position[1], 0.25, 0.38) ||
          !between(fit.feet[side].position[2], -1.9, -1.4) ||
          !unit(fit.feet[side].quaternion, 4) ||
          !unit(fit.knees[side], 3)
      )
    )
      return invalid();
  }
  const result = copy(venue);
  plans.set(coffee, result);
  return result;
}

export function coffeeVenueSeat(coffee, avatarId) {
  const venue = coffeeVenue(coffee), fit = venue && Object.hasOwn(venue.fits, avatarId) ? venue.fits[avatarId] : null;
  return fit ? venue.seat.map((value, index) => value + fit.offset[index]) : null;
}

export function coffeeVenueFeet(coffee, avatarId) {
  const venue = coffeeVenue(coffee), fit = venue && Object.hasOwn(venue.fits, avatarId) ? venue.fits[avatarId] : null;
  return fit ? { feet: fit.feet, knees: fit.knees } : null;
}

export function coffeeVenueApproach(coffee, station) {
  return coffeeVenue(coffee) ? dockPath(coffee.walkPath, station) : null;
}

export function coffeeVenueForRoutine(config, routine) {
  return routine?.id === "breakfast" && routine.sequence === "coffee" ? coffeeVenue(config?.equipment?.coffee) : null;
}
