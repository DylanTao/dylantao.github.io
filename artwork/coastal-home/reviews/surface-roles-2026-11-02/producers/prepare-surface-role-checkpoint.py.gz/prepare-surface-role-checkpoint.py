from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path.cwd();q=Path(__file__).parent
out=q/'surface-role-checkpoint';assert not out.exists();out.mkdir()
old=root/'artwork/coastal-home/reviews/house-2026-10-24/overlap-audit.json'
shutil.copyfile(old,out/'prior-overlap-audit.json')
cmd=[sys.executable,'bin/summarize_coastal_overlaps.py','--audit='+str(q/'surface-role-current-canonical-v1/native/AUDIT.json'),'--delivered='+str(q/'surface-role-current-canonical-v1/decoded/AUDIT.json'),'--before='+str(out/'prior-overlap-audit.json'),'--out='+str(out/'overlap-audit.json')]
with(out/'summarize.log').open('wb')as log:r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
d=json.loads((out/'overlap-audit.json').read_bytes())
assert d['sourceSha256']=='1e10b25d5cf0eec87d7001acbf9d938d65ba33af6076380d5a8e5d45cf3d23e7'
assert d['totals']['deepSitesOver5cm']<=350 and d['totals']['deepSeverity']<=50250 and d['totals']['grazingSeamM']<=5.6
assert d['totals']['zFightingVisibleAreaM2']<=2.2 and d['delivered']['totals']['zFightingVisibleAreaM2']<=2.5
shutil.copyfile(out/'overlap-audit.json',old)
cmd=[sys.executable,'-X','utf8','-m','unittest','discover','-s','test','-p','test_coastal_overlap*.py']
with(out/'targeted.log').open('wb')as log:r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
receipt={'exitCode':r.returncode,'command':cmd,'nativeTotals':d['totals'],'deliveredTotals':d['delivered']['totals'],'scope':'Fresh exact public native/decoded audit of finite crossed-material cave-roof roles. Native and model bytes unchanged. Limits unchanged; private straight/fin/garden/coffee geometry remains unadmitted.'}
(out/'TARGETED.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2));assert r.returncode==0
