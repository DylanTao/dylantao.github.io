"""Fresh owning garden replay, then 24-sample owned AO and qualified F4 export."""
from pathlib import Path
import hashlib,json,subprocess,sys

root=Path.cwd();q=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base=q/'finishing-joints-owning-ao-v1/candidate.blend'
assert sha(base)=='f4f2f8b72d69e26abb8c86b962cae9ca17d81d73a6a059a12fbc1601790d7aaf'
command=['D:/tools/blender-4.5.9-windows-x64/blender.exe','--background','--factory-startup','--python-exit-code','1','-t','4','--python']

def run(name,text):
    p=q/(name+'.py');assert not p.exists();compile(text,str(p),'exec');p.write_text(text,encoding='utf8')
    with(q/(name+'.log')).open('wb') as log:
        r=subprocess.run(command+[str(p)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
    assert r.returncode==0,(name,r.returncode)

s=(q/'build-open-garden-bench.py').read_text().replace("'garden-bench-open-v1'","'garden-bench-open-plant-v2'")
s=s.replace('same32cm width/depth, remove only upper16cm cushion/oak bridge.', 'same32cm width/depth, remove only upper16cm cushion/oak bridge; whole olive now200mm east of original to clear measured seated distal tail.')
run('build-open-garden-plant-v2',s)
native=q/'garden-bench-open-plant-v2/candidate.blend';rawsha=sha(native)
s=(q/'bake-open-garden-bench.py').read_text().replace("'garden-bench-open-v1/candidate.blend'","'garden-bench-open-plant-v2/candidate.blend'").replace('8b46a205d573a3f37ffa5709176aebf970f279f4ef4c9aa773ae021580e0c6fa',rawsha).replace("'garden-bench-open-ao-v1'","'garden-bench-open-plant-ao-v2'")
run('bake-open-garden-plant-v2',s)
native=q/'garden-bench-open-plant-ao-v2/candidate.blend';aosha=sha(native)
s=(q/'export-open-garden-bench.py').read_text().replace("'garden-bench-open-export-v1'","'garden-bench-open-plant-export-v2'").replace("'garden-bench-open-ao-v1/candidate.blend'","'garden-bench-open-plant-ao-v2/candidate.blend'").replace('c4de58834c68d067a4f579dabdbb08818f8fb3c5c691196810d52945e19d7191',aosha)
p=q/'export-open-garden-plant-v2.py';assert not p.exists();p.write_text(s,encoding='utf8')
with(q/'export-open-garden-plant-v2-process.log').open('wb')as log:
    r=subprocess.run([sys.executable,str(p)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
print(json.dumps({'rawNativeSha256':rawsha,'aoNativeSha256':aosha,'export':json.loads((q/'garden-bench-open-plant-export-v2/PROCESS.json').read_bytes())},indent=2))
