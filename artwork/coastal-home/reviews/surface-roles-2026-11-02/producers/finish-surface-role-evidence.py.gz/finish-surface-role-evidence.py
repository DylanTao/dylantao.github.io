from pathlib import Path
import gzip,hashlib,json,re,shutil
root=Path.cwd();q=Path(__file__).parent;out=q/'surface-role-checkpoint';packet=root/'artwork/coastal-home/reviews/surface-roles-2026-11-02'
a=(q/'entrance-checkpoint/site/al-folio/index.html').read_text(encoding='utf8');b=(out/'site/al-folio/index.html').read_text(encoding='utf8')
pattern=r'(/al-folio/assets/css/(?:site-icons|main)\.css\?v=)\d{14}'
assert re.sub(pattern,r'\1BUILD-TIMESTAMP',a)==re.sub(pattern,r'\1BUILD-TIMESTAMP',b)
for rel in ['assets/css/main.css','assets/css/site-icons.css']:assert (q/'entrance-checkpoint/site/al-folio'/rel).read_bytes()==(out/'site/al-folio'/rel).read_bytes()
receipt={'scope':'Read-only built-output equality. Every compiled module and CSS byte is unchanged; only three explicit CSS URL build timestamps differ in homepage HTML. No normalization of prose, script, model or cache bodies.','compiledModules':189,'sameModuleRoster':True,'cssBytesExact':True,'homepageEqualExceptThreeCssBuildTimestamps':True}
p=out/'HTML-QUALIFICATION.json';assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n')
manifest=json.loads((packet/'MANIFEST.json').read_bytes());rows=manifest['files'];seen={r['path']for r in rows};sha=lambda b:hashlib.sha256(b).hexdigest()
items=[('gates/'+n,out/n)for n in ['FAILED-BUILT-CUSTODY-V1.json','HTML-DIFFERENCE.json','HTML-QUALIFICATION.json','ITERATION.json','iteration.log','SERVER-CUSTODY.json']]
items += [('producers/'+n,q/n)for n in ['diagnose-surface-role-html.py','prepare-surface-role-preview.py','serve-surface-role-checkpoint.py','run-surface-role-iteration.py','finish-surface-role-evidence.py']]
items += [('render/home-top-light-1440x1000-still.png',q.parent/'iteration-surface-role-20261102/iteration-visual-iteration-home/home-top-light-1440x1000-still.png')]
for rel,p in items:
 target=packet/(rel+'.gz');assert target.relative_to(packet).as_posix()not in seen and not target.exists();target.parent.mkdir(parents=True,exist_ok=True)
 body=p.read_bytes();stored=gzip.compress(body,mtime=0);target.write_bytes(stored);rows.append({'path':target.relative_to(packet).as_posix(),'bytes':len(stored),'sha256':sha(stored),'encoding':'gzip','bodyBytes':len(body),'bodySha256':sha(body)})
(packet/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
shutil.copytree(packet,Path('C:/dev/cqa1102')/packet.relative_to(root),dirs_exist_ok=True)
print(json.dumps({'payloads':len(rows),'storedBytes':sum(r['bytes']for r in rows)}))
