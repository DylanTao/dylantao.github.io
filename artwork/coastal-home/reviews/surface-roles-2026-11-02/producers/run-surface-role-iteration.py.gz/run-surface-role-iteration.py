from pathlib import Path
import json,os,shutil,subprocess,time
root=Path.cwd();q=Path(__file__).parent;out=q/'surface-role-checkpoint'
server=json.loads((out/'server.json').read_bytes())
env=dict(os.environ,NO_WEBSERVER='1',VISUAL_BASE_URL=server['url'],VISUAL_ROUTE_IDS='home',VISUAL_OUTPUT_TAG='surface-role-20261102',VISUAL_TIMINGS='1')
cmd=[shutil.which('npm.cmd'),'run','test:visual:iterate'];start=time.monotonic()
with(out/'iteration.log').open('wb')as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={'command':cmd,'exitCode':r.returncode,'seconds':time.monotonic()-start,'server':server,'scope':'One representative home/light1440 production-source render; no private native or motion admission.'}
(out/'ITERATION.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2));assert r.returncode==0
