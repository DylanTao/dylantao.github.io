"""Qualify the completed official CORE bake; preserve excluded cave-roof fields."""
from pathlib import Path
import ast,hashlib,json
q=Path(__file__).parent
s=(q/'bake-local-roof-plant.py').read_text()
s=s.replace("owned={n:r['loops']for n,r in mask['owners'].items()}\nassert sorted(map(len,owned.values()))==[984,2111]", "owned={'core__golden coastal sandstone':mask['owners']['core__golden coastal sandstone']['loops']}\nassert len(owned['core__golden coastal sandstone'])==984")
s=s.replace("'garden-roof-owning-ao-v1';assert not out.exists()", "'garden-roof-owning-ao-v2';assert not out.exists()")
start=s.index("work=out/'bake-work.blend'")
end=s.index('baked={}',start)
s=s[:start]+'''# The unmodified baker completed and saved this exact work file before the
# v1 verifier incorrectly expected a caveRoof owner to be selected. Reuse its
# completed result, retaining that failed verifier and all original fields.
work=q/'garden-roof-owning-ao-v1/bake-work.blend'
stats=json.loads((work.parent/'BAKE.json').read_bytes())
assert stats['samples']==24 and {r['mesh']for r in stats['surfaces']}==set(owned)
bpy.ops.wm.open_mainfile(filepath=str(work))
''' + s[end:]
s=s.replace("'maskSha256':sha(mask_path)","'officialWorkSha256':sha(work),'officialReportSha256':sha(work.parent/'BAKE.json'),'retainedFailedControl':'garden-roof-owning-ao-v1: completed official baker, then verifier failed expecting excluded caveRoof to be selected','maskSha256':sha(mask_path)")
s=s.replace('Official24sample AO on984 actual moved CORE corners and2111 born BATH rebate-cap corners only.', 'Official24sample AO on984 actual moved CORE corners only. The unchanged owning baker excludes caveRoof, so all BATH fields including2111 hidden-cap colors remain exact. Reuses completed official v1 bake, without relabeling failed verifier.')
producer=q/'bake-local-roof-plant-v2.py';assert not producer.exists();compile(s,str(producer),'exec');producer.write_text(s)
print(str(producer))
