"""Official24sample AO merged only onto measured local changed-rock corners."""
import array,ast,hashlib,json,runpy,shutil,sys
from pathlib import Path
import bpy
root=Path.cwd();q=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=q/'garden-roof-combined-v2/candidate.blend'
expected='3ea7d9de7d2e17367e49c225eeb054c2a541eeed42beab41699a54351fa0d971'
assert sha(source)==expected and bpy.app.version==(4,5,9)
mask_path=source.parent/'OWNED-LOCAL-AO-MASKS.json'
mask=json.loads(mask_path.read_bytes())
assert mask['qualifiedCandidateSha256']=='463fcecc23a2da47ab085ea3519c6ca184e2296740d4779452a55b2c5d228623'
guard=json.loads((source.parent/'GUARDED-REPLAY.json').read_bytes())
assert guard['passed'] and guard['outputSha256']==expected
owned={n:r['loops']for n,r in mask['owners'].items()}
assert sorted(map(len,owned.values()))==[984,2111]
manifest=Path('C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/combined-side-fan-control-v1/candidate-attempt-1/manifest.json')
assert sha(manifest)=='1761204ff8d3bfc289296d252dadc64dab3bea44687065d5a803a950223f324f'
out=q/'garden-roof-owning-ao-v1';assert not out.exists();out.mkdir()
ns=runpy.run_path(str(root/'artwork/coastal-home/reviews/bedroom-ambience-2026-11-01/replay_lighting.py'))
tree=ast.parse((q/'bake-owned-exterior.py').read_text())
defs=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in {'shape','colors'}]
assert len(defs)==2
exec(compile(ast.Module(body=defs,type_ignores=[]),'<qualified-shape-colors>','exec'))
def extras(obj):
 active=obj.data.color_attributes.active_color.name
 return {a.name:(a.domain,a.data_type,colors(a).tobytes())for a in obj.data.color_attributes if a.name!=active}
bpy.ops.wm.open_mainfile(filepath=str(source))
before=ns['native_state']();materials=ns['materials']()
shapes={n:shape(bpy.data.objects[n])for n in owned}
extra={n:extras(bpy.data.objects[n])for n in owned}
for n,loops in owned.items():
 m=bpy.data.objects[n].data
 assert len(loops)==len(set(loops)) and min(loops)>=0 and max(loops)<len(m.loops)
 assert m.color_attributes.active_color.domain=='CORNER' and m.color_attributes.active_color.data_type=='FLOAT_COLOR'
work=out/'bake-work.blend';shutil.copyfile(source,work)
sys.argv=['bake_coastal_light.py','--','--cpu',f'--source={work}',f'--manifest={manifest}','--prefixes='+','.join(sorted(owned)),f'--report={out/"BAKE.json"}']
runpy.run_path(str(root/'bin/bake_coastal_light.py'),run_name='__main__')
stats=json.loads((out/'BAKE.json').read_bytes())
assert stats['samples']==24 and {r['mesh']for r in stats['surfaces']}==set(owned)
baked={}
for n in owned:
 o=bpy.data.objects[n];assert shape(o)==shapes[n] and extras(o)==extra[n]
 baked[n]=colors(o.data.color_attributes.active_color)
bpy.ops.wm.open_mainfile(filepath=str(source))
changes=[]
for n,loops in owned.items():
 o=bpy.data.objects[n];a=o.data.color_attributes.active_color;original=colors(a);values=array.array('f',original)
 for i in loops:values[4*i:4*i+4]=baked[n][4*i:4*i+4]
 a.data.foreach_set('color',values);actual=colors(a)
 changed=[i for i in range(len(a.data))if original[4*i:4*i+4]!=actual[4*i:4*i+4]]
 assert set(changed)<=set(loops) and shape(o)==shapes[n] and extras(o)==extra[n]
 changes.append({'owner':n,'eligibleLoopIds':loops,'changedCorners':len(changed),'protectedCornersExact':len(a.data)-len(loops),'shapeSha256':shapes[n]})
after=ns['native_state']()
assert set(before)==set(after) and all(before[n]==after[n]for n in before if n not in owned)
assert ns['materials']()==materials
target=out/'candidate.blend';bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(target),compress=True)
bpy.ops.wm.open_mainfile(filepath=str(target))
assert ns['native_state']()==after and ns['materials']()==materials and sha(source)==expected
receipt={'sourceSha256':expected,'candidateSha256':sha(target),'candidateBytes':target.stat().st_size,'producerSha256':sha(Path(__file__)),'bakerSha256':sha(root/'bin/bake_coastal_light.py'),'maskSha256':sha(mask_path),'changes':changes,'unownedMeshesExact':len(before)-len(owned),'bake':stats,'scope':'Official24sample AO on984 actual moved CORE corners and2111 born BATH rebate-cap corners only. Every protected color, other native field, role and material exact through save/reopen. Local proof only; appearance, global contacts, actual delivered capacity and publication remain separate.'}
(out/'OWNING-ROOF-AO.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k]for k in ['candidateSha256','candidateBytes','unownedMeshesExact']}))
