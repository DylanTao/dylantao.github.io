from pathlib import Path
q=Path(__file__).parent
s=(q/'serve-entrance-checkpoint.py').read_text().replace("'entrance-checkpoint'","'surface-role-checkpoint'").replace("'COMPILED-CUSTODY.json'","'SERVER-CUSTODY.json'")
p=q/'serve-surface-role-checkpoint.py';assert not p.exists();p.write_text(s)
exec(compile(s,str(p),'exec'))
