"""Exact disjoint-owner replay of qualified local rock repairs on the new garden."""
from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path.cwd();q=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=q/'garden-bench-open-plant-ao-v2/candidate.blend'
source_sha='966f7e779d8447dcc632e7be9ae21d5fc064080d510eaf824a054a4e03edc23e'
assert sha(source)==source_sha
patch=Path('C:/dev/site-takeover-worktrees/f6-native-20261029/.jekyll-cache/visual-qa/f6-native-20261029/local-roof-fit-v737-patch')
out=q/'garden-roof-combined-v2';assert not out.exists();out.mkdir()
config=json.loads((patch/'manifest.json').read_bytes())
assert config['acceptedInputSha256']=='f4f2f8b72d69e26abb8c86b962cae9ca17d81d73a6a059a12fbc1601790d7aaf'
assert set(config['targetOwners'])=={'core__golden coastal sandstone','core_bathwing_liftaway_roof'}
assert sha(patch/config['patchAsset'])==config['patchAssetSha256']
shutil.copyfile(patch/config['patchAsset'],out/config['patchAsset'])
shutil.copyfile(patch/'OWNED-LOCAL-AO-MASKS.json',out/'OWNED-LOCAL-AO-MASKS.json')
config['disjointInput']={'previousAcceptedInputSha256':config['acceptedInputSha256'],'parentManifestSha256':sha(patch/'manifest.json'),'scope':'Only accepted input is advanced to whole-olive/garden source. Both exact baseline owner fields and roles still must pass original preflight; every unrelated owner/field/material must pass save/reopen. Appearance, AO and global overlap remain OPEN.'}
config['acceptedInputSha256']=source_sha
(out/'manifest.json').write_text(json.dumps(config,indent=2)+'\n')
command=['D:/tools/blender-4.5.9-windows-x64/blender.exe','--background','--factory-startup','--python-exit-code','1','-t','4','--python',str(root/'bin/replay_coastal_f6_patch.py'),'--','--manifest='+str(out/'manifest.json'),'--source='+str(source),'--expected-source-sha256='+source_sha,'--out='+str(out/'candidate.blend'),'--report='+str(out/'GUARDED-REPLAY.json')]
(out/'COMMAND.json').write_text(json.dumps({'command':command,'replayerSha256':sha(root/'bin/replay_coastal_f6_patch.py')},indent=2)+'\n')
with(out/'replay.log').open('wb')as log:
 r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
result=json.loads((out/'GUARDED-REPLAY.json').read_bytes());assert result['passed']
print(json.dumps({k:result[k]for k in ['passed','outputSha256','allUnrelatedObjectsAndMaterialsExact','canonicalOwnedObjectRolesExact','sourceFileUnchanged']},indent=2))
