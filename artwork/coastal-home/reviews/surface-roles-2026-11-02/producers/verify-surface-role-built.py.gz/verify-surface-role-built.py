from pathlib import Path
import hashlib,json
root=Path.cwd();q=Path(__file__).parent;out=q/'surface-role-checkpoint';built=out/'site/al-folio';before=q/'entrance-checkpoint/site/al-folio'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
module=json.loads((built/'assets/js/module-build.json').read_bytes());rows=[]
for rel,r in module['modules'].items():
 assert hashlib.sha256((root/rel).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==r['sourceSha256']
 assert sha(built/rel)==r['outputSha256']
 assert sha(built/rel)==sha(before/rel)
 rows.append({'path':rel,'sourceSha256':r['sourceSha256'],'outputSha256':r['outputSha256']})
model_rows=[]
for p in sorted((root/'assets/models/home').rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(root);target=built/rel
 if p.suffix=='.json' and p.name!='static-light-field.json':
  assert json.loads(p.read_bytes())==json.loads(target.read_bytes())
  exact='semantic JSON, production minifier whitespace differs'
 else:
  assert sha(p)==sha(target),rel.as_posix()
  exact='byte exact'
 model_rows.append({'path':rel.as_posix(),'sourceSha256':sha(p),'outputSha256':sha(target),'equality':exact})
receipt={'scope':'Actual complete production build. All compiled runtime module bytes equal prior verified entrance build, source inventory exact; every home model/cache byte exact to canonical source, manifest semantically exact. This source-only checker/recipe checkpoint changes no public scene code or geometry.','compiledModules':len(rows),'modules':rows,'models':model_rows,'indexByteExactToPrevious':sha(built/'index.html')==sha(before/'index.html')}
(out/'COMPILED-CUSTODY.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k]for k in ['compiledModules','indexByteExactToPrevious']}))
