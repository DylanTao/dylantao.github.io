"""Complete frozen-module private geometry inspection; not routine admission."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time,urllib.request
root=Path.cwd();q=Path(__file__).parent;seed=q/'arrival-view-preview-v1'
out=q/'geometry-inspection-v1';assert not out.exists();out.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=out/'source';built=out/'site/al-folio'
for name in ['source','site']:shutil.copytree(seed/name,out/name)
models=q/'garden-roof-export-v1/models'
receipt=json.loads((models.parent/'PROCESS.json').read_bytes())
assert receipt['passed'] and receipt['sourceSha256']=='298616af0267ea9820ddd915dc8b81d704f0486a1b67fc20cb4c5402e62e75b3'
for name in ['home-shell.glb','room-kitchen.glb']:
 for folder in [source/'assets/models/home',built/'assets/models/home']:shutil.copyfile(models/name,folder/name)
for folder in [source/'assets/models/home',built/'assets/models/home']:shutil.copyfile(root/'assets/models/home/hinterland.glb',folder/'hinterland.glb')
files={p.relative_to(source).as_posix():sha(p)for p in source.rglob('*')if p.is_file()}
scope='Complete geometry-only inspection on current2986 native/93f9 hinterland, same frozenV20 private modules/metadata as prior standing-view control. Garden coffee motion remains explicitly rejected and no new breakfast placement is admitted. Pause is permitted for geometry capture; normal-clock and final production source require their own later proof.'
(out/'SOURCE-SNAPSHOT.json').write_text(json.dumps({'scope':scope,'seed':str(seed),'files':files,'nativeSourceSha256':receipt['sourceSha256']},indent=2)+'\n')
env=dict(os.environ,BUNDLE_PATH='C:/tools/site-gems-ruby33',NODE_PATH=str(root/'node_modules'))
compile_command=['C:/tools/Ruby33/bin/ruby.exe','C:/tools/Ruby33/bin/bundle','exec','ruby',str(q/'compile-private-modules.rb'),str(source),str(built)]
with(out/'compile.log').open('wb')as log:r=subprocess.run(compile_command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
shutil.copyfile(q/'private-serve-template.py',out/'serve.py')
with(out/'server.log').open('wb')as log:child=subprocess.Popen([sys.executable,str(out/'serve.py')],cwd=root,stdout=log,stderr=subprocess.STDOUT,creationflags=0x08000000)
for _ in range(100):
 if(out/'server.json').exists():break
 assert child.poll()is None;time.sleep(.1)
server=json.loads((out/'server.json').read_bytes());assert server['pid']==child.pid
with urllib.request.urlopen(server['url'],timeout=10)as r:assert r.headers['X-Sirui-Preview']==server['header']
env['COASTAL_CACHE_URL']=server['url'];cmd=[shutil.which('node'),str(source/'bin/bake_coastal_static_light.cjs')]
start=time.monotonic()
with(out/'official-bake.log').open('wb')as log:r=subprocess.run(cmd,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'PROCESS.json').write_text(json.dumps({'exitCode':r.returncode,'seconds':time.monotonic()-start,'server':server,'compile':compile_command,'bake':cmd},indent=2)+'\n')
assert r.returncode==0
for name in ['manifest.json','static-light-field.json']:shutil.copyfile(source/'assets/models/home'/name,built/'assets/models/home'/name)
cache=json.loads((source/'assets/models/home/static-light-field.json').read_bytes());stats=cache['statistics'];config=json.loads(cache['configuration'])
actual={'scope':scope,'server':server,'preROITriangles':stats['triangles']+stats['skippedTriangles'],'cacheBytes':(source/'assets/models/home/static-light-field.json').stat().st_size,'cacheSignature':cache['signature'],'regions':len(config['regions']),'probes':len(cache['probes']),'practicals':len(config['practicalSources'])}
(out/'CAPACITY.json').write_text(json.dumps(actual,indent=2)+'\n')
assert actual['preROITriangles']<=750000 and actual['cacheBytes']<=800000 and [actual[k]for k in ['regions','probes','practicals']]==[16,128,28]
modules=json.loads((built/'assets/js/module-build.json').read_bytes())
for rel,row in modules['modules'].items():assert hashlib.sha256((source/rel).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==row['sourceSha256']and sha(built/rel)==row['outputSha256']
actual['compiledModules']=len(modules['modules']);(out/'CAPACITY-AND-CUSTODY.json').write_text(json.dumps(actual,indent=2)+'\n');print(json.dumps(actual,indent=2))
