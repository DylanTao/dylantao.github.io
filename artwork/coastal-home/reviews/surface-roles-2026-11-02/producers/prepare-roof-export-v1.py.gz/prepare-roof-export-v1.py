from pathlib import Path
import json,subprocess,sys
q=Path(__file__).parent
s=(q/'export-open-garden-bench.py').read_text()
s=s.replace("'garden-bench-open-export-v1'","'garden-roof-export-v1'").replace("'garden-bench-open-ao-v1/candidate.blend'","'garden-roof-owning-ao-v2/candidate.blend'").replace('c4de58834c68d067a4f579dabdbb08818f8fb3c5c691196810d52945e19d7191','298616af0267ea9820ddd915dc8b81d704f0486a1b67fc20cb4c5402e62e75b3')
s=s.replace("seed=wq/'final-v628-maintained-final-five-assets/models'", "seed=q/'garden-bench-open-plant-export-v2/models'")
s=s.replace("--only=home-shell,room-kitchen","--only=home-shell")
p=q/'export-roof-plant-v1.py';assert not p.exists();p.write_text(s)
with(q/'export-roof-plant-v1.log').open('wb')as log:r=subprocess.run([sys.executable,str(p)],cwd=Path.cwd(),stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
print(json.dumps(json.loads((q/'garden-roof-export-v1/PROCESS.json').read_bytes()),indent=2))
