import bpy,hashlib,json,sys
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
root=Path.cwd();q=Path(__file__).parent
source=q/'garden-bench-open-plant-ao-v2/candidate.blend';source_sha='966f7e779d8447dcc632e7be9ae21d5fc064080d510eaf824a054a4e03edc23e'
assert hashlib.sha256(source.read_bytes()).hexdigest()==source_sha
bpy.ops.wm.open_mainfile(filepath=str(source))
def tree(name):
 o=bpy.data.objects[name];o.data.calc_loop_triangles();p=[o.matrix_world@v.co for v in o.data.vertices]
 return BVHTree.FromPolygons(p,[list(t.vertices)for t in o.data.loop_triangles],all_triangles=True)
seat=tree('kitchen_breakfast_cushion');floor=tree('core_breakfast_nook__warm cut stone')
rows=[]
for name,support in [('kitchen_breakfast_cushion.002',seat),('kitchen_nook_olive_pot__terracotta',floor)]:
 o=bpy.data.objects[name];p=[o.matrix_world@v.co for v in o.data.vertices];low=min(v.z for v in p);bounds=[[min(v[k]for v in p)for k in range(3)],[max(v[k]for v in p)for k in range(3)]];samples=[]
 for i,v in enumerate(p):
  if v.z>low+.01:continue
  hit,n,face,distance=support.ray_cast(v+Vector((0,0,.08)),Vector((0,0,-1)),.3)
  samples.append({'vertex':i,'nativePoint':list(v),'supportPoint':list(hit)if hit is not None else None,'gapM':v.z-hit.z if hit is not None else None,'supportNormal':list(n)if n is not None else None})
 center=Vector(((bounds[0][0]+bounds[1][0])/2,(bounds[0][1]+bounds[1][1])/2,low+.08));h,n,f,d=support.ray_cast(center,Vector((0,0,-1)),.3)
 rows.append({'owner':name,'boundsNative':bounds,'lowestSupportSamples':samples,'centerProjection':{'origin':list(center),'point':list(h)if h is not None else None,'bottomGapM':low-h.z if h is not None else None}})
result={'scope':'Read-only actual saved source lower-bearing vertical support probes. These are point witnesses, not full-footprint coverage or dynamic contact acceptance.','sourceSha256':source_sha,'owners':rows}
(q/'GARDEN-PLANT-V2-SUPPORT-POINTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({r['owner']:{'samples':len(r['lowestSupportSamples']),'gapsM':[p['gapM']for p in r['lowestSupportSamples']],'center':r['centerProjection']}for r in rows},indent=2))
