import collections,json,runpy,sys
from pathlib import Path
root=Path.cwd();q=Path(__file__).parent
series=sys.argv[1]if len(sys.argv)>1 else 'final-overlap-v11-roof-plant-native'
p=q/series/'native/AUDIT.json';a=json.loads(p.read_bytes())
totals=runpy.run_path(str(root/'bin/summarize_coastal_overlaps.py'))['totals'](a)
pairs={}
for r in a['interpenetration']:
 if r['severity']<=0 or r.get('grazing')or r['depth']<=.05:continue
 key=' | '.join(sorted([r['a'],r['b']]))
 row=pairs.setdefault(key,{'pair':key,'sites':0,'severity':0.,'maxDepth':0.,'rows':[]})
 row['sites']+=1;row['severity']+=r['severity'];row['maxDepth']=max(row['maxDepth'],r['depth']);row['rows'].append(r)
ranked=sorted(pairs.values(),key=lambda r:-r['severity'])
(q/(series+'-SUMMARY.json')).write_text(json.dumps({'totals':totals,'rankedDeepPairs':ranked},indent=2)+'\n')
print(json.dumps({'totals':totals,'topPairs':[{k:r[k]for k in ['pair','sites','severity','maxDepth']}for r in ranked[:18]]},indent=2))
