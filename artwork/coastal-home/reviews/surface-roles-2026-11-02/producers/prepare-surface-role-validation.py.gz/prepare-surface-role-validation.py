from pathlib import Path
q=Path(__file__).parent
s=(q/'prepare-entrance-validation.py').read_text().replace("'entrance-checkpoint'","'surface-role-checkpoint'").replace("'artwork/coastal-home/reviews/entrance-inspection-2026-11-02'","'artwork/coastal-home/reviews/surface-roles-2026-11-02'")
s=s.replace("'test/coastal-arrival-view.test.mjs'","'test/coastal-arrival-view.test.mjs','test/test_coastal_overlap_surface_role.py'")
exec(compile(s,str(q/'prepare-entrance-validation.py'),'exec'))
(q/'surface-role-checkpoint/site').mkdir()
s=(q/'run-entrance-validation.py').read_text().replace("'entrance-checkpoint'","'surface-role-checkpoint'")
p=q/'run-surface-role-validation.py';assert not p.exists();p.write_text(s)
