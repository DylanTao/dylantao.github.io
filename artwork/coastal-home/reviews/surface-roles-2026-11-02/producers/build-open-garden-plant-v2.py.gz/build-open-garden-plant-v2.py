import bpy,hashlib,json,runpy,sys
from pathlib import Path
root=Path.cwd();q=Path(__file__).parent;sys.path.insert(0,str(root/'bin'))
from coastal_garden_bench import finish_garden_bench
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=q/'finishing-joints-owning-ao-v1/candidate.blend'
assert sha(source)=='f4f2f8b72d69e26abb8c86b962cae9ca17d81d73a6a059a12fbc1601790d7aaf'
out=q/'garden-bench-open-plant-v2';assert not out.exists();out.mkdir()
ns=runpy.run_path(str(root/'artwork/coastal-home/reviews/bedroom-ambience-2026-11-01/replay_lighting.py'))
bpy.ops.wm.open_mainfile(filepath=str(source));before=ns['native_state']();materials=ns['materials']()
result=finish_garden_bench(bpy.context.scene);after=ns['native_state']()
assert all(before[n]==after[n]for n in before if n not in result['owned'])
assert ns['materials']()==materials and len(result['newBoxes'])==6
back=result['changes'][2];assert len(back['positiveParts'])==2
bpy.context.preferences.filepaths.save_version=0;candidate=out/'candidate.blend'
bpy.ops.wm.save_as_mainfile(filepath=str(candidate),compress=True)
bpy.ops.wm.open_mainfile(filepath=str(candidate));assert ns['native_state']()==after and ns['materials']()==materials
assert sha(source)=='f4f2f8b72d69e26abb8c86b962cae9ca17d81d73a6a059a12fbc1601790d7aaf'
receipt={'scope':'PRIVATE bounded correction of the NEW closed tail arch after exact94-frame bridge contact control: same32cm width/depth, remove only upper16cm cushion/oak bridge; whole olive now200mm east of original to clear measured seated distal tail. Six positive closed bearing prisms, two positive closed cushion lobes, original front seat and499unowned meshes/materials exact. Native support/temporal all5 avatars, AO/export/cache/appearance separate.','sourceSha256':sha(source),'candidateSha256':sha(candidate),'helperSha256':sha(root/'bin/coastal_garden_bench.py'),'unownedMeshesExact':len(before)-len(result['owned']),'result':result}
(out/'OPEN-BENCH.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'candidateSha256':sha(candidate),'unownedMeshesExact':receipt['unownedMeshesExact'],'backCushionParts':back['positiveParts']},indent=2))
