import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path.cwd()
q = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=['native', 'decoded', 'volume'])
parser.add_argument('--models', default='C:/dev/site-takeover-worktrees/f6-native-20261029/.jekyll-cache/visual-qa/f6-native-20261029/final-v567-exterior-current/models')
parser.add_argument('--series', default='final-overlap-v2')
parser.add_argument('--source')
parser.add_argument('--source-sha256')
args = parser.parse_args()
mode = args.mode
source = Path(args.source).resolve() if args.source else q / 'exterior-owning-ao-v1/candidate.blend'
models = Path(args.models).resolve()
manifest = models / 'manifest.json'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
expected_source = args.source_sha256 if args.source else '10f2cb6ef204fd38c88274e063edeb1b350aa913094789b4b1017620ebf393ee'
assert expected_source and sha(source) == expected_source
json.loads(manifest.read_bytes())
tool = root / 'bin' / ('audit_coastal_overlap_volume.py' if mode == 'volume' else 'audit_coastal_overlaps.py')
out = (q / args.series / mode).resolve()
assert out.is_relative_to(q)
assert not out.exists()
out.mkdir(parents=True)
command = ['D:/tools/blender-4.5.9-windows-x64/blender.exe', '--background', '--factory-startup', '--python-exit-code', '1', '-t', '4', '--python', str(tool), '--', '--source=' + str(source), '--manifest=' + str(manifest), '--models=' + str(models), '--out=' + str(out / 'AUDIT.json'), '--furniture=1']
if mode == 'decoded':
    command.append('--delivered=1')
inputs = {str(p): sha(p) for p in [source, manifest, tool, root / 'bin/audit_coastal_overlaps.py', *sorted(models.glob('*.glb')), models / 'furniture/index.json']}
receipt = {'mode': mode, 'command': command, 'started': datetime.now(timezone.utc).isoformat(), 'inputs': inputs, 'priorControl': 'Root first invocation failed before loading any geometry because it pointed at the parent manifest path. Those three logs remain as final-{native,decoded,volume}-overlaps.log. This invocation preflights the actual manifest inside models.'}
(out / 'INVOCATION.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
env = dict(os.environ, OPENBLAS_NUM_THREADS='1')
start = time.monotonic()
with (out / 'AUDIT.log').open('wb') as log:
    result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
unchanged = all(sha(Path(p)) == digest for p, digest in inputs.items())
receipt.update(exitCode=result.returncode, elapsedSeconds=time.monotonic() - start, allInputsUnchanged=unchanged, finished=datetime.now(timezone.utc).isoformat())
(out / 'PROCESS.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
print(json.dumps({'mode': mode, 'exitCode': result.returncode, 'allInputsUnchanged': unchanged, 'elapsedSeconds': receipt['elapsedSeconds']}))
assert result.returncode == 0 and unchanged
