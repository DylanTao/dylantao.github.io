from pathlib import Path
import gzip,hashlib,json,shutil
root=Path.cwd();q=Path(__file__).parent;packet=root/'artwork/coastal-home/reviews/surface-roles-2026-11-02';out=q/'surface-role-checkpoint'
manifest=json.loads((packet/'MANIFEST.json').read_bytes());rows=manifest['files'];seen={r['path']for r in rows};sha=lambda b:hashlib.sha256(b).hexdigest()
for rel,p in [(('gates/'+n),out/n)for n in ['UNIT-GATES.json','BUILD-GATES.json','python.log','node.log','style.log','production-build.log','COMPILED-CUSTODY.json','VALIDATION-SOURCE.json']]+[(('producers/'+n),q/n)for n in ['prepare-surface-role-validation.py','run-surface-role-validation.py','verify-surface-role-built.py','append-surface-role-gates.py']]:
 target=packet/(rel+'.gz');assert target.relative_to(packet).as_posix()not in seen;target.parent.mkdir(parents=True,exist_ok=True)
 body=p.read_bytes();stored=gzip.compress(body,mtime=0)
 if target.exists():assert target.read_bytes()==stored,'Only byte-identical unpublished interrupted deposits may resume'
 else:target.write_bytes(stored)
 rows.append({'path':target.relative_to(packet).as_posix(),'bytes':len(stored),'sha256':sha(stored),'encoding':'gzip','bodyBytes':len(body),'bodySha256':sha(body)})
(packet/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
shutil.copytree(packet,Path('C:/dev/cqa1102')/packet.relative_to(root),dirs_exist_ok=True)
print(json.dumps({'payloads':len(rows),'storedBytes':sum(r['bytes']for r in rows)}))
