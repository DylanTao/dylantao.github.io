import hashlib
import json
from pathlib import Path
import subprocess
import sys

root=Path.cwd()
q=Path(__file__).resolve().parent
source=q/'garden-bench-open-plant-ao-v2/candidate.blend'
source_sha='966f7e779d8447dcc632e7be9ae21d5fc064080d510eaf824a054a4e03edc23e'
assert hashlib.sha256(source.read_bytes()).hexdigest()==source_sha
out=q/'garden-bench-open-plant-body-v2'
assert not out.exists()
out.mkdir()
old=q/'fresh-garden-v8-body'
for name in ['extract.py','native-body.mjs','native-portal.mjs','qualify-standing-head.mjs']:
    text=(old/name).read_text(encoding='utf8')
    text=text.replace((q/'owning-ao-v1/candidate.blend').as_posix(),source.as_posix())
    text=text.replace('f89c2c2eb438a78ed7c9bb84779248fe9846fe902acd18ae1140ef16765bf295',source_sha)
    text=text.replace('f89c2c2e','1de522d9').replace('actual f89 source','actual complete bench-relief and moved whole-olive source')
    (out/name).write_text(text,encoding='utf8',newline='\n')
commands=[('extract',['D:/tools/blender-4.5.9-windows-x64/blender.exe','--background','--factory-startup','--python-exit-code','1','-t','4','--python',str(out/'extract.py')]),('legacy-body',['node',str(out/'native-body.mjs')]),('qualified-head',['node',str(out/'qualify-standing-head.mjs')]),('portal',['node',str(out/'native-portal.mjs')])]
rows=[]
for name,command in commands:
    with(out/(name+'.log')).open('wb')as log:
        result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
    rows.append({'name':name,'command':command,'exitCode':result.returncode})
    if name!='legacy-body'and result.returncode:
        break
(out/'PROCESS.json').write_text(json.dumps({'sourceSha256':source_sha,'processes':rows,'scope':'Fresh extraction of actual complete bench-relief and moved whole-olive source. Same105required finite standing/route boxes and unchanged SAT; original off-aisle head collector retained as failed diagnostic, with existing inside-box2.1m qualification separately executed. No export or gait claim.'},indent=2)+'\n',encoding='utf8')
print(json.dumps(rows,indent=2))
assert len(rows)==4 and all(r['exitCode'] == 0 for r in rows if r['name']!='legacy-body')
