from pathlib import Path
import json,subprocess,sys
q=Path(__file__).parent;root=Path.cwd()
newsha='966f7e779d8447dcc632e7be9ae21d5fc064080d510eaf824a054a4e03edc23e'
text=(q/'check-open-garden-bench-body.py').read_text().replace("'garden-bench-open-ao-v1/candidate.blend'","'garden-bench-open-plant-ao-v2/candidate.blend'").replace('c4de58834c68d067a4f579dabdbb08818f8fb3c5c691196810d52945e19d7191',newsha).replace("'garden-bench-open-body-v1'","'garden-bench-open-plant-body-v2'")
p=q/'check-open-garden-plant-body-v2.py';assert not p.exists();p.write_text(text)
with(q/'check-open-garden-plant-body-v2.log').open('wb')as log:
 r=subprocess.run([sys.executable,str(p)],stdout=log,stderr=subprocess.STDOUT,cwd=root)
assert r.returncode==0
text=(q/'inspect-garden-support.py').read_text().replace("'garden-bench-open-ao-v1/candidate.blend'","'garden-bench-open-plant-ao-v2/candidate.blend'").replace('c4de58834c68d067a4f579dabdbb08818f8fb3c5c691196810d52945e19d7191',newsha).replace("'GARDEN-SUPPORT-POINTS.json'","'GARDEN-PLANT-V2-SUPPORT-POINTS.json'")
p=q/'inspect-garden-plant-v2-support.py';assert not p.exists();p.write_text(text)
cmd=['D:/tools/blender-4.5.9-windows-x64/blender.exe','--background','--factory-startup','--python-exit-code','1','-t','4','--python',str(p)]
with(q/'inspect-garden-plant-v2-support.log').open('wb')as log:
 r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,cwd=root)
assert r.returncode==0
print(json.dumps({'sourceSha256':newsha,'body':json.loads((q/'garden-bench-open-plant-body-v2/PROCESS.json').read_bytes()),'support':json.loads((q/'GARDEN-PLANT-V2-SUPPORT-POINTS.json').read_bytes())},indent=2))
