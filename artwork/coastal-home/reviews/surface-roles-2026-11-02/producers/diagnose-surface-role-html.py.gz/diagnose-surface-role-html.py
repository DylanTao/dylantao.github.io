from pathlib import Path
import difflib,hashlib,json,re
q=Path(__file__).parent
old=q/'entrance-checkpoint/site/al-folio/index.html';new=q/'surface-role-checkpoint/site/al-folio/index.html'
a=old.read_text(encoding='utf8');b=new.read_text(encoding='utf8')
ta=re.findall(r'<[^>]+>|[^<]+',a);tb=re.findall(r'<[^>]+>|[^<]+',b)
rows=[]
for tag,a0,a1,b0,b1 in difflib.SequenceMatcher(None,ta,tb,autojunk=False).get_opcodes():
 if tag=='equal':continue
 rows.append({'kind':tag,'oldTokens':ta[a0:a1],'newTokens':tb[b0:b1]})
receipt={'scope':'Read-only complete built homepage HTML difference; all189 compiled modules unchanged and public model/cache bytes exact.','beforeSha256':hashlib.sha256(old.read_bytes()).hexdigest(),'afterSha256':hashlib.sha256(new.read_bytes()).hexdigest(),'changes':rows}
(q/'surface-role-checkpoint/HTML-DIFFERENCE.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'changes':[{'kind':r['kind'],'before':[s[:200]for s in r['oldTokens']],'after':[s[:200]for s in r['newTokens']]}for r in rows]},indent=2))
