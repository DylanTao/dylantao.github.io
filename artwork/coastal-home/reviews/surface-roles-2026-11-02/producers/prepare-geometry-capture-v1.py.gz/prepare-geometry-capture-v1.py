from pathlib import Path
q=Path(__file__).parent
s=(q/'capture-private-current.cjs').read_text().replace("'private-current-v1'","'geometry-inspection-v1'").replace("'native-preliminary-views'","'native-paused-geometry-views-v1'")
s=s.replace('COMPLETE compiled-seed candidate, native2K ordinary public Room/Pause/fullscreen/arrow UI; preliminary appearance before final coffee/camera metadata and global-overlap fixes.', 'COMPLETE2986 geometry/4da9 shell/f092 kitchen/93f9 hinterland and official473c cache; frozenV20 private modules, ordinary public Room/Pause/fullscreen/arrow UI. Paused geometry evidence ONLY. Garden coffee motion remains rejected; final pavilion and fin profile still open.')
p=q/'capture-geometry-inspection-v1.cjs';assert not p.exists();p.write_text(s)
