from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path.cwd();q=Path(__file__).parent
packet=root/'artwork/coastal-home/reviews/surface-roles-2026-11-02'
assert sorted(p.name for p in packet.iterdir())==['README.md']
sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
def deposit(relative,path):
 body=Path(path).read_bytes();target=packet/(relative+'.gz');assert not target.exists()
 target.parent.mkdir(parents=True,exist_ok=True);stored=gzip.compress(body,mtime=0);target.write_bytes(stored)
 rows.append({'path':target.relative_to(packet).as_posix(),'bytes':len(stored),'sha256':sha(stored),'encoding':'gzip','bodyBytes':len(body),'bodySha256':sha(body)})
for mode in ['native','decoded']:
 for n in ['AUDIT.json','AUDIT.log','PROCESS.json','INVOCATION.json']:deposit('canonical/'+mode+'/'+n,q/'surface-role-current-canonical-v1'/mode/n)
for n in ['prior-overlap-audit.json','TARGETED.json','targeted.log']:deposit('initial-gates/'+n,q/'surface-role-checkpoint'/n)
for folder,names in {
 'garden-bench-open-plant-v2':['OPEN-BENCH.json'],
 'garden-bench-open-plant-ao-v2':['OWNED-GARDEN-BENCH-AO.json','BAKE.json'],
 'garden-bench-open-plant-export-v2':['PROCESS.json','command.json','export.json'],
 'garden-bench-open-plant-body-v2':['PROCESS.json','COMPOSED-NATIVE-BODY-SUMMARY.json','STANDING-HEAD-QUALIFICATION.json','COMPOSED-NATIVE-PORTAL-WIDTH.json','legacy-body.log'],
 'garden-roof-combined-v1':['FAILED-PREFLIGHT.json'],
 'garden-roof-combined-v2':['GUARDED-REPLAY.json','COMMAND.json','OWNED-LOCAL-AO-MASKS.json'],
 'garden-roof-owning-ao-v1':['BAKE.json'],
 'garden-roof-owning-ao-v2':['OWNING-ROOF-AO.json'],
 'garden-roof-export-v1':['PROCESS.json','command.json','export.json'],
 'geometry-inspection-v1':['CAPACITY-AND-CUSTODY.json','PROCESS.json','SOURCE-SNAPSHOT.json'],
 'geometry-inspection-v1/native-paused-geometry-views-v1':['CAPTURE.json','outside-default.png','entrance-default.png','kitchen-default.png']
}.items():
 for n in names:deposit('private-controls/'+folder+'/'+n,q/folder/n)
for series in ['final-overlap-v11-roof-plant-native','final-overlap-v12-surface-roof-native','final-overlap-v13-measured-roof-native']:
 for n in ['AUDIT.json','PROCESS.json']:deposit('private-audits/'+series+'/'+n,q/series/'native'/n)
for n in ['GARDEN-PLANT-V2-SUPPORT-POINTS.json','GEOMETRY-INSPECTION-V1-CRITIQUE.json','bake-local-roof-plant.log','bake-local-roof-plant-v2.log']:deposit('private-controls/'+n,q/n)
worker=Path('C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/coffee-contact-v6/open-bench-v40-plant-f092-causal-47_8-v1')
for p in sorted(worker.iterdir()):
 if p.is_file():deposit('independent-pot-repeat/'+p.name,p)
selected=['bin/audit_coastal_overlaps.py','bin/coastal_breakfast_nook.py','bin/coastal_garden_bench.py','bin/replay_coastal_f6_patch.py','test/test_coastal_overlap_surface_role.py','test/test_resting_review_custody.py','artwork/coastal-home/reviews/house-2026-10-24/overlap-audit.json','artwork/coastal-home/reviews/house-2026-10-24/overlap-verdicts.json','docs/october-2026-handoff.md']
source=[]
for n in selected:
 deposit('selected-source/'+n,root/n);source.append({'path':n,'gitLfSha256':sha((root/n).read_bytes().replace(b'\r\n',b'\n'))})
for n in ['launch-final-audit.py','prepare-surface-role-checkpoint.py','summarize-roof-plant-v11.py','prepare-open-garden-plant-v2.py','build-open-garden-plant-v2.py','bake-open-garden-plant-v2.py','export-open-garden-plant-v2.py','check-open-garden-plant-v2.py','check-open-garden-plant-body-v2.py','inspect-garden-plant-v2-support.py','merge-local-roof-plant.py','bake-local-roof-plant.py','qualify-local-roof-ao-v2.py','bake-local-roof-plant-v2.py','prepare-roof-export-v1.py','export-roof-plant-v1.py','prepare-geometry-inspection-v1.py','prepare-geometry-capture-v1.py','capture-geometry-inspection-v1.cjs','archive-surface-role-checkpoint.py']:
 deposit('producers/'+n,q/n)
source_record={'parent':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':source,'scope':'Source/checker recipe checkpoint only. Canonical native master/public models/cache unchanged; private source paths and their retained unadmitted input SHAs are evidence, not newly public binaries. Full global limits unchanged. Guarded local roof fit and rejected silhouette controls remain separately identified.'}
p=q/'SURFACE-ROLE-SOURCE.json';assert not p.exists();p.write_text(json.dumps(source_record,indent=2)+'\n');deposit('SOURCE.json',p)
(packet/'MANIFEST.json').write_text(json.dumps({'schema':'coastal-surface-roles-v1','scope':'Actual source-bound native/decoded public audit plus distinct private plant, fit, failed-control and geometry-only evidence. README is editorial. Gates appended before first publication.','files':rows},indent=2)+'\n')
print(json.dumps({'payloads':len(rows),'storedBytes':sum(r['bytes']for r in rows)}))
