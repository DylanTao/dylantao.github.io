const { chromium } = require('playwright');
const fs = require('node:fs/promises');
const path = require('node:path');
const { PNG } = require('pngjs');
const q='.jekyll-cache/visual-qa/f6-native-20261029';
const base=process.env.F6_BASE_URL || 'http://127.0.0.1:4144/al-folio';
const prefix=process.env.F6_CAPTURE || 'v18-final';
const config=require(path.resolve('assets/models/home/manifest.json'));
const library=config.rooms.find(r=>r.id==='library');
const eyeRecords=[];
(async()=>{
 const browser=await chromium.launch({args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
 let page;const errors=[];const states={};
 try{
  page=await browser.newPage({viewport:{width:3840,height:2160},deviceScaleFactor:1,ignoreHTTPSErrors:true});
  page.on('requestfailed',r=>console.log('REQUEST_FAILED',r.resourceType(),new URL(r.url()).origin+new URL(r.url()).pathname,r.failure()?.errorText));
  page.on('response',r=>{if(r.status()>=400)console.log('HTTP_FAILED',r.status(),new URL(r.url()).origin+new URL(r.url()).pathname)});
  page.on('pageerror',e=>errors.push(String(e)));
  page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
  await page.emulateMedia({reducedMotion:'reduce'});
  await page.clock.setFixedTime(new Date('2026-10-28T14:00:00-07:00'));
  console.log('PHASE navigation');await page.goto(base+'/?scene-lab=1&quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});
  await page.evaluate(async()=>{const T=await import('/al-folio/assets/js/three.module.min.js');window.__F6Three=T;window.__F6Cameras=new Set();const original=T.Object3D.prototype.lookAt;T.Object3D.prototype.lookAt=function(...args){const result=original.apply(this,args);if(this.isPerspectiveCamera)window.__F6Cameras.add(this);return result}});
  await page.locator('[data-home-desk-mode="3d"]').click();
  await page.waitForFunction(()=>['ready','failed','error'].includes(document.querySelector('[data-home-desk-scene]')?.dataset.sceneState),null,{timeout:180000});
  if(await page.locator('[data-home-desk-scene]').getAttribute('data-scene-state')!=='ready')throw Error('Scene startup failed; see request-failure phase log');
  console.log('PHASE scene ready');
  const scene=page.locator('[data-home-desk-scene]'),canvas=scene.locator('canvas'),lab=page.locator('[data-world-lab]');
  const evidence=()=>scene.evaluate(e=>e.getSceneEvidence());
  const open=async()=>{if(!await lab.evaluate(e=>e.open))await lab.locator('summary').first().click()};
  const close=async()=>{if(await lab.evaluate(e=>e.open))await lab.locator('summary').first().click()};
  const frame=async(fn)=>{const n=(await evidence()).frames;await fn();await page.waitForFunction(n=>document.querySelector('[data-home-desk-scene]').getSceneEvidence().frames>n,n,{timeout:60000});};
  console.log('PHASE fullscreen');await page.locator('[data-world-fullscreen]').click();
  await open();await page.locator('[data-world-avatar]').selectOption('simpsons');
  await page.waitForFunction(()=>document.querySelector('[data-home-desk-scene]').getSceneEvidence().avatarId==='simpsons',null,{timeout:90000});
  await frame(()=>page.locator('[data-world-room="outside"]').click());await close();
  await page.waitForFunction(()=>{
   const element=document.querySelector('[data-home-desk-scene]');let flora=0,hinterland=0;
   element.labScene.scene.traverse(o=>{if(o.isMesh&&o.name.startsWith('core_flora_'))flora++;if(o.name.startsWith('hinterland_'))hinterland++});
   return flora>15&&hinterland>0&&element.labScene.scene.getObjectByName('clifftop-flora')?.visible===true&&element.labScene.scene.getObjectByName('coastal-hinterland')?.visible===true&&element.getSceneEvidence().ecology.wildlife.modelsReady;
  },null,{timeout:90000});
  const readyFrame=(await evidence()).frames;await scene.evaluate(e=>e.labScene.requestFrame());
  await page.waitForFunction(n=>document.querySelector('[data-home-desk-scene]').getSceneEvidence().frames>n,readyFrame,{timeout:60000});
  states.modelReadiness=await scene.evaluate(e=>({flora:e.labScene.scene.getObjectByName('clifftop-flora').visible,hinterland:e.labScene.scene.getObjectByName('coastal-hinterland').visible,frame:e.getSceneEvidence().frames}));
  console.log('PHASE complete models visible');await canvas.focus();
  await frame(()=>canvas.press('ArrowRight'));await frame(()=>canvas.press('ArrowRight'));
  await frame(()=>canvas.press('+'));await frame(()=>canvas.press('+'));
  await page.waitForTimeout(800);
  states.front=await evidence();await canvas.screenshot({path:path.join(q,prefix+'-front-4k.png')});
  for(let i=0;i<3;i++)await frame(()=>canvas.press('ArrowLeft'));
  await page.waitForTimeout(800);
  states.threeQuarter=await evidence();await canvas.screenshot({path:path.join(q,prefix+'-three-quarter-4k.png')});
  await open();await frame(()=>page.locator('[data-world-room="study"]').click());await close();
  await page.waitForTimeout(800);
  states.study=await evidence();await canvas.screenshot({path:path.join(q,prefix+'-study-public-4k.png')});
  await open();await page.locator('[data-world-activity]').selectOption('reading');await close();
  await page.waitForFunction(()=>{const e=document.querySelector('[data-home-desk-scene]').getSceneEvidence();return e.activity==='reading'&&!e.traveling},null,{timeout:90000});
  await page.waitForTimeout(800);
  const seated=await scene.evaluate((element,library)=>{
   const root=element.labScene.scene.getObjectByName('active-Sirui'),eyes=[];
   root.traverse(o=>{if(o.isBone&&/Eye(L|R|Left|Right)$/.test(o.name))eyes.push(o.getWorldPosition(root.position.clone()))});
   if(eyes.length!==2)throw Error('Two actual delivered optical eye bones required; found '+eyes.length);
   const eye=eyes[0].add(eyes[1]).multiplyScalar(.5);const local=root.worldToLocal(eye.clone());
   const c=Math.cos(library.facing||0),s=Math.sin(library.facing||0),anchor=library.actor;
   return {kind:'seated',eye:[anchor[0]+local.x*c+local.z*s,anchor[1]+local.y,anchor[2]-local.x*s+local.z*c],
    sourceEyeWorld:eye.toArray(),sourceActorWorld:root.getWorldPosition(root.position.clone()).toArray(),
    sourceLocalEye:local.toArray(),anchor,avatar:element.getSceneEvidence().avatarId,
    scope:'Actual runtime reading-pose optical bones rigidly placed at the modeled library reading-seat anchor'};
  },library);
  eyeRecords.push(seated);
  async function eyeStill(record){
   if(record.kind==='seated'){
    await scene.evaluate((element,record)=>element.setLabCamera({target:[record.eye[0],record.eye[1],record.eye[2]-1],yaw:0,pitch:0,radius:1,free:true}),record);
   }
   await page.waitForFunction(eye=>{const p=document.querySelector('[data-home-desk-scene]').getSceneEvidence().camera;return Math.hypot(...p.map((v,i)=>v-eye[i]))<.025},record.eye,{timeout:30000});
   await page.waitForTimeout(800);
   record.actualDrawnCamera=(await evidence()).camera;
   const buffer=await canvas.screenshot(),png=PNG.sync.read(buffer);let low=255,high=0;
   for(let i=0;i<png.data.length;i+=4*127){low=Math.min(low,png.data[i]);high=Math.max(high,png.data[i])}
   if(high-low<40)throw Error('Eye beauty still is blank');
   await fs.writeFile(path.join(q,prefix+'-'+record.kind+'-eye-full-pipeline-4k.png'),buffer);
  }
  await eyeStill(seated);

  const debug=await scene.evaluate(element=>{
   const T=window.__F6Three,e=element.getSceneEvidence(),c=[...window.__F6Cameras].sort((a,b)=>a.position.distanceTo(new T.Vector3().fromArray(e.camera))-b.position.distanceTo(new T.Vector3().fromArray(e.camera)))[0];
   c.updateMatrixWorld();const meshes=[];element.labScene.scene.traverse(o=>{if(!o.isMesh)return;for(let p=o;p;p=p.parent)if(!p.visible)return;meshes.push(o)});
   return{camera:{position:c.position.toArray(),matrixWorld:c.matrixWorld.toArray(),projectionMatrix:c.projectionMatrix.toArray()},picks:[[.25,.8],[.3,.68],[.42,.87],[.3,.52],[.46,.7]].map(uv=>{const r=new T.Raycaster();r.setFromCamera(new T.Vector2(uv[0]*2-1,1-uv[1]*2),c);return{uv,hits:r.intersectObjects(meshes,false).slice(0,12).map(h=>{const m=Array.isArray(h.object.material)?h.object.material[h.face.materialIndex]:h.object.material;return{name:h.object.name,parent:h.object.parent.name,point:h.point.toArray(),distance:h.distance,face:h.faceIndex,material:{name:m.name,type:m.type,color:m.color?.toArray(),opacity:m.opacity,transparent:m.transparent,colorWrite:m.colorWrite,depthWrite:m.depthWrite,side:m.side},data:h.object.userData}})}})};
  });
  for(let i=1;i<=2;i++){const n=(await evidence()).frames;await scene.evaluate(e=>e.labScene.requestFrame());await page.waitForFunction(n=>document.querySelector('[data-home-desk-scene]').getSceneEvidence().frames>n,n,{timeout:30000});await canvas.screenshot({path:path.join(q,prefix+'-seated-extra-frame'+i+'.png')});}

  await scene.evaluate(e=>{const found=[];e.labScene.scene.traverse(o=>{if(o.isMesh&&o.name.startsWith('coast_continuous_cliff_foundation')){found.push(o);const old=o.onBeforeRender;o.onBeforeRender=function(renderer,...args){window.__F6Renderer=renderer;return old.call(this,renderer,...args)}}});window.__F6CoastForState=found;});
  await frame(()=>scene.evaluate(e=>e.labScene.requestFrame()));
  const bound=await scene.evaluate(e=>{
   const summarize=value=>{if(typeof value==='number'||typeof value==='boolean')return value;if(value?.isTexture)return{texture:true,width:value.image?.width,height:value.image?.height,type:value.type,format:value.format};if(value?.toArray)return value.toArray();if(ArrayBuffer.isView(value)||Array.isArray(value)){let min=Infinity,max=-Infinity,nonfinite=0;for(const x of value){if(typeof x!=='number')continue;if(!Number.isFinite(x))nonfinite++;else{min=Math.min(min,x);max=Math.max(max,x)}}return{length:value.length,min,max,nonfinite}}return typeof value};
   return{field:e.getSceneEvidence().simulation.lightField,receiverPacks:e.getSceneEvidence().simulation.installations.receiverPacks,materials:window.__F6CoastForState.map(o=>{const m=o.material,p=window.__F6Renderer.properties.get(m),a=o.geometry.attributes.color;return{name:o.name,material:m.name,propertyKeys:Object.keys(p),uniforms:Object.fromEntries(Object.entries(p.uniforms||{}).filter(([k])=>/contact|slf|install|lightWell/i.test(k)).map(([k,u])=>[k,summarize(u.value)])),liveColor:{itemSize:a?.itemSize,normalized:a?.normalized,arrayType:a?.array.constructor.name}}})};
  });
  const modes={scope:'In-memory native AO/contact/installation controls ONLY; no acceptance, source edit, rebake, cache or capacity change.'};
  await scene.evaluate(()=>{window.__F6SavedColors=window.__F6CoastForState.map(o=>{const a=o.geometry.attributes.color;const old=a.array.slice();const v=a.normalized?(a.array instanceof Uint8Array?255:a.array instanceof Uint16Array?65535:1):1;a.array.fill(v);a.needsUpdate=true;return[a,old]})});
  await frame(()=>scene.evaluate(e=>e.labScene.requestFrame()));await frame(()=>scene.evaluate(e=>e.labScene.requestFrame()));
  await canvas.screenshot({path:path.join(q,prefix+'-DIAGNOSTIC-white-native-AO.png')});
  await scene.evaluate(()=>{for(const [a,old] of window.__F6SavedColors){a.array.set(old);a.needsUpdate=true}});
  for(const mode of ['normalized-bump']){
   modes[mode]=await scene.evaluate((element,mode)=>{const clones=new Map(),rows=[];window.__F6SavedMaterial=[];for(const o of window.__F6CoastForState){const old=o.material;let clone=clones.get(old);if(!clone){clone=old.clone();const hook=old.onBeforeCompile,key=old.customProgramCacheKey;clone.customProgramCacheKey=()=>key.call(old)+':DIAGNOSTIC-'+mode;clone.onBeforeCompile=function(shader,renderer){hook.call(this,shader,renderer);const name=mode==='contact-off'?'contactEnabled':mode==='installation-off'?'installActive':null;if(name&&shader.uniforms[name])shader.uniforms[name]={value:mode==='contact-off'?false:0};if(mode==='normal-bump-off'){const target='normal = normalize(abs(det)*normal - gradient);';if(!shader.fragmentShader.includes(target))throw Error('Expected derivative bump target missing');shader.fragmentShader=shader.fragmentShader.replace(target,'normal = normal;');}if(mode==='normal-nan-visualization'){shader.fragmentShader=shader.fragmentShader.replace('#include <tonemapping_fragment>','if (any(notEqual(normal,normal))) gl_FragColor=vec4(1.,0.,0.,1.); else gl_FragColor=vec4(normal*.5+.5,1.);\n#include <tonemapping_fragment>');}window.__F6DiagnosticUniforms??=[];window.__F6DiagnosticUniforms.push({mode,material:this.name,uniform:name,bound:name?shader.uniforms[name]?.value:null})};clones.set(old,clone)}window.__F6SavedMaterial.push([o,old]);o.material=clone;rows.push(o.name)}return rows;},mode);
   await scene.evaluate(()=>{for(const [o] of window.__F6SavedMaterial){const hook=o.material.onBeforeCompile;o.material.onBeforeCompile=function(shader,renderer){hook.call(this,shader,renderer);const target=/vec3 eyeX = dFdx\(-vViewPosition\), eyeY = dFdy\(-vViewPosition\);\s*vec3 r1 = cross\(eyeY, normal\), r2 = cross\(normal, eyeX\);\s*float det = dot\(eyeX, r1\);\s*vec3 gradient = sign\(det\) \* \(dFdx\(height\)\*r1 \+ dFdy\(height\)\*r2\);\s*normal = normalize\(abs\(det\)\*normal - gradient\);/;if(!target.test(shader.fragmentShader))throw Error('Complete derivative bump target missing');shader.fragmentShader=shader.fragmentShader.replace(target,`vec3 eyeX = dFdx(-vViewPosition), eyeY = dFdy(-vViewPosition);
      float xScale = max(length(eyeX), 1e-10);
      float yScale = max(length(eyeY), 1e-10);
      eyeX /= xScale;
      eyeY /= yScale;
      vec3 r1 = cross(eyeY, normal), r2 = cross(normal, eyeX);
      float det = dot(eyeX, r1);
      vec3 gradient = sign(det) * ((dFdx(height)/xScale)*r1 + (dFdy(height)/yScale)*r2);
      vec3 bumpNormal = abs(det)*normal - gradient;
      float bumpLength2 = dot(bumpNormal,bumpNormal);
      normal = bumpLength2 > 1e-12 ? bumpNormal*inversesqrt(bumpLength2) : normal;`);};}});
   await frame(()=>scene.evaluate(e=>e.labScene.requestFrame()));await frame(()=>scene.evaluate(e=>e.labScene.requestFrame()));
   await canvas.screenshot({path:path.join(q,prefix+'-DIAGNOSTIC-'+mode+'.png')});
   modes[mode+'-actual-bound']=await scene.evaluate(()=>window.__F6SavedMaterial.map(([o,old])=>{const u=window.__F6Renderer.properties.get(o.material).uniforms;return{mesh:o.name,isClone:o.material!==old,contact:u?.contactEnabled?.value,install:u?.installActive?.value,slf:u?.slfReady?.value}}));
   const views=[
    {id:'far-front',target:states.front.target,...states.front.cameraOrbit},
    {id:'close-coast-face',target:[14.15395,-3.23438,-11.7258],yaw:Math.PI,pitch:0,radius:1},
    {id:'grazing-floor',target:[-9.8,.1-Math.sin(.025),-1.3-Math.cos(.025)],yaw:0,pitch:.025,radius:1}
   ];
   const controls=[];
   await scene.evaluate(()=>{window.__F6BumpPairs=window.__F6SavedMaterial.map(([o,old])=>[o,old,o.material]);});
   for(const view of views){
    await scene.evaluate((e,v)=>e.setLabCamera({...v,free:true}),view);
    await page.waitForTimeout(800);
    const viewRecord={view,states:{}};
    for(const treatment of ['original','normalized']){
     await scene.evaluate((e,t)=>{for(const [o,old,fixed] of window.__F6BumpPairs)o.material=t==='original'?old:fixed;e.labScene.requestFrame();},treatment);
     await frame(()=>scene.evaluate(e=>e.labScene.requestFrame()));await frame(()=>scene.evaluate(e=>e.labScene.requestFrame()));
     viewRecord.states[treatment]=await evidence();
     await canvas.screenshot({path:path.join(q,prefix+'-DIAGNOSTIC-'+view.id+'-'+treatment+'.png')});
    }
    viewRecord.projectedDerivativeWitnesses=await scene.evaluate(e=>{
     const T=window.__F6Three,ev=e.getSceneEvidence(),cam=[...window.__F6Cameras].sort((a,b)=>a.position.distanceTo(new T.Vector3().fromArray(ev.camera))-b.position.distanceTo(new T.Vector3().fromArray(ev.camera)))[0];cam.updateMatrixWorld();
     const w=3840,h=2160,meshes=window.__F6CoastForState,view=new T.Matrix3().setFromMatrix4(cam.matrixWorldInverse);
     const hit=(px,py)=>{const ray=new T.Raycaster();ray.setFromCamera(new T.Vector2((px+.5)/w*2-1,1-(py+.5)/h*2),cam);return ray.intersectObjects(meshes,false)[0]};
     const out=[];
     for(const uv of [[.5,.5],[.25,.8],[.42,.87],[.3,.68],[.3,.9],[.15,.5],[.3,.5],[.5,.8],[.7,.8],[.1,.8]]){
      const x=Math.floor(uv[0]*w/2)*2,y=Math.floor(uv[1]*h/2)*2,a=hit(x,y),b=hit(x+1,y),c=hit(x,y+1);
      if(!a||!b||!c||a.object!==b.object||a.object!==c.object||a.faceIndex!==b.faceIndex||a.faceIndex!==c.faceIndex){out.push({uv,valid:false,reason:'Quad crosses triangle/owner or has no coast hit'});continue;}
      const dx=b.point.clone().sub(a.point).applyMatrix3(view),dy=c.point.clone().sub(a.point).applyMatrix3(view).negate(),normal=(a.normal||a.face.normal).clone().applyMatrix3(new T.Matrix3().getNormalMatrix(a.object.matrixWorld)).normalize().applyMatrix3(view).normalize();
      const lx=dx.length(),ly=dy.length(),det=dx.dot(new T.Vector3().crossVectors(dy,normal));
      out.push({uv,valid:true,mesh:a.object.name,face:a.faceIndex,world:a.point.toArray(),xDerivativeM:lx,yDerivativeM:ly,originalDeterminant:det,normalizedDeterminant:det/(lx*ly),scope:'CPU ray/quad reconstruction on same delivered triangle, not GPU height derivative readback'});
     }
     const gl=window.__F6Renderer.getContext(),precision=gl.getShaderPrecisionFormat(gl.FRAGMENT_SHADER,gl.HIGH_FLOAT);
     return{camera:cam.position.toArray(),highFloat:{rangeMin:precision.rangeMin,rangeMax:precision.rangeMax,precision:precision.precision},samples:out};
    });
    controls.push(viewRecord);
   }
   modes.matchedViewControls=controls;
   await scene.evaluate(()=>{const disposed=new Set();for(const [o,old] of window.__F6SavedMaterial){if(!disposed.has(o.material)){disposed.add(o.material);o.material.dispose()}o.material=old}});
  }
  const actualOverrides=await page.evaluate(()=>window.__F6DiagnosticUniforms||[]);
  await fs.writeFile(path.join(q,prefix+'-bound-state.json'),JSON.stringify({bound,modes,actualOverrides,debug,errors,eyeRecords,states},null,2));console.log('Bound AO and receiver controls captured');return;


  await open();await frame(()=>page.locator('[data-world-room="library"]').click());await close();
  await canvas.focus();await canvas.press('v');
  await page.waitForFunction(()=>document.querySelector('[data-home-desk-scene]').getSceneEvidence().walk.active,null,{timeout:90000});
  const placement=await scene.evaluate(element=>{
   for(const position of [[-10.55,0,1.25],[-10.55,0,1.6],[-10.55,0,2.1],[-10.4,0,2.7]]){
    if(element.setLabWalk({position,yaw:Math.PI,pitch:0}))return position;
   }
   return null;
  });
  if(!placement)throw Error('No actual collision-validated library standing placement');
  await page.waitForFunction(p=>{const e=document.querySelector('[data-home-desk-scene]').getSceneEvidence();return e.walk.active&&Math.hypot(e.walk.position[0]-p[0],e.walk.position[2]-p[2])<.05},placement,{timeout:30000});
  await page.waitForTimeout(600);
  const walk=await evidence();
  const standing={kind:'standing',eye:walk.camera,avatar:walk.avatarId,walk:walk.walk,
    placement,scope:'Declared library lab placement accepted by the actual Walk collision field; real public Walk optical camera and complete normal rendering pipeline'};
  eyeRecords.push(standing);states.walk=walk;await eyeStill(standing);
  await fs.writeFile(path.join(q,prefix+'-review.json'),JSON.stringify({base,errors,states,eyeRecords,
   eyeStillScope:'Complete normal rendering pipeline. Seated optical bones are rigidly placed at the library seat through setLabCamera; standing uses a declared library setLabWalk placement validated by the real collision field. Navigation proof is separate.'},null,2));
  console.log(prefix+' review captured');
 }catch(error){
  const state=await page?.evaluate(()=>({stage:document.querySelector('[data-home-desk-scene]')?.dataset,evidence:document.querySelector('[data-home-desk-scene]')?.getSceneEvidence?.()})).catch(e=>({error:String(e)}));
  await fs.writeFile(path.join(q,prefix+'-review-failure.json'),JSON.stringify({error:String(error),errors,state,eyeRecords},null,2));
  throw error;
 }finally{await browser.close();}
})().catch(error=>{console.error(error);process.exitCode=1});
