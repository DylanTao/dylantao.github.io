const http=require('node:http');
async function startLoopbackPreview(port=4155){
 const server=http.createServer((req,res)=>{
  if(!['GET','HEAD'].includes(req.method)||!req.url.startsWith('/')){res.writeHead(405);res.end();return}
  const upstream=http.request({hostname:'host.docker.internal',port,path:req.url,method:req.method,headers:req.headers},response=>{
   res.writeHead(response.statusCode,response.headers);response.pipe(res);
  });
  upstream.on('error',error=>{if(!res.headersSent)res.writeHead(502);res.end(error.message)});
  req.pipe(upstream);res.on('close',()=>upstream.destroy());
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve)});
 return {baseURL:`http://127.0.0.1:${port}/al-folio`,close:()=>new Promise(resolve=>{server.close(resolve);server.closeAllConnections()})};
}
module.exports={startLoopbackPreview};
