const fs=require('node:fs'),path=require('node:path'),{spawn}=require('node:child_process');
const {startSceneEnvironment}=require('../../../bin/visual_scene_environment.cjs');
(async()=>{
 const folder=path.resolve('.jekyll-cache/visual-qa/pc-camera-audit-20261029/mesa-sweeps-final');fs.mkdirSync(folder,{recursive:true});
 const owned=await startSceneEnvironment(folder);const preview=await require('./loopback-proxy.cjs').startLoopbackPreview();
 try {
  const child=spawn(process.execPath,['node_modules/@playwright/test/cli.js','test','--config','.jekyll-cache/visual-qa/house-final-2026-10-28/qualified.config.cjs','--workers','1','--grep','desktop orbit sweeps','desk-scene.spec.js','--project','desktop-1440','--reporter','line','--output',path.join(folder,'cases')],{env:{...owned.env,NO_WEBSERVER:'1',VISUAL_BASE_URL:preview.baseURL},stdio:'inherit'});
  process.exitCode=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('exit',resolve)});
 }finally{await preview.close();await owned.close()}
})().catch(e=>{process.stderr.write(e.stack+'\n');process.exitCode=1});
