import { readFileSync, writeFileSync } from 'node:fs';
import * as THREE from '../../../assets/js/three.module.min.js';
import { nativeGeometry } from '../../../test/helpers/coastal-native-geometry.mjs';
import { walkKind } from '../../../assets/js/home-scene/colliders.mjs';
const config=JSON.parse(readFileSync('assets/models/home/manifest.json'));
const files=[config.shell,...config.rooms.map(r=>r.file),config.coast,config.flora,config.hinterland?.file].filter(Boolean);
const objects=[];
for(const file of files){const root=await nativeGeometry(file);root.traverse(o=>{if(o.isMesh&&walkKind(o,root)){o.material.side=THREE.DoubleSide;objects.push(o)}})}
const x=-2.7645890438490124,z=22.99926357171053,rows=[];
const ray=new THREE.Raycaster(new THREE.Vector3(),new THREE.Vector3(0,-1,0),0,2);
for(let i=-1;i<16;i++){
const angle=i*Math.PI/8,r=i<0?0:.24,px=x+r*Math.cos(angle),pz=z+r*Math.sin(angle);ray.ray.origin.set(px,9,pz);
const hits=ray.intersectObjects(objects,false).filter(h=>h.face.normal.clone().transformDirection(h.object.matrixWorld).y>.2);
rows.push({x:px,z:pz,hits:hits.slice(0,3).map(h=>({name:h.object.name,y:h.point.y,face:h.faceIndex}))});
}
writeFileSync('.jekyll-cache/visual-qa/pc-camera-audit-20261029/entrance-floor-probe.json',JSON.stringify(rows,null,2)+'\n');
console.log(JSON.stringify(rows,null,2));
