from pathlib import Path
import json,math,hashlib
q=Path('.jekyll-cache/visual-qa/laundry-2026-10-28');d=json.loads((q/'cloth-live-cycle.json').read_text());poses=[json.loads((q/'cloth-still-geometry.json').read_text())]+d['samples'];p=[v for row in poses for v in row['positions']];lo=[min(v[i] for v in p) for i in range(3)];hi=[max(v[i] for v in p) for i in range(3)];best=(math.inf,None);n=0;routes=0
with (q/'companion-flights.jsonl').open() as f:
 context=json.loads(next(f))
 for line in f:
  row=json.loads(line)
  if row.get('type')!='flight':continue
  routes+=1
  for i,p in enumerate(row['centers']):
   dist=math.sqrt(sum(max(lo[j]-p[j],0,p[j]-hi[j])**2 for j in range(3)));n+=1
   if dist<best[0]:best=(dist,{'route':row['id'],'sample':i,'center':p})
r={'scope':'All sampled P centers against one conservative union AABB containing every particle in the 19 captured cloth poses. This bounds the captured garments and rope; it is not an all-weather proof.','clothBounds':[lo,hi],'routes':routes,'samples':n,'minimumCenterBoxDistanceM':best[0],'witness':best[1],'companionRadiusM':.42,'passed':best[0]>=.42,'flightContext':context,'clothLiveSha256':hashlib.sha256((q/'cloth-live-cycle.json').read_bytes()).hexdigest()};(q/'companion-cloth-audit.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));assert r['passed']
