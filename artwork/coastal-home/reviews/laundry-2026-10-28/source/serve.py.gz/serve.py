from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import unquote,urlsplit
import hashlib,json
Q=Path.cwd()/'.jekyll-cache/visual-qa/laundry-2026-10-28';BASE=(Q/'baseline-site/al-folio').resolve();CAND=(Q/'candidate-assets').resolve()
class Handler(SimpleHTTPRequestHandler):
 def translate_path(self,path):
  name=unquote(urlsplit(path).path).removeprefix('/al-folio/').lstrip('/');active=json.loads((Q/'active.json').read_text());root=CAND if active['variant']=='candidate' and name in active['overrides'] else BASE;full=(root/name).resolve();self.binding=None
  if not full.is_relative_to(root):return str(root/'forbidden')
  if full.is_file() and (name.startswith('assets/js/home-scene/') or name.startswith('assets/models/home/')):
   body=full.read_bytes();self.binding={'sha':hashlib.sha256(body).hexdigest(),'variant':active['variant'],'origin':'candidate' if root==CAND else 'complete-frozen-production'}
  return str(full)
 def end_headers(self):
  self.send_header('Cache-Control','no-store')
  if getattr(self,'binding',None):
   self.send_header('X-Laundry-Sha256',self.binding['sha']);self.send_header('X-Laundry-Source',self.binding['origin']);self.send_header('X-Laundry-Variant',self.binding['variant'])
  super().end_headers()
 def log_message(self,*args):pass
print('Laundry4123: complete frozen production baseline; explicit candidate overrides only.',flush=True)
ThreadingHTTPServer(('127.0.0.1',4123),Handler).serve_forever()
