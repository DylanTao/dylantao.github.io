from pathlib import Path
import json,struct,hashlib
q=Path('.jekyll-cache/visual-qa/laundry-2026-10-28')
def glb(p):
 b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+n]);off=20+n;size=struct.unpack_from('<I',b,off)[0];return j,b[off+8:off+8+size]
a,ab=glb(q/'baseline-export/home-shell.glb');b,bb=glb(q/'candidate-assets/assets/models/home/home-shell.glb')
def node(j,body,n):
 v={k:x for k,x in n.items() if k!='mesh'}
 if 'mesh' in n:
  mesh=j['meshes'][n['mesh']];prims=[]
  for p in mesh['primitives']:
   d=p['extensions']['KHR_draco_mesh_compression'];view=j['bufferViews'][d['bufferView']];start=view.get('byteOffset',0);prim={k:x for k,x in p.items() if k not in ['attributes','indices','extensions','material']};prim['dracoAttributes']=d['attributes'];prim['dracoPayloadSha256']=hashlib.sha256(body[start:start+view['byteLength']]).hexdigest();prim['accessors']={k:j['accessors'][i] for k,i in p['attributes'].items()};prim['indices']=j['accessors'][p['indices']];prim['material']=j['materials'][p['material']];prims.append(prim)
  v['mesh']={**{k:x for k,x in mesh.items() if k!='primitives'},'primitives':prims}
 return v
A={n['name']:node(a,ab,n) for n in a['nodes'] };B={n['name']:node(b,bb,n) for n in b['nodes'] };changed=[k for k in A if A[k]!=B.get(k)];added=sorted(set(B)-set(A));r={'oldDeliveredNodes':len(A),'oldMeshNodes':sum('mesh' in n for n in a['nodes']),'changed':changed,'added':added,'unchanged':not changed,'baselineSha256':hashlib.sha256((q/'baseline-export/home-shell.glb').read_bytes()).hexdigest(),'candidateSha256':hashlib.sha256((q/'candidate-assets/assets/models/home/home-shell.glb').read_bytes()).hexdigest(),'candidateBytes':(q/'candidate-assets/assets/models/home/home-shell.glb').stat().st_size,'scope':'Compressed Draco payloads, accessor metadata, material descriptors, transforms and extras for every retained mesh node.'};(q/'delivered-identity.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));assert not changed and added==['core_laundry_frame_posts']
