import fs from 'node:fs';
import {createLaundryLine,createTerraceDraft} from '../../../assets/js/home-scene/laundry-line.mjs';
import {createCoastWind} from '../../../assets/js/home-scene/wind-field.mjs';
import {laundryFrame,windInFrame} from '../../../assets/js/home-scene/laundry-frame.mjs';
const q='.jekyll-cache/visual-qa/laundry-2026-10-28', f=JSON.parse(fs.readFileSync(q+'/candidate-recipe.json')).frame;
f.translation[2]-=.03;const rows=[];
for(const [minute,start] of [[840,0],[840,300],[930,300]]){
 const coast=createCoastWind({minute,doors:1}),wind=windInFrame(createTerraceDraft({coast}),laundryFrame(f));
 const {island,model}=createLaundryLine({wind,rail:[],floorY:0,postBaseY:-.03,postTopY:2.57});island.settle(1.5);island.wake();
 let peak=0,at=0,worst=[];
 for(let k=0;k<1800;k++){const t=start+k/30;coast.update({seconds:t,minute});island.step(t);let where=[];const e=island.strain(where,true);if(e>peak){peak=e;at=t;worst=where;}}
 rows.push({minute,start,seconds:60,peak,at,worst,counts:island.counts,passed:peak<.2});
}
fs.writeFileSync(q+'/cloth-frame-stress.json',JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify(rows,null,2));if(rows.some(r=>!r.passed))process.exitCode=1;
