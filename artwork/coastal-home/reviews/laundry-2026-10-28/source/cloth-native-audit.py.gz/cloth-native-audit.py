import bpy,json,sys,math,hashlib,numpy as np
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
Q=Path.cwd()/'.jekyll-cache/visual-qa/laundry-2026-10-28';sys.path.insert(0,str(Path.cwd()/'bin'))
import audit_coastal_overlaps as audit
source=Q/'candidate.blend';bpy.ops.wm.open_mainfile(filepath=str(source));vertices=[];triangles=[];owners=[]
for obj in bpy.context.scene.objects:
 if obj.type!='MESH' or obj.get('shadowOnly') or obj.get('facadeDoor') or obj.get('estateDoor'):continue
 if obj.get('flora') and not any(m and any(k in m.name.lower() for k in ['bark','trunk']) for m in obj.data.materials):continue
 mesh=obj.data;mesh.calc_loop_triangles();offset=len(vertices);vertices.extend((obj.matrix_world@v.co) for v in mesh.vertices)
 for tri in mesh.loop_triangles:
  if tri.area<1e-12:continue
  triangles.append([offset+i for i in tri.vertices]);owners.append(obj.name)
tree=BVHTree.FromPolygons(vertices,triangles,all_triangles=True);nativeP=np.array([[vertices[i] for i in t] for t in triangles])
a=json.loads((Q/'cloth-live-cycle.json').read_text());still=json.loads((Q/'cloth-still-geometry.json').read_text());poses=[{'id':'still',**still}]+[{'id':'live-'+str(i),**p} for i,p in enumerate(a['samples'])];faces=[r['index'][i:i+3] for r in a['items'] for i in range(0,len(r['index']),3)];records=[]
for row in poses:
 points=[Vector((p[0],-p[2],p[1])) for p in row['positions']];cloth=BVHTree.FromPolygons(points,faces,all_triangles=True);pairs=tree.overlap(cloth);crossings=[]
 if pairs:
  ids=np.asarray(pairs,dtype=np.int64);P=np.array([[points[i] for i in f] for f in faces]);s0,s1,length,coplanar=audit.segments(nativeP[ids[:,0]],P[ids[:,1]])
  crossings=[{'native':owners[int(ids[k,0])],'clothTriangle':int(ids[k,1]),'seamLength':float(length[k])} for k in np.flatnonzero(length>1e-6)]
 members=set(i for f in faces for i in f);near=min((tree.find_nearest(points[i])[3],i) for i in members);records.append({'id':row['id'],'crossingTriangles':crossings,'minimumVertexClearanceM':near[0],'minimumVertex':near[1],'finite':all(math.isfinite(v) for p in row['positions'] for v in p),'strain':row['laundry']['maxStretch']})
# Bearing witnesses exclude the hardware itself, so a pole cannot support itself.
new=bpy.data.objects['core_laundry_frame_posts'];frame=json.loads(new['nativeLaundryFrame']);support=[]
obj=bpy.data.objects['core_estate_terrace__travertine paving stone'];mesh=obj.data
host=BVHTree.FromPolygons([obj.matrix_world@v.co for v in mesh.vertices],[list(f.vertices) for f in mesh.polygons])
for pole,p in enumerate(frame['postsWorld']):
 for k in range(9):
  x=p[0]+(.028*math.cos(k*math.tau/8) if k<8 else 0);z=p[2]+(.028*math.sin(k*math.tau/8) if k<8 else 0)
  hit,n,index,d=host.ray_cast(Vector((x,-z,.2)),Vector((0,0,-1)),.5)
  bearing={'object':obj.name,'point':[hit.x,hit.z,-hit.y],'triangle':index,'heightError':abs(hit.z-p[1])} if hit is not None else None
  support.append({'pole':pole,'sample':k,'bearing':bearing})
report={'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'poses':records,'support':support,'passed':all(not r['crossingTriangles'] and r['finite'] and r['strain']<.2 for r in records) and all(r['bearing'] and r['bearing']['heightError']<.00001 for r in support),'scope':'Actual browser-rendered cloth triangles against native hard geometry; finite sampled poses, not an all-weather proof. Eighteen native paving bearing witnesses.'}
(Q/'cloth-native-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
if not report['passed']:raise RuntimeError('Native cloth/support gate failed')
