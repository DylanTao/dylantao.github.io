from pathlib import Path
q=Path(__file__).parent
s=(q/'check-4f-live-v1.py').read_text(encoding='utf8')
s=s.replace("'ci-4f-live-v1'", "'gym-ci-live-v1'")
s=s.replace('4f325d2e6ec33781793c4e8534697b85d6f273f3','273063754da6a0b8a4986578df7b59d1953b0fb7')
s=s.replace('len(runs)==7','len(runs)==8').replace('41556029652','41575238527')
s=s.replace("'assets/js/home-scene/room-journey.mjs',", "'assets/js/home-scene/light-trace-core.mjs','assets/js/home-scene/light-installations.mjs','assets/js/home-scene/realism.mjs',")
s=s.replace('private house geometry/routine/light experiments are not included.', 'the strict directed gym repair is included. Native/GLB geometry and optional breakfast venue remain unchanged. Private crown/arrival/garden/coffee integration is not included.')
p=q/'check-gym-live-v1.py';assert not p.exists();compile(s,str(p),'exec');p.write_text(s,encoding='utf8',newline='\n')
print(str(p))
