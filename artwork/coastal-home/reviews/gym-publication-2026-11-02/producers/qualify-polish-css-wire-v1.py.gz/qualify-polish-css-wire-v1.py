from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,urllib.request
q=Path(__file__).parent
out=q/'public-polish-review-v2'
r=json.loads((out/'CAPTURE.json').read_bytes())
s=r['server'];built=q/'gym-directed-checkpoint/site/al-folio'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not r['errors'] and not r['failed']
assert len([row for row in r['rows']if 'file'in row])==20
bad=[row for row in r['responses']if row.get('error')or not row['exact']or row['status']>=400 or row['owner']!=s['header']]
assert len(bad)==8 and {row['path']for row in bad}=={'assets/css/main.css','assets/css/site-icons.css'}
wire=[]
for rel in sorted({row['path']for row in bad}):
    expected=(built/rel).read_bytes()
    assert expected.startswith(b'\xef\xbb\xbf')
    with urllib.request.urlopen(s['url']+rel+'?wire-polish=1',timeout=20)as response:
        body=response.read();status=response.status;owner=response.headers['X-Sirui-Preview']
    assert status==200 and owner==s['header']and body==expected
    matching=[row for row in bad if row['path']==rel]
    assert all(row['sha256']==sha(expected[3:])and row['bytes']==len(expected)-3 for row in matching)
    wire.append({'path':rel,'status':status,'owner':owner,'wireBytes':len(body),'wireSha256':sha(body),'fileExact':True,'browserBodyBytes':len(expected)-3,'browserBodySha256':sha(expected[3:]),'browserDifference':'Exactly the leading UTF8 BOM, no other byte difference','matchedObservedResponses':len(matching)})
receipt={'at':datetime.now(timezone.utc).isoformat(),'scope':'Qualification of retained strict CSS observer failure only. Server independently returns exact original production bytes; all eight Chromium stylesheet bodies equal those bytes after omission of exactly the UTF8 BOM. No CSS, asset, runtime, assertions or captured image changed. Original failed capture remains failed; this separate qualification supplies actual wire/source binding for the twenty completed visual views. Not physical-phone/performance or house admission.','sourceCaptureSha256':sha((out/'CAPTURE.json').read_bytes()),'server':s,'views':20,'otherExactResponses':len(r['responses'])-len(bad),'wire':wire,'passed':True}
p=out/'WIRE-QUALIFICATION.json';assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps(receipt,indent=2))
