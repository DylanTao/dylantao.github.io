from pathlib import Path
import json
q=Path(__file__).parent
s=(q/'capture-public-polish-v1.cjs').read_text(encoding='utf8')
s=s.replace("'public-polish-review-v1'", "'public-polish-review-v2'")
s=s.replace("e=>e.firstChild.textContent.trim()", "e=>e.textContent.replaceAll(',', '').trim()")
p=q/'capture-public-polish-v2.cjs'
assert not p.exists()
p.write_text(s,encoding='utf8',newline='\n')
(q/'public-polish-review-v1/OBSERVATION-CORRECTION.json').write_text(json.dumps({'scope':'QA getter assumed first child held full first name, but the real animation uses one span per letter. Observed S is only the first letter. V2 reads complete actual text, removing the separately animated comma. No product change or relaxed identity check.'},indent=2)+'\n',encoding='utf8')
