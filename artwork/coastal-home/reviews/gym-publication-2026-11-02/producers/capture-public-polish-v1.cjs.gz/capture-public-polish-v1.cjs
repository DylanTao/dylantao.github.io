const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const { chromium, expect } = require('@playwright/test');
const q = __dirname, preview = path.join(q, 'gym-directed-checkpoint');
const server = JSON.parse(fs.readFileSync(path.join(preview, 'server.json')));
const built = path.join(preview, 'site/al-folio'), base = server.url;
const out = path.join(q, 'public-polish-review-v1');
if (fs.existsSync(out)) throw Error('Fresh evidence required');
fs.mkdirSync(out);
const hash = b => crypto.createHash('sha256').update(b).digest('hex');
const errors = [], failed = [], responses = [], pending = [], rows = [];
async function theme(p, mode) {
  await p.locator('[data-theme-toggle]:visible').first().click();
  await p.locator(`[data-theme-mode-option="${mode}"]:visible`).first().click();
  await p.locator('[data-theme-toggle]:visible').first().click();
  await p.waitForTimeout(900);
}
async function shot(p, label, selector = null) {
  const target = selector ? p.locator(selector) : p;
  const file = label + '.png';
  await target.screenshot({path:path.join(out, file)});
  const layout = await p.evaluate(() => ({viewport:[innerWidth,innerHeight],scrollWidth:document.documentElement.scrollWidth, theme:document.documentElement.dataset.theme}));
  expect(layout.scrollWidth).toBeLessThanOrEqual(layout.viewport[0] + 1);
  rows.push({label,file,layout});
}
(async () => {
  const browser = await chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
  try {
    for (const [label,width,height,touch] of [['desktop',2560,1440,false],['phone-size',390,1000,true]]) {
      const context = await browser.newContext({viewport:{width,height},deviceScaleFactor:1,isMobile:touch,hasTouch:touch,timezoneId:'America/Los_Angeles',reducedMotion:'no-preference'});
      const p = await context.newPage(); p.setDefaultTimeout(60000);
      await p.route(/https:\/\/(?:analytics\.google\.com|www\.google-analytics\.com|www\.googletagmanager\.com|plausible\.io)\//,r=>r.fulfill({status:204,body:''}));
      p.on('pageerror',e=>errors.push({label,error:e.message}));
      p.on('console',m=>{if(m.type()==='error')errors.push({label,error:m.text()});});
      p.on('requestfailed',r=>failed.push({label,url:r.url(),failure:r.failure()}));
      p.on('response',r=>{if(!r.url().startsWith(base)||!/\.(?:js|mjs|glb|json|css|webp)(?:\?|$)/.test(r.url()))return;
        pending.push((async()=>{try {const body=await r.body(),rel=decodeURIComponent(new URL(r.url()).pathname.slice(new URL(base).pathname.length)),expected=fs.readFileSync(path.join(built,rel));responses.push({label,path:rel,status:r.status(),bytes:body.length,sha256:hash(body),exact:body.equals(expected),owner:r.headers()['x-sirui-preview']});} catch(e) {responses.push({label,url:r.url(),error:String(e)});}})());});
      await p.goto(base,{waitUntil:'domcontentloaded'}); await p.evaluate(()=>document.fonts.ready);
      await theme(p,'noon');
      const identity = await p.locator('.brand-name-first').evaluate(e=>e.firstChild.textContent.trim());
      expect(identity).toBe('Sirui');
      await shot(p,label+'-home-noon');
      await shot(p,label+'-brand-rest','.site-brand');
      const name=p.locator('[data-brand-discover]');
      if(touch)await name.tap();else await name.hover();
      await p.waitForTimeout(4400);if(!touch)await p.mouse.move(width-30,140);
      await shot(p,label+'-brand-story','.site-brand');
      await p.locator('.home-artifact-stack').scrollIntoViewIfNeeded();
      await p.waitForTimeout(900);await shot(p,label+'-artifacts-noon');
      for(const mode of ['noon','evening']) {
        if(mode==='evening')await theme(p,mode);
        const mini=p.locator('[data-miniature]');
        await mini.scrollIntoViewIfNeeded();await expect(mini).toHaveAttribute('data-state','ready',{timeout:120000});
        await shot(p,label+'-miniature-'+mode,'[data-miniature]');
        const footer=p.locator('footer [data-footer-coast]');
        await footer.scrollIntoViewIfNeeded();await expect(footer).toHaveAttribute('data-state','ready',{timeout:120000});
        await shot(p,label+'-footer-'+mode,'footer.coastal-page-footer');
        rows.push({label,mode,miniature:await mini.evaluate(e=>e.getCoastEvidence()),footer:await footer.evaluate(e=>e.getCoastEvidence())});
      }
      await p.goto(base+'cv/',{waitUntil:'domcontentloaded'});await p.evaluate(()=>document.fonts.ready);
      for(const mode of ['noon','evening']) {await theme(p,mode);await shot(p,label+'-cv-'+mode);}
      await context.close();
    }
    await Promise.all(pending);
    const receipt={at:new Date().toISOString(),scope:'Current complete production seed, canonical model/compiled module product. Native2K and390px phone-sized Chromium layout review of brand, coffee artifacts, miniature, footer and CV, public theme/pointer/touch only; no physical-phone or performance claim. House native integration remains separate.',server,rows,errors,failed,responses};
    fs.writeFileSync(path.join(out,'CAPTURE.json'),JSON.stringify(receipt,null,2)+'\n');
    expect(errors).toEqual([]);expect(failed).toEqual([]);expect(responses.filter(r=>r.error||!r.exact||r.status>=400||r.owner!==server.header)).toEqual([]);
    console.log(JSON.stringify({views:rows.filter(r=>r.file).length,responses:responses.length,errors,failed,out}));
  } finally {await browser.close();}
})().catch(e=>{fs.writeFileSync(path.join(out,'FAILURE.json'),JSON.stringify({error:String(e),rows,errors,failed,responses},null,2));console.error(e);process.exitCode=1;});
