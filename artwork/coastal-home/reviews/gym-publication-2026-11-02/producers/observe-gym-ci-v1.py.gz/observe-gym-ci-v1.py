from pathlib import Path
from datetime import datetime, timezone
import json
import subprocess

ROOT = Path.cwd()
Q = Path(__file__).parent / 'gym-ci-observations-v1'
HEAD = '273063754da6a0b8a4986578df7b59d1953b0fb7'
Q.mkdir(exist_ok=True)

def gh(*args):
    return json.loads(subprocess.check_output(['gh', *args, '--repo', 'DylanTao/dylantao.github.io'], cwd=ROOT))

runs = gh('run', 'list', '--commit', HEAD, '--limit', '20', '--json', 'databaseId,workflowName,status,conclusion,url,headSha')
visual = gh('run', 'view', '41575238527', '--json', 'status,conclusion,jobs,headSha,url')
assert visual['headSha'] == HEAD
assert len(visual['jobs']) == 46
now = datetime.now(timezone.utc)
record = {'at': now.isoformat(), 'sourceHead': HEAD, 'runs': runs, 'visual': visual}
(Q / (now.strftime('%Y%m%dT%H%M%S%f') + '.json')).write_text(json.dumps(record, indent=2) + '\n', encoding='utf8')
bad = lambda row: row['conclusion'] not in ('', 'success', 'skipped')
print(json.dumps({'at': record['at'], 'visualStatus': visual['status'], 'visualConclusion': visual['conclusion'], 'passed': sum(j['conclusion'] == 'success' for j in visual['jobs']), 'total': 46, 'failedJobs': [{'name': j['name'], 'conclusion': j['conclusion'], 'id': j['databaseId']} for j in visual['jobs'] if bad(j)], 'workflows': [{'name': r['workflowName'], 'status': r['status'], 'conclusion': r['conclusion']} for r in runs]}, indent=2))
