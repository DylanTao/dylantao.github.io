from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,urllib.request
root=Path.cwd();q=Path(__file__).parent;out=q/'gym-ci-live-v1';assert not out.exists();out.mkdir()
head='273063754da6a0b8a4986578df7b59d1953b0fb7'
run=lambda args:subprocess.check_output(args,cwd=root)
assert run(['git','rev-parse','HEAD']).decode().strip()==head
assert run(['git','rev-parse','origin/main']).decode().strip()==head
pages=run(['git','rev-parse','origin/gh-pages']).decode().strip();subject=run(['git','log','-1','--format=%s',pages]).decode().strip();assert head in subject
runs=json.loads(run(['gh','run','list','--commit',head,'--limit','15','--json','databaseId,name,status,conclusion,headSha,url']))
assert len(runs)==8 and all(r['headSha']==head and r['status']=='completed'and(r['conclusion']=='success'or(r['name']=='Check for broken links'and r['conclusion']=='skipped'))for r in runs)
visual=json.loads(run(['gh','run','view','41575238527','--json','databaseId,status,conclusion,jobs,headSha,url']))
assert visual['headSha']==head and visual['conclusion']=='success'and len(visual['jobs'])==46 and all(j['conclusion']=='success'for j in visual['jobs'])
(out/'RUNS.json').write_text(json.dumps(runs,indent=2)+'\n',encoding='utf8');(out/'VISUAL-JOBS.json').write_text(json.dumps(visual,indent=2)+'\n',encoding='utf8')
rows=[];sha=lambda b:hashlib.sha256(b).hexdigest()
for rel in ['index.html','assets/js/module-build.json','assets/js/home-scene/controller.mjs','assets/js/home-scene/warm-practicals.mjs','assets/js/home-scene/static-light-field.mjs','assets/js/home-scene/light-trace-core.mjs','assets/js/home-scene/light-installations.mjs','assets/js/home-scene/realism.mjs','assets/models/home/manifest.json','assets/models/home/static-light-field.json','assets/models/home/home-shell.glb']:
    expected=run(['git','show',pages+':'+rel]);url='https://dylantao.github.io/'+(''if rel=='index.html'else rel)+'?delivery='+head
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Sirui-site-deployment-verification'}),timeout=60)as response:body=response.read();status=response.status
    exact=body==expected;row={'path':rel,'url':url,'status':status,'bytes':len(body),'sha256':sha(body),'expectedSha256':sha(expected),'exact':exact};rows.append(row)
    assert status==200 and exact,row
    if rel=='assets/js/module-build.json':
        modules=json.loads(body)['modules'];assert len(modules)==189
        for name,record in modules.items():assert sha((root/name).read_bytes().replace(b'\r\n',b'\n'))==record['sourceSha256']
receipt={'at':datetime.now(timezone.utc).isoformat(),'sourceHead':head,'pagesHead':pages,'pagesSubject':subject,'visualRun':visual['url'],'visualJobsPassed':46,'compiledSourceModules':len(modules),'allApplicableRunsPassed':True,'responses':rows,'scope':'Exact public deployment readback after all46current visual jobs and other applicable workflows succeeded. Prior cancelled/failed runs remain retained. This is publication of the source/checker/CI checkpoint; the strict directed gym repair is included. Native/GLB geometry and optional breakfast venue remain unchanged. Private crown/arrival/garden/coffee integration is not included.'}
(out/'DELIVERY.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');print(json.dumps(receipt,indent=2))
