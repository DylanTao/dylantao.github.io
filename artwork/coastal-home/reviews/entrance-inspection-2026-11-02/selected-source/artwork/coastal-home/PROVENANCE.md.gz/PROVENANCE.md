# Coastal home asset provenance

## November 2: source-bound entrance planting clearance

The [entrance inspection](reviews/entrance-inspection-2026-11-02/README.md)
removes eight complete old hillside shrub components intersecting the actual
new inclined stair opening. Only `hinterland.blend` (`0dc3ee23…`) and its GLB
(`93f90372…`) change. All 93 other native meshes, 159 other compressed
primitives and every retained decoded planting position, normal and color are
exact. The public house master remains `1e10b25d…`; the new straight-arrival
metadata, garden and fin source require their separate final integration.

## November 2: integrated bedside light and kitchen olive

The [ambience integration](reviews/ambience-integration-2026-11-02/README.md)
replays the qualified bedside practical/region and olive recipes onto the
retained native source in Blender 4.5.9. The current master is
`1e10b25d5cf0eec87d7001acbf9d938d65ba33af6076380d5a8e5d45cf3d23e7`.
All 459 unowned original meshes retain their native geometry and fields. Only
the forty replacement leaves and six new branches receive the owning native
24-sample contact/indirect bake. Sleep and kitchen exports, the official light
cache, perch source binding and full overlap reports are regenerated. The
review distinguishes exact native preservation from the shared kitchen wood's
bounded codec quantization and records desktop/WebKit appearance evidence.
Cliff, arrival and garden-nook changes still require their own integration.

## October 31: retained hardware, foliage and reading light

The [combined interior checkpoint](reviews/interior-integration-2026-10-31/README.md)
replays the qualified hardware, Epipremnum and paper-lantern recipes on the retained
native source using Blender 4.5.9. Sirui confirmed 43 inch and 31.5 inch displays,
a 17 inch laptop and a tower beneath the desk. Whole hardware assemblies retain
their topology, finish attributes and interaction anchors. Thirty trailing leaf
blades receive curved, light-facing laminae while every petiole remains rooted.
The suspended paper lantern has a measured ceiling attachment and at least
2.1775 m of standing clearance; its one bounded analytic line is direct-only.

The study, library and upper library receive a fresh native contact/bounce bake
and effort-10 Draco exports. Geometry and effective normals are exact across that
bake. The official static-light producer, perch contacts and loading drawings
are regenerated. The drawings use lossless deflate packing; their decoded
coordinates, line weights and pen order remain byte-exact. No external bitmap or
new reference artwork is included in these additions. Cliff and entrance trials
remain private until their independent geometry and visual gates pass.

## October 24: house retreat and a more open living prospect

This is the current design/source contract. The [dated house review](../../docs/design-reviews/2026-10-24/HOUSE_REVISION.md) records final native/browser evidence, release custody and remaining limits. The dated October 23
records below preserve their actual earlier geometry and evidence. Their broad
piers, two-level library, rear bedroom corridor and upper arrival glass door do
not override Sirui's subsequent correction.

`bin/coastal_retreat.py` and `refresh_coastal_retreat.py` move the dwelling eight
meters landward into the cave while preserving the coast and shoreline. The
lighter terrace/pool should read as borne by rock, with a relaxed clifftop
hangout and useful lower-living-to-patio circulation. A curved 48-tread main
descent enters the lower living foyer through an oak proximity door. One bowed
16-tread internal stair replaces the duplicated straight routes. A discreet
private spiral approach serves the onsen without the former obstructing glass
door.

The screen-right cave library becomes one tall room with high bookshelves,
a rolling ladder that is nonclimbable in Walk, a recessed warm hearth and the
complete original workstation. Its native workstation translation is
`[-10.4, 6.7, -2.6]` before the final eight-meter setback. A compact spiral connects the bedroom wing through the retained upper bridge; immediate adjacency remains partial, as recorded in the house review. The former main-house study becomes private chill space. Original desk devices, props, source links and fitted activity
contacts belong to that assembly, rather than being independently approximated.

`coastal_bathrooms.py` refines the flush stone floors and vanity lighting;
`coastal_interior_refinement.py` supplies fitted Strelitzia, Asplenium and
Epipremnum compositions plus the library hearth. The matched pre-setback native
images and their bounded proof are retained in
[the interior source review](reviews/interior-refinement-2026-10-24/README.md).
Living curtains remain parked for the panorama at night and during private
sleep, with only a small low-sun response. No new texture set, PointLight or
shadow map is attributed to those decoration changes.

The short-window NWS forecast and NOAA daily precipitation custody, chronological
validation and seasonal fallback are recorded in
[the weather source review](weather-2026-10-24/README.md). The fallback is a small
statistical scene model, not a claim of SOTA forecasting. Outside recorded NWS
hourly intervals, the runtime identifies seasonal simulation explicitly.
`coastal-rain.mjs` renders a bounded authored line field in one draw, with no
extra rendering pass or shadow caster. Pause holds its active-time positions;
the existing live routine clock may still refresh the weather plan.

The final native refresh must keep one housing frame across geometry, actors,
anchors, CPU/GPU wind shelter, fixtures, materials, reflections and wildlife
perches. Manifest world coordinates are transformed once, not again at render
time. A manifold result alone is insufficient: this revision exposed a foliage
Boolean that produced an unintended grass sheet. Native/rendered inspection
and actual bearing/circulation probes remain acceptance gates alongside
closed-solid checks. No final release SHA or completed browser proof is claimed
by this source contract.

## October 23: coastal estate, library and arrival garden

The estate continues the retained Blender source with original geometry in
`coastal_estate_architecture.py` and `coastal_estate_outdoors.py`. The screen-right cave library
has two connected levels, fitted book walls, an ocean-facing reading bay, a private writing
gallery and a bedroom connection behind the bathrooms. Its internal stair reaches the usable
side of the writing desk through an 82 cm passage. The public lower foyer and private upper
arrival have separate fluted-glass pocket doors. Only the complete bedroom artwork and foyer
bench assemblies move; existing routine, desk, bed and bathing anchors remain intact.

The terrace has a continuous stone ring beam and three broad cliff sockets. Its pool separates
a 10.8 m swimming lane, 22 cm chaise shelf and 85 cm stool bay. A sheltered cooking, wet-bar and
dining pavilion occupies the social side. The retained fire bench turns toward the sea to keep
the dry promenade connected. The garden uses a curved mineral path, terrain-fitted meadow beds,
low view seats and shielded path fixtures. All 123 plant roots are sampled from retained native
triangles. Source checks, images and the exact circulation repairs live in `reviews/estate-*`.

The layout study used [WOHA's Alila Villas Uluwatu](https://woha.net/project/alila-villas-uluwatu/)
for cliff/pavilion continuity, [Amangiri](https://www.aman.com/resorts/amangiri) for distinct pool
and lounging spaces around retained rock, and the shallow-water typology documented by
[Ledge Lounger](https://ledgeloungers.com/collections/in-pool-chaise-loungers). No plans, product
meshes or project photographs are copied into the scene; every added mesh is authored here.

Actual native door leaves remain solid moving obstacles, while their old positions are excluded
from static collision fields. The active library cameras keep the mezzanine and vault enclosed,
avoiding floating guard balusters in cutaways. Lighting uses static receiver groups with the
unchanged 18-line/10-point analytic material budget. The original broad mainland/coast batches
have a documented receiver approximation; cached transport and local room fixtures remain
separate. Two measured library task lamps and stronger pavilion pendants follow the combined
night review. No new native PointLights, shadow maps or texture downloads are added.

Walk's selected-avatar instance and the live cropped bathroom reflection are documented in
`docs/evidence/estate-mirrors-2026-10-23/`. They share original GPU assets, preserve full sun shadows,
and keep the 128/256 reflection target and 15 Hz cap. The optional extreme look-down neck opening
and unmeasured physical-phone frame rates remain explicit limitations.

## October 23: two carved bathrooms

`coastal_bathrooms.py` and `refresh_coastal_bathrooms.py` continue the retained Blender 4.5.9
house with an original stacked bathroom wing on the bedroom side. The guest bathroom opens from
the living floor's rear aisle; the upper room is a bedroom en suite. The actual sandstone is
excavated for both rooms and their 1.2 m wall apertures, preserving unaffected connected coastal
components. New structural slabs, plaster enclosure and a native lift-away cliff section retain
the house's enclosed Walk view and cutaway orbit views. Existing entrance, bed, desk and onsen
anchors stay in place.

Both rooms contain a real hollow wall-hung WC and separate seat/lid, a fluted floating oak vanity,
an original hollow vessel basin with visible drain, inset mirror storage, satin bronze fittings,
a curbless walk-in shower, a genuine recessed bathing niche, a linear drain and one folded linen.
The en suite uses a restrained celadon ceramic shower zone; the guest room uses warm honed stone.
Fixed shower glass has a thin bronze free-edge stile to make the physical pane readable. A
full-height rounded plaster nib screens each WC from the hall. The doors are visibly parked oak
pocket leaves; the actual opening is traversable without ignoring any visible solid.

The fitted bedroom wardrobe is rebuilt as three useful bays, leaving a generous dressing approach.
The existing guest-threshold planter's pot, soil, stems and leaves move together to an adjacent
solid wall. These decisions followed tests of the delivered Draco meshes: early tests caught a
thin wardrobe front left by a Boolean and separate foliage/stem islands left in the route. Both
were corrected in the native source rather than weakening collision. Transparent shower screens
are explicitly solid to walking; the open gap remains curbless and usable.

`review_coastal_bathrooms.py` records source-native floors, headroom, real wall aperture widths and
hall-to-WC occlusion. `reviews/bathrooms/` retains the survey, editable-geometry counts, and three
actual Eevee renders. The browser supplies its own authored material detail and bounded practical
light transport. The two original compressed room exports add no texture downloads or render
passes. Their neutral AO/indirect vertex colours use the existing 24-sample Cycles bake, with
driver-side lighting and shader compilation remaining runtime work. Fixture-line endpoints and
bounded lighting regions are authored in each room's manifest entry, rather than approximated by
new global PointLights. No plumbing simulation or sanitary activity animation is claimed.

## October 23: main entrance to the living floor

`refresh_coastal_arrival_living.py` continues the retained Blender 4.5.9 source. The original
clifftop stair now turns at its intermediate landing into a second carved, 1.6 m wide flight:
16 oak-topped treads at 16.25 cm rise and 28 cm going reach a recessed ground-floor foyer. The
upper gallery remains an optional side entrance. Its obstructing decorative cedar rail is
actually cut at the doorway; collision does not ignore visible architecture. Additional guards
close the upper stair void's blind edges. Eight native islands from the old sage cupboard banks
were retired on the first pass, opening the rear hall; a recessed pale-oak coat and shoe bench
gives the new foyer a specific use.

The lounge keeps its fitted actor, fireplace and furniture anchors. Its existing boucle cushions
gain actual 2.2 mm welts, the loose pillows lean slightly, and one original bounded linen-knit
throw drapes over an arm and seat. These details reuse material batches and add no textures or
render passes. Two warm entry washers are mounted on the real foyer walls. Dining metadata
now names the two actual saucer shades rather than a single invented midpoint source.

`reviews/arrival-living/native-route.json` surveys all 58 main-route waypoints against native
source triangles: maximum floor discrepancy 2.5 mm and minimum measured headroom 2.227 m.
The runtime's separate delivered-Draco capsule tests traverse the main and optional upper routes
in both directions, plus a clifftop loop. These are circulation and contact checks, not a
photorealism claim. Source-only review renders and exported asset costs are retained beside the
survey; the browser supplies its own coastal lighting and designed furniture replacements.

The release's source-bound perch check caught a disjoint-Boolean regression in a remote talus
batch. `repair_coastal_arrival_talus.py` restores every original coastal component and native
bedding assignment from the exact retained Git source, then reruns the actual perch exporter.
`talus-repair.json` retains all 96 component comparisons and four measured rock roosts. The
authoring Boolean now isolates potentially intersecting components and preserves the remainder
outside both the Boolean and its cleanup; a nonintersecting batch is left untouched.

## October 23: open kitchen, conversation pit and connected arrival

The retained October 20 interior source is continued by `refresh_coastal_interior.py`,
`coastal_sunken.py`, `coastal_kitchen.py`, `coastal_living.py` and `coastal_arrival.py` in Blender
4.5.9 LTS. These are original authored meshes. The kitchen and lounge floors are genuinely cut into
the native slab and mainland, with 42 cm deep lined floors, oak treads and matching browser supports.
The suspended fireplace's house-owned flue continues through the vault into a sandstone cap. The
designed furniture is supplied separately through floor-contact anchors; Herman Miller reference
downloads remain reference-only and are never exported in the house.

An inland opening connects the upper gallery to a foyer and 32 oak-topped stone treads through the
retained cliff. The 1.6 m stair has 28 cm goings, approximately 15.4 cm risers, bronze handrails and an
open slatted portal at the cliff top. Boolean cuts preserve closed native sandstone solids and stay
inside the mainland's original perimeter, so the hinterland seam is unchanged. The paired top/rock
cut is the actual passage aperture rather than a door placed against uncut rock.

The terrace infinity basin is tied into a dry approach through a cut in the original parapet. Its
1.13 m deep tiled basin, submerged entry steps, low overflow lip, catch gutter and fixed -9 cm
waterline are native geometry. `infinity-pool.mjs` adds only sheltered ripple normals, using the
coast's clock and scene sun/moon; it adds no water solver or render target. The water is tagged as a
Walk exclusion. The gym gains a supported pan shelf, scheduled brighter pendants and exact pan and
dumbbell anchors. The study chair replacement retains the existing 51.5 cm seated hip contact.

`review_coastal_interior.py` surveys the finished native mesh: both sunken floors, all 32 arrival
treads, overhead clearance and a 52 cm wide clear route. Its measured record is
`reviews/interior-contacts.json`; the export/bake records retain the delivered geometry and neutral
lighting evidence. Browser captures remain under the ignored `.jekyll-cache/visual-qa/house-*` paths.

Created September 2026 for Sirui Tao's personal site. The five characters depict Sirui as an adult man, with long black hair, round glasses, and a clean-shaven face.

| Asset                                  | Source and authorship                                                                                                                      | Use                                                                                                           |
| -------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------- |
| `coastal-home.blend`                   | Original geometry authored with `bin/build_coastal_home.py`, `bin/coastal_sculpt.py`, and `bin/coastal_craft.py` in Blender 4.5.9 LTS      | Editable carved cave, rooms, furniture, continuous bluff, beach, and inland terrain                           |
| `sirui-*.blend`                        | Original mesh and bone animation, anchored to Sirui's supplied portrait and character studies                                              | Five personal avatars; ten exported clips each                                                                |
| `assets/models/home/*.glb`             | Exports from these Blender sources; no downloaded model or commercial game asset                                                           | Browser geometry and animations, including connected coastal geology                                          |
| `artwork/coastal-home/portraits/*.png` | Original 384 × 480 Cycles renders of the five authored avatar meshes; 24 samples and denoising                                             | Model-review studies, excluded from the production website                                                    |
| `assets/img/home/sirui_capy.jpg`       | Existing Sirui-supplied capybara beach-party image, selected again in the September 13 review                                              | Same kitchen wall print for every avatar; unchanged source image                                              |
| `assets/img/home/coastal-vignette.svg` | Original feathered vector alpha silhouette                                                                                                 | Theme-independent scene edge mask; contains no scenery                                                        |
| `coastal-print-source.png`             | Built-in OpenAI image generation, September 12, 2026; generation `exec-ecb12927-ec1c-4586-a825-7a52b5a45e3f`                               | Original Pacific print, retained with alpha                                                                   |
| `coastal-print.webp`                   | 1200 × 600 WebP derivative, quality 78, alpha retained                                                                                     | Isolated depth study only; excluded from Jekyll                                                               |
| Real portrait                          | Existing `assets/img/sirui_pic.jpg`, supplied by Sirui                                                                                     | Likeness anchor and unchanged 2D photograph                                                                   |
| Album covers and artist links          | Existing site assets and source links                                                                                                      | Existing album interaction; independent of avatar choice                                                      |
| Newsreader                             | [Google Fonts / Newsreader](https://github.com/google/fonts/tree/main/ofl/newsreader), by the Newsreader Project Authors / Production Type | Self-hosted WOFF2 converted from original variable TTF; SIL OFL retained in `assets/fonts/newsreader/OFL.txt` |
| Three.js loader closure                | Upstream r164, MIT                                                                                                                         | Import-only local path adjustment; source hashes and license beside loader                                    |
| Splat study libraries                  | Three.js 0.180.0 and Spark 2.2.0, loaded from pinned package URLs                                                                          | Local experiment only; not in the homepage dependency graph                                                   |

The experimental print prompt requested a panoramic Pacific coastline with ochre sandstone cliffs, distant ocean, agave, orange sky, bold ink contours, crosshatching, halftones, and expressive color separation; isolated alpha edges, no text, no people, and no buildings. The concept boards guided composition and identity, rather than being treated as finished meshes or research figures. Sirui subsequently rejected using an image behind the homepage scene, so the print is used only in the separate depth experiment. Every homepage view uses actual water and cliff geometry.

The cartoon options are original personal interpretations of the named animation styles. No studio model, character mesh, film frame, or commercial texture is bundled. Style names describe the requested visual studies; no affiliation is implied.

The supplied generated concepts are retained as `reference-home-style-board.png` (generation `exec-da5b9dd0-eca4-4b5b-a225-cfd2590785af`) and `reference-character-study.png` (`exec-6162ab91-136a-417e-ac71-eb72779a0163`). These are art-direction references, not captures of the finished website or approval of the resulting models. The later live-review corrections take precedence over their compositions.

## Rebuild

Run `blender --background --python-exit-code 1 --python bin/build_coastal_home.py` from the repository root. The script writes the editable sources, GLBs, and model-review portraits. Each character source opens on the idle NLA track; choose another track to inspect its clip. The four human variants share bone names; Lizard adds Tail and TailTip. Append `-- --house-only`, `-- --characters-only`, `-- --lizard-only`, or `-- --avatar=ghibli` (any of the five avatar IDs) for a focused rebuild.

The September 12 refinement replaces disconnected body masses with continuous remeshed skin, flowing hair surfaces, fitted clothing, and blended arm/leg weights. Mouths are recessed geometry; Ghibli uses a quieter closed smile. The house has a vaulted stone envelope connected to inland terrain, a cliff descending roughly seven meters to the tide, a sloping crescent beach, and receding headlands. Roof vegetation follows the roof's cutaway visibility. The subsequent Realistic pass replaces the old disconnected relief chips with continuous cliff fluting; illustrated erosion strokes remain a deferred lab experiment.

The installed Microsoft Store launcher denied background execution. The implementation used the official portable Blender 4.5.9 LTS archive from `download.blender.org`, verified against the release SHA-256 list. No Store permissions were changed.

The subsequent Realistic pass adds `bin/coastal_craft.py`: original mesh floorboards, joinery, built-in shelves/books, keyboard keys, ceramic cup, thin curved leaves and stems, cabinet fronts, lanterns, a braided rug, irregular onsen stones, and folded linen. Cliff fluting and erosion are modeled into the continuous surface. Physical-scale procedural material detail, sky/environment light, contact occlusion, shoreline wash, live water reflection, onsen ripples, and soft vapor are authored in the browser. No commercial textures or scenic backdrop images are used.

Three.js r164 postprocessing and Draco loader sources, plus Google's Apache-2.0 Draco decoder, are pinned locally with source hashes in `assets/js/vendor/three-r164/README.md`. The static worker entry point is extracted from that exact loader by `bin/prepare_draco_worker.py`; it works with the existing site CSP. The sea's oblique reflection-camera construction follows the official r164 Water implementation.

Asset creation used Blender's Python API in background mode. Mouse/keyboard control of the native Blender application was unavailable in this Codex session. The `.blend` files are editable geometry and rigs, not generated pictures presented as models. Append `-- --export-only` to read the existing sources and re-export every GLB with Draco compression, restoring all character animation tracks for export.

The full home source is excluded from Jekyll via `artwork/`. Only the optimized browser assets ship with the website.

After a focused room-source change, `bin/bake_coastal_light.py -- --room=sleep` and `bin/optimize_coastal_exports.py -- --room=sleep` rebake/export that room only, retaining the other room records in the review reports. Any of the six room IDs is accepted. Omit that option for a complete house bake/export.

The September 13 habitat refinement adds `bin/coastal_interiors.py`: original curved wall ribbons, rounded alcove returns, an arched print niche, oak battens, rubber tiles, a four-post rack, loaded barbell with collars, padded bench and two-tier dumbbell stand. `bin/coastal_characters.py` rebuilds the four human variants against the supplied character board, with explicit jaw profiles, inset eyes, off-centre hair sweeps and tapered locks, relaxed sleeves, individual fingers and laced canvas shoes. All ten clips use the established bone/contact convention. The Lizard geometry is retained. The same capybara print replaces every avatar-dependent wall portrait; no generated backdrop was introduced.

## September 13: connected section and likeness correction

`bin/coastal_section.py` replaces the single-level pedestal and arch with two inhabited storeys at 0 and 2.6 meters. It carves the cave into a mainland mesh, verifies the opening with a Blender ray cast, fits a 15-riser stair, and joins the cliff and beach along the same shoreline. Floor offsets and stair circulation are read from the scene manifest. Only the local ceiling lifts for cutaways. The browser supplies sky, sea, waves and reflections; the standalone Blender review shows the authored geometry without those browser effects.

`bin/coastal_hair.py` builds side-parted scalp and collar-length, ear-tucked surfaces. `bin/coastal_clothing.py` builds sleeves from torso openings. The revised figures have different head proportions, shaped jaws, smaller natural eyes, connected trousers, and a continuous weighted Lizard tail with rounded toes and fingers. Ghibli's face and glasses follow the real portrait more closely; the other figures remain exaggerated style interpretations. These are authored models, not a claim of photographic likeness or equivalence to the generated concept illustrations.

`portraits/` contains front, profile and full-body Cycles studies in addition to the original review angle. `reviews/` contains direct Blender views of the house. All authoring studies remain excluded from Jekyll. Asset creation used Blender's Python API; native Blender mouse and keyboard control is unavailable in this session.

After a full house rebuild, `-- --section-only` reuses the local room cache to rebuild floors and coast, and `-- --coast-only` reuses the local section cache for terrain iteration. These caches are optional and gitignored; the full build reconstructs them from source. `bin/render_coastal_review.py` renders the saved house for direct inspection. The public renderer remains Realistic, with the three-style comparison deferred to GPT-7.

## September 13: garden, beach ecology and Pip

`bin/coastal_garden.py` authors the hanging study planter, trailing leaves, cords and bracket, plus larger lounge and kitchen plants. These meshes are saved in `coastal-home.blend` and exported with the relevant room assets. The widened beach reads its 14-meter base depth, cove bulge and shoreline variation from `manifest.json`; Blender and browser contact geometry share those values.

The September 13 Pip and animals were original code-authored geometry. The robot’s room model was replaced on September 14 with an original articulated Blender GLB; see [Pip provenance](../pip/PROVENANCE.md). `assets/js/companion/portrait.mjs` still draws the matching analytic robot for the 2D page. `wildlife.mjs` models two brush rabbits, a raccoon, four flying gulls, a balcony gull and three sandpipers in browser geometry. The garden, beach and revised robot use Blender's background Python API; native application mouse control was unavailable.

Ceramic reflections, colored rim light, soft hover shadows, leaf backlighting/wind, wet sand, broken wave crests, spray, dust and steam are procedural browser effects. Motion uses damped springs, authored paths and particle fields. No physical fluid simulation, unrestricted rigid-body solver or trained animal model is claimed. All remarks are locally authored strings; no remote conversational service is called.

## September 14: reference, geometry, and contact review

`direction/architecture.png` and `direction/character-wildlife.png` are coordinated generated studies requested for this pass. The original PNGs retain their metadata. `direction/provenance.json` records every retained concept's SHA-256 and C2PA model metadata: **gpt-image, version 2.0**. The tool exposed no model selector, so these must not be labeled Images 2.5. Generated studies are distinct from actual Blender renders in `reviews/` and actual browser evidence in the documentation.

`bin/coastal_landscape.py` authors the nonperiodic coastal masses, sloping beach, and exact sampled support data. The version-4 manifest exports each stair tread, floor polygons, habitat paths, shoreline elevations, perches, and tidal basins. `bin/build_coastal_wildlife.py` builds original brush rabbit, California sea lion, and harbor seal masters; `wildlife.blend` retains them. Habitat choices follow the [City of San Diego's Children's Pool information](https://www.sandiego.gov/lifeguards/beaches/pool). Wildlife behavior is authored rest/look/groom/walk/hop and flight/perch motion, not a physical simulation or biological movement model.

The review loop retained neutral-clay and material views with the manifest's exterior and cutaway cameras, then captured actual browser room views. Seated checks exposed missing trouser skin weights, wrongly oriented sleeve openings, and typing hand orientation; these were corrected in the authoring scripts. Walking contacts now use exported tread surfaces instead of the old stair equation. Groundcover uses upward-facing triangles. Planting, habitat paths, and perches are raycast against the actual carved mainland mesh with a Blender BVH, rather than using an approximate pre-carving height or a flat fan across slopes. Sleeves blend through eight rings into rounded cuffs perpendicular to the arms.

After a geometry rebuild, run `bin/bake_coastal_light.py`, then `bin/optimize_coastal_exports.py`. The first retains Cycles AO and indirect diffuse lighting on the editable source; the second exports quantized byte vertex colors and Draco geometry without overwriting the high-detail `.blend`. The browser uses procedural, physical-scale material normals, dynamic sunlight and lamps, bounded ambient contact shadows, and reflections. No baked normal-map texture set, fluid solver, or film-production quality is claimed.

Run `bin/render_coastal_review.py` for matched-camera clay/material views and `bin/render_coastal_contacts.py` for five seated poses plus the animal masters. The full authoring command remains reproducible without the ignored local caches. The public visual direction is Realistic; Architectural and Illustrated remain explicitly deferred GPT-7 experiments.

Inter now replaces Newsreader on the website. Its regular/italic WOFF2 files, pinned source hashes, weight-range conversion, and SIL OFL are in `assets/fonts/inter/`. The retained Newsreader font is historical and no longer loaded.

## September 14 finishing pass: solid cutaway and fitted activities

This pass continues the approved reference boards above. It generated no additional concept images and makes no new image-model claim. Blender 4.5.9 LTS and the existing Python workflow authored the delivered geometry, animation and optimized GLBs.

The old centroid-based roof split left open boundaries. `coastal_section.py` now partitions a closed cave with exact Boolean intersection/difference, welds coincident vertices, fills residual coplanar boundary loops, recalculates normals, and rejects remaining nonmanifold edges. Both exported sections retain closed solids. `coastal_camera.py` samples the final terrain BVH for camera clearance; it also exports cutaway tags and exterior/interior envelopes consumed by `camera.mjs`.

`coastal_furnishing.py` is the canonical final kitchen and gym authoring source. It retains the capybara artwork and adds fitted cabinetry, island, detailed coffee equipment, a paired-door refrigerator, and ocean-facing dining. The rack gains neutral pull-up grips and dip attachments; the bench parks clear of these exercises. Coffee and weight props remain individually tagged through material batching, so the runtime moves the same authored objects between their rest surfaces and the character's hand.

All five character sources were rebuilt with fourteen clips, softer sleeve weighting and revised eyelids. `activities.mjs` runs phase-based approaches and rests and solves residual arm contact drift against exported equipment grips. The poses remain authored stylization; contact correction is not a whole-body dynamics solver.

The production assets were re-exported after Cycles vertex-light baking and Draco/byte-color optimization. `reviews/` retains matched-camera neutral-clay/material views plus seated, reaching, pull-up and dip studies for all five variants. The live exterior orbit, cup and weight transfers, room views and responsive checks are recorded in [the finishing evidence](../../docs/evidence/coastal-finish-2026-09-14/README.md).

## October 1: adult proportion, object sections and La Jolla geology

This pass uses the existing supplied likeness, capybara print and approved art direction. It adds no generated artwork, imported character, third-party model or photographic scenery. The public scene remains an original imagined home in La Jolla; its cave, terrain and building are not a surveyed reconstruction or a real residence.

`coastal_anatomy.py` lengthens the original weighted long bones in rest space, preserving hand and foot scale, named bones and activity endpoints. The four human studies now stand between 1.70 and 1.90 meters, and Lizard at 1.94 meters. All five retain fourteen authored clips. The natural study has a smaller head and eyes, a tapered jaw and neck, a clear swept-back forehead, ear-tucked side surfaces, shoulder-length back hair, round glasses, a clean-shaven face and separate slim fingers. The other styles retain their distinct original silhouettes.

The seated clips and furniture were fitted together: open oak footrests in the study and dining area and the lowered lounge ottoman meet the seated soles at 22 centimeters. The original seat, desk, equipment and room anchors remain unchanged. Revised root heights preserve exact pull-up and dip wrists; a modest forward lean permits coffee preparation to reach its original equipment targets. The sleep pose fits the existing pillow, Lizard's tail lies along the mattress, and a shaped cloth envelope covers the feet. `review_coastal_models.py` measures actual deformed source vertices and wrists at five key times per clip, verifies the fitted sole bounds and raycasts the weighted sleeping feet against the real cloth. It records delivered GLB SHA-256 values, bytes and triangle counts in `reviews/model-contacts.json`. These measurements concern authored poses and fixed contacts, not a whole-body dynamics or cloth solver.

`coastal_objects.py` authors closed lathed ceramic sections, with actual inside walls and rounded rims. The study mug and transferred espresso cup have recessed coffee surfaces; the kitchen gains a true worktop opening, an undermount metal basin and drain, a hollow fruit bowl and a shaped plate. Chair backs have a restrained lumbar bow. These are mesh details, rather than images drawn over the previous objects. Existing prop tags and transfer origins are retained.

The outside sandstone gains quiet inclined bedding on the actual cliff faces, and the fallen talus gains flattened fracture shapes and embedded bases. The uninterrupted mainland, carved cave, closed roof cutaway, sloping beach and authored Pacific geometry remain connected. The [UC San Diego SIO15 Beach Walk notes](https://geowiki.ucsd.edu/sio15/pdfs/beachwalk-summ.pdf) describe Scripps Sandstone above Ardath Shale, differential erosion, undercutting and rockfalls along the local coast; [Scripps' cliff-failure research](https://scripps.ucsd.edu/news/exposing-failures) explains erosion and the cliffs' contribution to beaches. Those sources inform the original layering and fallen-rock forms. They do not establish the invented home's location, exact rock units or a geotechnical safety claim.

Sources and review renders were rebuilt with the SHA-256-verified official Blender 4.5.9 LTS portable distribution. The final house received the existing 24-sample neutral Cycles contact and diffuse-indirect bake, followed by 32-step byte vertex colors and Draco geometry. Front, profile, body, fitted-pose and matched exterior/cutaway studies remain in `portraits/` and `reviews/`; actual Docker browser comparison and measured results are recorded in [the model evidence](../../docs/evidence/coastal-models-2026-10-01/README.md).

## October 1 follow-up: Realistic portrait and warm finishes

The Ghibli figure continues from the original model with a narrower adult head, quieter glasses, shaped jaw/temples, swept hairline, long ear-tucked nape and shallow shirt folds. Its current authored height is 1.657 meters. The other four original sources and all five named contact rigs retain their existing identities and fourteen clips. Front, profile, body and four Ghibli contact renders were regenerated; actual sleep, soak and mobile study views were inspected.

`coastal_finishes.py` owns the linear-RGB finish definitions used by the full house builder: darker ash joinery, warm oak, quiet cut stone, olive cabinetry and restrained ceramic glaze. The study mug has its own celadon material instead of sharing linen. `refresh_coastal_finishes.py` updates the retained house's materials and reassigns the existing mug polygons without rebuilding the house. Its before/after hash includes every object's matrix, mesh vertices and polygon connectivity and confirms those remain identical. The existing neutral contact bake is retained; `optimize_coastal_exports.py -- --interiors-only` updates the seven house exports without touching the cliff. No photographic textures, generated artwork, imported geometry, new terrain or runtime shader changes are introduced.

The [follow-up evidence](../../docs/evidence/coastal-realistic-2026-10-01/README.md) retains original comparable Docker PNGs, previous source portraits, measured bytes and reconstruction commands. Delivered home/wildlife GLBs grow by 6,716 bytes, about 0.095%; all static triangle counts remain unchanged. The face and surfaces remain authored stylization, rather than a likeness scan or physical hair/cloth simulation.

## October 1: native Ghibli fingers and anatomical gym wrists

The original Ghibli hands stayed open above the pull-up bars, whose contact targets also placed the wrist skin inside the handles. `coastal_hands.py` adds twenty original finger joints and fits the two grip clips to anatomical wrist positions beside the cylinders. The original eighteen-joint rig and fourteen clips remain; the source arms and fingers are baked every frame for these contacts. A skin-offset prototype produced flared wrists and was rejected. The delivered pose moves the true wrist target, with a coupled runtime adapter consuming Ghibli-only `gripWristOffsets` in exported Y-up actor-local meters. The full builder, focused exporter and manifest writer share the same offset generation.

The rest vertices, topology and material assignments retain their original hash. Sixty sampled non-grip poses preserve the original deformed surface within 0.36 micrometers. Across 132 grip hand/frame samples, 128 at actual half-frame interpolation times, every digit has vertices within 2 millimeters of its finite cylinder; deepest sampled intersection is 2.09 millimeters and no sampled vertex lies more than 3 millimeters inside. Maximum native interpolated wrist error is 0.33 millimeters. This is authored skin compression measured separately from wrist-target error, not a dynamics solver or continuous triangle collision proof. Existing typing, coffee, sleep, onsen, other-avatar, room, terrain, camera and capybara contracts remain.

Only Ghibli's editable source and GLB change. The other fifteen GLBs are byte-identical, and Ghibli stays at 166,110 triangles. Native joints, animation and skin weights add 182,448 raw GLB bytes; the complete selected Ghibli geometry grows by 32,091 computed gzip-equivalent bytes, rather than measured HTTP or full-page bytes. The [grip evidence](../../docs/evidence/coastal-grips-2026-10-01/README.md) retains original matched Cycles and actual Docker screenshots, exact metadata, source surface/pose checks, asset hashes, limitations and reconstruction commands. Rest front/profile/body portraits are retained without regeneration noise.

## October 2: continued character optics and coastal neighbours

`coastal_expression.py` and `refresh_coastal_expression.py` fit Ghibli's closed native lid morph to the bounded gaze envelope. The open vertices, triangle counts, original body/face geometry, limb weights, bones and fourteen activity keys remain exact; the other four avatar GLBs are unchanged from the first eyelid checkpoint. Camera-aware attention cancels additive head motion for contact-sensitive activities. Fifty sampled native front/profile closures and sixty retained eating/drinking contact states are recorded in the [continued character evidence](../../docs/evidence/character-refinement-2026-10-02/README.md).

`rabbit_habitats.py` owns the two clifftop loop plans. The full landscape writer and focused `repair_rabbit_habitats.py` sample their elevation against the finished retained coast. These nearby clear scrub edges replace paths that physically crossed the planting. The repair changes only the two path arrays; the coast, vegetation, other habitat definitions and animal exports remain unchanged. The retained-source probe report distinguishes sampled clearance from continuous deforming-body collision proof.

`build_coastal_neighbors.py` and `neighbors.blend` preserve the original raccoon, Western gull and sandpiper masters; [NEIGHBORS.md](NEIGHBORS.md) records the independent assets, acting pivots and reconstruction. Runtime stance anchors, bounded two-segment leg fitting, torso accommodation and smooth flight/perch trajectories replace the earlier inline shapes. These are original authored contacts and choreography. No imported Disney geometry, motion-capture assets, biomechanics, fluid solver or film-production quality is claimed. The production payload and native resource/performance evidence are retained separately from the ignored review media.

`build_coastal_perch_support.py` exports bounded retained-source loop triangles matching the GLB's tessellation and sampled decoded gull soles. Runtime ankle fitting preserves native leg length, accommodates hidden hips inside the original body and maintains contact through sampled flare/toe-off poses. It changes no native meshes or GPU resources. P uses a separately measured air-corridor profile and four locally corrected perches; this is authored clearance rather than a general swept collision solver. The continued character evidence records the actual route, component, contact and interrupted-flight checks.

Close animal inspections enable the existing indirect contact-lighting pass. A dedicated contact-only sea exemption prevents its undisplaced override plane from creating false contacts; the actual beauty waves, reflections and camera rays remain. Native desktop timing, actual rendered lighting invariance and context-recovery checks accompany the change. No photographic scenery or new raster assets are introduced.

## October 14: fitted bedding

The rigid box pillow, which every sleeping head sank about 9 cm into, and the hand-shaped cover, whose top hem cut through the sleepers' chests, are replaced by six bed variants from `bin/refresh_coastal_bedding.py`, which a full build also runs after the avatars: a made bed and one pillow-and-duvet pair per avatar, tagged with a `bedding` extra. Each pillow has a flat contact patch and a pinched seam and is dented under its avatar's head, found by vertical ray casts against the deformed sleep clip at its deepest and shallowest breath and spread by an 8 cm tension funnel. Each duvet is settled over its sleeper by an original position-based cloth solver in `coastal_bedding.py` (coloured Gauss-Seidel distance constraints over the upper envelope of sleeper, pillow, mattress, frame and bedside table), trimmed straight across the chest 7 cm below the chin, quilted and given 3 cm of fill. Blender's built-in cloth solver was tried first and was unstable against these sleepers. `bake_coastal_light.py` bakes each variant with the others hidden. The runtime shows the made bed until the sleep clip plays, then the active avatar's pair. `review_coastal_models.py` checks each avatar's sleeping feet against its own duvet and asserts the whole-body and pillow measurements recorded in `reviews/bedding.json`. These are authored drapes, not runtime cloth: the duvets do not move with breathing, which the 3 cm fill covers.

## October 14: river stones and room decoration

`bin/coastal_decor.py` and `bin/refresh_coastal_decor.py` replace the onsen's 22 faceted carved slabs with 24 rounded river stones (noise-shaped icospheres with flattened seats, overlapping so the waterline never shows a gap) and add an onsen corner (a bamboo spout on a forked post, a wooden bucket with brass hoops and a bath stool, and a cedar slat panel), a framed seascape in the bedroom, a cork pinboard of sketches in the study, and a coiled-rope sun and a shelf of three thrown pots in the lounge. Each piece was placed on a wall the room's authored camera actually sees, found by casting rays through that camera's image. All are original code-authored meshes, joined per room and material; re-running the refresh replaces them. The four rooms were rebaked and re-exported. Re-quantizing the onsen's exported stone moved the measured basin depth by 0.02 mm.

## October 14: the light well

`bin/coastal_lightwell.py` and `bin/refresh_coastal_lightwell.py` drill a shaft from the clifftop into the onsen's vault (0.42 m radius, 1.67 m through the rock, leaning 28 degrees toward the noon sun) with an exact Boolean on the closed lift-away ceiling, flare its lower lip, ring the clifftop opening with river stones tagged with the roof so the cutaway lifts them too, and record the opening in the manifest as `lightWell`. A shadow-only copy of the onsen's part of the vault, with a curtain on its south side, is exported with the onsen; the browser draws it only into the sun's shadow map. The drilled roof and the onsen were rebaked and re-exported. The runtime light transport is described in `assets/js/home-scene/light-well.mjs`.

## October 14: the glass front, the terrace and the alcove screens

`bin/coastal_facade.py` and `bin/refresh_coastal_facade.py` close the cave mouth with a glazed front 0.4 m inside the rock lip, where a ray survey of the retained mainland found the jamb continuous on both sides except an eroded notch at the foot of the north side; a cut-stone pier fills the notch. A dark bronze frame is scribed to the excavated arch, with a door head at 3.2 m, fixed low-iron panes on an outer track and two lift-and-slide doors on an inner track. The door openings are placed where the kitchen and lounge cameras look through the glass line (their frusta cross it at x from -3.3 to -0.9 m and 2.1 to 3.7 m), and each door carries `facadeDoor` and `slideX` extras: the browser slides it its own width into the rock jamb (the lounge door into the pier) by day. Above the door head a fixed lunette is tagged with the roof, so the cutaway lifts it with the vault. Two potted plants that stood where the door tracks run were moved back as whole pieces, and both doors and every pane are checked against the room meshes in both positions (`reviews/facade.json`).

Outside, the terrace is a corbelled sandstone ledge: a 0.3 m carved lip over an underside that curves back into the cliff, with recessed beds every 0.42 m and three octaves of noise, deepest (3.1 m) against the south rock and narrowing to a walk at the north pier. It carries travertine paving cut to its outline, a sandstone parapet with travertine coping and a glass balustrade, a built-in bench against the rock beside a copper fire bowl, two teak loungers, a bistro table outside the kitchen door, an olive and two rosemary pots, and a festoon of bulbs on three posts between eye bolts in the two jambs; the festoon and fire positions are written to the manifest as `terrace`. Inside, two full-height cedar slat screens make the bedroom and the onsen alcoves beside the study. All of it is original code-authored geometry. The bake hides the glass and the doors, so neither shades the house's baked light; the whole house was rebaked and re-exported, and the shell grows by about 140 KB.

## October 14: the clifftop planting

`bin/coastal_flora.py` and `bin/refresh_coastal_flora.py` replace the clifftop's ellipsoid-crowned shrubs, flat groundcover discs and flower spheres (cleared once from the batched planting meshes) with coastal sage scrub mounds of grey-green and dark leaf sprays on woody stems, rusty buckwheat flower heads, iceplant mats with magenta flowers where the old discs lay, dry grass tufts, and four Torrey pines with leaning, twisting trunks and needle tufts at the limb ends. Every leaf, needle and blade carries a sway weight in its UV x for the browser's breeze. Plants keep clear of the house roof, the light well, the rabbits' paths and the gulls' perches, which `build_coastal_perch_support.py` now samples without foliage. The same refresh shades the clifftop's up-facing faces smooth with sharp edges at the rim, so its 2 m triangles no longer show as facets. The planting is exported as `flora.glb`, which loads after the first frame; it is original code-authored geometry.

## October 15: the second clifftop planting

Sirui kept the first planting and asked for more kinds of plant. The same two scripts now add a second planting on its own random stream, so every plant from October 14 stays where it was. Its species and October colours come from photographs of the real bluffs. They were used as reference only, and none is shipped:

- Torrey Pines State Natural Reserve: [a wind-shaped Torrey pine over scrub](https://commons.wikimedia.org/wiki/File:Wind-shaped_Torrey_pine_on_a_bluff_above_the_beach,_Torrey_Pines_State_Natural_Reserve,_California.jpg), [a yucca on the bluff top](https://commons.wikimedia.org/wiki/File:Yucca_on_a_coastal_bluff_above_the_Pacific,_Torrey_Pines_State_Natural_Reserve,_California.jpg) and [scrub-covered bluffs toward Del Mar](https://commons.wikimedia.org/wiki/File:Coastline_toward_Del_Mar_from_a_scrub-covered_bluff,_Torrey_Pines_State_Natural_Reserve,_California.jpg) (Z3lvs, CC0), and [Razor Point](https://commons.wikimedia.org/wiki/File:Razor_point,_torrey_pines_state_park.,7.jpg) (XeresNelro, CC BY-SA 4.0).
- Above La Jolla's sea caves: [Goldfish Point](https://commons.wikimedia.org/wiki/File:Goldfish_Point,_La_Jolla,_CA.jpg) and [the Coast Walk](https://commons.wikimedia.org/wiki/File:Coast_Walk,_La_Jolla,_California.jpg) (Mollymcc, CC0), [the cliffs east of Goldfish Point](https://commons.wikimedia.org/wiki/File:San_Diego_La_Jolla_cliffs_a.jpg) (JiriMatejicek, CC BY-SA 4.0) and [the Coast Walk Trail](https://commons.wikimedia.org/wiki/File:La_Jolla_Coast_Walk_Trail.jpg) (FarFromTheMiddleEast, CC BY-SA 4.0).
- Species: [lemonade berry at Sunset Cliffs](https://commons.wikimedia.org/wiki/File:Rhus_integrifolia_kz01.jpg), [California buckwheat at Torrey Pines](https://commons.wikimedia.org/wiki/File:Eriogonum_fasciculatum_kz13.jpg) and [coast prickly pear](https://commons.wikimedia.org/wiki/File:Opuntia_littoralis_kz04.jpg) (Krzysztof Ziarnek, CC BY-SA 4.0). The plant list follows Cabrillo National Monument's [bluff scrub communities](https://home.nps.gov/cabr/learn/nature/plant-communities.htm).

Each species is placed by its distance from the cliff edge. Prickly pear clumps with red fruit, Mojave yuccas on short trunks in skirts of dead leaves, and three iceplant mats turned rust-red for the dry season grow on the rim. Dense, dark lemonade berry shrubs (each over a solid inner dome so its gaps read as shade) and airy, silver California sagebrush cover the slope. Golden wild oats with drooping spikelets fill the openings, and drifts of Santa Barbara daisies line the stepping stones and the rabbits' walks. One Canary Island date palm stands beside the stepping stones, as along the Coast Walk, trimmed of dead fronds as La Jolla's palms are; its fronds sway from base to tip. Everything keeps clear of the clifftop doorway, the stepping stones, the rabbits' paths, the perches, the landscape's blue agaves and the first planting. It is original code-authored geometry in `flora.glb`.

## October 15: the land around the mainland

Sirui found the left, right and back of the mountain lazy. The retained mainland ended in flat walls at its back (y = -32 m) and at both ends (x = -36 m and 76 m), so from outside, or zoomed out, the land stopped like a cake slice. `bin/build_coastal_hinterland.py` builds what continues from those walls as its own asset, `hinterland.glb`, with its source in `hinterland.blend`; `coastal_hinterland.py` holds the design and `coastal_hinterland_props.py` the planting and fixtures. The build appends the mainland's block, foundation and beach from `coastal-home.blend` into a fresh file and never saves the source. It snaps the new ground to the 225 back-edge and 41 end-edge vertices of the retained top surface (largest offset 1 µm) and continues the mainland's own `top_height`, `cliff_surface` and `beach_point` across each seam, so height and slope match there. The flat walls are now buried.

- Inland, a coastal mesa of stepped marine terraces rises toward a long hill (after Mount Soledad, not to scale). Two canyons cut it, one reaching the beach past each end of the mainland. Their fluted badland walls have ribs standing forward of rounded gullies under an iron-red cap, as at Torrey Pines, and small ravines notch the tall northern bluffs.
- North, the bluffs climb from the mainland's 15 m to about 32 m of pale Torrey sandstone over a long beach, with deep gullies and talus. The gliderport's grassy launch is on top, with a post-and-chain edge fence, two benches and an orange-and-white wind sock on a 6.4 m mast. The sock is its own node, `hinterland_windsock`: its hoop is at the node origin and the sock runs along local +Z, and the manifest's `hinterland.windsock` records its pivot and still pose. `hinterland.mjs` turns it with the coast's wind (`coastWind.vane` in `wind-field.mjs`): it points downwind and hangs or stands out with each gust.
- South, a cove with a wide beach lies at the south canyon's mouth. A headland beyond it holds three sea caves at the waterline in its north face, under a timber viewing deck with a bench and a coin-operated binocular viewer, as at Goldfish Point. The Coast Walk leads to the deck. A second trail runs along the mesa behind the house, round the north canyon's head, to the gliderport. A distant point closes the southern view.
- Sage, chaparral, buckwheat, the washes' riparian shrubs and 156 Torrey pines are low-poly masses in one vertex-coloured canopy material: denser and finer near the house, coarser far away. The ground's vertex colours follow the same cover map. The retained clifftop's own planting stops about 20 m inland, so a sparse transition planting (136 shrubs, in this asset) covers the mainland's bare rear strip; it keeps 2.2 m from every flora vertex, the doorway and its stepping stones. No shrub stands where the ground rises or falls a metre within its reach, so none hangs over a rim.
- Three paragliders and a hang glider soar the ridge lift along the north bluffs (`assets/js/home-scene/gliders.mjs`). Their poses follow the scene clock, so they stop when motion is paused and hold still under reduced motion.
- The shore shader clamps its surf line to the mainland's end values, so every new beach keeps its waterline seaward of that line and no surf floats offshore.

Ambient occlusion is baked into vertex colours with the mainland as an occluder; open ground bakes to 0.95, as on the house. Within 8 m of a seam the shade eases to the retained surface's own baked value. The outside camera's terrain grid grows over the new land as data. `hinterland.cameraGrid` samples the land on the retained 2 m lattice, each node holding the highest ground within 2 m. `hinterland.mjs` merges it into `cameraCollision` when the land loads, and the retained cells win. The asset loads on the first visit outside or to the whole house, like the flora, and stays out of the first scene's bytes. `reviews/hinterland.json` records the build. These photographs were used as reference only, and none is shipped:

- Torrey Pines Gliderport: [paragliders over the launch, with its wind sock](https://commons.wikimedia.org/wiki/File:Torrey_Pines_Gliderport_1.jpg) (Ncysea, CC BY-SA 4.0), [the grassy launch field](https://commons.wikimedia.org/wiki/File:Torrey-pines-gliderport.JPG) (Dmadeo, CC BY-SA 3.0) and [the post-and-chain fence at the bluff edge](https://commons.wikimedia.org/wiki/File:Torrey_Pines_Gliderport_2_2017-10-19.jpg) (FASTILY, CC BY-SA 4.0).
- Torrey Pines State Natural Reserve: [eroded sandstone badlands looking south toward La Jolla](https://commons.wikimedia.org/wiki/File:Eroded_sandstone_badlands_and_sea_cliffs_looking_south_toward_La_Jolla,_Torrey_Pines_State_Natural_Reserve,_California.jpg) (Z3lvs, CC0) and [the Torrey Sandstone cliffs over Black's Beach](https://commons.wikimedia.org/wiki/File:Overlooking_the_steep_Torrey_Sandstone_cliffs_of_Torrey_Pines_State_Natural_Resever_and_Black%27s_Beach_below.jpg) (Stch2022, CC0).
- La Jolla: [a sea cave from inside](https://commons.wikimedia.org/wiki/File:La_Jolla_005_-_sea_cave.jpg) (Andrek02, CC0) and [Goldfish Point's sea cave and viewing deck](https://commons.wikimedia.org/wiki/File:San_Diego_La_Jolla_Goldfish_Point.jpg) (JiriMatejicek, CC BY-SA 4.0).

All of it is original code-authored geometry. The scale is compressed, and the arrangement borrows the coast's character, not its map.

## October 15: hair, brows and expressions from Sirui's portraits

Sirui found that the four human figures did not match his 2D portraits (`assets/img/sirui_pic_ghbili.png`, `sirui_pic_south_park.png`, `sirui_pic_simpsons.png`, `sirui_pic_rick_and_morty.png`). In every portrait the hair is shoulder-length and black (very dark brown in the Ghibli one), parted at the crown and full enough to frame the face down past the jaw, with the ends flicking outward. The models' hair was slicked to the skull like a cap, with thin strands at the back. The portraits also have thick dark brows and open expressions.

`bin/coastal_likeness.py` replaces only the head features. The full builder and `bin/refresh_coastal_likeness.py` both call it. It removes the old hair, brows, face skin and mouth parts. It then rebuilds the face with the builder's own recipe, now shared as `coastal_characters.adult_face`, and cuts each style's mouth into it:

- South Park: a large D-shaped mouth with a black interior and four teeth.
- Simpsons: a wide overbite grin with a row of upper teeth.
- Rick and Morty: a wide open grin with scalloped teeth and a tongue, on a broader, rounder jaw. The jaw widens from below the eyes, so the eyes and glasses do not move.
- Ghibli: a gentle open smile with a tongue, on a slightly softer jaw.

The hair is one closed shell over the skull. It is thickest on top and leaves an arched forehead under the side part, with more volume on the side the hair sweeps toward. Above each ear it sweeps down from the forehead and stops just above the ear and the glasses arm. Behind the ear it falls in a curtain to about the jaw, flaring into pointed locks that flick outward. The brows are thick swept bars set on the forehead above each glasses ring.

Every new vertex is skinned fully to Head, so the hair moves with the head in all fourteen clips; there is no secondary motion. The rig, skin weights, body, hands, feet, neck, glasses, eyes, eyelids and Blink morphs are unchanged, and so is every authored key. In the exported GLBs the animation samples and inverse bind matrices are byte-identical. The back of the hair stays inside the old hair's rearmost point, so the sleep clip still rests the head where it did. Near the neck the curtain's inner surface keeps 2.2 cm clear, so the deepest forward head pitch (reading) cannot press hair into it. The Lizard has no 2D reference and is unchanged.

`reviews/character-likeness.json` records bytes and triangles. GLB sizes before and after are 718,608 to 716,452 (South Park), 671,740 to 669,956 (Simpsons), 854,348 to 861,208 (Ghibli) and 655,740 to 663,812 (Rick and Morty). `bin/review_coastal_likeness.py` writes `reviews/character-likeness-review.json`, which records the following against `f403dfead`:

- Everything outside the replaced features is exactly retained.
- No hair is inside the ears, glasses rims or eyelids.
- Only a few glasses-arm vertices tuck into the hair at the ear.
- No hair is inside the body in any clip except the sleep clip and South Park's pull-up. Both had the same contact before: the sleep clip lifts the head 13 to 22 cm off the spine, and South Park's raised arms meet its wide head.

`review_coastal_expression.py` now compares everything outside these features with `4767b7805`.

The per-avatar pillows and duvets were fitted to the old heads. The new hair sinks 1.4 to 3.3 cm into them. A refit would also move each duvet hem 3.6 to 18 cm toward the chin, because the old collar sheets reached further down the back. `bin/refresh_coastal_bedding.py`, followed by the sleep room's bake and export, refits them.

These are original authored meshes, measured on actual Blender poses. The 2D portraits are Sirui's own and were used as visual reference only; no generated imagery was added. Matched before and after renders and comparison sheets are in `.jekyll-cache/visual-qa/character-likeness/`.

## October 18: livelier coastal animals, pelicans and cormorants

Sirui asked for more animal animation and found some of the movement too rigid and some of it off. Each animal was 12 to 23 rigid parts acting the same few moves on a fixed cycle: a back could not bend, a jaw could not open and a tail could not follow through.

`bin/coastal_wildlife_rig.py` now turns every master into one skinned mesh with its own rig, from the same original geometry. `build_coastal_wildlife.py` rebuilds the rabbit, sea lion and seal, and `build_coastal_neighbors.py` the raccoon, gull and sandpiper. The new `build_coastal_seabirds.py` adds a brown pelican and a Brandt's cormorant, with their source in `seabirds.blend`. The runtime acts every animal from the scene's active time, with varied epochs, keyed springs, follow-through and smooth flight joins. Five pelicans glide in a line over the swell, and the last one plunge-dives now and then. Four cormorants stand on the rocks at the cliff foot and dry their wings, and two sea lions porpoise offshore, so the coast now has 28 animals. [NEIGHBORS.md](NEIGHBORS.md) records each species' rig, repertoire, contacts, budgets and limits.

The six earlier masters weighed 361,576 bytes and the eight skinned masters weigh 279,544. The 28 animals draw 56 primitives, where the 17 earlier ones drew 256. `build_coastal_perch_support.py` now finds the gull's feet by their vertex groups and also exports four rock roosts for the cormorants; rerun it after any change to the coast. The pelican line and dive and the sandpipers' wave-chasing follow the Cornell Lab's [Brown Pelican](https://www.allaboutbirds.org/guide/Brown_Pelican/overview) and [Sanderling](https://www.allaboutbirds.org/guide/Sanderling/overview) overviews, and the cormorant is the Pacific coast's [Brandt's Cormorant](https://www.allaboutbirds.org/guide/Brandts_Cormorant/overview). Those pages were used as reference only; the cormorants' wing-drying is authored.

All of it is original code-authored geometry, and the motion is authored acting, not motion capture or a physics simulation. `bin/render_coastal_wildlife_rigs.py` renders review sheets of the rigs. Frame-stepped browser captures from `bin/capture_coastal_wildlife.cjs` are in `.jekyll-cache/visual-qa/wildlife-final*/`.

## October 16: the renovation

Sirui asked for the house to be redesigned as a group of interior architects would: a larger house and office, the office he actually works in, a cozy living room and a better kitchen and dining room, with high-end plaster walls, wood and stone as the two material families, a little shiny metal and the odd colour pop, and no knife-sharp edges. `bin/refresh_coastal_renovation.py` applies it in four idempotent phases from `coastal_renovation.py`, `coastal_shell.py`, `coastal_office.py`, `coastal_living.py` and `coastal_kitchen.py`.

Every new piece is original code-authored geometry. Real products set only sizes and proportions, and none is modelled as a replica or trademark:

- the LG gram Pro 16 (357 x 248 x 15 mm);
- an AORUS FV43U-sized 43-inch monitor (967 x 586 mm panel);
- a 32-inch monitor (714 x 425 mm);
- an RTX 3080 Ti-sized three-fan card (28.5 cm);
- RH Cloud sectional proportions;
- a Noguchi Akari 75D-sized paper lantern (74 cm);
- a dining chair after Hans Wegner's wishbone.

The plaster, marble and travertine are procedural shading in `assets/js/home-scene/realism.mjs`. No texture, scan or downloaded model was added. The deeper excavation is an exact Boolean on the existing closed mainland, checked manifold in `reviews/renovation.json`. The gym's coloured pound bumpers, black iron plates and fuller hex dumbbell rack follow standard bumper and plate diameters.
