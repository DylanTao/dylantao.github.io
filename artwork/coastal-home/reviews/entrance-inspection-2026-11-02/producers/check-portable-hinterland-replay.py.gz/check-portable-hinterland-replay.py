import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();q=Path(__file__).parent
old=q/'hinterland-before-clearing.blend';assert not old.exists()
old.write_bytes(subprocess.check_output(['git','show','a068dbf461a557b3252f968cdeaa69a84cbbce7a:artwork/coastal-home/hinterland.blend'],cwd=root))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(old)=='5bf9e2c11f66d2d2ea3514616a49573b2a6fc5e48b23b5298a556eafe9cef2b0'
census=q/'ARRIVAL-HINTERLAND-CLEARING-CENSUS.json';script=root/'artwork/coastal-home/reviews/entrance-inspection-2026-11-02/replay_hinterland_clearing.py';out=q/'portable-hinterland-replay-v1'
command=['D:/tools/blender-4.5.9-windows-x64/blender.exe','--background','--factory-startup','--python-exit-code','1','-t','4','--python',str(script),'--','--repo-root',str(root),'--source',str(old),'--source-sha256',sha(old),'--census',str(census),'--census-sha256',sha(census),'--output',str(out)]
with(q/'portable-hinterland-replay-v1.log').open('wb')as log:r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
receipt={'command':command,'exitCode':r.returncode,'scriptSha256':sha(script),'sourceSha256':sha(old)}
if not r.returncode:
 receipt.update(exportSha256=sha(out/'hinterland.glb'),qualifiedExportSha256=sha(q/'arrival-hinterland-clearing-v2/hinterland.glb'))
 assert receipt['exportSha256']==receipt['qualifiedExportSha256']
(q/'PORTABLE-HINTERLAND-REPLAY.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2));assert not r.returncode
