"""Official24sample AO for whole newly positioned garden furniture/plant owners."""
import array
import ast
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import sys
import bpy
root=Path.cwd();q=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=q/'garden-bench-open-v1/candidate.blend'
source_sha='8b46a205d573a3f37ffa5709176aebf970f279f4ef4c9aa773ae021580e0c6fa'
assert sha(source)==source_sha and bpy.app.version==(4,5,9)
proof=json.loads((source.parent/'OPEN-BENCH.json').read_bytes())
assert proof['candidateSha256']==source_sha
owned={'kitchen_breakfast_cushion.001','kitchen_breakfast_cushion.002',
       'kitchen__olive leaf','kitchen_nook_olive__honey ash',
       'kitchen_nook_olive_pot__terracotta','kitchen_nook_olive_stem__honey ash',
       *proof['result']['newObjects']}
assert len(owned)==8
manifest=Path('C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/combined-side-fan-control-v1/candidate-attempt-1/manifest.json')
assert sha(manifest)=='1761204ff8d3bfc289296d252dadc64dab3bea44687065d5a803a950223f324f'
out=q/'garden-bench-open-ao-v1';assert not out.exists();out.mkdir()
ns=runpy.run_path(str(root/'artwork/coastal-home/reviews/bedroom-ambience-2026-11-01/replay_lighting.py'))
tree=ast.parse((q/'bake-owned-exterior.py').read_text(encoding='utf8'))
defs=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in {'shape','colors'}]
assert len(defs)==2
exec(compile(ast.Module(body=defs,type_ignores=[]),'<qualified-shape-colors>','exec'))
bpy.ops.wm.open_mainfile(filepath=str(source))
before=ns['native_state']();materials=ns['materials']()
shapes={name:shape(bpy.data.objects[name])for name in owned}
tags={name:bpy.data.objects[name].get('bakedLighting')for name in owned}
work=out/'bake-work.blend';shutil.copyfile(source,work)
sys.argv=['bake_coastal_light.py','--','--cpu',f'--source={work}',f'--manifest={manifest}','--prefixes='+','.join(sorted(owned)),f'--report={out/"BAKE.json"}']
runpy.run_path(str(root/'bin/bake_coastal_light.py'),run_name='__main__')
stats=json.loads((out/'BAKE.json').read_bytes())
assert stats['samples']==24 and {r['mesh']for r in stats['surfaces']}==owned
baked={}
for name in owned:
    obj=bpy.data.objects[name]
    if tags[name]is None:
        if'bakedLighting'in obj:del obj['bakedLighting']
    else:obj['bakedLighting']=tags[name]
    assert shape(obj)==shapes[name],name
    a=obj.data.color_attributes.active_color
    assert a.domain=='CORNER'and a.data_type=='FLOAT_COLOR'
    baked[name]=(a.name,colors(a))
bpy.ops.wm.open_mainfile(filepath=str(source))
changes=[]
for name in sorted(owned):
    obj=bpy.data.objects[name];attr=obj.data.color_attributes.active_color
    old=colors(attr)if attr else None
    if attr is None:attr=obj.data.color_attributes.new(name=baked[name][0],type='FLOAT_COLOR',domain='CORNER')
    assert attr.domain=='CORNER'and attr.data_type=='FLOAT_COLOR'
    attr.data.foreach_set('color',baked[name][1])
    obj.data.color_attributes.active_color=attr
    assert colors(attr)==baked[name][1]and shape(obj)==shapes[name]
    changed=len(attr.data)if old is None else sum(old[4*i:4*i+4]!=baked[name][1][4*i:4*i+4]for i in range(len(attr.data)))
    changes.append({'owner':name,'eligibleCorners':len(attr.data),'changedCorners':changed,'shapeSha256':shapes[name],'newColorLayer':old is None})
after=ns['native_state']()
assert set(before)==set(after)and all(before[n]==after[n]for n in before if n not in owned)
assert ns['materials']()==materials
target=out/'candidate.blend';bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(target),compress=True)
bpy.ops.wm.open_mainfile(filepath=str(target))
assert ns['native_state']()==after and ns['materials']()==materials and sha(source)==source_sha
receipt={'scope':'Whole8explicitly owned NEW/moved furniture/plant CORNER colors only, official24sampleCPU AO/indirect; every other native field/material exact. Full temporal contacts, delivered geometry, cache, global overlap and appearance remain separate.','sourceSha256':source_sha,'candidateSha256':sha(target),'producerSha256':sha(Path(__file__)),'bakerSha256':sha(root/'bin/bake_coastal_light.py'),'changes':changes,'unownedMeshesExact':len(before)-len(owned),'bake':stats}
(out/'OWNED-GARDEN-BENCH-AO.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps({'candidateSha256':sha(target),'owned':len(owned),'unownedMeshesExact':receipt['unownedMeshesExact']}))
