import json,os,subprocess,time
from pathlib import Path
q=Path(__file__).parent;out=q/'entrance-checkpoint';work=Path('C:/dev/cqa1102');server=json.loads((out/'server.json').read_bytes())
env=dict(os.environ,NO_WEBSERVER='1',VISUAL_BASE_URL=server['url'],PLAYWRIGHT_HTML_REPORT=str(out/'html-report'),PLAYWRIGHT_JSON_OUTPUT_FILE=str(out/'playwright-results.json'))
command=['node',str(work/'node_modules/@playwright/test/cli.js'),'test','--config','test/visual/public.config.js','desk-scene.spec.js','--grep','public room navigation works|a public desktop turn continues','--project','desktop-1440','--project','mobile-390','--workers','1','--output',str(out/'playwright-output'),'--reporter','list,json']
started=time.monotonic()
with(out/'public-navigation.log').open('wb')as log:r=subprocess.run(command,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={'command':command,'exitCode':r.returncode,'seconds':time.monotonic()-started,'server':server,'scope':'Actual complete current canonical production build, existing public Rooms/Walk and PC free-turn regressions at desktop and phone-sized Chromium. Private straight-descent matrix separately bound; physicalphone/performance remain separate.'}
(out/'PUBLIC-NAVIGATION.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2));raise SystemExit(r.returncode)
