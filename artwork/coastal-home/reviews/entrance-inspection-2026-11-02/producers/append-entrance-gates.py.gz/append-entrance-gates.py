import gzip,hashlib,json,shutil
from pathlib import Path
root=Path.cwd();q=Path(__file__).parent;out=q/'entrance-checkpoint';packet=root/'artwork/coastal-home/reviews/entrance-inspection-2026-11-02'
manifest=json.loads((packet/'MANIFEST.json').read_text());rows=manifest['files'];seen={r['path']for r in rows}
sha=lambda b:hashlib.sha256(b).hexdigest()
def deposit(relative,body):
 target=packet/(relative+'.gz');assert target.relative_to(packet).as_posix()not in seen and not target.exists();target.parent.mkdir(parents=True,exist_ok=True)
 stored=gzip.compress(body,mtime=0);target.write_bytes(stored);rows.append({'path':target.relative_to(packet).as_posix(),'bytes':len(stored),'sha256':sha(stored),'encoding':'gzip','bodyBytes':len(body),'bodySha256':sha(body)})
for name in ['BUILD-GATES.json','UNIT-GATES.json','production-build.log','python.log','node.log','style.log','VALIDATION-SOURCE.json','BUILT-BODY-DIAGNOSTIC.json','COMPILED-CUSTODY.json','PUBLIC-NAVIGATION.json','public-navigation.log','playwright-results.json']:
 deposit('gates/'+name,(out/name).read_bytes())
for name in ['production-build.log','BUILD-GATES.json','EXPLANATION.json']:deposit('gates/failed-production-build-v1/'+name,(out/'failed-production-build-v1'/name).read_bytes())
for name in ['PROCESS.json','STANDING-HEAD-QUALIFICATION.json','COMPOSED-NATIVE-BODY-SUMMARY.json','COMPOSED-NATIVE-PORTAL-WIDTH.json']:
 deposit('garden-open-body/'+name,(q/'garden-bench-open-body-v1'/name).read_bytes())
for name in ['run-entrance-validation.py','serve-entrance-checkpoint.py','run-entrance-public-navigation.py','check-open-garden-bench-body.py','append-entrance-gates.py']:
 deposit('producers/'+name,(q/name).read_bytes())
(packet/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
shutil.copytree(packet,Path('C:/dev/cqa1102')/packet.relative_to(root),dirs_exist_ok=True)
print(json.dumps({'payloads':len(rows),'storedBytes':sum(r['bytes']for r in rows)}))
