const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const{chromium,expect}=require('C:/dev/cqa1102/node_modules/@playwright/test');
const q=path.join(__dirname,'arrival-clearing-preview-v1'),server=JSON.parse(fs.readFileSync(path.join(q,'server.json'))),base=server.url,out=path.join(q,'native-arrival-standing-cleared-v1');
if(fs.existsSync(out))throw Error('Fresh evidence required');fs.mkdirSync(out);
const rows=[],errors=[],failed=[],responses=[],pending=[];
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const state=p=>p.locator('[data-home-desk-scene]').evaluate(e=>e.getSceneEvidence());
async function settle(p,paused=false){let old;for(let k=0;k<120;k++){const e=await state(p);if(old&&!e.traveling&&(!paused||!e.framePending)&&Math.hypot(...e.camera.map((v,i)=>v-old[i]))<1e-5)return e;old=e.camera;await p.waitForTimeout(100);}throw Error('Camera did not settle');}
async function lab(p,open){const e=p.locator('[data-world-lab]');if(await e.evaluate(n=>n.open)!==open)await e.locator(':scope>summary').click();}
async function visit(p,id){await p.locator('[data-world-places]>summary').click();await p.locator(`[data-world-destination="${id}"]`).click();await expect.poll(async()=>(await state(p)).currentRoom).toBe(id);await settle(p);}
async function capture(p,id){const e=await settle(p,true);await p.screenshot({path:path.join(out,id+'.png')});rows.push({id,evidence:e});console.log(JSON.stringify({id,camera:e.camera,fov:e.cameraFov,activity:e.activity,actor:e.actorPosition}));}
(async()=>{const browser=await chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']});try{
const context=await browser.newContext({viewport:{width:2560,height:1440},deviceScaleFactor:1,timezoneId:'America/Los_Angeles'}),p=await context.newPage();p.setDefaultTimeout(90000);
await p.route(/https:\/\/(?:analytics\.google\.com|www\.google-analytics\.com|www\.googletagmanager\.com|plausible\.io)\//,r=>r.fulfill({status:204,body:''}));
p.on('pageerror',e=>errors.push(e.message));p.on('console',m=>{if(m.type()==='error')errors.push(m.text());});p.on('requestfailed',r=>failed.push({url:r.url(),failure:r.failure()}));
p.on('response',r=>{if(!r.url().startsWith(base)||!/\.(?:mjs|glb|json|js)(?:\?|$)/.test(r.url()))return;pending.push((async()=>{try{const b=await r.body(),rel=decodeURIComponent(new URL(r.url()).pathname.slice(new URL(base).pathname.length)),expected=fs.readFileSync(path.join(q,'site/al-folio',rel));responses.push({url:r.url(),status:r.status(),bytes:b.length,sha256:hash(b),owned:r.headers()['x-sirui-preview']===server.header,exact:hash(b)===hash(expected)});}catch(e){responses.push({url:r.url(),error:String(e)});}})());});
await p.goto(base+'?scene-lab=1&quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});await p.evaluate(()=>document.fonts.ready);
await p.locator('[data-theme-toggle]:visible').first().click();await p.locator('[data-theme-mode-option="noon"]:visible').first().click();await p.locator('[data-theme-toggle]:visible').first().click();
await p.locator('[data-home-desk-mode="3d"]').click();const scene=p.locator('[data-home-desk-scene]');await expect(scene).toHaveAttribute('data-scene-state','ready',{timeout:180000});await p.locator('[data-world-fullscreen]').click();
await visit(p,'outside');await expect.poll(async()=>(await state(p)).ecology?.farField?.near?.complete,{timeout:90000}).toBe(true);
await lab(p,true);await p.locator('[data-world-pause]').click();await lab(p,false);
await p.locator('[data-world-places]>summary').click();await p.locator('[data-world-destination="entrance"]').click();await settle(p,true);await capture(p,'arrival-current');
await p.locator('[data-world-walk]').click();
await expect.poll(async()=>(await state(p)).walk?.active).toBe(true);
await p.waitForTimeout(900);await capture(p,'arrival-standing');
expect(rows.at(-1).evidence.walk.destination).toBe('entrance');
const descent=[];await p.keyboard.down('w');
try{for(let k=0;k<60;k++){await p.waitForTimeout(200);const ev=await state(p);descent.push({sample:k,walk:ev.walk,camera:ev.camera});if([19,39,59].includes(k))await p.screenshot({path:path.join(out,'descent-'+k+'.png')});if(ev.walk.position[1]<.3)break;}}finally{await p.keyboard.up('w');}
fs.writeFileSync(path.join(out,'DESCENT.json'),JSON.stringify({scope:'Actual public keyboardW descent from the authored entrance. Native-clock motion; no lab placement or training/session seek. Frozen V20coffee remains unrelated and unqualified.',samples:descent},null,2)+'\n');
await capture(p,'descent-end');
expect(descent.at(-1).walk.position[1]).toBeLessThan(1.8);
expect(Math.hypot(descent.at(-1).walk.position[0]-descent[0].walk.position[0],descent.at(-1).walk.position[2]-descent[0].walk.position[2])).toBeGreaterThan(13);

await Promise.all(pending);const result={scope:'Private actual straight-arrival baseline and public Walk standing entry, derived from the complete authored stair route; complete new22cf/645d/54dc products,191compiled integratedV20modules and official cache. Native clocks and publicPause. No training or coffee session seek is used. Pending later route/sole/transition fixes and F6 not admitted; no continuous motion or performance claim.',server,rows,errors,failed,responses};fs.writeFileSync(path.join(out,'CAPTURE.json'),JSON.stringify(result,null,2)+'\n');expect(errors).toEqual([]);expect(failed).toEqual([]);expect(responses.filter(r=>r.error||!r.exact||!r.owned||r.status>=400)).toEqual([]);await context.close();
}finally{await browser.close();}})().catch(e=>{fs.writeFileSync(path.join(out,'FAILURE.json'),JSON.stringify({error:String(e),rows,errors,failed,responses},null,2));console.error(e);process.exitCode=1;});
