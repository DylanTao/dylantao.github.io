import gzip,hashlib,json
from pathlib import Path
root=Path.cwd();q=Path(__file__).parent;out=q/'entrance-checkpoint';packet=root/'artwork/coastal-home/reviews/entrance-inspection-2026-11-02'
manifest=json.loads((packet/'MANIFEST.json').read_text());rows=manifest['files'];sha=lambda b:hashlib.sha256(b).hexdigest()
def deposit(relative,body):
 target=packet/(relative+'.gz');assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True);stored=gzip.compress(body,mtime=0);target.write_bytes(stored);rows.append({'path':target.relative_to(packet).as_posix(),'bytes':len(stored),'sha256':sha(stored),'encoding':'gzip','bodyBytes':len(body),'bodySha256':sha(body)})
for name in ['WEATHER-FAST-FORWARD.json','BUILD-GATES.json','production-build.log','COMPILED-CUSTODY.json','WEATHER-COMBINED-NAVIGATION.json','weather-combined-navigation.log','weather-combined-playwright-results.json']:
 deposit('gates/weather-combined/'+name,(out/name).read_bytes())
deposit('gates/weather-combined/module-build.json',(out/'site/al-folio/assets/js/module-build.json').read_bytes())
deposit('gates/weather-combined/weather-data.mjs',(root/'assets/js/home-scene/weather-data.mjs').read_bytes())
observed={'scope':'Observed root tool invocation summary after fast-forwarde850; counts come from actual tool output, not a fabricated raw process log. Both commands exited0. Previous404Python/1008Nodefullruns are retained separately; only changed weather data and cache binding are repeated here.','commands':[{'command':'node --test test/coastal-weather.test.mjs test/static-light-cache.test.mjs','passed':10,'failed':0},{'command':'python -X utf8 -m unittest discover -s test -p test_coastal_weather.py','passed':12,'failed':0}]}
deposit('gates/weather-combined/OBSERVED-FOCUSED-CHECKS.json',(json.dumps(observed,indent=2)+'\n').encode())
for name in ['prepare-weather-combined-entrance.py','run-weather-combined-navigation.py','append-weather-combined-gates.py']:deposit('producers/'+name,(q/name).read_bytes())
(packet/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'payloads':len(rows),'storedBytes':sum(r['bytes']for r in rows)}))
