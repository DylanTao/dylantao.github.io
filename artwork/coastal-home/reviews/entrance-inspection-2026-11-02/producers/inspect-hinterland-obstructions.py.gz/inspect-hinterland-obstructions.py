import bpy,hashlib,json,math,sys
from pathlib import Path
from mathutils import Vector
root=Path.cwd();q=Path(__file__).parent
sys.path.insert(0,str(root/'bin'))
import coastal_breakfast_nook as nook
source=root/'artwork/coastal-home/hinterland.blend'
source_sha='5bf9e2c11f66d2d2ea3514616a49573b2a6fc5e48b23b5298a556eafe9cef2b0'
assert hashlib.sha256(source.read_bytes()).hexdigest()==source_sha
bpy.ops.wm.open_mainfile(filepath=str(source))
capture=json.loads((q/'garden-bench-coffee-v21-preview/native-arrival-standing-v1/CAPTURE.json').read_text())
e=capture['rows'][1]['evidence'];w=e['walk'];eye=Vector(e['camera'])
forward=Vector((math.sin(w['yaw'])*math.cos(w['pitch']),math.sin(w['pitch']),math.cos(w['yaw'])*math.cos(w['pitch'])))
right=forward.cross(Vector((0,1,0))).normalized();up=right.cross(forward).normalized()
tan=math.tan(math.radians(e['cameraFov'])/2);aspect=2560/1440
def native(v):return Vector((v[0],-v[2],v[1]))
def world(v):return [v[0],v[2],-v[1]]
deps=bpy.context.evaluated_depsgraph_get();rows=[];owners={}
for screen in [(1850,800),(1500,850),(2150,400),(1200,320),(940,365),(1390,360),(1150,600),(900,700),(1200,950),(1600,250)]:
    nx=screen[0]/1280-1;ny=1-screen[1]/720
    direction=(forward+right*(nx*tan*aspect)+up*(ny*tan)).normalized()
    hit,loc,n,face,obj,matrix=bpy.context.scene.ray_cast(deps,native(eye),native(direction),distance=300)
    row={'screen':screen,'nativeRay':list(native(direction)),'hit':hit}
    if hit:
        row.update(owner=obj.name,polygon=face,worldHit=world(loc),distance=(loc-native(eye)).length,hiddenRender=obj.hide_render)
        if obj.name not in owners:
            islands=nook._islands(obj)
            owned=[]
            for part in islands:
                if face in part['faces']:
                    owned.append({'nativeVertices':len(part['vertices']),'polygons':len(part['faces']),'faces':sorted(part['faces']),'worldLo':part['lo'],'worldHi':part['hi']})
            owners[obj.name]={'nativeVertices':len(obj.data.vertices),'polygons':len(obj.data.polygons),'hitComponents':owned}
        else:
            for part in nook._islands(obj):
                if face in part['faces'] and not any(part['faces']==set(old['faces'])for old in owners[obj.name]['hitComponents']):
                    owners[obj.name]['hitComponents'].append({'nativeVertices':len(part['vertices']),'polygons':len(part['faces']),'faces':sorted(part['faces']),'worldLo':part['lo'],'worldHi':part['hi']})
    rows.append(row)
assert hashlib.sha256(source.read_bytes()).hexdigest()==source_sha
result={'sourceSha256':source_sha,'camera':e['camera'],'yaw':w['yaw'],'pitch':w['pitch'],'fov':e['cameraFov'],'rays':rows,'owners':owners,'scope':'Read-only native first-hit rays from actual rendered public Walk camera; exact source polygon/component identities, no visibility or geometry edits. Runtime appearance corroborated by saved PNG; decoded confirmation still required.'}
(q/'ARRIVAL-HINTERLAND-OBSTRUCTIONS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'rays':rows,'owners':{k:{'vertices':v['nativeVertices'],'components':[{'vertices':p['nativeVertices'],'faces':p['polygons'],'lo':p['worldLo'],'hi':p['worldHi']}for p in v['hitComponents']]}for k,v in owners.items()}},indent=2))
