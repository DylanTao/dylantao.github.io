import hashlib,json,os,shutil,subprocess,sys,time,urllib.request
from pathlib import Path
root=Path.cwd();q=Path(__file__).parent;seed=q/'arrival-clearing-preview-v1'
out=q/'arrival-view-preview-v1';assert not out.exists();out.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['source','site']:shutil.copytree(seed/name,out/name)
source=out/'source';built=out/'site/al-folio';merge=out/'merge';merge.mkdir()
rel='assets/js/home-scene/controller.mjs'
ours=(root/rel).read_bytes().replace(b'\r\n',b'\n');theirs=(source/rel).read_bytes().replace(b'\r\n',b'\n');ancestor=subprocess.check_output(['git','show','a068dbf461a557b3252f968cdeaa69a84cbbce7a:'+rel]).replace(b'\r\n',b'\n')
for n,b in [('ours',ours),('base',ancestor),('theirs',theirs)]:(merge/n).write_bytes(b)
command=['git','merge-file','--stdout','--diff3',str(merge/'ours'),str(merge/'base'),str(merge/'theirs')]
r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert r.returncode==0,r.stderr
(source/rel).write_bytes(r.stdout)
for relative in ['assets/js/home-scene/arrival-view.mjs','bin/coastal_static_light_inputs.cjs']:shutil.copyfile(root/relative,source/relative)
(out/'MERGE.json').write_text(json.dumps({'base':'a068dbf461a557b3252f968cdeaa69a84cbbce7a','exitCode':r.returncode,'rootControllerSha256':hashlib.sha256(ours).hexdigest(),'seedIntegratedControllerSha256':hashlib.sha256(theirs).hexdigest(),'mergedControllerSha256':sha(source/rel),'scope':'Only root noncoffee Arrival-view changes merged into already inspected frozenV20coffee source. Zero conflicts. Every other seed module retained exact. Not final coffee or F6 admission.'},indent=2)+'\n')
env=dict(os.environ,BUNDLE_PATH='C:/tools/site-gems-ruby33',NODE_PATH=str(root/'node_modules'))
compile_command=['C:/tools/Ruby33/bin/ruby.exe','C:/tools/Ruby33/bin/bundle','exec','ruby',str(q/'compile-private-modules.rb'),str(source),str(built)]
with(out/'compile.log').open('wb')as log:r=subprocess.run(compile_command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
shutil.copyfile(q/'private-serve-template.py',out/'serve.py')
with(out/'server.log').open('wb')as log:child=subprocess.Popen([sys.executable,str(out/'serve.py')],cwd=root,stdout=log,stderr=subprocess.STDOUT,creationflags=0x08000000)
for _ in range(100):
 if(out/'server.json').exists():break
 assert child.poll()is None;time.sleep(.1)
server=json.loads((out/'server.json').read_bytes());assert server['pid']==child.pid
with urllib.request.urlopen(server['url'],timeout=10)as response:assert response.headers['X-Sirui-Preview']==server['header']
env['COASTAL_CACHE_URL']=server['url'];command=[shutil.which('node'),str(source/'bin/bake_coastal_static_light.cjs')];start=time.monotonic()
with(out/'official-bake.log').open('wb')as log:r=subprocess.run(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'PROCESS.json').write_text(json.dumps({'exitCode':r.returncode,'seconds':time.monotonic()-start,'server':server,'compileCommand':compile_command,'bakeCommand':command},indent=2)+'\n');assert r.returncode==0
for relative in ['assets/models/home/manifest.json','assets/models/home/static-light-field.json']:shutil.copyfile(source/relative,built/relative)
cache=json.loads((source/'assets/models/home/static-light-field.json').read_bytes());configuration=json.loads(cache['configuration']);stats=cache['statistics'];modules=json.loads((built/'assets/js/module-build.json').read_bytes())
assert stats['triangles']+stats['skippedTriangles']<=750000 and len(cache['probes'])==128 and len(configuration['regions'])==16 and len(configuration['practicalSources'])==28
for name,row in modules['modules'].items():assert hashlib.sha256((source/name).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==row['sourceSha256']and sha(built/name)==row['outputSha256']
receipt={'scope':'Complete private new Arrival standing-view controller on root8shrub clearing/native22cf6assets and frozenV20coffee source. Official unmodified rebake and exact compiled source inventory. Final fin and coffee motion gates remain open.','server':server,'modules':len(modules['modules']),'preROITriangles':stats['triangles']+stats['skippedTriangles'],'cacheSignature':cache['signature'],'cacheBytes':(source/'assets/models/home/static-light-field.json').stat().st_size,'regions':16,'probes':128,'practicals':28}
(out/'CAPACITY-AND-CUSTODY.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
