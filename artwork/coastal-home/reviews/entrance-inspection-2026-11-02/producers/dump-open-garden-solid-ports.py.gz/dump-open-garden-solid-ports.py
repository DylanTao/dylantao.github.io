import hashlib
import json
from pathlib import Path
import sys
import bpy
import bmesh
root=Path.cwd();q=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'bin'))
import coastal_breakfast_nook as nook
source=q/'garden-bench-open-ao-v1/candidate.blend'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(source)=='c4de58834c68d067a4f579dabdbb08818f8fb3c5c691196810d52945e19d7191'
bpy.ops.wm.open_mainfile(filepath=str(source))
rows=[]
for name,expected in [('core_garden_bench_tail__honey ash',4),('core_garden_bench_tail__pale oak',2)]:
    obj=bpy.data.objects[name];groups=nook._islands(obj)
    assert len(groups)==expected
    for g in groups:
        mesh=nook._subset(obj.data,g['faces'],'private constituent proof')
        bm=bmesh.new();bm.from_mesh(mesh)
        invalid=sum(not e.is_manifold or not e.is_contiguous for e in bm.edges)
        volume=bm.calc_volume(signed=True);bm.free();bpy.data.meshes.remove(mesh)
        assert invalid==0 and volume>0 and len(g['vertices'])==8 and len(g['faces'])==6
        points={str(i):list(obj.matrix_world@obj.data.vertices[i].co)for i in sorted(g['vertices'])}
        faces=[]
        for i in sorted(g['faces']):
            f=obj.data.polygons[i]
            faces.append({'face':i,'vertices':list(f.vertices),'loopIds':list(f.loop_indices),
                          'cornerN':[list(obj.data.corner_normals[j].vector)for j in f.loop_indices],
                          'cornerColor':[list(obj.data.color_attributes.active_color.data[j].color)for j in f.loop_indices]})
        rows.append({'owner':name,'component':len([r for r in rows if r['owner']==name]),'worldLo':g['lo'],'worldHi':g['hi'],'nativeWorldPoints':points,'faces':faces,'invalidDirectedEdges':invalid,'signedVolumeM3':volume})
receipt={'scope':'All6actual saved native constituent closed positive prisms with every original native face/port/cornerN/RGB. Touching geometric face/edge multiplicity across batched prisms is retained, not welded or assumed manifold. Actual decoded component closure/field correspondence and contacts require independent proof.','source':str(source),'sourceSha256':sha(source),'producerSha256':sha(Path(__file__)),'components':rows,'models':{n:sha(q/'garden-bench-open-export-v1/models'/n)for n in ['home-shell.glb','room-kitchen.glb']}}
(q/'GARDEN-OPEN-BENCH-CONSTITUENT-PORTS.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps({'components':len(rows),'allPositiveClosed':True,'nativeSha256':receipt['sourceSha256']}))
