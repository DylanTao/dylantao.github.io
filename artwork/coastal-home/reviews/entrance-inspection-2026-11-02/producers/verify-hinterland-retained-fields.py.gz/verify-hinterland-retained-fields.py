import bpy,array,hashlib,json,sys
from pathlib import Path
root=Path.cwd();q=Path(__file__).parent;sys.path.insert(0,str(root/'bin'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=root/'artwork/coastal-home/hinterland.blend';candidate=q/'arrival-hinterland-clearing-v2/candidate.blend'
receipt=json.loads((q/'arrival-hinterland-clearing-v2/CLEARING.json').read_text())
assert sha(source)==receipt['sourceSha256'] and sha(candidate)==receipt['candidateSha256']
owner='hinterland_flora_10_09'
bpy.ops.wm.open_mainfile(filepath=str(source));old=bpy.data.objects[owner];m=old.data
removed={f for row in receipt['removed']for f in row['faces']};fi=sorted(set(range(len(m.polygons)))-removed);vi=sorted({v for i in fi for v in m.polygons[i].vertices});li=[i for f in fi for i in m.polygons[f].loop_indices]
inverse={v:i for i,v in enumerate(vi)}
expected={'matrix':[list(r)for r in old.matrix_world],'positions':[list(m.vertices[i].co)for i in vi],'polygons':[[inverse[v]for v in m.polygons[i].vertices]for i in fi],'cornerNormals':[list(m.corner_normals[i].vector)for i in li],'smooth':[m.polygons[i].use_smooth for i in fi],'materialIndices':[m.polygons[i].material_index for i in fi],'materials':[a.name for a in m.materials]}
attrs={}
for a in m.attributes:
 if a.name.startswith('.')or a.name in['position','material_index']:continue
 indices={'POINT':vi,'FACE':fi,'CORNER':li}.get(a.domain)
 if indices is None:
  assert a.domain=='EDGE' and a.data_type=='BOOLEAN'
  # Whole independent mounds are removed; no retained edge is split or re-paired.
  assert len({tuple(sorted(e.vertices))for e in m.edges})==len(m.edges)
  attrs[a.name]={'domain':a.domain,'type':a.data_type,'byPair':{str(tuple(sorted(inverse[v]for v in e.vertices))):bool(a.data[e.index].value)for e in m.edges if all(v in inverse for v in e.vertices)}}
  continue
 props={}
 for prop in a.data[0].bl_rna.properties if len(a.data)else[]:
  if prop.identifier=='rna_type'or prop.type not in('INT','FLOAT','BOOLEAN'):continue
  if a.data_type in('FLOAT_COLOR','BYTE_COLOR')and prop.identifier!=('color'if a.data_type=='FLOAT_COLOR'else'color_srgb'):continue
  props[prop.identifier]=[list(getattr(a.data[i],prop.identifier))if prop.is_array else getattr(a.data[i],prop.identifier)for i in indices]
 attrs[a.name]={'domain':a.domain,'type':a.data_type,'properties':props}
bpy.ops.wm.open_mainfile(filepath=str(candidate));obj=bpy.data.objects[owner];n=obj.data
actual={'matrix':[list(r)for r in obj.matrix_world],'positions':[list(v.co)for v in n.vertices],'polygons':[list(p.vertices)for p in n.polygons],'cornerNormals':[list(a.vector)for a in n.corner_normals],'smooth':[p.use_smooth for p in n.polygons],'materialIndices':[p.material_index for p in n.polygons],'materials':[a.name for a in n.materials]}
assert actual==expected,[k for k in actual if actual[k]!=expected[k]]
for name,row in attrs.items():
 a=n.attributes[name];assert a.domain==row['domain']and a.data_type==row['type']
 if 'byPair'in row:
  assert {str(tuple(sorted(e.vertices))):bool(a.data[e.index].value)for e in n.edges}==row['byPair']
 else:
  for name,values in row['properties'].items():
   actual_values=[list(getattr(v,name))if hasattr(getattr(v,name),'__len__')else getattr(v,name)for v in a.data]
   assert actual_values==values,(a.name,name)
result={'sourceSha256':sha(source),'candidateSha256':sha(candidate),'retiredWholeComponents':8,'retiredTriangles':len(removed),'exactRetainedVertices':len(vi),'exactRetainedCorners':len(li),'exactRetainedFaces':len(fi),'exactAttributes':sorted(attrs),'maximumPositionNormalColorDeviation':0,'allMappedFieldsExact':True,'scope':'Independent direct original-ID mapping checks actual saved candidate arrays, not merely a constructor self comparison. All retained P/loop order/cornerN/smooth/material/numeric attributes exact; edge roles uniquely mapped with no parallel alias.'}
(q/'arrival-hinterland-clearing-v2/RETAINED-FIELDS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
