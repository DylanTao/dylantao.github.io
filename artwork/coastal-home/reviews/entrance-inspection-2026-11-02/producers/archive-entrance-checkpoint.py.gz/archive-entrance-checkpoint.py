import gzip,hashlib,json
from pathlib import Path
root=Path.cwd();q=Path(__file__).parent;packet=root/'artwork/coastal-home/reviews/entrance-inspection-2026-11-02'
assert sorted(p.name for p in packet.iterdir())==['README.md','replay_hinterland_clearing.py']
sha=lambda b:hashlib.sha256(b).hexdigest();records=[]
def deposit(relative,body,compress=True):
 target=packet/(relative+('.gz'if compress else''));target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists()
 stored=gzip.compress(body,mtime=0)if compress else body;target.write_bytes(stored)
 row={'path':target.relative_to(packet).as_posix(),'bytes':len(stored),'sha256':sha(stored)}
 if compress:row.update(encoding='gzip',bodyBytes=len(body),bodySha256=sha(body))
 records.append(row)
for name in ['ARRIVAL-HINTERLAND-CLEARING-CENSUS.json','ARRIVAL-HINTERLAND-OBSTRUCTIONS.json','ARRIVAL-OBSTRUCTIONS.json','ARRIVAL-CAPTURE-CORRECTIONS.json','PORTABLE-HINTERLAND-REPLAY.json','HINTERLAND-INSTALL.json','OVERLAP-DELIVERY.json','GARDEN-OPEN-BENCH-CONSTITUENT-PORTS.json']:
 deposit('evidence/'+name,(q/name).read_bytes())
for name in ['CLEARING.json','RETAINED-FIELDS.json','GLB-PRIMITIVE-COMPARISON.json','DECODED-RETAINED-FIELDS.json','KHRONOS-VALIDATION.json']:
 deposit('hinterland/'+name,(q/'arrival-hinterland-clearing-v2'/name).read_bytes())
for relative in ['garden-bench-relief-v3/BENCH-RELIEF.json','garden-bench-open-v1/OPEN-BENCH.json','garden-bench-open-ao-v1/OWNED-GARDEN-BENCH-AO.json','garden-bench-open-ao-v1/BAKE.json','garden-bench-open-export-v1/command.json','garden-bench-open-export-v1/PROCESS.json','entrance-checkpoint/BAKE-PROCESS.json','entrance-checkpoint/CACHE.json','arrival-view-preview-v1/MERGE.json','arrival-view-preview-v1/CAPACITY-AND-CUSTODY.json','arrival-view-preview-v1/native-standing-view-v1/STOPPED.json','arrival-view-preview-v1/native-standing-view-v2/FAILURE.json','arrival-view-preview-v1/native-standing-view-v3/CAPTURE.json','arrival-clearing-preview-v1/native-arrival-standing-cleared-v1/CAPTURE.json','arrival-clearing-preview-v1/native-arrival-standing-cleared-v1/DESCENT.json','arrival-hinterland-clearing-v1/FAILURE.json']:
 deposit('retained/'+relative,(q/relative).read_bytes())
coffee=Path('C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/coffee-contact-v6')
for name in ['ARCH-BRIDGE-CONTACT-ENVELOPE-V4.json','derive-retained-arch-bridge-envelope-v4.mjs']:
 deposit('retained/closed-bench/'+name,(coffee/name).read_bytes())
for name in ['qualify-arrival-hinterland-clearing.py','inspect-hinterland-obstructions.py','verify-hinterland-retained-fields.py','compare-hinterland-glbs.cjs','compare-hinterland-decoded.cjs','validate-hinterland.cjs','check-portable-hinterland-replay.py','build-open-garden-bench.py','bake-open-garden-bench.py','export-open-garden-bench.py','dump-open-garden-solid-ports.py','capture-arrival-standing-v1.cjs','capture-arrival-cleared-v1.cjs','capture-standing-view-v3.cjs','prepare-arrival-view-preview.py','bake-entrance-checkpoint.py','archive-entrance-checkpoint.py']:
 deposit('producers/'+name,(q/name).read_bytes())
for name,relative in [('before-planting.png','garden-bench-coffee-v21-preview/native-arrival-standing-v1/arrival-standing.png'),('cleared-planting.png','arrival-clearing-preview-v1/native-arrival-standing-cleared-v1/arrival-standing.png'),('entrance-2k.png','arrival-view-preview-v1/native-standing-view-v3/arrival-current.png'),('entrance-embed-390.png','arrival-view-preview-v1/native-standing-view-v3/embed-standing-390.png'),('entrance-fullscreen-390.png','arrival-view-preview-v1/native-standing-view-v3/standing-390.png')]:
 deposit('images/'+name,(q/relative).read_bytes(),False)
selected=['assets/js/home-scene/arrival-view.mjs','assets/js/home-scene/controller.mjs','bin/coastal_static_light_inputs.cjs','bin/coastal_breakfast_nook.py','bin/coastal_garden_bench.py','bin/refresh_coastal_breakfast_nook.py','test/coastal-arrival-view.test.mjs','test/visual/desk-scene.spec.js','test/test_resting_review_custody.py','docs/october-2026-handoff.md','docs/homepage-desk-scene-brief.md','artwork/coastal-home/PROVENANCE.md']
sources=[]
for name in selected:
 body=(root/name).read_bytes();deposit('selected-source/'+name,body);sources.append({'path':name,'gitLfSha256':sha(body.replace(b'\r\n',b'\n'))})
deposit('SOURCE.json',(json.dumps({'parent':'a068dbf461a557b3252f968cdeaa69a84cbbce7a','files':sources,'scope':'Only source-bound8shrub hinterland retirement, guarded future standing entrance view, qualified owning bench recipe, tests/docs and official cache. Main house master stays1e10; private F6/arrival/garden/coffee integration remains open.'},indent=2)+'\n').encode())
(packet/'MANIFEST.json').write_text(json.dumps({'schema':'coastal-entrance-inspection-v1','scope':'Sealed original source/evidence bodies and actual rendered states. Correction receipt clarifies inherited Pause/module labels. Final validation receipts may be appended before first publication; editorialREADME/replayer are tracked normally.','files':records},indent=2)+'\n')
print(json.dumps({'payloads':len(records),'storedBytes':sum(r['bytes']for r in records)}))
