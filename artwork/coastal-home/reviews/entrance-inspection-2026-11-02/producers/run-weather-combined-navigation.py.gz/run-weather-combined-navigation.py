import json,os,subprocess,time
from pathlib import Path
q=Path(__file__).parent;out=q/'entrance-checkpoint';work=Path('C:/dev/cqa1102');server=json.loads((out/'server.json').read_text())
env=dict(os.environ,NO_WEBSERVER='1',VISUAL_BASE_URL=server['url'],PLAYWRIGHT_JSON_OUTPUT_FILE=str(out/'weather-combined-playwright-results.json'))
command=['node',str(work/'node_modules/@playwright/test/cli.js'),'test','--config','test/visual/public.config.js','desk-scene.spec.js','--grep','public room navigation works','--project','desktop-1440','--workers','1','--output',str(out/'weather-combined-playwright-output'),'--reporter','list,json']
started=time.monotonic()
with(out/'weather-combined-navigation.log').open('wb')as log:r=subprocess.run(command,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'WEATHER-COMBINED-NAVIGATION.json').write_text(json.dumps({'command':command,'exitCode':r.returncode,'seconds':time.monotonic()-started,'server':server,'scope':'Fresh complete production build after retaining scheduled weather commit e850e8c40; actual public Rooms/Walk smoke. Prior4width private standing-view and3case public regressions retained. Currentweather10Node/12Python plus cachebinding pass.'},indent=2)+'\n');print('Combined-weather public navigation exitCode',r.returncode);raise SystemExit(r.returncode)
