"""Read-only source-bound census against the owning piecewise shaft, not its AABB."""
import bpy,hashlib,json,math,sys
from pathlib import Path
root=Path.cwd();q=Path(__file__).parent
sys.path.insert(0,str(root/'bin'))
import coastal_breakfast_nook as nook
source=root/'artwork/coastal-home/hinterland.blend'
source_sha='5bf9e2c11f66d2d2ea3514616a49573b2a6fc5e48b23b5298a556eafe9cef2b0'
manifest=q/'garden-bench-coffee-v21-preview/source/assets/models/home/manifest.json'
config=json.loads(manifest.read_text());e=config['entrance']
assert hashlib.sha256(source.read_bytes()).hexdigest()==source_sha
assert e['straightDescent'] is True and e['stairWidth']==2.2
assert e['going']==.28 and abs(e['riser']-2.6/15)<1e-14
ax,az=math.sin(math.radians(52)),math.cos(math.radians(52))
flights=e['flights'];assert [f['risers']for f in flights]==[15,18,19]
line=[(.5,.5*e['riser']/e['going'])]
for f in flights:
    if f['startS']>.5:line.append((f['startS'],f['bottom']))
    line.append((f['endS'],f['top']))
line.append((flights[-1]['endS']+2.42,flights[-1]['top']))
cells=[]
for (a,ha),(b,hb)in zip(line,line[1:]):
    slope=(hb-ha)/(b-a);offset=ha-slope*a
    cells.append({'s':[a,b],'t':[-2.05,2.05],'slope':slope,'heightOffset':offset,'below':-.40,'above':2.65})
def local(p):return(ax*p.x+az*(-p.y-17.3),az*p.x-ax*(-p.y-17.3),p.z)
def clip(poly,normal,offset):
    out=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        da=sum(a[k]*normal[k]for k in range(3))-offset;db=sum(b[k]*normal[k]for k in range(3))-offset
        ia,ib=da<=0,db<=0
        if ia:out.append(a)
        if ia!=ib:
            t=da/(da-db);out.append(tuple(a[k]+t*(b[k]-a[k])for k in range(3)))
    return out
def intersect(points,cell):
    s0,s1=cell['s'];t0,t1=cell['t'];m,c=cell['slope'],cell['heightOffset']
    poly=list(points)
    for n,d in [((-1,0,0),-s0),((1,0,0),s1),((0,-1,0),-t0),((0,1,0),t1),((m,0,-1),-c+.40),((-m,0,1),c+2.65)]:
        poly=clip(poly,n,d)
        if not poly:return None
    return poly
bpy.ops.wm.open_mainfile(filepath=str(source))
rows=[];census=[]
for obj in bpy.context.scene.objects:
    if obj.type!='MESH'or not obj.name.startswith(('hinterland_flora','hinterland_talus')):continue
    mesh=obj.data;mesh.calc_loop_triangles();parts=nook._islands(obj);world=[obj.matrix_world@v.co for v in mesh.vertices]
    tris={}
    for t in mesh.loop_triangles:tris.setdefault(t.polygon_index,[]).append(t)
    affected=0
    for part in parts:
        # This first rejection only skips provably disjoint bounds; the decision uses finite triangle clipping.
        if part['hi'][0]<-4 or part['lo'][0]>20 or part['hi'][2]<15 or part['lo'][2]>34:continue
        hits=[]
        for face in sorted(part['faces']):
            for tri in tris[face]:
                points=[local(world[i])for i in tri.vertices]
                for ci,cell in enumerate(cells):
                    poly=intersect(points,cell)
                    if poly:
                        hits.append({'triangle':tri.index,'polygon':face,'cell':ci,'intersectionLocal':poly})
        census.append({'owner':obj.name,'firstPolygon':min(part['faces']),'polygons':len(part['faces']),'vertices':len(part['vertices']),'lo':part['lo'],'hi':part['hi'],'intersectionCount':len(hits)})
        if hits:
            affected+=1
            materials=sorted({mesh.materials[mesh.polygons[f].material_index].name for f in part['faces']})
            rows.append({'owner':obj.name,'faces':sorted(part['faces']),'vertices':sorted(part['vertices']),'lo':part['lo'],'hi':part['hi'],'materials':materials,'finiteTriangleIntersections':hits})
    print(obj.name,'parts',len(parts),'affected',affected,flush=True)
result={'scope':'READ ONLY. All whole flora/talus components near the new straight arrival are tested against the exact six convex cells of the owning piecewise shaft. No global shaft AABB decides retirement. Components and finite clipped witnesses retained; no write/export/admission.','sourceSha256':source_sha,'manifestSha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'frame':{'originWorld':[0,0,17.3],'axis':[ax,0,az],'angleDegrees':52},'shaftProfile':line,'cells':cells,'census':census,'affected':rows}
(q/'ARRIVAL-HINTERLAND-CLEARING-CENSUS.json').write_text(json.dumps(result,indent=2)+'\n')
assert hashlib.sha256(source.read_bytes()).hexdigest()==source_sha
print(json.dumps({'affectedComponents':len(rows),'affectedTriangles':sum(len(r['faces'])for r in rows),'parts':[{'owner':r['owner'],'lo':r['lo'],'hi':r['hi'],'materials':r['materials'],'faces':len(r['faces']),'vertices':len(r['vertices'])}for r in rows]},indent=2))
