const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const{chromium,expect}=require('C:/dev/cqa1102/node_modules/@playwright/test');
const q=path.join(__dirname,'arrival-view-preview-v1'),server=JSON.parse(fs.readFileSync(path.join(q,'server.json'))),base=server.url,out=path.join(q,'native-standing-view-v3');
if(fs.existsSync(out))throw Error('Fresh evidence required');fs.mkdirSync(out);
const rows=[],errors=[],failed=[],responses=[],pending=[];
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const state=p=>p.locator('[data-home-desk-scene]').evaluate(e=>e.getSceneEvidence());
async function settle(p,paused=false){let old;for(let k=0;k<120;k++){const e=await state(p);if(old&&!e.traveling&&(!paused||!e.framePending)&&Math.hypot(...e.camera.map((v,i)=>v-old[i]))<1e-5)return e;old=e.camera;await p.waitForTimeout(100);}throw Error('Camera did not settle');}
async function lab(p,open){const e=p.locator('[data-world-lab]');if(await e.evaluate(n=>n.open)!==open)await e.locator(':scope>summary').click();}
async function visit(p,id){await p.locator('[data-world-places]>summary').click();await p.locator(`[data-world-destination="${id}"]`).click();await expect.poll(async()=>(await state(p)).currentRoom).toBe(id);await settle(p);}
async function capture(p,id){const e=await settle(p,false);await p.screenshot({path:path.join(out,id+'.png')});rows.push({id,evidence:e});console.log(JSON.stringify({id,camera:e.camera,fov:e.cameraFov,activity:e.activity,actor:e.actorPosition}));}
(async()=>{const browser=await chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']});try{
const context=await browser.newContext({viewport:{width:2560,height:1440},deviceScaleFactor:1,timezoneId:'America/Los_Angeles'}),p=await context.newPage();p.setDefaultTimeout(90000);
await p.route(/https:\/\/(?:analytics\.google\.com|www\.google-analytics\.com|www\.googletagmanager\.com|plausible\.io)\//,r=>r.fulfill({status:204,body:''}));
p.on('pageerror',e=>errors.push(e.message));p.on('console',m=>{if(m.type()==='error')errors.push(m.text());});p.on('requestfailed',r=>failed.push({url:r.url(),failure:r.failure()}));
p.on('response',r=>{if(!r.url().startsWith(base)||!/\.(?:mjs|glb|json|js)(?:\?|$)/.test(r.url()))return;pending.push((async()=>{try{const b=await r.body(),rel=decodeURIComponent(new URL(r.url()).pathname.slice(new URL(base).pathname.length)),expected=fs.readFileSync(path.join(q,'site/al-folio',rel));responses.push({url:r.url(),status:r.status(),bytes:b.length,sha256:hash(b),owned:r.headers()['x-sirui-preview']===server.header,exact:hash(b)===hash(expected)});}catch(e){responses.push({url:r.url(),error:String(e)});}})());});
console.log('navigation');await p.goto(base+'?quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});await p.evaluate(()=>document.fonts.ready);
await p.locator('[data-theme-toggle]:visible').first().click();await p.locator('[data-theme-mode-option="noon"]:visible').first().click();await p.locator('[data-theme-toggle]:visible').first().click();
await p.locator('[data-home-desk-mode="3d"]').click();const scene=p.locator('[data-home-desk-scene]');await expect(scene).toHaveAttribute('data-scene-state','ready',{timeout:180000});console.log('ready');await p.locator('[data-world-fullscreen]').click();
console.log('outside');await visit(p,'outside');await expect.poll(async()=>(await state(p)).ecology?.farField?.near?.complete,{timeout:90000}).toBe(true);

await p.locator('[data-world-places]>summary').click();await p.locator('[data-world-destination="entrance"]').click();await settle(p,false);await capture(p,'arrival-current');

const authored=JSON.parse(fs.readFileSync(path.join(q,'source/assets/models/home/manifest.json'))).walk.start;
let ev=await state(p);expect(ev.freeLook).not.toBeNull();expect(ev.walk.active).toBe(false);expect(ev.cameraFov).toBeCloseTo(62,5);
for(let i=0;i<3;i++)expect(ev.camera[i]).toBeCloseTo(authored.position[i]+(i===1?1.6:0),5);
await p.locator('[data-world-places]>summary').click();
await expect(p.locator('[data-world-destination="entrance"]')).toHaveAttribute('aria-pressed','true');
await expect(p.locator('[data-world-destination="outside"]')).toHaveAttribute('aria-pressed','false');
await expect(p.locator('[data-world-look]')).toHaveText('Coast view');
await p.locator('[data-world-look]').click();await expect.poll(async()=>(await state(p)).freeLook).toBeNull();
await p.locator('[data-world-places]>summary').click();await p.locator('[data-world-destination="entrance"]').click();await settle(p);
for(const viewport of [{width:1440,height:1000},{width:1280,height:800},{width:768,height:1024},{width:390,height:1000}]){
 await p.locator('[data-world-exit]').click();await expect.poll(async()=>(await state(p)).fullscreen).toBeNull();
 await p.setViewportSize(viewport);await scene.scrollIntoViewIfNeeded();
 await p.locator('[data-world-places]>summary').click();await p.locator('[data-world-destination="entrance"]').click();
 await p.waitForTimeout(400);await capture(p,'embed-standing-'+viewport.width);
 await p.locator('[data-world-fullscreen]').click();await p.waitForTimeout(500);await capture(p,'standing-'+viewport.width);
 const e=await state(p);expect(e.freeLook).not.toBeNull();for(let i=0;i<3;i++)expect(e.camera[i]).toBeCloseTo(authored.position[i]+(i===1?1.6:0),5);
}
await p.locator('[data-world-exit]').click();await expect.poll(async()=>(await state(p)).fullscreen).toBeNull();
await p.setViewportSize({width:2560,height:1440});await scene.scrollIntoViewIfNeeded();await p.locator('[data-world-fullscreen]').click();await p.waitForTimeout(500);
await p.locator('[data-world-walk]').click();
await expect.poll(async()=>(await state(p)).walk?.active).toBe(true);
await p.waitForTimeout(900);await capture(p,'arrival-standing');
expect(rows.at(-1).evidence.walk.destination).toBe('entrance');
await Promise.all(pending);const result={scope:'Private actual public Rooms standing entry, selected-place semantics, Coast-view return,2K/1440/390-width inspections and matching publicWalk entry, derived from the complete authored stair route; complete new22cf/645d/54dc products,191compiled integratedV20modules and official cache. Native clocks and publicPause. No training or coffee session seek is used. Pending later route/sole/transition fixes and F6 not admitted; no continuous motion or performance claim.',server,rows,errors,failed,responses};fs.writeFileSync(path.join(out,'CAPTURE.json'),JSON.stringify(result,null,2)+'\n');expect(errors).toEqual([]);expect(failed).toEqual([]);expect(responses.filter(r=>r.error||!r.exact||!r.owned||r.status>=400)).toEqual([]);await context.close();
}finally{await browser.close();}})().catch(e=>{fs.writeFileSync(path.join(out,'FAILURE.json'),JSON.stringify({error:String(e),rows,errors,failed,responses},null,2));console.error(e);process.exitCode=1;});
