import json,shutil,subprocess,urllib.request
from pathlib import Path
root=Path.cwd();q=Path(__file__).parent;out=q/'entrance-checkpoint';work=Path('C:/dev/cqa1102')
server=json.loads((out/'server.json').read_text())
with urllib.request.urlopen(server['url'],timeout=10)as r:assert r.headers['X-Sirui-Preview']==server['header']
r=subprocess.run(['taskkill.exe','/PID',str(server['pid']),'/T','/F'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT);assert r.returncode==0
for name,target in [('site','site-before-weather'),('server.json','server-before-weather.json'),('COMPILED-CUSTODY.json','COMPILED-CUSTODY-BEFORE-WEATHER.json'),('production-build.log','production-build-before-weather.log'),('BUILD-GATES.json','BUILD-GATES-BEFORE-WEATHER.json')]:
 src=(out/name).resolve();dst=(out/target).resolve()
 assert src.is_relative_to(q.resolve())and dst.is_relative_to(q.resolve())and not dst.exists()
 src.rename(dst)
(out/'site').mkdir()
names=subprocess.check_output(['git','diff','--name-only','a068dbf461a557b3252f968cdeaa69a84cbbce7a','HEAD'],cwd=root,text=True).splitlines()
assert len(names)==5 and 'assets/js/home-scene/weather-data.mjs'in names
for name in names:target=work/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,target)
(out/'WEATHER-FAST-FORWARD.json').write_text(json.dumps({'scope':'Scheduled GitHubActions weather-only commit fast-forwarded without touching pending local edits. Preserve the entire previously tested production tree and receipts; rebuild the combined current source with the actual production pipeline. Static-light inputs unchanged and cache-binding unit passes.','weatherCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'paths':names,'previousServerStopped':server,'previousSitePreserved':str(out/'site-before-weather')},indent=2)+'\n')
print('Preserved previous complete build; copied five scheduled weather paths for combined production build.')
