import hashlib,json,shutil,subprocess,sys,time,urllib.request
from pathlib import Path
root=Path.cwd();q=Path(__file__).parent;out=q/'entrance-checkpoint';site=out/'site/al-folio'
modules=json.loads((site/'assets/js/module-build.json').read_bytes());work=Path('C:/dev/cqa1102')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,row in modules['modules'].items():
 assert hashlib.sha256((work/name).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==row['sourceSha256']
 assert sha(site/name)==row['outputSha256']
assert json.loads((site/'assets/models/home/manifest.json').read_bytes())==json.loads((root/'assets/models/home/manifest.json').read_bytes())
for name in ['static-light-field.json','hinterland.glb']:assert sha(site/'assets/models/home'/name)==sha(root/'assets/models/home'/name)
shutil.copyfile(q/'private-serve-template.py',out/'serve.py')
with(out/'server.log').open('wb')as log:child=subprocess.Popen([sys.executable,str(out/'serve.py')],cwd=root,stdout=log,stderr=subprocess.STDOUT,creationflags=0x08000000)
for _ in range(100):
 if(out/'server.json').exists():break
 assert child.poll()is None;time.sleep(.1)
server=json.loads((out/'server.json').read_bytes());assert server['pid']==child.pid
with urllib.request.urlopen(server['url'],timeout=10)as r:assert r.headers['X-Sirui-Preview']==server['header']
(out/'COMPILED-CUSTODY.json').write_text(json.dumps({'modules':len(modules['modules']),'allModuleSourcesAndOutputsExact':True,'canonicalManifestSemanticsExact':True,'canonicalCacheHinterlandBytesExact':True,'server':server},indent=2)+'\n');print(json.dumps(server,indent=2))
