import hashlib,json,os,subprocess,time,urllib.request
from pathlib import Path
root=Path.cwd();q=Path(__file__).parent
server=json.loads((q/'exporter-checkpoint/server.json').read_text())
with urllib.request.urlopen(server['url'],timeout=10)as r:assert r.headers['X-Sirui-Preview']==server['header']
out=q/'entrance-checkpoint';assert not out.exists();out.mkdir()
env=dict(os.environ,COASTAL_CACHE_URL=server['url'])
command=['node',str(root/'bin/bake_coastal_static_light.cjs')];started=time.monotonic()
with(out/'official-bake.log').open('wb')as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={'exitCode':r.returncode,'command':command,'seconds':time.monotonic()-started,'ownedServer':server,'scope':'Unmodified official producer serving current canonical source modules/model dependencies over the owned production preview; includes new arrival-view dependency and exact8shrub retirement. Existing1e10house/oldarrival metadata remain. Fresh complete production build/renderer qualification follow.'}
(out/'BAKE-PROCESS.json').write_text(json.dumps(receipt,indent=2)+'\n');assert r.returncode==0
cache_path=root/'assets/models/home/static-light-field.json';cache=json.loads(cache_path.read_bytes());configuration=json.loads(cache['configuration']);stats=cache['statistics']
assert len(configuration['regions'])==16 and len(configuration['practicalSources'])==28 and len(cache['probes'])==128 and stats['triangles']+stats['skippedTriangles']<=750000 and cache_path.stat().st_size<=800000
receipt.update(signature=cache['signature'],cacheSha256=hashlib.sha256(cache_path.read_bytes()).hexdigest(),cacheBytes=cache_path.stat().st_size,preROITriangles=stats['triangles']+stats['skippedTriangles'],regions=16,practicals=28,probes=128)
(out/'CACHE.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
