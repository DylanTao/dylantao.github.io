import bpy,sys,json,hashlib,itertools
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,r"C:/dev/site-takeover-worktrees/breakfast-nook-20261101/bin")
import coastal_pavilion_chair as c
p=Path(r"C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/coffee-contact-v6/pavilion-breakfast-v1/chair-lobes-native-v3/candidate.blend");assert hashlib.sha256(p.read_bytes()).hexdigest()=="5b71c16e04309ba426073533618527058c34b59052f83fa6b2b7630e7a25f4c1"
bpy.ops.wm.open_mainfile(filepath=str(p));bpy.context.view_layer.update()
def world(obj,v):
 p=obj.matrix_world@v;return Vector((p.x,p.z,-p.y))
def components(obj):
 m=obj.data;adj=[set()for v in m.vertices]
 for e in m.edges:a,b=e.vertices;adj[a].add(b);adj[b].add(a)
 seen=set();out=[]
 for i in range(len(m.vertices)):
  if i in seen:continue
  todo=[i];ids=set();seen.add(i)
  while todo:
   v=todo.pop();ids.add(v)
   for n in adj[v]:
    if n not in seen:seen.add(n);todo.append(n)
  ps=[world(obj,m.vertices[i].co)for i in ids];lo=[min(p[k]for p in ps)for k in range(3)];hi=[max(p[k]for p in ps)for k in range(3)]
  fs=[f for f in m.polygons if all(v in ids for v in f.vertices)];planes=[]
  for f in fs:
   vs=[world(obj,m.vertices[v].co)for v in f.vertices];n=(vs[1]-vs[0]).cross(vs[2]-vs[0]);
   if n.length>1e-14:planes.append((n.normalized(),vs[0],f.index))
  convex=max((n.dot(at-a)for n,a,_ in planes for at in ps),default=0)
  out.append({'id':len(out),'vertices':sorted(ids),'bounds':[lo,hi],'planes':planes,'convexError':convex,'owner':obj.name})
 return out
def inside(s,p):return max(n.dot(p-a)for n,a,_ in s['planes'])
posts=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH' or not o.name.startswith('core_estate_pavilion__'):continue
 for s in components(o):
  lo,hi=s['bounds']
  if lo[0]<6.45 and hi[0]>6.32 and lo[1]<.9 and hi[1]>.4 and lo[2]<-.9 and hi[2]>-1.05:posts.append(s)
print([(s["owner"],s["id"],s["bounds"],len(s["vertices"]),s["convexError"])for s in posts])
