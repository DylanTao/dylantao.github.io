import fs from "node:fs";import path from "node:path";import{pathToFileURL}from"node:url";
const root=process.cwd(),q=path.resolve(".jekyll-cache/visual-qa/breakfast-nook-20261101/coffee-contact-v6/pavilion-breakfast-v1"),base="C:/dev/dylantao.github.io/.jekyll-cache/visual-qa/final-house-integration-20261102/public-pavilion-export-v1/models/";
const{THREE:T,loadNativeModel}=await import("../bound-native-avatar-v1.mjs"),{nativeGeometry}=await import("../bound-native-geometry-v1.mjs"),{createTriangleParity}=await import(pathToFileURL(path.join(root,"test/helpers/coastal-triangle-parity.mjs")));
const config=JSON.parse(fs.readFileSync(base+"manifest.json")),scene=new T.Group(),region=new T.Box3(new T.Vector3(4,-.15,-3.4),new T.Vector3(8.8,3,.8)),solids=[],surfaces=[],unresolved=[];
for(const file of new Set(["home-shell.glb","coast.glb","flora.glb","hinterland.glb",...config.rooms.map(r=>r.file)])){const g=await nativeGeometry(file,pathToFileURL(file==="hinterland.glb"?"C:/dev/dylantao.github.io/assets/models/home/":base));g.userData.sourceFile=file;scene.add(g);}scene.updateMatrixWorld(true);
// Reconnect exact coincident decoded position seams for COMPONENT identification only.
// Every original finite triangle remains in the parity surface; no geometry is simplified.
scene.traverse((mesh) => {
  if (!mesh.isMesh) return;
  const a = mesh.geometry.attributes.position, index = mesh.geometry.index, points = [], canonical = new Map(), ids = [], uf = [];
  const find = (i) => { while (uf[i] !== i) { uf[i] = uf[uf[i]]; i = uf[i]; } return i; };
  const join = (a, b) => { uf[find(a)] = find(b); };
  for (let i = 0; i < a.count; i++) {
    const p = new T.Vector3().fromBufferAttribute(a, i).applyMatrix4(mesh.matrixWorld), key = p.toArray().join(",");
    if (!canonical.has(key)) { const id = points.length; canonical.set(key, id); points.push(p); uf.push(id); }
    ids.push(canonical.get(key));
  }
  const faces = [];
  for (let i = 0; i < (index?.count ?? a.count); i += 3) {
    const vi = [0, 1, 2].map((k) => ids[index ? index.getX(i + k) : i + k]); join(vi[0], vi[1]); join(vi[1], vi[2]); faces.push({ id: i / 3, vi });
  }
  const components = new Map();
  for (const face of faces) { const id = find(face.vi[0]); if (!components.has(id)) components.set(id, []); components.get(id).push(face); }
  let island = 0;
  for (const faces of components.values()) {
    const bounds = new T.Box3(); for (const f of faces) for (const i of f.vi) bounds.expandByPoint(points[i]);
    const id = island++; if (!bounds.intersectsBox(region)) continue;
    const nonzero = faces.filter((f) => new T.Triangle(...f.vi.map((i) => points[i])).getArea() > 0), edges = new Map();
    for (const f of nonzero) for (let k = 0; k < 3; k++) { const a = f.vi[k], b = f.vi[(k + 1) % 3], key = [Math.min(a, b), Math.max(a, b)].join(","); const list = edges.get(key) || []; list.push([a, b]); edges.set(key, list); }
    const bad = [...edges.values()].filter((list) => list.length !== 2 || list[0][0] !== list[1][1] || list[0][1] !== list[1][0]);
    const record = { owner: mesh.parent.name, material: mesh.material.name, island: id, originalFaces: faces.length, nonzeroFaces: nonzero.length, badOrientedEdges: bad.length, bounds: [bounds.min.toArray(), bounds.max.toArray()] };
    surfaces.push({ ...record, closed: !bad.length && Boolean(nonzero.length), box: bounds,
      triangles: faces.map((f) => ({ id: f.id, zeroArea: new T.Triangle(...f.vi.map((v) => points[v])).getArea() === 0, triangle: new T.Triangle(...f.vi.map((v) => points[v])) })) });
    if (bad.length || !nonzero.length) { unresolved.push(record); continue; }
    const p = new Float64Array(nonzero.length * 9);
    nonzero.forEach((f, i) => f.vi.forEach((v, k) => points[v].toArray(p, i * 9 + k * 3)));
    const geometry = new T.BufferGeometry(); geometry.setAttribute("position", new T.BufferAttribute(p, 3));
    solids.push({ ...record, box: bounds, contains: createTriangleParity(T, geometry), triangles: nonzero.map((f) => ({ id: f.id, triangle: new T.Triangle(...f.vi.map((v) => points[v])) })) });
  }
});
// Explicit PRIVATE native-design overlay: retire only exact original panel188tri.
const originalPanel=surfaces.find(s=>s.owner==="core_estate_pavilion__pale oak"&&s.island===5);if(originalPanel.triangles.length!==188)throw Error("panel mapping changed");for(const list of[surfaces,solids]){const i=list.findIndex(s=>s.owner===originalPanel.owner&&s.island===originalPanel.island);if(i<0)throw Error("panel absent");list.splice(i,1);}
const nativeChair=JSON.parse(fs.readFileSync(path.join(q,"NATIVE-CHAIR-PARTS-V6.json")));
for(const part of nativeChair.parts){const points=part.worldPoints.map(p=>new T.Vector3(...p)),triangles=part.triangles.map((v,id)=>({id,sourcePolygon:part.polygonNativeIds[id],triangle:new T.Triangle(...v.map(i=>points[i]))})),box=new T.Box3().setFromPoints(points),geometry=new T.BufferGeometry();geometry.setAttribute("position",new T.BufferAttribute(new Float64Array(triangles.flatMap(t=>[t.triangle.a,t.triangle.b,t.triangle.c].flatMap(p=>p.toArray()))),3));const row={owner:part.name,material:part.materials[0],island:0,box,bounds:[box.min.toArray(),box.max.toArray()],triangles};surfaces.push(row);solids.push({...row,contains:createTriangleParity(T,geometry)});}
export{T,root,q,base,config,scene,solids,surfaces,unresolved,loadNativeModel};
