import bpy,json,sys
from pathlib import Path
from mathutils import Vector
source=Path(r"C:\dev\site-takeover-worktrees\breakfast-nook-20261101\.jekyll-cache\visual-qa\breakfast-nook-20261101\coffee-contact-v6\pavilion-breakfast-v1\native-footrest-v2\candidate.blend")
bpy.ops.wm.open_mainfile(filepath=str(source));obj=bpy.data.objects["core_estate_terrace__travertine paving stone"];inverse=obj.matrix_world.inverted();direction=(inverse.to_3x3()@Vector((0,0,-1))).normalized();rows=[]
for x in[6.12,6.15,6.18,6.76,6.79,6.82]:
 for z in[-1.87,-1.695,-1.52]:
  origin=inverse@Vector((x,-z,1));hit,p,n,face=obj.ray_cast(origin,direction);world=obj.matrix_world@p if hit else None;rows.append({"x":x,"z":z,"nativeFace":face,"hit":hit,"worldFloor":world.z if hit else None,"pointNative":list(world)if hit else None})
out=Path(r"C:\dev\site-takeover-worktrees\breakfast-nook-20261101\.jekyll-cache\visual-qa\breakfast-nook-20261101\coffee-contact-v6\pavilion-breakfast-v1\NATIVE-PAVING-BEARING-V1.json");out.write_text(json.dumps({"source":str(source),"object":obj.name,"rows":rows},indent=2)+"\n");print(rows)
