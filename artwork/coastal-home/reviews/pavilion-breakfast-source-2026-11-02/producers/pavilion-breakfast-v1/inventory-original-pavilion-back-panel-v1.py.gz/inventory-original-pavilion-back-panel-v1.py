import bpy,hashlib,json,sys
from pathlib import Path
from mathutils import Vector
SOURCE=Path(r"C:/dev/dylantao.github.io/artwork/coastal-home/coastal-home.blend")
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()=="1e10b25d5cf0eec87d7001acbf9d938d65ba33af6076380d5a8e5d45cf3d23e7"
bpy.ops.wm.open_mainfile(filepath=str(SOURCE));bpy.context.view_layer.update()
o=bpy.data.objects["core_estate_pavilion__pale oak"];m=o.data
adj=[set()for v in m.vertices]
for e in m.edges:a,b=e.vertices;adj[a].add(b);adj[b].add(a)
seen=set();components=[]
def world(v):
 p=o.matrix_world@v;return [p.x,p.z,-p.y]
for i in range(len(m.vertices)):
 if i in seen:continue
 todo=[i];seen.add(i);ids=[]
 while todo:
  v=todo.pop();ids.append(v)
  for n in adj[v]:
   if n not in seen:seen.add(n);todo.append(n)
 pts=[world(m.vertices[v].co)for v in ids];lo=[min(p[k]for p in pts)for k in range(3)];hi=[max(p[k]for p in pts)for k in range(3)]
 components.append({"id":len(components),"vertices":sorted(ids),"bounds":[lo,hi]})
panels=[c for c in components if abs(c["bounds"][0][0]-6.345)<.002 and abs(c["bounds"][1][0]-6.855)<.002 and .63<c["bounds"][0][1]<.66 and .88<c["bounds"][1][1]<.91 and -.98<c["bounds"][0][2]<-.96]
assert len(panels)==1,panels
panel=panels[0];ids=set(panel["vertices"]);m.calc_loop_triangles()
faces=[p for p in m.polygons if all(v in ids for v in p.vertices)];edges=[e for e in m.edges if all(v in ids for v in e.vertices)];normals=m.corner_normals;colors=m.color_attributes.get("COLOR_0")
row={"source":str(SOURCE),"sourceSHA256":hashlib.sha256(SOURCE.read_bytes()).hexdigest(),"owner":o.name,"matrix":[list(r)for r in o.matrix_world],"component":panel,"vertices":[{"id":v,"localP":list(m.vertices[v].co),"worldP":world(m.vertices[v].co)}for v in sorted(ids)],"edges":[{"id":e.index,"vertices":list(e.vertices)}for e in edges],"faces":[{"id":p.index,"vertices":list(p.vertices),"loops":list(p.loop_indices),"materialIndex":p.material_index,"smooth":p.use_smooth,"corners":[{"loop":j,"N":list(normals[j].vector),"RGB":list(colors.data[j].color)if colors else None,"UV":{u.name:list(u.data[j].uv)for u in m.uv_layers}}for j in p.loop_indices]}for p in faces],"triangles":[{"id":t.index,"face":t.polygon_index,"vertices":list(t.vertices),"loops":list(t.loops)}for t in m.loop_triangles if t.polygon_index in{p.index for p in faces}],"materialSlots":[x.name if x else None for x in m.materials],"allOwnerVertexCount":len(m.vertices),"allOwnerPolygonCount":len(m.polygons)}
row["componentSHA256"]=hashlib.sha256(json.dumps(row,sort_keys=True,separators=(",",":")).encode()).hexdigest()
out=Path(r"C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/coffee-contact-v6/pavilion-breakfast-v1/PAVILION-ORIGINAL-BACK-PANEL-V1.json");assert not out.exists();out.write_text(json.dumps(row,indent=2)+"\n");print({"component":panel["id"],"bounds":panel["bounds"],"vertices":len(ids),"polygons":len(faces),"triangles":len(row["triangles"]),"sha256":row["componentSHA256"]})
