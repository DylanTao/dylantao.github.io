import bpy,json,hashlib,sys
from pathlib import Path
sys.path.insert(0,r"C:/dev/site-takeover-worktrees/breakfast-nook-20261101/bin")
import coastal_pavilion_chair as c
p=Path(r"C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/coffee-contact-v6/pavilion-breakfast-v1/chair-lobes-native-v6/candidate.blend");h=hashlib.sha256(p.read_bytes()).hexdigest();assert h=="16f3a9d226ca5352b268d5160350f277e7cd28816cd0d6ae1b489a655c801b47";bpy.ops.wm.open_mainfile(filepath=str(p));bpy.context.view_layer.update();parts=[]
for name in (*c.NAMES,c.POST_NAME):
 o=bpy.data.objects[name];m=o.data;m.calc_loop_triangles();ps=[o.matrix_world@v.co for v in m.vertices]
 parts.append({'name':name,'worldPoints':[[p.x,p.z,-p.y]for p in ps],'triangles':[list(t.vertices)for t in m.loop_triangles],'triangleNativeIds':[t.index for t in m.loop_triangles],'polygonNativeIds':[t.polygon_index for t in m.loop_triangles],'matrix':[list(r)for r in o.matrix_world],'materials':[m.name for m in m.materials],'nativeDigest':c._mesh_digest(o)})
out=Path(r"C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/coffee-contact-v6/pavilion-breakfast-v1/NATIVE-CHAIR-PARTS-V6.json");assert not out.exists();out.write_text(json.dumps({'sourceSHA256':h,'parts':parts},indent=2)+'\n');print([(p['name'],len(p['worldPoints']),len(p['triangles']))for p in parts])
