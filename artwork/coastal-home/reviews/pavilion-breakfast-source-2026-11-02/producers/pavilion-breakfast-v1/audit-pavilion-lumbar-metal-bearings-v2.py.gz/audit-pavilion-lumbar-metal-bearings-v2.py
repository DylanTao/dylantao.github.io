import bpy,sys,json,hashlib,itertools
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,r"C:/dev/site-takeover-worktrees/breakfast-nook-20261101/bin")
import coastal_pavilion_chair as c
p=Path(r"C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/coffee-contact-v6/pavilion-breakfast-v1/chair-lobes-native-v3/candidate.blend");assert hashlib.sha256(p.read_bytes()).hexdigest()=="5b71c16e04309ba426073533618527058c34b59052f83fa6b2b7630e7a25f4c1"
bpy.ops.wm.open_mainfile(filepath=str(p));bpy.context.view_layer.update()
def world(obj,v):
 p=obj.matrix_world@v;return Vector((p.x,p.z,-p.y))
def components(obj):
 m=obj.data;adj=[set()for v in m.vertices]
 for e in m.edges:a,b=e.vertices;adj[a].add(b);adj[b].add(a)
 seen=set();out=[]
 for i in range(len(m.vertices)):
  if i in seen:continue
  todo=[i];ids=set();seen.add(i)
  while todo:
   v=todo.pop();ids.add(v)
   for n in adj[v]:
    if n not in seen:seen.add(n);todo.append(n)
  ps=[world(obj,m.vertices[i].co)for i in ids];lo=[min(p[k]for p in ps)for k in range(3)];hi=[max(p[k]for p in ps)for k in range(3)]
  fs=[f for f in m.polygons if all(v in ids for v in f.vertices)];planes=[]
  for f in fs:
   vs=[world(obj,m.vertices[v].co)for v in f.vertices];n=(vs[1]-vs[0]).cross(vs[2]-vs[0]);
   if n.length>1e-14:planes.append((n.normalized(),vs[0],f.index))
  convex=max((n.dot(at-a)for n,a,_ in planes for at in ps),default=0)
  out.append({'id':len(out),'vertices':sorted(ids),'bounds':[lo,hi],'planes':planes,'convexError':convex,'owner':obj.name})
 return out
def inside(s,p):return max(n.dot(p-a)for n,a,_ in s['planes'])
posts=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH' or not o.name.startswith('core_estate_pavilion__'):continue
 for s in components(o):
  lo,hi=s['bounds']
  if 6.3<lo[0]<6.9 and .4<lo[1]<.5 and .85<hi[1]<.9 and -1.1<lo[2]<-.8 and hi[2]<-.8:posts.append(s)
assert len(posts)==2,[(s['bounds'],s['owner'])for s in posts]
rows=[]
for name in c.NAMES:
 lobe=components(bpy.data.objects[name]);assert len(lobe)==1;lobe=lobe[0];best=None
 for post in posts:
  cx=(post['bounds'][0][0]+post['bounds'][1][0])/2
  for half in [.008,.006,.004,.002]:
   for y,z,dx in itertools.product([.70,.72,.74,.76,.78,.80,.82],[-.960,-.955,-.950,-.945,-.940,-.935,-.930],[-.005,0,.005]):
    center=Vector((cx+dx,y,z));corners=[center+Vector(offset)for offset in itertools.product([-half,half],repeat=3)]
    gap=max(inside(s,p)for s in [post,lobe]for p in corners)
    if gap < -1e-7 and (best is None or half>best['half']):best={'half':half,'center':list(center),'corners':[list(p)for p in corners],'maximumSignedPlaneDistance':gap,'post':{k:v for k,v in post.items()if k!='planes'},'lobe':{k:v for k,v in lobe.items()if k!='planes'}}
  if best:break
 assert best,name
 rows.append({'lobe':name,'bearingBox':best,'positiveOverlapVolume':(2*best['half'])**3})
out=Path(r"C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/coffee-contact-v6/pavilion-breakfast-v1/LUMBAR-METAL-POST-BEARINGS-V2.json");assert not out.exists();out.write_text(json.dumps({'status':'PASS source positive-volume inscribed metal-post/lumbar contacts','source':str(p),'sourceSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'rows':rows,'scope':'Actual saved/reopened source convex component planes, all8corners inside BOTH original post and new closed lobe; no AABB-only overlap inference. Native field/contact/render gates separate.'},indent=2)+'\n');print([(r['lobe'],r['bearingBox']['half'],r['bearingBox']['center'])for r in rows])
