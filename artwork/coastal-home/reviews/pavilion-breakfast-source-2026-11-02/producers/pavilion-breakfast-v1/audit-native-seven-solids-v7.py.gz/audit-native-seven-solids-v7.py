import bpy,sys,hashlib,json
from pathlib import Path
sys.path.insert(0,r"C:/dev/site-takeover-worktrees/breakfast-nook-20261101/bin")
import coastal_pavilion_chair as c
import coastal_pavilion_breakfast as f
p=Path(r"C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/coffee-contact-v6/pavilion-breakfast-v1/chair-lobes-native-v6/candidate.blend");h=hashlib.sha256(p.read_bytes()).hexdigest();assert h=="16f3a9d226ca5352b268d5160350f277e7cd28816cd0d6ae1b489a655c801b47";bpy.ops.wm.open_mainfile(filepath=str(p));rows=[]
for name in(*f.NAMES,*c.NAMES,c.POST_NAME):
 o=bpy.data.objects[name];m=o.data;m.calc_loop_triangles();proof=f.topology({'points':[list(v.co)for v in m.vertices],'triangles':[tuple(t.vertices)for t in m.loop_triangles]});assert proof['badDirectedEdges']==0 and proof['signedVolume']>0 and proof['minimumDoubleArea']>0;rows.append({'name':name,'proof':proof,'matrix':[list(r)for r in o.matrix_world],'digest':f._mesh_digest(o)})
out=Path(r"C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/coffee-contact-v6/pavilion-breakfast-v1/NATIVE-SEVEN-SOLIDS-V7.json");assert not out.exists();out.write_text(json.dumps({'status':'PASS actual saved seven new directed positive closed solids','sourceSHA256':h,'rows':rows,'triangles':sum(r['proof']['triangles']for r in rows),'retiredOriginalTriangles':188,'netVsCanonical':sum(r['proof']['triangles']for r in rows)-188},indent=2)+'\n');print([(r['name'],r['proof']['triangles'],r['proof']['signedVolume'])for r in rows])
