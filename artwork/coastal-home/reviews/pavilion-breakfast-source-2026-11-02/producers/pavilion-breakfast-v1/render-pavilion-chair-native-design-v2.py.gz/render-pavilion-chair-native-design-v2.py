import bpy,json,hashlib,time
from pathlib import Path
from mathutils import Vector
q=Path(r"C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/coffee-contact-v6/pavilion-breakfast-v1/chair-native-design-v2");q.mkdir(exist_ok=True)
sources=[('rounded-open-back',Path(r"C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/coffee-contact-v6/pavilion-breakfast-v1/chair-lobes-native-v6/candidate.blend"),'16f3a9d226ca5352b268d5160350f277e7cd28816cd0d6ae1b489a655c801b47')]
def native(p):return Vector((p[0],-p[2],p[1]))
rows=[]
for label,p,h in sources:
 assert hashlib.sha256(p.read_bytes()).hexdigest()==h;bpy.ops.wm.open_mainfile(filepath=str(p));scene=bpy.context.scene;scene.render.engine='CYCLES' if False else 'BLENDER_EEVEE_NEXT';scene.render.resolution_x=1600;scene.render.resolution_y=1200;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
 # Explicit temporary studio sources assess shape only, not website lighting.
 for o in list(scene.objects):
  if o.type=='LIGHT':o.hide_render=True
 for name,at,power,size in [('Q_STUDIO_KEY',(7.8,3.0,-.2),180,3),('Q_STUDIO_FILL',(5,2.2,-2.4),90,2)]:
  data=bpy.data.lights.new(name,'AREA');data.energy=power;data.shape='DISK';data.size=size;ob=bpy.data.objects.new(name,data);scene.collection.objects.link(ob);ob.location=native(at);ob.rotation_euler=(native((6.6,.55,-1.2))-ob.location).to_track_quat('-Z','Y').to_euler()
 world=bpy.data.worlds.new('Q_NEUTRAL_STUDIO');world.use_nodes=True;world.node_tree.nodes['Background'].inputs['Color'].default_value=(.23,.27,.30,1);world.node_tree.nodes['Background'].inputs['Strength'].default_value=.4;scene.world=world
 data=bpy.data.cameras.new('Q_CHAIR_CAMERA');camera=bpy.data.objects.new('Q_CHAIR_CAMERA',data);scene.collection.objects.link(camera);camera.location=native((7.65,1.45,0));camera.rotation_euler=(native((6.6,.55,-1.2))-camera.location).to_track_quat('-Z','Y').to_euler();data.lens=57;data.clip_start=.01;data.clip_end=500;scene.camera=camera;scene.view_settings.view_transform='AgX';scene.view_settings.exposure=0
 out=q/(label+'.png');assert not out.exists();scene.render.filepath=str(out);start=time.time();bpy.ops.render.render(write_still=True);rows.append({'label':label,'source':str(p),'sourceSHA256':h,'png':str(out),'pngSHA256':hashlib.sha256(out.read_bytes()).hexdigest(),'elapsedSeconds':time.time()-start,'cameraWorld':[7.65,1.45,0],'targetWorld':[6.6,.55,-1.2],'lens':57})
(q/'CAPTURE.json').write_text(json.dumps({'status':'DESIGN ONLY matched native geometry close view; not actual browser ambience/performance or seated-entry acceptance','engine':'BLENDER_EEVEE_NEXT','temporaryLights':[{'powerW':180,'size':3},{'powerW':90,'size':2}],'worldStrength':.4,'resolution':[1600,1200],'rows':rows,'noNativeSave':True,'producerSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
