import bpy,sys,json,hashlib
from pathlib import Path
sys.path.insert(0,r"C:/dev/site-takeover-worktrees/breakfast-nook-20261101/bin")
import coastal_pavilion_chair as chair
p=Path(r"C:/dev/dylantao.github.io/artwork/coastal-home/coastal-home.blend");assert hashlib.sha256(p.read_bytes()).hexdigest()=="1e10b25d5cf0eec87d7001acbf9d938d65ba33af6076380d5a8e5d45cf3d23e7"
bpy.ops.wm.open_mainfile(filepath=str(p));bpy.context.view_layer.update()
h,r=chair.panel_fingerprint(bpy.data.objects[chair.OWNER]);out=Path(r"C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/coffee-contact-v6/pavilion-breakfast-v1/PANEL-ALL-RAW-FIELDS-V2.json");assert not out.exists();out.write_text(json.dumps({"sourceSHA256":hashlib.sha256(p.read_bytes()).hexdigest(),"panelSHA256":h,"record":r,"helperSHA256":hashlib.sha256(Path(chair.__file__).read_bytes()).hexdigest()},indent=2)+"\n");print(h)
