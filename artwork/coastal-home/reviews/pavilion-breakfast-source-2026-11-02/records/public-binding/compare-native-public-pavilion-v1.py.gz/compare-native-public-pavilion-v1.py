import bpy,sys,json,hashlib
from pathlib import Path
sys.path.insert(0,r"C:/dev/site-takeover-worktrees/breakfast-nook-20261101/bin")
import coastal_pavilion_breakfast as helper
sources=[Path(r"C:/dev/dylantao.github.io/artwork/coastal-home/coastal-home.blend"),Path(r"C:/dev/dylantao.github.io/.jekyll-cache/visual-qa/final-house-integration-20261102/garden-bench-open-plant-ao-v2/candidate.blend")]
def material_digest(m):
 data={"name":m.name,"diffuse":list(m.diffuse_color),"roughness":m.roughness,"metallic":m.metallic,"useNodes":m.use_nodes,"nodes":[],"links":[]}
 if m.node_tree:
  for n in m.node_tree.nodes:
   row={"type":n.bl_idname,"name":n.name,"inputs":[]}
   for i in n.inputs:
    if hasattr(i,"default_value"):
     v=i.default_value
     if not isinstance(v,(float,int,str,bool,type(None))):
      try:v=list(v)
      except TypeError:v=str(v)
     row["inputs"].append((i.identifier,v))
   data["nodes"].append(row)
  data["links"]=[(l.from_node.name,l.from_socket.identifier,l.to_node.name,l.to_socket.identifier)for l in m.node_tree.links]
 return hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()
rows=[]
for source in sources:
 raw=source.read_bytes();bpy.ops.wm.open_mainfile(filepath=str(source));bpy.context.view_layer.update();objects={};materials={}
 for o in bpy.context.scene.objects:
  if o.type!="MESH"or not(o.name.startswith("core_estate_pavilion")or o.name.startswith("core_walkflow_pavilion")or o.name in["core_estate_terrace__travertine paving stone","core_estate_terrace__warm cut stone"]):continue
  objects[o.name]={"digest":helper._mesh_digest(o),"vertices":len(o.data.vertices),"faces":len(o.data.polygons),"matrix":[list(r)for r in o.matrix_world]}
  for m in o.data.materials:
   if m:materials[m.name]=material_digest(m)
 rows.append({"source":str(source),"sha256":hashlib.sha256(raw).hexdigest(),"objects":objects,"materials":materials})
a,b=rows;diff=[k for k in set(a["objects"])|set(b["objects"])if a["objects"].get(k)!=b["objects"].get(k)];mdiff=[k for k in set(a["materials"])|set(b["materials"])if a["materials"].get(k)!=b["materials"].get(k)]
out=Path(r"C:\dev\site-takeover-worktrees\breakfast-nook-20261101\.jekyll-cache\visual-qa\breakfast-nook-20261101\coffee-contact-v6\pavilion-breakfast-v1\public-binding\NATIVE-PUBLIC-PAVILION-EQUALITY-V1.json");out.write_text(json.dumps({"status":"PASS"if not diff and not mdiff else"RED","scope":"Read-only exact native pavilion/table/chair/counter/support source fields and material graphs. No whole-house/F6 transfer or decoded equality inferred.","sources":rows,"changedObjects":diff,"changedMaterials":mdiff,"helperSha256":hashlib.sha256(Path(helper.__file__).read_bytes()).hexdigest()},indent=2)+"\n");print({"objects":len(a["objects"]),"materials":len(a["materials"]),"diff":diff,"materialDiff":mdiff})
