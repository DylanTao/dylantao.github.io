import crypto from "node:crypto";
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { THREE, loadNativeModel } from "file:///C:/dev/site-takeover-worktrees/identity-footer/test/helpers/coastal-native-avatar.mjs";
import { nativeGeometry } from "file:///C:/dev/site-takeover-worktrees/identity-footer/test/helpers/coastal-native-geometry.mjs";
const {createWildlife}=await import(new URL("./rabbit-fixed/frozen-rabbit-runtime.mjs",import.meta.url));
import { createGroundPatch } from "file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife-ground-contact.mjs";
import { rabbitActing, rabbitSchedule } from "file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife-motion.mjs";

const models = new URL("file:///C:/dev/site-takeover-worktrees/identity-footer/.jekyll-cache/visual-qa/animal-readonly-20261031/rabbit-fixed/inputs/assets/models/home/");
const config = JSON.parse(fs.readFileSync(new URL("manifest.json", models)));
const perches = JSON.parse(fs.readFileSync(new URL("wildlife-perch-support.json", models)));
const species = ["BrushRabbit", "CaliforniaSeaLion", "HarborSeal", "Raccoon", "WesternGull", "Sandpiper", "BrownPelican", "BrandtsCormorant"];
const masters = await Promise.all(species.map((name) => loadNativeModel(name + ".glb", models)));
async function world(manifest, grounds) {
  const scene = new THREE.Group(), environment = new THREE.Group(); scene.add(environment, ...grounds);
  const wildlife = createWildlife(environment, manifest, {
    createModelLoader: () => ({ loader: { loadAsync: async (url) => masters[species.indexOf(url.split("/").at(-1).replace(".glb", ""))] }, decoder: { dispose() {} } }),
    loadPerchSupport: async () => perches,
  });
  for (let i = 0; i < 100 && !wildlife.evidence().modelsReady; i++) await new Promise(setImmediate);
  assert.equal(wildlife.evidence().modelsReady, true);
  wildlife.captureGround(grounds); scene.updateMatrixWorld(true);
  const paws = [0, 1].map((index) => {
    const list=[];
    scene.traverse((mesh) => {
      if (!mesh.isSkinnedMesh || mesh.userData.action?.id !== `rabbit-${index}`) return;
      const skin=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight;
      for(let i=0;i<skin.count;i++) {
        const names=new Map();
        for(let k=0;k<4;k++){const name=mesh.skeleton.bones[skin.getComponent(i,k)].name;names.set(name,(names.get(name)||0)+weights.getComponent(i,k));}
        for(const [name,weight]of names)if(/^(Front|Hind)Paw[LR]$/.test(name)&&weight>=.999)list.push({mesh,index:i,name});
      }
    });
    assert.ok(list.length>1000);return list;
  });
  const patches=["rabbitWest","rabbitEast"].map((key)=>{const p=createGroundPatch(manifest.terrain.habitats[key].path,1);p.capture(grounds);assert.ok(p.evidence().ready);return p});
  function measure(index) {
    scene.updateMatrixWorld(true);
    for(const mesh of new Set(paws[index].map(p=>p.mesh)))mesh.skeleton.update();
    const feet=Object.fromEntries(["FrontPawL","FrontPawR","HindPawL","HindPawR"].map(n=>[n,{minimum:Infinity,missing:0,points:[]} ]));
    for(const p of paws[index]){
      const v=p.mesh.getVertexPosition(p.index,new THREE.Vector3()).applyMatrix4(p.mesh.matrixWorld),hit=patches[index].sample(v.x,v.z,v.y+.5),foot=feet[p.name];
      foot.points.push(v.toArray());if(!hit)foot.missing++;else foot.minimum=Math.min(foot.minimum,v.y-hit.height);
    }
    return feet;
  }
  return {scene,wildlife,paws,measure};
}
function samples() {
  const times=new Set([0,1,2,4,8,12,16,24,32,40,48,56,64,72]);
  for(const seed of [1,2])for(const at of [0,40,80]){
    const schedule=rabbitSchedule(at,seed);
    for(const s of schedule.segments)for(const t of [s.start+1e-5,(s.start+s.end)/2,s.end-1e-5])if(t>=0)times.add(t);
    for(const h of schedule.hops)for(const u of [0,.05,.1,.18,.2,.35,.5,.7,.76,.85,.95,1]){
      const t=h.start+(h.end-h.start)*u;if(t>=0)times.add(t);
    }
  }
  return [...times].sort((a,b)=>a-b);
}


const grounds=await Promise.all([nativeGeometry("home-shell.glb",models),nativeGeometry("coast.glb",models)]);
const runtime=await world(structuredClone(config),grounds),rows=[],others=[],pawCache=runtime.paws;
const patches=["rabbitWest","rabbitEast"].map(key=>{const p=createGroundPatch(config.terrain.habitats[key].path,1);p.capture(grounds);return p});
const allMeshes=[0,1].map(index=>{const out=[];runtime.scene.traverse(o=>{if(o.isSkinnedMesh&&o.userData.action?.id===`rabbit-${index}`)out.push(o)});return out});
const digest=b=>crypto.createHash("sha256").update(JSON.stringify(b)).digest("hex");
for(const time of samples()){
 runtime.wildlife.update(time,"day",{force:true});runtime.scene.updateMatrixWorld(true);
 for(let index=0;index<2;index++){
  const pose=rabbitActing(time,index+1),feet=runtime.measure(index),points=[];let minimum=null,missing=0,total=0;
  for(const mesh of allMeshes[index]){
   mesh.skeleton.update();const skin=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight;
   for(let i=0;i<skin.count;i++){
    const p=mesh.getVertexPosition(i,new THREE.Vector3()).applyMatrix4(mesh.matrixWorld);points.push(...p.toArray());total++;
    const hit=patches[index].sample(p.x,p.z,p.y+.5);if(!hit){missing++;continue}
    const gap=p.y-hit.height;
    if(!minimum||gap<minimum.gap)minimum={gap,vertex:i,mesh:mesh.name,material:mesh.material.name,point:p.toArray(),support:{height:hit.height,mesh:hit.mesh,triangle:hit.triangle},weights:Array.from({length:4},(_,k)=>({bone:mesh.skeleton.bones[skin.getComponent(i,k)].name,weight:weights.getComponent(i,k)}))};
   }
  }
  const group=allMeshes[index][0].parent;
  rows.push({time,index,state:pose.state,phase:pose.phase,airborne:pose.airborne,lift:pose.lift,
    rootPosition:runtime.wildlife.evidence().rabbitHabitats[index].position,
    feet:Object.fromEntries(Object.entries(feet).map(([n,f])=>[n,{minimum:f.minimum,missing:f.missing}])),
    allSkin:{minimum,total,missing,worldVerticesSha256:digest(points)},contacts:runtime.wildlife.evidence().rabbitHabitats[index].contacts||[]});
 }
 const byId={};runtime.scene.traverse(o=>{
  if(!o.isSkinnedMesh||!o.userData.action?.id||o.userData.action.id.startsWith("rabbit-"))return;
  const id=o.userData.action.id;if(byId[id])return;
  byId[id]=[o.parent.position.toArray(),o.parent.quaternion.toArray(),o.parent.scale.toArray(),o.skeleton.bones.map(b=>[b.name,...b.position.toArray(),...b.quaternion.toArray(),...b.scale.toArray()])];
 });others.push({time,sha256:digest(byId)});
}
const label=process.argv.includes("--baseline")?"baseline":"candidate";
fs.writeFileSync(new URL(`./rabbit-fixed/native-${label}.json`,import.meta.url),JSON.stringify({rows,otherSpecies:others},null,2));
console.log(JSON.stringify({label,rows:rows.length,times:others.length,minimumBodyGap:Math.min(...rows.map(r=>r.allSkin.minimum.gap)),minimumToeGap:Math.min(...rows.flatMap(r=>Object.values(r.feet).map(f=>f.minimum))),worst:rows.sort((a,b)=>a.allSkin.minimum.gap-b.allSkin.minimum.gap).slice(0,3).map(r=>({time:r.time,index:r.index,state:r.state,air:r.airborne,witness:r.allSkin.minimum}))}));
