import json
from pathlib import Path
q=Path(__file__).parent
out=q/'rabbit-fixed'
manifest=json.loads((q/'inputs/assets/models/home/manifest.json').read_text())
proposal=json.loads((out/'route-proposal.json').read_text())
manifest['terrain']['habitats']['rabbitEast']['path']=proposal['path']
(out/'view-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
proxy=(q/'proxy-rabbit-fixed.py').read_text()
proxy=proxy.replace('class Handler(BaseHTTPRequestHandler):','OWNED["/al-folio/assets/models/home/manifest.json"]=q/"rabbit-fixed/view-manifest.json"\nclass Handler(BaseHTTPRequestHandler):')
(q/'proxy-rabbit-fixed-view.py').write_text(proxy,encoding='utf-8')
capture=(q/'rabbit-fixed-cutaway.cjs').read_text()
capture=capture.replace("await preparePage(page,'light');", "page.setDefaultTimeout(60000);console.log('prepare');await preparePage(page,'light');")
capture=capture.replace("await page.goto('http", "console.log('goto');await page.goto('http")
capture=capture.replace("await page.locator('[data-home-desk-mode=\"3d\"]').click();", "console.log('activate');await page.locator('[data-home-desk-mode=\"3d\"]').click();")
capture=capture.replace("timeout:240000", "timeout:60000")
capture=capture.replace("  const rows=[];", "  console.log('overview');const rows=[];")
(q/'rabbit-fixed-cutaway-retry.cjs').write_text(capture,encoding='utf-8')
