import gzip
import hashlib
import json
from pathlib import Path
q=Path(__file__).parent
root=q.parents[2]
data=q/'rabbit-fixed'
out=root/'artwork/coastal-home/reviews/rabbit-fixed-ground-2026-10-31'
assert not out.exists()
native=json.loads((data/'native-candidate.json').read_text())
views=json.loads((data/'cutaway-rabbits.json').read_text())
assert len(native['rows'])==742 and len(views)==2
assert all(r['allSkin']['missing']==0 and r['allSkin']['minimum']['gap']>=-1e-10 for r in native['rows'])
assert all(not r['errors'] and r['fullSkin']['missing']==0 and r['fullSkin']['minimum']['gap']>=0.00059 for r in views)
assert all(s['actuallyVisible'] for r in views for s in r['supports'])
out.mkdir(parents=True)
def put(path,name,compress=True):
    b=Path(path).read_bytes();p=out/(name+('.gz'if compress else''));p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(b,compresslevel=9,mtime=0)if compress else b)
for name in ['route-proposal.json','TERRAIN_INPUTS.json','native-candidate.json','cutaway-rabbits.json','baseline-d309-manifest.json','view-manifest.json','native-proof.log','cutaway.log','cutaway-retry.log']:
    put(data/name,'data/'+name)
for name in ['home-shell.glb','coast.glb','manifest.json']:
    put(data/'inputs/assets/models/home'/name,'controls/d309-route-fixture/'+name)
for name in ['cutaway-rabbit-0.png','cutaway-rabbit-1.png']:
    put(data/name,'views/'+name,False)
for name in ['prepare-rabbit-fixed-review.py','prepare-rabbit-fixed-view-retry.py','rabbit-fixed-native-proof.mjs','rabbit-fixed-cutaway.cjs','rabbit-fixed-cutaway-retry.cjs','proxy-rabbit-fixed.py','proxy-rabbit-fixed-view.py','seal-fixed-route.py']:
    put(q/name,'producers/'+name)
binding={'rabbitSourceCommit':'31412345bc78b1e508311b55d4fc0ec4f997cf31','priorContactEvidenceCommit':'da646f8400083c6406d801707e20cfa92cb0c1ae','terrainPublicCommit':'d3099670c','canonicalNativeSha256':'de217984242f77903145dd6d16f277923b57fd5e3eb2469c906c2507b494ad87','scope':'Read-only decoded and actual overview cutaway qualification of the +4 m X rabbitEast route. Native full-skin proof uses exact d309 terrain/manifest plus new path. Corrected rendered counterfactual preserves the complete frozen503 runtime/manifest and substitutes only the new path, with sealed314 rabbit source; d309 home-shell/coast are byte-identical to that preview terrain. The first full-d309-manifest/old503-runtime mix failed readiness and is retained as rejected evidence. No root source/model/manifest/cache write or publication.','newSourceOrGeometryChanges':False,'futureGate':'Final F6 geometry requires independent route resurvey, full-skin and actual cutaway recheck; root owns sourcebuilder/manifest integration and official combined cache.'}
(out/'SOURCE_BINDINGS.json').write_text(json.dumps(binding,indent=2)+'\n',encoding='utf-8',newline='\n')
readme='''# Eastern rabbit on visible fixed ground

The proposed route translates the same 48-point loop 4 m east onto fixed golden
coastal sandstone. Its native survey on canonical `de217984` has 1,920 footprint
witnesses, no liftaway-roof support and at most 3.66 mm of linear interpolation
residual. This packet independently qualifies that proposal; it does not change
the source builder or public manifest.

The exact accepted `d3099670c` home-shell/coast exports are hash-verified. They are
byte-identical to the earlier frozen public503 terrain. With the sealed rabbit
contact source `31412345b`, 742 decoded poses at 371 times check every skin vertex
and every rigid toe across both rabbits and their scheduled graze/groom/idle and
jump phases. No sampled skin point lacks physical support; the worst skin/toe gap
is numerical roundoff (-5.33e-15 m). Eastern witnesses now hit the fixed sandstone.

In the actual browser overview cutaway, a disclosed close authoring camera shows
the eastern rabbit standing on visible ground rather than floating over the
hidden roof. Independent visible-ground queries check all 7,763 skin vertices and
1,092 rigid toe vertices: none lacks support, the skin minimum is 0.600 mm, and all
four toes are within numerical precision of 0.600 mm. The current actual support
owner `core_carved_mainland002` is visible through its full ancestor chain. The
western control is also supported. Both captures are nonblank and have zero
runtime errors.

The first attempted view mixed the newer full d309 manifest with the older503
runtime and failed scene readiness. Its log is retained and contributes no
acceptance evidence. The corrected causal view keeps the complete frozen503
runtime and manifest, replacing only the eastern path and the sealed314 rabbit
modules. The terrain bytes match d309 exactly. This separates the route/cutaway
question from unrelated newer lighting metadata. Its old cache is a control,
not a newly signed production acceptance cache.

Native paired measurements, the proposed points, exact terrain bindings, fixture
manifests, failed/successful logs, producers and original PNGs are retained.
`MANIFEST.json` hashes every other payload. `SOURCE_BINDINGS.json` identifies the
prior source/evidence and the accepted geometry. The preceding
[contact review](../rabbit-contact-2026-10-31/README.md) retains the full baseline
animal inputs and original roof failure.

The coordinator still owns the actual builder/manifest change, official cache,
public navigation checks and publication. When the F6 geometry is integrated,
its final route must be resurveyed and these full-skin/cutaway checks repeated.
Nothing here verifies an unexported F6 surface or completes all wildlife issues.
'''
(out/'README.md').write_text(readme,encoding='utf-8',newline='\n')
manifest={'schema':1,'scope':'Read-only current accepted-terrain rabbitEast route qualification; final F6 geometry remains a separate gate.','files':[]}
for path in sorted(out.rglob('*')):
    if path.is_file():
        b=path.read_bytes();manifest['files'].append({'path':path.relative_to(out).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'payloads':len(manifest['files']),'bytes':sum(r['bytes']for r in manifest['files'])}))
