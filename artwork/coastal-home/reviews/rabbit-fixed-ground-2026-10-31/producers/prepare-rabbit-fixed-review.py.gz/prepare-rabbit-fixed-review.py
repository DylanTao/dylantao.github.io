import hashlib
import json
import re
import shutil
from pathlib import Path
q=Path(__file__).parent
root=q.parents[2]
out=q/'rabbit-fixed'
models=out/'inputs/assets/models/home'
models.mkdir(parents=True,exist_ok=True)
f6=Path('C:/dev/site-takeover-worktrees/f6-native-20261029/.jekyll-cache/visual-qa/f6-native-20261029')
receipt=json.loads((f6/'accepted-d309-terrain/INPUTS.json').read_text())
for row in receipt['products']:
    source=Path(row['path']);data=source.read_bytes()
    assert hashlib.sha256(data).hexdigest()==row['sha256'] and len(data)==row['bytes']
    shutil.copy2(source,models/source.name)
for source in (q/'inputs/assets/models/home').iterdir():
    if not (models/source.name).exists():shutil.copy2(source,models/source.name)
shutil.copy2(models/'manifest.json',out/'baseline-d309-manifest.json')
proposal=json.loads((f6/'rabbit-east-fixed-ground-path-de217.json').read_text())
manifest=json.loads((models/'manifest.json').read_text())
assert proposal['sourceSha256']==receipt['canonicalNativeSha256']
manifest['terrain']['habitats']['rabbitEast']['path']=proposal['path']
(models/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
shutil.copy2(f6/'rabbit-east-fixed-ground-path-de217.json',out/'route-proposal.json')
shutil.copy2(f6/'accepted-d309-terrain/INPUTS.json',out/'TERRAIN_INPUTS.json')
source=(q/'sealed-rabbit/assets/js/home-scene/wildlife.mjs').read_text()
source=re.sub(r'from\s*([\"\'])(\.[^\"\']+)\1',lambda m:'from '+m[1]+(root/'assets/js/home-scene'/m[2]).resolve().as_uri()+m[1],source)
(out/'frozen-rabbit-runtime.mjs').write_text(source,encoding='utf-8')
source=(q/'native-proof.mjs').read_text()
source=re.sub(r'const \{createWildlife\}=await import\([^\n]+\);','const {createWildlife}=await import(new URL("./rabbit-fixed/frozen-rabbit-runtime.mjs",import.meta.url));',source)
source=source.replace('animal-readonly-20261031/inputs/assets/models/home/','animal-readonly-20261031/rabbit-fixed/inputs/assets/models/home/')
source=source.replace('`./native-${label}.json`','`./rabbit-fixed/native-${label}.json`')
(q/'rabbit-fixed-native-proof.mjs').write_text(source,encoding='utf-8')
proxy=(q/'proxy.py').read_text()
start=proxy.index('OWNED=');end=proxy.index('\nclass Handler',start)
definition='OWNED={f"/al-folio/assets/js/home-scene/{name}":q/"sealed-rabbit/assets/js/home-scene"/name for name in ["wildlife.mjs","wildlife-rabbit-contact.mjs"]}\nOWNED.update({f"/al-folio/assets/models/home/{name}":q/"rabbit-fixed/inputs/assets/models/home"/name for name in ["home-shell.glb","coast.glb","manifest.json"]})'
proxy=proxy[:start]+definition+proxy[end:]
proxy=proxy.replace("4162","4164").replace("headers={'Content-Type':'text/javascript; charset=utf-8'}","headers={'Content-Type': 'application/json' if name.endswith('.json') else 'model/gltf-binary' if name.endswith('.glb') else 'text/javascript; charset=utf-8'}")
(q/'proxy-rabbit-fixed.py').write_text(proxy,encoding='utf-8')
capture=(q/'cutaway-probe-corrected.cjs').read_text().replace('4162','4164').replace('const q=__dirname;','const q=__dirname,out=path.join(q,"rabbit-fixed");')
capture=capture.replace('path.join(q,row.file)','path.join(out,row.file)').replace("path.join(q,'cutaway-rabbits.json')","path.join(out,'cutaway-rabbits.json')")
capture=capture.replace("const feet=Object.fromEntries", "let minimumSkin=null,missingSkin=0,totalSkin=0;const feet=Object.fromEntries")
capture=capture.replace('for(let i=0;i<s.count;i++)for(const name of Object.keys(feet)){','for(let i=0;i<s.count;i++){const p=mesh.getVertexPosition(i,new T.Vector3()).applyMatrix4(mesh.matrixWorld),hit=patch.sample(p.x,p.z,p.y+.5);totalSkin++;if(!hit)missingSkin++;else if(!minimumSkin||p.y-hit.height<minimumSkin.gap)minimumSkin={gap:p.y-hit.height,vertex:i,mesh:mesh.name,point:p.toArray(),support:hit.mesh,triangle:hit.triangle};for(const name of Object.keys(feet)){')
capture=capture.replace('     }\n    });','     }}\n    });')
capture=capture.replace('return{index,evidence:ev,feet,supports,visiblePatch:', 'return{index,evidence:ev,feet,supports,fullSkin:{total:totalSkin,missing:missingSkin,minimum:minimumSkin},visiblePatch:')
(q/'rabbit-fixed-cutaway.cjs').write_text(capture,encoding='utf-8')
print(json.dumps({'source':proposal['sourceSha256'],'routePoints':len(proposal['path']),'terrainByteExact':True,'previewPort':4164}))
