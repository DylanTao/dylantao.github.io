import bpy,json,gzip,sys,math,hashlib
from pathlib import Path
from mathutils import Vector
q=Path(__file__).resolve().parent
prefix=(q/'make-native-control-v3.py').read_text(encoding='utf8').split('# This control changes')[0];ns={'__file__':str(q/'qualify-native-joins.py')};exec(compile(prefix,'original-twig-selection','exec'),ns)
old=ns['old'];layout=ns['layout'];source=q/'candidate-v4.blend';bpy.ops.wm.open_mainfile(filepath=str(source));scene=bpy.context.scene;wood=scene.objects['kitchen__honey ash'];leaf=scene.objects['kitchen__olive leaf']
def runtime(point,obj=wood):
 p=obj.matrix_world@point;return[p.x,p.z,-p.y]
rows=[]
for k,(_,_,ids)in enumerate(old):
 definition=layout['leaves'][k];axis=(definition['root']-definition['base']).normalized();points=[wood.data.vertices[i].co for i in ids];project=[(p-definition['base']).dot(axis)for p in points];middle=(max(project)+min(project))*.5
 base=sum((p for p,t in zip(points,project)if t<middle),Vector())/3;end=sum((p for p,t in zip(points,project)if t>=middle),Vector())/3;root=leaf.data.vertices[k*11].co
 error=max((base-definition['base']).length,(end-definition['root']).length,(root-definition['root']).length);assert error<1e-6
 rows.append({'leaf':k,'kind':'apex'if definition['branch']is None else'spray','branch':definition['branch'],'base':runtime(base),'root':runtime(root,leaf),'tip':runtime(definition['tip'],leaf),'petioleEnd':runtime(end),'nativeJoinErrorM':error})
branches=[];obj=scene.objects['kitchen_nook_olive__honey ash'];groups=ns['islands'](obj.data);assert len(groups)==6
for i,(base,end)in enumerate(layout['branches']):
 centre=(base+end)*.5;ids=min(groups,key=lambda ids:(sum((obj.data.vertices[j].co for j in ids),Vector())/len(ids)-centre).length);points=[obj.data.vertices[j].co for j in ids];axis=(end-base).normalized();projection=[(p-base).dot(axis)for p in points];middle=(min(projection)+max(projection))*.5;actualbase=sum((p for p,t in zip(points,projection)if t<middle),Vector())/6;actualend=sum((p for p,t in zip(points,projection)if t>=middle),Vector())/6;error=max((actualbase-base).length,(actualend-end).length);assert error<1e-6;trunk=layout['crown']-layout['foot'];radial=(base-layout['foot']).cross(trunk).length/trunk.length;assert radial<1e-6
 branches.append({'branch':i,'base':runtime(actualbase,obj),'end':runtime(actualend,obj),'endpointErrorM':error,'baseToRetainedTrunkAxisM':radial,'minimumTrunkEmbeddingMarginM':.016-.005-radial})
report={'scope':'Read-only native candidate joins: exact measured ring centres and leaf roots; all branch bases embed within the retained trunk, all petals supported, no native write. Final export checks separate.','candidateSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'leaves':rows,'branches':branches}
(q/'NATIVE-LEAF-JOINS.json.gz').write_bytes(gzip.compress(json.dumps(report).encode('utf8'),mtime=0));print({'leafJoinMaxM':max(r['nativeJoinErrorM']for r in rows),'branchEndpointMaxM':max(b['endpointErrorM']for b in branches),'minTrunkEmbeddingM':min(b['minimumTrunkEmbeddingMarginM']for b in branches)})
