import bpy,json,hashlib
from pathlib import Path
p=Path("C:/dev/dylantao.github.io/artwork/coastal-home/coastal-home.blend")
assert bpy.app.version==(4,5,9)
assert hashlib.sha256(p.read_bytes()).hexdigest()=="de217984242f77903145dd6d16f277923b57fd5e3eb2469c906c2507b494ad87"
bpy.ops.wm.open_mainfile(filepath=str(p))
rows=[]
for o in bpy.context.scene.objects:
 if o.type=="MESH" and o.name.startswith("kitchen_") and any(m and m.name in ["olive leaf","honey ash"] for m in o.data.materials):
  rows.append({"name":o.name,"materials":[m.name for m in o.data.materials],"vertices":len(o.data.vertices),"polygons":len(o.data.polygons),"quads":sum(len(f.vertices)==4 for f in o.data.polygons),"bounds":[[min(v.co[a] for v in o.data.vertices) for a in range(3)],[max(v.co[a] for v in o.data.vertices) for a in range(3)]],"matrix":[list(row) for row in o.matrix_world],"props":dict(o.items())})
Path("C:/dev/site-takeover-worktrees/nook-plant-20261101/.jekyll-cache/visual-qa/nook-plant-20261101/native-inspection.json").write_text(json.dumps(rows,indent=2)+"\n",encoding="utf8")
print(json.dumps(rows))
