from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import os,socket
root=Path(__file__).resolve().parent/'candidate-site'
owner='nook-plant-20261101-4206-'+str(os.getpid())
class Handler(SimpleHTTPRequestHandler):
 protocol_version='HTTP/1.1'
 def log_message(self,*args):pass
 def end_headers(self):self.send_header('X-Sirui-Preview',owner);self.send_header('Cache-Control','no-store');super().end_headers()
class Server(ThreadingHTTPServer):
 allow_reuse_address=False
 request_queue_size=128
 daemon_threads=True
 def server_bind(self):
  if hasattr(socket,'SO_EXCLUSIVEADDRUSE'):self.socket.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
  super().server_bind()
server=Server(('127.0.0.1',4206),partial(Handler,directory=str(root)))
print(owner,root.resolve(),flush=True)
server.serve_forever()
