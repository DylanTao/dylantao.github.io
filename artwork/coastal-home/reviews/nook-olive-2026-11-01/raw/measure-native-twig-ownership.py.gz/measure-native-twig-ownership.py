import bpy,json,gzip,hashlib
from pathlib import Path
q=Path(__file__).resolve().parent
prefix=(q/'make-native-control-v3.py').read_text(encoding='utf8').split('# This control changes')[0]
# Selection prefix only reads the retained source; no builder or mutation executes.
ns={'__file__':str(q/'measure-native-twig-ownership.py')};exec(compile(prefix,'retained-petiole-selection','exec'),ns)
ids=sorted(ns['selected']['kitchen__honey ash']);assert len(ids)==240
rows={}
for label,file in [('original',Path('C:/dev/dylantao.github.io/artwork/coastal-home/coastal-home.blend')),('candidate',q/'candidate-v4.blend')]:
 bpy.ops.wm.open_mainfile(filepath=str(file));obj=bpy.context.scene.objects['kitchen__honey ash'];points=[]
 for index in ids:
  p=obj.matrix_world@obj.data.vertices[index].co;points.append([p.x,p.z,-p.y])
 rows[label]={'sourceSha256':hashlib.sha256(file.read_bytes()).hexdigest(),'vertices':ids,'runtimePositions':points}
(q/'NATIVE-TWIG-OWNERSHIP.json.gz').write_bytes(gzip.compress(json.dumps(rows).encode('utf8'),mtime=0));print('Measured240 owned petiole points in original and candidate; no native file writes.')
