from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,shutil,subprocess,time
root=Path.cwd();q=Path(__file__).parent;out=q/'chair-producer-root-v1';assert not out.exists();out.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
packet=root/'artwork/coastal-home/reviews/pavilion-seating-geometry-2026-11-03'
original=json.loads(gzip.decompress((packet/'results/CHAIR-PRODUCER-ACTUAL-V45-PROCESS.json.gz').read_bytes()))
argv=original['command'];reference=Path(argv[argv.index('--reference')+1]);expected=argv[argv.index('--reference-sha')+1];assert sha(reference)==expected
reference_copy=out/'reference/home-shell.glb';reference_copy.parent.mkdir();shutil.copyfile(reference,reference_copy);assert sha(reference_copy)==expected
roster=out/'reference/CHAIR-TYPED-CENSUS-V1.json';roster.write_bytes(gzip.decompress((packet/'inputs/CHAIR-TYPED-CENSUS-V1.json.gz').read_bytes()));assert sha(roster)==argv[argv.index('--roster-sha')+1]
module=root/'assets/js/home-scene/coffee-chair.mjs';command=['node','bin/produce_coastal_coffee_chair.mjs','--reference',str(reference_copy),'--reference-sha',expected,'--candidate',str(reference_copy),'--candidate-sha',expected,'--roster',str(roster),'--roster-sha',sha(roster),'--module',str(module),'--module-sha',sha(module),'--out',str(out/'candidate')]
start=time.monotonic()
with(out/'producer.log').open('wb')as log:r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=120)
record={'at':datetime.now(timezone.utc).isoformat(),'command':command,'exitCode':r.returncode,'seconds':time.monotonic()-start,'referenceSha256':sha(reference_copy),'rosterSha256':sha(roster),'moduleSha256':sha(module),'scope':'Independent coordinator replay of maintained guarded producer on the actual complete312 reference, using the sealed approved14part roster. Preserved the exact reference GLB outside the worker worktree before cleanup. Same reference as candidate is a tooling control, not final-source geometry/coffee/Walk/GI admission.'}
(out/'PROCESS.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');print(json.dumps(record));assert r.returncode==0
