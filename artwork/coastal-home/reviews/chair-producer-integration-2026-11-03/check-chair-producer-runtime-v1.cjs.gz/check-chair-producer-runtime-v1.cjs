const fs = require('node:fs'),path = require('node:path'),crypto = require('node:crypto');
const {coastalLightInputs} = require(path.join(process.cwd(),'bin/coastal_static_light_inputs.cjs'));
(async()=>{
 const result = await coastalLightInputs(process.cwd());
 const cacheFile = 'assets/models/home/static-light-field.json';
 const cache = JSON.parse(fs.readFileSync(cacheFile));
 if(result.signature !== cache.signature) throw Error('Signature changed');
 const out = path.join(__dirname,'chair-producer-checkpoint-v1');
 const modules = directory => JSON.parse(fs.readFileSync(path.join(directory,'site/al-folio/assets/js/module-build.json'))).modules;
 const actual = modules(out), previous = modules(path.join(__dirname,'runtime-navigation-checkpoint-v2'));
 const rows = Object.keys(actual).map(file=>({file,outputExact:actual[file].outputSha256===previous[file].outputSha256,sourceExact:actual[file].sourceSha256===previous[file].sourceSha256}));
 if(rows.length!==192||!rows.every(row=>row.outputExact)) throw Error('Runtime output changed');
 const {PurgeCSS}=require('purgecss'),configuration=require(path.join(process.cwd(),'purgecss.config.js'));
 const built=path.join(out,'site/al-folio');
 const cleaned=await new PurgeCSS().purge({...configuration,content:['**/*.html','**/*.js','**/*.mjs'].map(glob=>path.join(built,glob).replaceAll('\\','/')),css:[path.join(built,'assets/css/*.css').replaceAll('\\','/')],skippedContentGlobs:[path.join(built,'assets/**/*.html').replaceAll('\\','/')]});
 const styles=[];
 for(const result of cleaned){const name=path.basename(result.file),body=Buffer.from(result.css),baseline=fs.readFileSync(path.join(__dirname,'runtime-navigation-checkpoint-v2/corrected',name));if(!body.equals(baseline))throw Error('Publisher CSS changed '+name);styles.push({file:name,bytes:body.length,sha256:crypto.createHash('sha256').update(body).digest('hex'),exact:true});fs.writeFileSync(result.file,body);}
 const receipt = {
  at:new Date().toISOString(),
  scope:'Guarded producer tooling/tests plus a historical-reference comment in an unwired module. All192compiled module bodies remain exact to published db85127b4. Static-light signature/cache bytes unchanged: no signature input changed, so no owning bake required. No venue/native/contact admission.',
  signature:result.signature,cacheBytes:fs.statSync(cacheFile).size,
  cacheSha256:crypto.createHash('sha256').update(fs.readFileSync(cacheFile)).digest('hex'),
  compiledModules:rows.length,changedSourceBindings:rows.filter(row=>!row.sourceExact),rows,publisherStyles:styles
 };
 fs.writeFileSync(path.join(out,'RUNTIME-AND-CACHE-EXACT.json'),JSON.stringify(receipt,null,2)+'\n');
 console.log(JSON.stringify({signature:result.signature,compiledModuleBodiesExact:rows.length,changedSourceBindings:receipt.changedSourceBindings}));
})().catch(error=>{console.error(error);process.exitCode=1;});
