import json
import os
import socket
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

q = Path(__file__).resolve().parent
marker = 'rain-broadphase-20261102-' + str(os.getpid())

class Handler(SimpleHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def log_message(self, *args):
        pass
    def end_headers(self):
        self.send_header('X-Sirui-Preview', marker)
        super().end_headers()

class Server(ThreadingHTTPServer):
    allow_reuse_address = False
    request_queue_size = 128
    daemon_threads = True

server = Server(('127.0.0.1', 0), partial(Handler, directory=str(q / 'site')), bind_and_activate=False)
if hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
    server.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
server.server_bind()
server.server_activate()
port = server.server_address[1]
(q / 'server.json').write_text(json.dumps({'pid': os.getpid(), 'port': port, 'header': marker, 'url': f'http://127.0.0.1:{port}/al-folio/', 'directory': str(q / 'site')}), encoding='utf8')
print(marker, port, flush=True)
server.serve_forever()
