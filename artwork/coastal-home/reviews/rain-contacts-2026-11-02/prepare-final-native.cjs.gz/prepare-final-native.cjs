const fs=require('node:fs'),path=require('node:path');
const q=__dirname;
let source=fs.readFileSync(path.join(q,'../rain-production-20261102/measure-native.cjs'),'utf8');
const once=(a,b)=>{if(source.split(a).length!==2)throw Error('Changed final native anchor');source=source.replace(a,b);};
once("const runs=[['baseline',2560,1440],['candidate',2560,1440],['candidate',3840,2160],['baseline',3840,2160]];","const runs=[['candidate',2560,1440],['candidate',3840,2160]];");
once('  const backend=await scene.evaluate',`  if(width===2560){
    const cdp=await page.context().newCDPSession(page);
    await cdp.send('Profiler.enable');await cdp.send('Profiler.start');
    await page.waitForTimeout(4000);
    const {profile}=await cdp.send('Profiler.stop');
    fs.writeFileSync(path.join(q,'final-native-2k.cpuprofile.json.gz'),require('node:zlib').gzipSync(JSON.stringify(profile)));
    await cdp.detach();
  }
  const backend=await scene.evaluate`);
once('Matched full-product native RTX3080Ti ABBA-sized comparison;','Final broad-phase source, quiet follow-up native RTX3080Ti measurements. Earlier ABBA comparison retained separately. CPU sampling follows the2K timing readback and is excluded from it;');
fs.writeFileSync(path.join(q,'measure-final-native.cjs'),source);
