"""Select and seal existing rain evidence. Does not run or synthesize captures."""
import gzip
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd()
Q = ROOT / ".jekyll-cache/visual-qa/rain-broadphase-20261102"
P = Q.parent / "rain-production-20261102"
EARLY = Q.parent / "rain-contact-20261101"
DEST = ROOT / "artwork/coastal-home/reviews/rain-contacts-2026-11-02"
BASE = "6f3be81b8e6a84a40e2cb9ba345f6c600835aff3"
SITE = Q / "site/al-folio"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(name, value):
    (DEST / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf8", newline="\n")


selected = []


def retain(source, name=None, compress=False):
    name = name or source.name
    raw = source.read_bytes()
    destination = name + (".gz" if compress else "")
    (DEST / destination).write_bytes(gzip.compress(raw, mtime=0) if compress else raw)
    selected.append({"path": destination, "originalAuthoringPath": source.relative_to(ROOT).as_posix(),
                     "uncompressedBytes": len(raw), "uncompressedSha256": digest(raw)})


for name in ["actual-contact-comparison.json.gz", "actual-contact-receipt.json", "observer-bindings.json",
             "cache-preservation.json", "final-native-2k.cpuprofile.json.gz", "profile-summary.json",
             "rain-normal-on-2k.png", "rain-normal-repeat-2k.png", "rain-normal-off-2k.png",
             "native-candidate-3840.png"]:
    retain(Q / name)

for name in ["capture-observer.cjs", "prepare-observer.cjs", "coastal-rain-observed.mjs",
             "environment-observed.mjs", "rain-contact-reference-v1.mjs", "prepare-final-native.cjs",
             "measure-final-native.cjs", "modern-webkit.config.cjs", "run-webkit.sh", "serve.py",
             "native-cost.json", "native-cost.log", "native-contact.log", "modern-webkit-contact.log",
             "node-all.log", "cache.log", "observer.log", "build.log", "server.json"]:
    retain(Q / name, compress=True)

for name in ["measure-native.cjs", "native-cost.json", "native-cost.log", "python-all.log",
             "scene-registry.log", "style-contract.log", "before-broadphase-source.json"]:
    retain(P / name, "preceding-" + name, compress=True)

for name in ["build.log", "build-qualified.log", "native-contact.log", "node-all.log"]:
    retain(P / name, "rejected-" + name, compress=True)

early = sorted(EARLY.glob("*"))
early_selected = [p for p in early if p.is_file() and p.name in {
    "rain-ripples-v1-rejected.mjs", "production-rain-first.log", "rain-first.log"}]
for source in early_selected:
    retain(source, "early-" + source.name, compress=True)
retain(SITE / "assets/js/module-build.json", "module-build.json", compress=True)
retain(Path(__file__), compress=True)

source_paths = [
    "assets/js/home-scene/rain-trajectories.mjs", "assets/js/home-scene/rain-contact.mjs",
    "assets/js/home-scene/rain-water-sampler.mjs", "assets/js/home-scene/rain-surface-spectrum.mjs",
    "assets/js/home-scene/rain-surface.mjs", "assets/js/home-scene/coastal-rain.mjs",
    "assets/js/home-scene/environment.mjs", "assets/js/home-scene/controller.mjs",
    "assets/js/home-scene/infinity-pool.mjs", "assets/js/home-scene/PHYSICS.md", "assets/js/home.js",
    "assets/models/home/manifest.json", "assets/models/home/static-light-field.json",
    "test/coastal-rain.test.mjs", "test/rain-contact.test.mjs", "test/rain-surface.test.mjs",
    "test/infinity-pool.test.mjs", "test/visual/coastal-finish.spec.js", "test/visual/scene-groups.json",
    "test/visual/helpers.js", "test/visual/public.config.js", "bin/bake_coastal_static_light.cjs",
    "_plugins/site_module_assets.rb", "Gemfile.lock",
    "artwork/coastal-home/research/notes/rain-ocean-impact.md", "docs/october-2026-handoff.md",
]
snapshot = []
for relative in source_paths:
    raw = (ROOT / relative).read_bytes()
    data = raw.replace(b"\r\n", b"\n")
    snapshot.append({"path": relative, "normalization": "UTF-8/LF", "bytes": len(data),
                     "sha256": digest(data), "checkoutSha256": digest(raw), "source": data.decode("utf8")})
(DEST / "source-snapshot.json.gz").write_bytes(gzip.compress(
    json.dumps(snapshot, ensure_ascii=False).encode("utf8"), mtime=0))

native = ROOT / "artwork/coastal-home/coastal-home.blend"
native_hash = digest(native.read_bytes())
assert native_hash == "de217984242f77903145dd6d16f277923b57fd5e3eb2469c906c2507b494ad87"
models = subprocess.check_output(["git", "ls-files", "assets/models/home/*.glb"], cwd=ROOT, text=True).splitlines()
model_bindings = []
for relative in models:
    current = (ROOT / relative).read_bytes()
    old = subprocess.check_output(["git", "show", f"{BASE}:{relative}"], cwd=ROOT)
    assert current == old, relative
    model_bindings.append({"path": relative, "bytes": len(current), "sha256": digest(current), "exactVsParent": True})

build_bindings = []
module_receipt = json.loads((SITE / "assets/js/module-build.json").read_text(encoding="utf8"))
for relative in [s for s in source_paths if s.startswith("assets/js/") and s.endswith(".mjs")] + [
    "assets/js/home.js", "assets/models/home/manifest.json", "assets/models/home/static-light-field.json"]:
    data = (SITE / relative).read_bytes()
    exact = data.replace(b"\r\n", b"\n") == (ROOT / relative).read_bytes().replace(b"\r\n", b"\n")
    compiled = None
    if relative.endswith(".mjs"):
        compiled = module_receipt["modules"][relative]
        assert compiled["sourceSha256"] == digest((ROOT / relative).read_bytes().replace(b"\r\n", b"\n")), relative
        assert compiled["outputSha256"] == digest(data), relative
        assert compiled["bytes"] == len(data), relative
    if relative.startswith("assets/models/"):
        assert exact, relative
    build_bindings.append({"path": relative, "bytes": len(data), "sha256": digest(data), "sourceLFExact": exact, "compiledBinding": compiled})

write_json("PROOF.json", {
    "schemaVersion": 1,
    "recordedAt": datetime.now(timezone.utc).isoformat(),
    "sourceParent": BASE,
    "status": "Verified local checkpoint. CI and deployed delivery require separate receipts.",
    "scope": "Rain trajectories, first contact, bounded ocean normal response, filtered shower forcing and conservative query bounds. No native geometry/GLB changes.",
    "canonicalNative": {"path": native.relative_to(ROOT).as_posix(), "sha256": native_hash},
    "unchangedModels": model_bindings,
    "productionBuild": {
        "command": "bundle exec jekyll build --baseurl /al-folio --destination <owning site/al-folio>",
        "directory": SITE.relative_to(ROOT).as_posix(),
        "runtimeBindings": build_bindings,
        "modulePipeline": module_receipt["pipeline"],
        "imageGeneration": "Existing ImageMagick wrapper selected through scoped PATH; unchanged responsive image outputs seeded from the immediately preceding complete build, with all source/assets included.",
    },
    "cache": json.loads((Q / "cache-preservation.json").read_text(encoding="utf8")),
    "contacts": json.loads((Q / "actual-contact-receipt.json").read_text(encoding="utf8")),
    "checks": {
        "node": {"total": 988, "passed": 981, "intentionalSkipped": 7},
        "pythonBeforeSeal": {"passed": 378},
        "chromiumContactCases": {"passed": 4, "seconds": 52.8, "viewports": ["1440x1000", "390x1000"]},
        "modernWebkitContactCases": {"passed": 2, "minutes": 2.6, "viewport": "390x1000",
            "image": "mcr.microsoft.com/playwright:v1.58.2-noble",
            "imageSha256": "6446946a1d9fd62d9ae501312a2d76a43ee688542b21622056a372959b65d63d",
            "limit": "Linux software functional evidence, not physical-iPhone/native cost."},
        "sceneRegistry": {"cases": 149, "widths": [1440, 1280, 768, 390], "missing": 0, "extra": 0, "duplicate": 0},
    },
    "performance": {
        "backend": "Native ANGLE D3D11, NVIDIA GeForce RTX 3080 Ti; actual renderer/buffer/clocks in retained raw results.",
        "quality": "Complete world, high fixed resolution, MSAA4, real RAF/Date/performance, authoring time13:20 and declared coastal lab eye.",
        "order": "Preceding baseline2K/candidate2K/candidate4K/baseline4K; final source2K then4K. Both quiet worker holds. No randomized/repeated speedup claim.",
        "finalMedianFrameMs": [50, 50], "finalP95FrameMs": [50.1, 66.7],
        "finalGpuMedianMs": [25.428992, 42.257408],
        "limit": "Whole-scene performance remains open. Four-second CPU sampling follows the2K ROI; sampled wall time includes native waits.",
    },
    "retainedSelections": selected,
    "producerPortability": "Compressed producer bytes retain their original authoring paths and output names. Recreate the recorded local layout or adapt only those paths. Observers/reference add diagnostic workload; they do not establish timing.",
    "custodyLimit": "Selected primary evidence only. All original trials remain locally; this packet does not claim complete custody of every private trial. Packet seal/custody results are recorded after sealing outside its own immutable payload.",
})
print(json.dumps({"selected": len(selected), "modelsUnchanged": len(models), "buildBindings": len(build_bindings)}))
