const { chromium, expect } = require('@playwright/test');
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {preparePage,collectRuntimeErrors}=require('../../../test/visual/helpers.js');
const q=__dirname,candidate=JSON.parse(fs.readFileSync(path.join(q,'server.json'),'utf8'));
const runs=[['candidate',2560,1440],['candidate',3840,2160]];
const rows=[];
const hash=body=>crypto.createHash('sha256').update(body).digest('hex');
(async()=>{for(const[label,width,height]of runs){
 const base=label==='candidate'?candidate.url:'http://127.0.0.1:4207/al-folio/';
 const browser=await chromium.launch({args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
 try{
  const page=await browser.newPage({viewport:{width,height},deviceScaleFactor:1});page.setDefaultTimeout(150000);
  const errors=collectRuntimeErrors(page),bindings=[];
  await preparePage(page,'noon');await page.emulateMedia({reducedMotion:'reduce'});
  for(const relative of ['assets/js/home.js','assets/js/home-scene/controller.mjs','assets/js/home-scene/environment.mjs','assets/models/home/manifest.json','assets/models/home/home-shell.glb']){
   const response=await page.request.get(new URL(relative,base).href);expect(response.status()).toBe(200);const body=await response.body();
   bindings.push({relative,status:response.status(),owner:response.headers()['x-sirui-preview'],bytes:body.length,sha256:hash(body)});
  }
  await page.goto(base+'?scene-lab=1&quality=high&resolution=fixed&weather=rain&perf=1',{waitUntil:'domcontentloaded'});
  await page.locator('[data-home-desk-mode="3d"]').click();const scene=page.locator('[data-home-desk-scene]');await scene.scrollIntoViewIfNeeded();
  await expect(scene).toHaveAttribute('data-scene-state','ready',{timeout:150000});
  await page.waitForFunction(()=>document.querySelector('[data-home-desk-scene]')?.getSceneEvidence()?.ecology?.wildlife?.modelsReady===true,null,{timeout:120000});
  const ui=page.locator('[data-home-world-controls]');
  await ui.locator('[data-world-time]').evaluate(e=>{e.value='800';e.dispatchEvent(new Event('input',{bubbles:true}));});
  await ui.locator('[data-world-view]').click();await ui.locator('[data-world-fullscreen]').click();
  await scene.evaluate(e=>e.setLabCamera({target:[0,-7.35,-32],yaw:3.2,pitch:.17,radius:24,free:true}));
  await page.waitForTimeout(500);
  const start=await scene.evaluate(e=>e.getSceneEvidence());
  expect(start.simulation.lightField.cacheHit).toBe(true);
  await page.emulateMedia({reducedMotion:'no-preference'});
  await page.waitForTimeout(12000);
  const evidence=await scene.evaluate(e=>e.getSceneEvidence());
  if(width===2560){
    const cdp=await page.context().newCDPSession(page);
    await cdp.send('Profiler.enable');await cdp.send('Profiler.start');
    await page.waitForTimeout(4000);
    const {profile}=await cdp.send('Profiler.stop');
    fs.writeFileSync(path.join(q,'final-native-2k.cpuprofile.json.gz'),require('node:zlib').gzipSync(JSON.stringify(profile)));
    await cdp.detach();
  }
  const backend=await scene.evaluate(e=>{const c=e.querySelector('canvas'),gl=c.getContext('webgl2'),ext=gl.getExtension('WEBGL_debug_renderer_info');return{renderer:gl.getParameter(ext?.UNMASKED_RENDERER_WEBGL||gl.RENDERER),drawingBuffer:[gl.drawingBufferWidth,gl.drawingBufferHeight],attributes:gl.getContextAttributes(),clocks:{Date:Date.toString(),performance:performance.now.toString(),raf:requestAnimationFrame.toString(),pwClock:Boolean(globalThis.__pwClock)}}});
  fs.writeFileSync(path.join(q,`native-observed-${label}-${width}.json`),JSON.stringify({label,width,height,base,bindings,backend,errors,evidence},null,2));
  expect(backend.renderer).toMatch(/NVIDIA.*3080 Ti/);
  expect(backend.drawingBuffer).toEqual([width,height]);expect(evidence.frameTiming.samples).toBeGreaterThanOrEqual(120);expect(errors).toEqual([]);
  const details=ui.locator('[data-world-lab]');if(!await details.evaluate(e=>e.open))await details.locator(':scope > summary').click();
  await ui.locator('[data-world-pause]').click();await details.locator(':scope > summary').click();
  await scene.locator('canvas').screenshot({path:path.join(q,`native-${label}-${width}.png`)});
  const row={label,width,height,base,bindings,backend,errors,evidence};rows.push(row);
  fs.writeFileSync(path.join(q,'native-cost.json'),JSON.stringify({scope:'Final broad-phase source, quiet follow-up native RTX3080Ti measurements. Earlier ABBA comparison retained separately. CPU sampling follows the2K timing readback and is excluded from it; real RAF/performance/Date, public13:20 preview and declared lab eye.12seconds moving after complete load. Fixed high/factor1, exact buffer asserted. Page clock and graphics source untouched. Source delivery preflights are separate from renderer state. Single paired run per size; no startup speed or general benchmark claim.',at:new Date().toISOString(),rows},null,2));
  console.log(JSON.stringify({label,width,buffer:backend.drawingBuffer,timing:evidence.frameTiming,gpu:evidence.rendering.gpu,draws:evidence.drawCalls,rain:evidence.simulation.rain?.ocean&&{active:evidence.simulation.rain.ocean.active,overflow:evidence.simulation.rain.ocean.binOverflow},errors}));
 }finally{await browser.close()}
}})().catch(e=>{fs.writeFileSync(path.join(q,'native-cost-failure.txt'),String(e.stack||e));console.error(e);process.exitCode=1});
