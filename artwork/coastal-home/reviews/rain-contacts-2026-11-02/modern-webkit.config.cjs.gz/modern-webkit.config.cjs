const base = require('/repo/test/visual/public.config.js');
module.exports = {
  ...base,
  reporter: 'line',
  outputDir: '/qa/test-modern-webkit-contact',
  use: { ...base.use, browserName: 'webkit', launchOptions: {} },
  projects: [{ name: 'mobile-390', use: { browserName: 'webkit', isMobile: true, hasTouch: true, deviceScaleFactor: 1, viewport: { width: 390, height: 1000 } } }],
};
