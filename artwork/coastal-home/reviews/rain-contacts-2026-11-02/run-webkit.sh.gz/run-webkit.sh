#!/usr/bin/env bash
set -eu
python3 -m http.server 8423 --bind 127.0.0.1 --directory /site >/qa/webkit-server.log 2>&1 &
server_pid=$!
trap 'kill "$server_pid" 2>/dev/null || true' EXIT
export NO_WEBSERVER=1
export VISUAL_BASE_URL=http://127.0.0.1:8423/al-folio/
export VISUAL_TRANSPORT_SOFTWARE=1
node /repo/node_modules/playwright/cli.js test --config /qa/modern-webkit.config.cjs coastal-finish.spec.js --grep 'first-contact ripples|retained natural rain' --project mobile-390 --workers 1 --reporter line --output /qa/test-modern-webkit-contact
