const{chromium,expect}=require('@playwright/test');
const fs=require('node:fs'),path=require('node:path'),zlib=require('node:zlib');
const{PNG}=require('pngjs');
const{preparePage,collectRuntimeErrors}=require('../../../test/visual/helpers.js');
const q=__dirname,preview=JSON.parse(fs.readFileSync(path.join(q,'server.json')));
(async()=>{const browser=await chromium.launch({args:['--use-angle=d3d11','--ignore-gpu-blocklist']});try{
 const page=await browser.newPage({viewport:{width:2560,height:1440},deviceScaleFactor:1});page.setDefaultTimeout(150000);
 const errors=collectRuntimeErrors(page),failures=[];page.on('requestfailed',r=>failures.push({url:r.url(),error:r.failure()}));
 await preparePage(page,'noon');await page.emulateMedia({reducedMotion:'no-preference'});
 await page.route('**/home-scene/coastal-rain.mjs*',r=>r.fulfill({path:path.join(q,'coastal-rain-observed.mjs'),contentType:'text/javascript'}));
 await page.route('**/home-scene/rain-contact-reference-v1.mjs*',r=>r.fulfill({path:path.join(q,'rain-contact-reference-v1.mjs'),contentType:'text/javascript'}));
 await page.route('**/home-scene/environment.mjs*',r=>r.fulfill({path:path.join(q,'environment-observed.mjs'),contentType:'text/javascript'}));
 await page.goto(preview.url+'?scene-lab=1&quality=high&resolution=fixed&weather=rain',{waitUntil:'domcontentloaded'});
 await page.locator('[data-home-desk-mode="3d"]').click();const scene=page.locator('[data-home-desk-scene]');await scene.scrollIntoViewIfNeeded();
 await expect(scene).toHaveAttribute('data-scene-state','ready',{timeout:150000});
 const ui=page.locator('[data-home-world-controls]');await ui.locator('[data-world-time]').evaluate(e=>{e.value='800';e.dispatchEvent(new Event('input',{bubbles:true}));});
 await page.waitForTimeout(1500);await ui.locator('[data-world-view]').click();await ui.locator('[data-world-fullscreen]').click();
 const stages=[];
 for(const[label,camera]of [['sea',{target:[0,-7.35,-32],yaw:3.2,pitch:.17,radius:24,free:true}],['pool',{target:[0,-.09,-5],yaw:3.2,pitch:.5,radius:6,free:true}],['near-sea',{target:[0,-7.6,-40],yaw:3.2,pitch:.55,radius:4,free:true}]]){
  await scene.evaluate((e,c)=>e.setLabCamera(c),camera);await page.waitForTimeout(4000);
  stages.push({label,evidence:await scene.evaluate(e=>e.getSceneEvidence())});
 }
 const details=ui.locator('[data-world-lab]');if(!await details.evaluate(e=>e.open))await details.locator(':scope > summary').click();await ui.locator('[data-world-pause]').click();await details.locator(':scope > summary').click();await page.waitForTimeout(200);
 const comparison=await page.evaluate(()=>globalThis.__rainBoundsComparison);
 fs.writeFileSync(path.join(q,'actual-contact-comparison.json.gz'),zlib.gzipSync(JSON.stringify({scope:'Full actual scene, its real terrain/roof mask, ocean rendered-grid model, captured bed and pool mean waterline. Parallel frozen pre-broad-phase reference uses identical native times/trajectories. No timing claim.',comparison,stages,errors,failures})));
 expect(comparison.fast).toEqual(comparison.reference);expect(comparison.mismatches).toEqual([]);expect(comparison.fast.length).toBeGreaterThan(0);expect(comparison.actualCounts.queries).toBeLessThan(comparison.referenceCounts.queries);
 expect(stages.at(-1).evidence.simulation.lightField.cacheHit).toBe(true);
 const canvas=scene.locator('canvas');const on=await canvas.screenshot({path:path.join(q,'rain-normal-on-2k.png')}),repeat=await canvas.screenshot({path:path.join(q,'rain-normal-repeat-2k.png')});
 await page.evaluate(()=>{const u=globalThis.__rainResponseObserver.uniforms;u.rainPacketCount.value=0;u.rainBinSlots.value=0;u.rainCoarseVariance.value=0;u.rainForcingVariance.value=0;});
 await scene.evaluate(e=>{const s=e.getSceneEvidence();e.setLabCamera({target:s.target,...s.cameraOrbit,free:true})});await page.waitForTimeout(200);
 const off=await canvas.screenshot({path:path.join(q,'rain-normal-off-2k.png')});
 const a=PNG.sync.read(on).data,b=PNG.sync.read(off).data,c=PNG.sync.read(repeat).data;let changed=0,repeatChanged=0,max=0;
 for(let i=0;i<a.length;i++){if(a[i]!==b[i]){changed++;max=Math.max(max,Math.abs(a[i]-b[i]));}if(a[i]!==c[i])repeatChanged++;}
 const receipt={events:comparison.fast.length,owners:[...new Set(comparison.fast.map(e=>e.water))],identicalEvents:true,landedMismatches:comparison.mismatches.length,queries:{actual:comparison.actualCounts.queries,reference:comparison.referenceCounts.queries,aboveSurface:comparison.actualCounts.aboveSurface},changedChannels:changed,maximumChannelDifference:max,repeatChangedChannels:repeatChanged,errors,failures};
 fs.writeFileSync(path.join(q,'actual-contact-receipt.json'),JSON.stringify(receipt,null,2));expect(repeatChanged).toBe(0);expect(changed).toBeGreaterThan(10000);expect(errors).toEqual([]);expect(failures).toEqual([]);console.log(JSON.stringify(receipt));
}finally{await browser.close()}})().catch(e=>{fs.writeFileSync(path.join(q,'observer-failure.txt'),String(e.stack||e));console.error(e);process.exitCode=1});
