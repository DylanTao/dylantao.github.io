// Sparse normal detail for representative rain impacts. Gravity/capillary dispersion follows
// omega^2=g*k+sigma*k^3/rho (Waterloo AMATH463 surface-gravity notes). This is an authored wave-packet
// approximation, not a water-volume solver or a calibrated rainfall rate. The large sea shape stays
// with its existing spectrum; unresolved packet slopes become roughness rather than temporal sparkle.
export const RAIN_RIPPLES = Object.freeze({ maximum: 24, compactMaximum: 8, lifetime: 1.4, gravity: 9.80665, density: 1000, tension: 0.0728, referenceArea: 0.005, coupling: 0.08, maximumAmplitude: 0.00016 });
const hash = value => { const v = Math.sin(value * 127.1 + 31.7) * 43758.5453123; return v - Math.floor(v); };

export function rainPacket(event) {
  const { position, seconds, relativeSpeed, index = 0, diameter = 0.001 } = event;
  if (!position?.every(Number.isFinite) || !Number.isFinite(seconds) || seconds < 0 || !Number.isFinite(relativeSpeed) || relativeSpeed <= 0 || relativeSpeed > 30 || !Number.isFinite(diameter) || diameter < 0.0005 || diameter > 0.002) return null;
  const wavelength = 0.027 + 0.032 * hash(index), k = 2 * Math.PI / wavelength;
  const omega = Math.sqrt(RAIN_RIPPLES.gravity * k + RAIN_RIPPLES.tension * k ** 3 / RAIN_RIPPLES.density);
  const group = (RAIN_RIPPLES.gravity + 3 * RAIN_RIPPLES.tension * k * k / RAIN_RIPPLES.density) / (2 * omega);
  const mass = RAIN_RIPPLES.density * Math.PI * diameter ** 3 / 6, incomingEnergy = mass * relativeSpeed * relativeSpeed / 2;
  // A reference annulus sets the small visual amplitude. This is not a proof that an approximate
  // packet conserves its energy at every age or that overlapping packets have independent energy.
  const amplitude = Math.min(RAIN_RIPPLES.maximumAmplitude, Math.sqrt(incomingEnergy * RAIN_RIPPLES.coupling / ((RAIN_RIPPLES.density * RAIN_RIPPLES.gravity + RAIN_RIPPLES.tension * k * k) * RAIN_RIPPLES.referenceArea)));
  return { x: position[0], z: position[2], born: seconds, amplitude, k, omega, group, incomingEnergy, wavelength };
}

export function sampleRainPacket(packet, x, z, seconds, footprint = 0) {
  const age = seconds - packet.born;
  if (age <= 0 || age >= RAIN_RIPPLES.lifetime || !Number.isFinite(age)) return [0, 0, 0];
  const dx = x - packet.x, dz = z - packet.z, r = Math.hypot(dx, dz);
  const width = 0.014 + 0.02 * age, sigma2 = width * width + footprint * footprint;
  const q = r - packet.group * age, envelope = Math.exp(-0.5 * q * q / sigma2) * width / Math.sqrt(sigma2);
  const ramp = 1 - Math.exp(-age / 0.008), fade = Math.exp(-2.5 * age) * ramp * Math.max(0, 1 - age / RAIN_RIPPLES.lifetime);
  const filter = Math.exp(-0.5 * packet.k * packet.k * footprint * footprint), phase = packet.k * r - packet.omega * age;
  const center = 1 - Math.exp(-r * r / 0.000036), centerDerivative = 2 * r / 0.000036 * Math.exp(-r * r / 0.000036);
  const scale = packet.amplitude * fade;
  const radial = scale * filter * envelope * ((packet.k * Math.cos(phase) - q / sigma2 * Math.sin(phase)) * center + Math.sin(phase) * centerDerivative);
  const variance = 0.5 * scale * scale * packet.k * packet.k * envelope * Math.max(0, 1 - filter * filter);
  return [radial * dx / Math.max(r, 0.000001), radial * dz / Math.max(r, 0.000001), variance];
}

export function createRainRippleField({ compact = false } = {}) {
  const maximum = compact ? RAIN_RIPPLES.compactMaximum : RAIN_RIPPLES.maximum;
  const a = new Float32Array(RAIN_RIPPLES.maximum * 4), b = new Float32Array(a.length), packets = [];
  const uniforms = { rainRippleA: { value: a }, rainRippleB: { value: b }, rainRippleCount: { value: 0 } };
  let count = 0, total = 0, evicted = 0, seconds = 0, last = null;
  return {
    uniforms,
    impact(event) {
      const packet = rainPacket(event);
      if (!packet) return false;
      if (packets.length === maximum) { packets.shift(); evicted++; }
      packets.push(packet); total++; last = { ...packet }; return true;
    },
    update(time) {
      if (!Number.isFinite(time) || time < seconds) { packets.length = 0; count = uniforms.rainRippleCount.value = 0; seconds = Math.max(0, Number.isFinite(time) ? time : 0); return; }
      seconds = time;
      while (packets.length && seconds - packets[0].born >= RAIN_RIPPLES.lifetime) packets.shift();
      count = 0;
      for (const p of packets) {
        const age = seconds - p.born;
        if (age < 0) continue;
        a.set([p.x, p.z, age, p.amplitude], count * 4);
        b.set([p.k, p.omega, p.group, 0], count * 4); count++;
      }
      uniforms.rainRippleCount.value = count;
    },
    sample(x, z, at, footprint = 0) { const out = [0, 0, 0]; for (const p of packets) { const v = sampleRainPacket(p, x, z, at, footprint); for (let j = 0; j < 3; j++) out[j] += v[j]; } return out; },
    evidence: () => ({ method: 'bounded first-contact rain normal packets with gravity-capillary dispersion and unresolved slope variance', maximum, active: count, total, evicted, seconds, last, extraPasses: 0, vertexDisplacement: false, animalWakeSlotsUsed: 0 }),
  };
}

export const rainRipplesGLSL = `
uniform vec4 rainRippleA[24];
uniform vec4 rainRippleB[24];
uniform int rainRippleCount;
vec3 rainRipples(vec2 p, float footprint) {
  vec3 result=vec3(0.);
  for(int i=0;i<rainRippleCount;i++) {
    vec4 a=rainRippleA[i], b=rainRippleB[i];
    float age=a.z;
    if(age<=0.||age>=1.4) continue;
    vec2 rel=p-a.xy;
    float width=.014+.02*age, sigma2=width*width+footprint*footprint;
    float reach=b.z*age+4.*sqrt(sigma2);
    if(dot(rel,rel)>reach*reach) continue;
    float r=length(rel),q=r-b.z*age;
    float envelope=exp(-.5*q*q/sigma2)*width/sqrt(sigma2);
    float fade=exp(-2.5*age)*(1.-exp(-age/.008))*max(0.,1.-age/1.4);
    float filter=exp(-.5*b.x*b.x*footprint*footprint),phase=b.x*r-b.y*age;
    float c=exp(-r*r/.000036),center=1.-c,centerDerivative=2.*r/.000036*c;
    float scale=a.w*fade;
    float radial=scale*filter*envelope*((b.x*cos(phase)-q/sigma2*sin(phase))*center+sin(phase)*centerDerivative);
    result.xy+=radial*rel/max(r,.000001);
    result.z+=.5*scale*scale*b.x*b.x*envelope*max(0.,1.-filter*filter);
  }
  return result;
}`;
