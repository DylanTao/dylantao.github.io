const base=require("../../../test/visual/public.config.js");
const {sceneBrowserUse}=require("../../../bin/visual_scene_environment.cjs");
module.exports={...base,use:sceneBrowserUse(base.use)};
