const base=require("../../../test/visual/public.config.js");
const {devices}=require("@playwright/test");
module.exports={...base,projects:[{name:"phone-webkit",use:{...devices["iPhone 12"],browserName:"webkit",deviceScaleFactor:1,viewport:{width:390,height:1000}}}]};
