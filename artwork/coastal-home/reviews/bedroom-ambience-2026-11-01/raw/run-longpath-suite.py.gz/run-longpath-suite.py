import unittest,sys
from pathlib import Path
suite=unittest.defaultTestLoader.discover('test',pattern='test_*.py')
module=sys.modules['test_resting_review_custody']
original=module.REVIEWS
module.REVIEWS=Path(chr(92)*2+'?'+chr(92)+str(original.resolve()))
print('Invocation-only Windows long-path custody root:',module.REVIEWS,flush=True)
result=unittest.TextTestRunner(verbosity=1).run(suite)
print('Result:',result.testsRun,'failures',len(result.failures),'errors',len(result.errors),'skipped',len(result.skipped),flush=True)
raise SystemExit(0 if result.wasSuccessful() else 1)
