require 'jekyll'
require 'json'
require 'digest'
q=File.expand_path(__dir__); source_root=File.join(q,'private-source');site_root=File.join(q,'candidate-site','al-folio')
load File.join(source_root,'_plugins','site_module_assets.rb')
receipt_path=File.join(site_root,'assets/js/module-build.json');receipt=JSON.parse(File.read(receipt_path,encoding:'UTF-8'))
raise 'compiler key mismatch' unless receipt['pipeline']['compilerKey']==SiruiSite::ModuleAssets::COMPILER_KEY
records={}
['assets/js/home-scene/warm-practicals.mjs','assets/js/home-scene/controller.mjs'].each do |relative|
 source=File.read(File.join(source_root,relative),encoding:'UTF-8');content=SiruiSite::ModuleAssets.compile(source)
 File.binwrite(File.join(site_root,relative),content)
 records[relative]={'sourceSha256'=>Digest::SHA256.hexdigest(source.gsub("\r\n","\n")), 'outputSha256'=>Digest::SHA256.hexdigest(content),'bytes'=>content.bytesize}
 receipt['modules'][relative]=records[relative]
end
File.binwrite(receipt_path,JSON.generate(receipt)+"\n")
report={scope:'Complete1364-file201be0 seed, exact owning compiler for warm source and root201be0 controller plus only reserved binding call. No source camera or other root controller behavior replaced.',pipeline:receipt['pipeline'],records:records}
File.binwrite(File.join(q,'SHADE-COMPILED-OVERLAY.json'),JSON.pretty_generate(report)+"\n");puts JSON.pretty_generate(report)
