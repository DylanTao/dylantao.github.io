import bpy,json,hashlib,sys,array,copy
from pathlib import Path
q=Path(__file__).resolve().parent;root=q.parents[2];sys.path.insert(0,str(root/'bin'))
def stream(collection,field,width,typecode='f'):
 data=array.array(typecode,[0])*(len(collection)*width);collection.foreach_get(field,data);return data.tobytes()
def geometry(obj):
 m=obj.data;h=hashlib.sha256();h.update(repr(tuple(v for row in obj.matrix_world for v in row)).encode('ascii'))
 for c,f,w,t in [(m.vertices,'co',3,'f'),(m.vertices,'normal',3,'f'),(m.edges,'vertices',2,'i'),(m.loops,'vertex_index',1,'i'),(m.polygons,'loop_start',1,'i'),(m.polygons,'loop_total',1,'i'),(m.polygons,'use_smooth',1,'b'),(m.corner_normals,'vector',3,'f')]:h.update(stream(c,f,w,t))
 attributes=[]
 for attr in sorted(m.attributes,key=lambda a:a.name):
  if attr.name=='material_index':continue  # Compared exhaustively in faceMaterials, including exact owned polygon IDs.
  if attr.data_type in ['FLOAT_COLOR','BYTE_COLOR']:field,width,t='color',4,'f'
  elif attr.data_type=='FLOAT_VECTOR':field,width,t='vector',3,'f'
  elif attr.data_type=='FLOAT2':field,width,t='vector',2,'f'
  elif attr.data_type in ['INT16_2D','INT32_2D','INT32_4D']:field,width,t='value',4 if attr.data_type=='INT32_4D'else 2,'i'
  elif attr.data_type in ['FLOAT','INT','BOOLEAN','INT8']:
   field,width,t='value',1,'f'if attr.data_type=='FLOAT'else'i'
  else:raise RuntimeError('Unhandled native attribute '+attr.name+' '+attr.data_type)
  body=stream(attr.data,field,width,t);h.update(attr.name.encode('utf8'));h.update(body);attributes.append({'name':attr.name,'domain':attr.domain,'type':attr.data_type,'sha256':hashlib.sha256(body).hexdigest()})
 return {'sha256':h.hexdigest(),'vertices':len(m.vertices),'polygons':len(m.polygons),'loops':len(m.loops),'attributes':attributes}
def native_state():
 result={}
 for obj in sorted(bpy.context.scene.objects,key=lambda x:x.name):
  if obj.type!='MESH':continue
  result[obj.name]={'geometry':geometry(obj),'faceMaterials':list(stream(obj.data.polygons,'material_index',1,'i')),'slots':[s.material.name if s.material else None for s in obj.material_slots]}
 return result
def materials():
 result={}
 for m in bpy.data.materials:
  bsdf=next((n for n in m.node_tree.nodes if n.type=='BSDF_PRINCIPLED'),None)if m.use_nodes else None
  result[m.name]={'diffuseColor':list(m.diffuse_color),'roughness':m.roughness,'metallic':m.metallic,'bsdf':{k:list(bsdf.inputs[k].default_value)if hasattr(bsdf.inputs[k].default_value,'__len__')else bsdf.inputs[k].default_value for k in ['Base Color','Roughness','Metallic','Emission Color','Emission Strength']if bsdf and k in bsdf.inputs}}
 return result
source=Path(bpy.data.filepath);source_sha=hashlib.sha256(source.read_bytes()).hexdigest();before=native_state();before_materials=materials()
from coastal_architecture_finish import bedside_diffuser_material
config=json.loads((q/'practical-position-export/manifest.json').read_text(encoding='utf8'));old_config=copy.deepcopy(config);receipt=bedside_diffuser_material(bpy.context.scene,config);assert config==old_config
after=native_state();after_materials=materials();assert set(before)==set(after)
assert all(before[k]['geometry']==after[k]['geometry']for k in before)
changed=[k for k in before if before[k]!=after[k]];assert changed==['sleep__linen'],changed
assert all(before_materials[k]==after_materials[k]for k in before_materials)
assert set(after_materials)-set(before_materials)=={'sleep bedside linen diffuser'}
new_material=dict(after_materials['sleep bedside linen diffuser']);assert new_material==before_materials['linen'];assert new_material['bsdf']['Emission Strength']==0
obj=bpy.context.scene.objects['sleep__linen'];face_ids=set(receipt['nativePolygonIndices']);oldmat=array.array('i');oldmat.frombytes(bytes(before['sleep__linen']['faceMaterials']));newmat=array.array('i');newmat.frombytes(bytes(after['sleep__linen']['faceMaterials']));assert set(i for i,(a,b)in enumerate(zip(oldmat,newmat))if a!=b)==face_ids
assert before['sleep__linen']['slots']==['linen']and after['sleep__linen']['slots']==['linen','sleep bedside linen diffuser']
assert hashlib.sha256(source.read_bytes()).hexdigest()==source_sha
out=q/'shade-candidate.blend';bpy.context.preferences.filepaths.save_version=0;bpy.ops.wm.save_as_mainfile(filepath=str(out),compress=True)
report={'scope':'Exact isolated material-role split, no new geometry. All mesh coordinates, topology, normals, UV/color/other numeric attributes and matrices compare byte-exact in native memory; only globe polygon slots and new material role differ. Offline emission remains zero.','sourceSha256':source_sha,'sourceFileUnchanged':True,'candidateSha256':hashlib.sha256(out.read_bytes()).hexdigest(),'blender':bpy.app.version_string,'allNativeGeometryExact':True,'meshCount':len(before),'changedMeshAssignments':changed,'allOriginalMaterialsExact':True,'newMaterialCopiesOriginalLinen':True,'unchangedMetadata':True,'receipt':receipt,'before':before,'after':after,'materialsBefore':before_materials,'materialsAfter':after_materials}
import gzip
(q/'SHADE-NATIVE-PRESERVATION.json.gz').write_bytes(gzip.compress(json.dumps(report).encode('utf8')))
(q/'SHADE-NATIVE-SUMMARY.json').write_text(json.dumps({k:v for k,v in report.items()if k not in ['before','after','materialsBefore','materialsAfter']},indent=2)+'\n',encoding='utf8')
print(json.dumps({'allNativeGeometryExact':True,'meshCount':len(before),'nativeGlobeVertices':receipt['vertices'],'nativeGlobePolygons':receipt['nativePolygons'],'changedFaceAssignments':len(face_ids),'candidateSha256':report['candidateSha256']}))
