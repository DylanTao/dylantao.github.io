from pathlib import Path
import json,gzip,numpy as np,hashlib
q=Path(__file__).resolve().parent
families=[('shade-focus-',lambda r:not r['label'].startswith('maximum-')),('shade-peak-',lambda r:True)];controls=[];used=[]
for prefix,predicate in families:
 programs=json.loads(gzip.decompress((q/(prefix+'native-programs.json.gz')).read_bytes()));used.extend(programs)
 for row in json.loads((q/(prefix+'appearance-rows.json')).read_text(encoding='utf8')):
  if not predicate(row):continue
  e=row['evidence'];draws=json.loads(gzip.decompress((q/(prefix+row['label']+'-globe.json.gz')).read_bytes()));main=[d for d in draws if max(abs(x-y)for x,y in zip(d['camera'],e['camera']))<1e-6 and d['viewport']==[0,0,2560,1440]]
  assert {d['kind']for d in main}=={'shade','mattress'},(prefix,row['label'],len(main))
  shade=[d for d in main if d['kind']=='shade'];mat=[d for d in main if d['kind']=='mattress'];power=e['simulation']['practicals']['sources'][1]['intensity'];expected=.65*min(1,max(0,power/2.7))
  assert all(abs(d['emissiveIntensity']-expected)<1e-12 for d in shade)
  assert all(not any(d['uniforms']['emissive'])and not any(np.array(d['emissiveColor'])*d['emissiveIntensity'])for d in mat)
  err=max(float(np.max(np.abs(np.array(d['uniforms']['emissive'])-np.array(d['emissiveColor'])*expected)))for d in shade);assert err<1e-7
  for d in main:assert not any(d['maps'].values())and abs(d['uniforms']['roughness']-.96)<1e-6
  gpu=json.loads(gzip.decompress((q/(prefix+row['label']+'-gpu.json.gz')).read_bytes()));exposures=[p['uniforms']['toneMappingExposure']for p in gpu if 'toneMappingExposure'in p['uniforms']]
  assert exposures and all(abs(value-1.05)<1e-6 for value in exposures)
  controls.append({'family':prefix,'label':row['label'],'sourcePower':power,'visibleShadeIntensity':expected,'mattressUploadedEmission':[0,0,0],'mattressScalarIntensity':sorted({d['emissiveIntensity']for d in mat}),'uploadedEmissionMaxError':err,'actualMaterialPrograms':sorted({d['program']for d in main}),'actualFinalPassExposureUniforms':exposures,'mainDraws':len(main),'actualBuffer':[e['canvasWidth'],e['canvasHeight']],'actualMSAA':e['rendering']['msaaSamples']})
for p in used:
 assert set(a['name']for a in p['attributes'])=={'position','normal','color'}
 source='\n'.join(p['sources']);assert 'surfacePoint = (modelMatrix * vec4(transformed, 1.0)).xyz'in source and 'vec3 p = surfacePoint'in source and 'float weave = sin(p.x*590.0)'in source
report={'scope':'Actual per-draw GPU uniforms on exact native globe AND retained mattress in9 public Noon/Evening/maximum-existing-source poses; native clocks/complete source-bound high2K product; no timing claim. First cached/no-fresh-draw peak control retained; separate public-input peak replacement qualified.','controls':controls,'linenUVUse':{'activeAttributes':[{'program':p['id'],'names':[a['name']for a in p['attributes']]}for p in used],'allTextureMapsNull':True,'actualWorldSpaceFinishPresent':True,'shaderSourcesSha256':[hashlib.sha256('\n'.join(p['sources']).encode()).hexdigest()for p in used],'interpretation':'Current linen renderer reads world position, normal and vertex colour; UV is not an active shader input. UV quantization delta is retained but cannot alter this current finish. Future texture-mapped uses need new qualification.'},'noExtraTransportEmitter':True,'limits':'Shade emission is an art-directed visible raster approximation tied to existing point-light power; not a calibrated physical area-light radiance model. Native cloth draws are linear HDR with no exposure uniform; actual final-pass exposure is checked separately.'}
(q/'SHADE-GPU-UV-PROOF.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print({'views':len(controls),'activeAttributes':report['linenUVUse']['activeAttributes'],'maximumEmissionUniformError':max(r['uploadedEmissionMaxError']for r in controls),'maxShadeIntensity':max(r['visibleShadeIntensity']for r in controls)})
