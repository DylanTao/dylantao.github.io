from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,time
q=Path(__file__).parent;out=q/'subject-ci-v1';assert not out.exists();out.mkdir()
head='01c95f6be044a95102f902ae883a3866f66a10a0';start=time.monotonic();prior=None
while time.monotonic()-start<7200:
    raw=subprocess.check_output(['gh','run','list','--commit',head,'--limit','20','--json','databaseId,name,status,conclusion,headSha,url'],timeout=45);runs=json.loads(raw)
    visual=next((r for r in runs if r['name']=='Visual checkpoints'),None)
    detail=json.loads(subprocess.check_output(['gh','run','view',str(visual['databaseId']),'--json','status,conclusion,jobs,headSha,url'],timeout=45))if visual else None
    summary={'at':datetime.now(timezone.utc).isoformat(),'completed':sum(r['status']=='completed'for r in runs),'runCount':len(runs),'failures':[{'name':r['name'],'conclusion':r['conclusion'],'url':r['url']}for r in runs if r['status']=='completed'and r['conclusion']not in ['success','skipped']],'visualJobs':len(detail['jobs'])if detail else 0,'visualPassed':sum(j['conclusion']=='success'for j in detail['jobs'])if detail else 0}
    (out/'RUNS.json').write_bytes(raw);(out/'VISUAL-JOBS.json').write_text(json.dumps(detail,indent=2)+'\n',encoding='utf8');(out/'STATUS.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
    with(out/'HISTORY.jsonl').open('a',encoding='utf8')as log:log.write(json.dumps(summary)+'\n')
    current=tuple(summary[k]if not isinstance(summary[k],list)else json.dumps(summary[k])for k in ['completed','runCount','visualJobs','visualPassed','failures'])
    if current!=prior:print(json.dumps(summary),flush=True);prior=current
    if summary['failures']:raise SystemExit(1)
    if {'Visual checkpoints','Deploy site','Integration tests','Upgrade contract checks','Prettier code formatter','CodeQL Advanced','Check for broken links','Check for broken links on site'}.issubset({r['name']for r in runs}) and all(r['status']=='completed'for r in runs)and detail and detail['conclusion']=='success'and len(detail['jobs'])==46 and all(j['conclusion']=='success'for j in detail['jobs']):
        (out/'GREEN.json').write_text(json.dumps({'at':datetime.now(timezone.utc).isoformat(),'head':head,'allApplicablePassed':True,'visualPassed':46,'runs':runs},indent=2)+'\n',encoding='utf8');print('ALL APPLICABLE WORKFLOWS AND46VISUAL JOBS GREEN',flush=True);break
    time.sleep(45)
else:raise TimeoutError('Bounded CI observation ended; retained exact status')
