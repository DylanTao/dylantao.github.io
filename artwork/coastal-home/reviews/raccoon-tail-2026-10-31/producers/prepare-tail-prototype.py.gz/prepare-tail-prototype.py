from pathlib import Path
q=Path(__file__).parent
prefix=(q/'native-proof.mjs').read_text().split('function samples()')[0]
body='''
const grounds=await Promise.all([nativeGeometry("home-shell.glb",models),nativeGeometry("coast.glb",models)]);
const runtime=await world(structuredClone(config),grounds),patch=createGroundPatch(config.terrain.habitats.raccoon.path,2);patch.capture(grounds);
const meshes=[];runtime.scene.traverse(o=>{if(o.isSkinnedMesh&&o.userData.action?.id==="raccoon-0")meshes.push(o)});
const bones=meshes[0].skeleton.bones,tail=bones.find(b=>b.name==="Tail"),points=[];
for(const mesh of meshes){const skin=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight;for(let i=0;i<skin.count;i++){let total=0;for(let k=0;k<4;k++)if(/^Tail/.test(mesh.skeleton.bones[skin.getComponent(i,k)].name))total+=weights.getComponent(i,k);if(total>.0001)points.push({mesh,index:i})}}
function minimum(){runtime.scene.updateMatrixWorld(true);for(const m of meshes)m.skeleton.update();let gap=Infinity,missing=0,witness=null;for(const p of points){const v=p.mesh.getVertexPosition(p.index,new THREE.Vector3()).applyMatrix4(p.mesh.matrixWorld),hit=patch.sample(v.x,v.z,v.y+1);if(!hit){missing++;continue}if(v.y-hit.height<gap){gap=v.y-hit.height;witness={point:v.toArray(),mesh:p.mesh.name,vertex:p.index,support:hit.mesh}}}return{gap,missing,witness}}
const rows=[];
for(const night of [false,true])for(const time of [0,1,2,4,8,14.4167,18.8007,23.5357,32,48,64,80,96,112,128]){
 runtime.wildlife.update(time,night?"evening":"noon",{force:true});runtime.scene.updateMatrixWorld(true);
 const original=tail.rotation.x,row={night,time,state:runtime.wildlife.evidence().raccoon.state,vertices:points.length,baseline:minimum(),angles:[]};
 for(const angle of [0,.1,.2,.3,.4,.5,.6,.7,.8,.9,1,1.1,1.2]){tail.rotation.x=original+angle;row.angles.push({angle,...minimum()})}
 rows.push(row);tail.rotation.x=original;
}
fs.writeFileSync(new URL("./tail-prototype.json",import.meta.url),JSON.stringify(rows,null,2));
for(const row of rows)console.log(JSON.stringify({night:row.night,time:row.time,state:row.state,vertices:row.vertices,gap:row.baseline.gap,firstClear:row.angles.find(r=>r.gap>=.0006)||null}));
'''
(q/'tail-prototype.mjs').write_text(prefix+body,encoding='utf-8')
