from pathlib import Path
q=Path(__file__).parent
source=(q/'gpu-skin.cjs').read_text().replace('4162','4163').replace('rabbit-0','raccoon-0').replace('__rabbitGPU','__tailGPU').replace('actual-gpu-skin.json','actual-gpu-tail.json')
source=source.replace("await canvas.press('n');", "for(let i=0;i<28;i++){await canvas.press('n');if(await host.evaluate(e=>e.getSceneEvidence().inspection?.id)==='raccoon-0')break}")
(q/'gpu-tail.cjs').write_text(source,encoding='utf-8')
