from pathlib import Path
q=Path(__file__).parent
prefix=(q/'native-proof.mjs').read_text().split('function samples()')[0]
prefix=prefix.replace('new URL("./baseline-wildlife.mjs",import.meta.url).href','new URL("./rabbit-fixed/frozen-rabbit-runtime.mjs",import.meta.url).href')
body='''
const grounds=await Promise.all([nativeGeometry("home-shell.glb",models),nativeGeometry("coast.glb",models)]),runtime=await world(structuredClone(config),grounds),patch=createGroundPatch(config.terrain.habitats.raccoon.path,1.15);patch.capture(grounds);
const meshes=[];runtime.scene.traverse(o=>{if(o.isSkinnedMesh&&o.userData.action?.id==="raccoon-0")meshes.push(o)});
let group=meshes[0];while(group.parent&&group.parent.name!=="Coastal neighbours")group=group.parent;
const lists={tail:[],retained:[]};for(const mesh of meshes){const skin=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight;for(let i=0;i<skin.count;i++){let total=0;for(let k=0;k<4;k++)if(/^Tail/.test(mesh.skeleton.bones[skin.getComponent(i,k)].name))total+=weights.getComponent(i,k);lists[total>.0001?"tail":"retained"].push({mesh,index:i})}}
const digest=b=>crypto.createHash("sha256").update(JSON.stringify(b)).digest("hex"),rows=[];
for(const palette of ["noon","evening"])for(let time=0;time<=160;time+=.5){
 runtime.wildlife.update(time,palette,{force:true});runtime.scene.updateMatrixWorld(true);let minimum=null,missing=0;
 for(const p of lists.tail){const v=p.mesh.getVertexPosition(p.index,new THREE.Vector3()).applyMatrix4(p.mesh.matrixWorld),hit=patch.sample(v.x,v.z,v.y+.5);if(!hit){missing++;continue}const gap=v.y-hit.height;if(!minimum||gap<minimum.gap)minimum={gap,point:v.toArray(),mesh:p.mesh.name,vertex:p.index,support:{height:hit.height,mesh:hit.mesh,triangle:hit.triangle,normal:hit.normal.toArray(),visible:hit.visible}}}
 const retained=[];for(const p of lists.retained)retained.push(...p.mesh.getVertexPosition(p.index,new THREE.Vector3()).applyMatrix4(p.mesh.matrixWorld).toArray());
 const nonTailBones=meshes[0].skeleton.bones.filter(b=>!/^Tail/.test(b.name)).map(b=>[b.name,...b.matrixWorld.elements]),others={};runtime.scene.traverse(o=>{if(!o.isSkinnedMesh||!o.userData.action?.id||o.userData.action.id==="raccoon-0"||others[o.userData.action.id])return;others[o.userData.action.id]=o.skeleton.bones.map(b=>[b.name,...b.matrixWorld.elements])});
 rows.push({time,palette,state:runtime.wildlife.evidence().raccoon.state,tailVertices:lists.tail.length,retainedVertices:lists.retained.length,missing,minimum,rootSha256:digest(group.matrixWorld.toArray()),nonTailJointWorldSha256:digest(nonTailBones),nonTailWorldVerticesSha256:digest(retained),other27SkeletonWorldSha256:digest(others),tailContact:runtime.wildlife.evidence().raccoon.tailContact||null});
}
const label=process.argv.includes("--baseline")?"baseline":"candidate";fs.writeFileSync(new URL("./tail-native-"+label+".json",import.meta.url),JSON.stringify(rows,null,2));console.log(JSON.stringify({label,rows:rows.length,states:[...new Set(rows.map(r=>r.state))],minimum:Math.min(...rows.map(r=>r.minimum.gap)),missing:rows.reduce((n,r)=>n+r.missing,0),maxFitRotation:Math.max(...rows.map(r=>r.tailContact?.rotation||0))}));
'''
(q/'tail-native-proof.mjs').write_text(prefix+body,encoding='utf-8')
