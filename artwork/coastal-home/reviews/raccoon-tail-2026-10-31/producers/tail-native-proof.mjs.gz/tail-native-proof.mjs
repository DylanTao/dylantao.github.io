import crypto from "node:crypto";
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { THREE, loadNativeModel } from "file:///C:/dev/site-takeover-worktrees/identity-footer/test/helpers/coastal-native-avatar.mjs";
import { nativeGeometry } from "file:///C:/dev/site-takeover-worktrees/identity-footer/test/helpers/coastal-native-geometry.mjs";
const {createWildlife}=await import(process.argv.includes("--baseline")?new URL("./rabbit-fixed/frozen-rabbit-runtime.mjs",import.meta.url).href:"file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife.mjs");
import { createGroundPatch } from "file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife-ground-contact.mjs";
import { rabbitActing, rabbitSchedule } from "file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife-motion.mjs";

const models = new URL("file:///C:/dev/site-takeover-worktrees/identity-footer/.jekyll-cache/visual-qa/animal-readonly-20261031/inputs/assets/models/home/");
const config = JSON.parse(fs.readFileSync(new URL("manifest.json", models)));
const perches = JSON.parse(fs.readFileSync(new URL("wildlife-perch-support.json", models)));
const species = ["BrushRabbit", "CaliforniaSeaLion", "HarborSeal", "Raccoon", "WesternGull", "Sandpiper", "BrownPelican", "BrandtsCormorant"];
const masters = await Promise.all(species.map((name) => loadNativeModel(name + ".glb", models)));
async function world(manifest, grounds) {
  const scene = new THREE.Group(), environment = new THREE.Group(); scene.add(environment, ...grounds);
  const wildlife = createWildlife(environment, manifest, {
    createModelLoader: () => ({ loader: { loadAsync: async (url) => masters[species.indexOf(url.split("/").at(-1).replace(".glb", ""))] }, decoder: { dispose() {} } }),
    loadPerchSupport: async () => perches,
  });
  for (let i = 0; i < 100 && !wildlife.evidence().modelsReady; i++) await new Promise(setImmediate);
  assert.equal(wildlife.evidence().modelsReady, true);
  wildlife.captureGround(grounds); scene.updateMatrixWorld(true);
  const paws = [0, 1].map((index) => {
    const list=[];
    scene.traverse((mesh) => {
      if (!mesh.isSkinnedMesh || mesh.userData.action?.id !== `rabbit-${index}`) return;
      const skin=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight;
      for(let i=0;i<skin.count;i++) {
        const names=new Map();
        for(let k=0;k<4;k++){const name=mesh.skeleton.bones[skin.getComponent(i,k)].name;names.set(name,(names.get(name)||0)+weights.getComponent(i,k));}
        for(const [name,weight]of names)if(/^(Front|Hind)Paw[LR]$/.test(name)&&weight>=.999)list.push({mesh,index:i,name});
      }
    });
    assert.ok(list.length>1000);return list;
  });
  const patches=["rabbitWest","rabbitEast"].map((key)=>{const p=createGroundPatch(manifest.terrain.habitats[key].path,1);p.capture(grounds);assert.ok(p.evidence().ready);return p});
  function measure(index) {
    scene.updateMatrixWorld(true);
    for(const mesh of new Set(paws[index].map(p=>p.mesh)))mesh.skeleton.update();
    const feet=Object.fromEntries(["FrontPawL","FrontPawR","HindPawL","HindPawR"].map(n=>[n,{minimum:Infinity,missing:0,points:[]} ]));
    for(const p of paws[index]){
      const v=p.mesh.getVertexPosition(p.index,new THREE.Vector3()).applyMatrix4(p.mesh.matrixWorld),hit=patches[index].sample(v.x,v.z,v.y+.5),foot=feet[p.name];
      foot.points.push(v.toArray());if(!hit)foot.missing++;else foot.minimum=Math.min(foot.minimum,v.y-hit.height);
    }
    return feet;
  }
  return {scene,wildlife,paws,measure};
}

const grounds=await Promise.all([nativeGeometry("home-shell.glb",models),nativeGeometry("coast.glb",models)]),runtime=await world(structuredClone(config),grounds),patch=createGroundPatch(config.terrain.habitats.raccoon.path,1.15);patch.capture(grounds);
const meshes=[];runtime.scene.traverse(o=>{if(o.isSkinnedMesh&&o.userData.action?.id==="raccoon-0")meshes.push(o)});
let group=meshes[0];while(group.parent&&group.parent.name!=="Coastal neighbours")group=group.parent;
const lists={tail:[],retained:[]};for(const mesh of meshes){const skin=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight;for(let i=0;i<skin.count;i++){let total=0;for(let k=0;k<4;k++)if(/^Tail/.test(mesh.skeleton.bones[skin.getComponent(i,k)].name))total+=weights.getComponent(i,k);lists[total>.0001?"tail":"retained"].push({mesh,index:i})}}
const digest=b=>crypto.createHash("sha256").update(JSON.stringify(b)).digest("hex"),rows=[];
for(const palette of ["noon","evening"])for(let time=0;time<=160;time+=.5){
 runtime.wildlife.update(time,palette,{force:true});runtime.scene.updateMatrixWorld(true);let minimum=null,missing=0;
 for(const p of lists.tail){const v=p.mesh.getVertexPosition(p.index,new THREE.Vector3()).applyMatrix4(p.mesh.matrixWorld),hit=patch.sample(v.x,v.z,v.y+.5);if(!hit){missing++;continue}const gap=v.y-hit.height;if(!minimum||gap<minimum.gap)minimum={gap,point:v.toArray(),mesh:p.mesh.name,vertex:p.index,support:{height:hit.height,mesh:hit.mesh,triangle:hit.triangle,normal:hit.normal.toArray(),visible:hit.visible}}}
 const retained=[];for(const p of lists.retained)retained.push(...p.mesh.getVertexPosition(p.index,new THREE.Vector3()).applyMatrix4(p.mesh.matrixWorld).toArray());
 const nonTailBones=meshes[0].skeleton.bones.filter(b=>!/^Tail/.test(b.name)).map(b=>[b.name,...b.matrixWorld.elements]),others={};runtime.scene.traverse(o=>{if(!o.isSkinnedMesh||!o.userData.action?.id||o.userData.action.id==="raccoon-0"||others[o.userData.action.id])return;others[o.userData.action.id]=o.skeleton.bones.map(b=>[b.name,...b.matrixWorld.elements])});
 rows.push({time,palette,state:runtime.wildlife.evidence().raccoon.state,tailVertices:lists.tail.length,retainedVertices:lists.retained.length,missing,minimum,rootSha256:digest(group.matrixWorld.toArray()),nonTailJointWorldSha256:digest(nonTailBones),nonTailWorldVerticesSha256:digest(retained),other27SkeletonWorldSha256:digest(others),tailContact:runtime.wildlife.evidence().raccoon.tailContact||null});
}
const label=process.argv.includes("--baseline")?"baseline":"candidate";fs.writeFileSync(new URL("./tail-native-"+label+".json",import.meta.url),JSON.stringify(rows,null,2));console.log(JSON.stringify({label,rows:rows.length,states:[...new Set(rows.map(r=>r.state))],minimum:Math.min(...rows.map(r=>r.minimum.gap)),missing:rows.reduce((n,r)=>n+r.missing,0),maxFitRotation:Math.max(...rows.map(r=>r.tailContact?.rotation||0))}));
