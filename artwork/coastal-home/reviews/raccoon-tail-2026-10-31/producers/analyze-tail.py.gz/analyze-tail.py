import json
from pathlib import Path
q=Path(__file__).parent
before=json.loads((q/'tail-native-baseline.json').read_text())
after=json.loads((q/'tail-native-candidate.json').read_text())
assert len(before)==len(after)==642
keys=['rootSha256','nonTailJointWorldSha256','nonTailWorldVerticesSha256','other27SkeletonWorldSha256']
for b,c in zip(before,after):
    assert (b['time'],b['palette'],b['state'])==(c['time'],c['palette'],c['state'])
    for key in keys:assert b[key]==c[key],(c['time'],c['palette'],key)
    assert c['missing']==0 and c['minimum']['gap']>=.00059 and c['tailContact']['supported']
    assert c['tailContact']['rotation']<=.65
    if c['state']=='sleep':assert c['minimum']['gap']<.001
desktop=json.loads((q/'resting-live-v1/chromium-frames.json').read_text())
phone=json.loads((q/'resting-live-v1/webkit-frames.json').read_text())
assert len(desktop)==len(phone)==56 and all(not r['errors']for r in desktop+phone)
gpu=json.loads((q/'actual-gpu-tail.json').read_text())
assert gpu['callbacksRestored']and not gpu['errors']
assert all(b['maximumAbsoluteError']==0 for r in gpu['rows']for b in r['bones'])
report={'rows':len(after),'tailVerticesPerPose':after[0]['tailVertices'],'retainedBodyPawVerticesPerPose':after[0]['retainedVertices'],'exactDigestFieldsEveryPair':keys,'baselineMinimumTailGapM':min(r['minimum']['gap']for r in before),'candidateMinimumTailGapM':min(r['minimum']['gap']for r in after),'candidateMaximumSleepingGapM':max(r['minimum']['gap']for r in after if r['state']=='sleep'),'maximumTailJointCorrectionRad':max(r['tailContact']['rotation']for r in after),'actualGpuMatrixMaximumError':0,'chromiumNativeRafRecords':len(desktop),'webkitNativeRafRecords':len(phone),'originalPngs':sum('file'in r for r in desktop+phone),'states':sorted({r['state']for r in after}),'limits':'Finite decoded native proof on frozen accepted terrain. Sleeping trunk underside remains unchanged and has separate baseline penetration witnesses. Final F6 support and publication gates belong to coordinator.'}
(q/'tail-analysis.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report))
