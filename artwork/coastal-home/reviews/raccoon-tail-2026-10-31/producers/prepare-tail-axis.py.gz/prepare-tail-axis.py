from pathlib import Path
q=Path(__file__).parent
source=(q/'tail-prototype.mjs').read_text()
source=source.replace('tail-prototype.json','tail-axis-prototype.json')
start=source.index('for(const night of [false,true])')
source=source[:start]+'''
for(const night of [false,true])for(const time of [0,1,2,4,8,14.4167,18.8007,23.5357,32,48,64,80,96,112,128]){
 runtime.wildlife.update(time,night?"evening":"noon",{force:true});runtime.scene.updateMatrixWorld(true);
 const original=tail.quaternion.clone(),row={night,time,state:runtime.wildlife.evidence().raccoon.state,vertices:points.length,baseline:minimum(),iterations:[]};
 for(let i=0;i<12;i++){
  const m=minimum();if(m.gap>=.0006){row.final=m;break}
  const pivot=tail.getWorldPosition(new THREE.Vector3()),v=new THREE.Vector3(...m.witness.point).sub(pivot),axis=v.clone().cross(new THREE.Vector3(0,1,0)).normalize();
  const angle=Math.min(.22,Math.atan2(.00065-m.gap,Math.hypot(v.x,v.z))*1.03),p=tail.parent.getWorldQuaternion(new THREE.Quaternion());
  tail.quaternion.premultiply(p.clone().invert().multiply(new THREE.Quaternion().setFromAxisAngle(axis,angle)).multiply(p));
  row.iterations.push({angle,axis:axis.toArray(),minimum:m.gap});
 }
 row.final=minimum();row.quaternionDelta=original.angleTo(tail.quaternion);rows.push(row);tail.quaternion.copy(original);
}
fs.writeFileSync(new URL("./tail-axis-prototype.json",import.meta.url),JSON.stringify(rows,null,2));
for(const row of rows)console.log(JSON.stringify({night:row.night,time:row.time,state:row.state,gap:row.baseline.gap,final:row.final.gap,delta:row.quaternionDelta,steps:row.iterations.length}));
'''
(q/'tail-axis-prototype.mjs').write_text(source,encoding='utf-8')
