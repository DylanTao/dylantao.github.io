import crypto from "node:crypto";
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { THREE, loadNativeModel } from "file:///C:/dev/site-takeover-worktrees/identity-footer/test/helpers/coastal-native-avatar.mjs";
import { nativeGeometry } from "file:///C:/dev/site-takeover-worktrees/identity-footer/test/helpers/coastal-native-geometry.mjs";
const {createWildlife}=await import(process.argv.includes("--baseline")?new URL("./baseline-wildlife.mjs",import.meta.url).href:"file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife.mjs");
import { createGroundPatch } from "file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife-ground-contact.mjs";
import { rabbitActing, rabbitSchedule } from "file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife-motion.mjs";

const models = new URL("file:///C:/dev/site-takeover-worktrees/identity-footer/.jekyll-cache/visual-qa/animal-readonly-20261031/inputs/assets/models/home/");
const config = JSON.parse(fs.readFileSync(new URL("manifest.json", models)));
const perches = JSON.parse(fs.readFileSync(new URL("wildlife-perch-support.json", models)));
const species = ["BrushRabbit", "CaliforniaSeaLion", "HarborSeal", "Raccoon", "WesternGull", "Sandpiper", "BrownPelican", "BrandtsCormorant"];
const masters = await Promise.all(species.map((name) => loadNativeModel(name + ".glb", models)));
async function world(manifest, grounds) {
  const scene = new THREE.Group(), environment = new THREE.Group(); scene.add(environment, ...grounds);
  const wildlife = createWildlife(environment, manifest, {
    createModelLoader: () => ({ loader: { loadAsync: async (url) => masters[species.indexOf(url.split("/").at(-1).replace(".glb", ""))] }, decoder: { dispose() {} } }),
    loadPerchSupport: async () => perches,
  });
  for (let i = 0; i < 100 && !wildlife.evidence().modelsReady; i++) await new Promise(setImmediate);
  assert.equal(wildlife.evidence().modelsReady, true);
  wildlife.captureGround(grounds); scene.updateMatrixWorld(true);
  const paws = [0, 1].map((index) => {
    const list=[];
    scene.traverse((mesh) => {
      if (!mesh.isSkinnedMesh || mesh.userData.action?.id !== `rabbit-${index}`) return;
      const skin=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight;
      for(let i=0;i<skin.count;i++) {
        const names=new Map();
        for(let k=0;k<4;k++){const name=mesh.skeleton.bones[skin.getComponent(i,k)].name;names.set(name,(names.get(name)||0)+weights.getComponent(i,k));}
        for(const [name,weight]of names)if(/^(Front|Hind)Paw[LR]$/.test(name)&&weight>=.999)list.push({mesh,index:i,name});
      }
    });
    assert.ok(list.length>1000);return list;
  });
  const patches=["rabbitWest","rabbitEast"].map((key)=>{const p=createGroundPatch(manifest.terrain.habitats[key].path,1);p.capture(grounds);assert.ok(p.evidence().ready);return p});
  function measure(index) {
    scene.updateMatrixWorld(true);
    for(const mesh of new Set(paws[index].map(p=>p.mesh)))mesh.skeleton.update();
    const feet=Object.fromEntries(["FrontPawL","FrontPawR","HindPawL","HindPawR"].map(n=>[n,{minimum:Infinity,missing:0,points:[]} ]));
    for(const p of paws[index]){
      const v=p.mesh.getVertexPosition(p.index,new THREE.Vector3()).applyMatrix4(p.mesh.matrixWorld),hit=patches[index].sample(v.x,v.z,v.y+.5),foot=feet[p.name];
      foot.points.push(v.toArray());if(!hit)foot.missing++;else foot.minimum=Math.min(foot.minimum,v.y-hit.height);
    }
    return feet;
  }
  return {scene,wildlife,paws,measure};
}

const grounds=await Promise.all([nativeGeometry("home-shell.glb",models),nativeGeometry("coast.glb",models)]);
const runtime=await world(structuredClone(config),grounds),patch=createGroundPatch(config.terrain.habitats.raccoon.path,2);patch.capture(grounds);
const meshes=[];runtime.scene.traverse(o=>{if(o.isSkinnedMesh&&o.userData.action?.id==="raccoon-0")meshes.push(o)});
const bones=meshes[0].skeleton.bones,tail=bones.find(b=>b.name==="Tail"),points=[];
for(const mesh of meshes){const skin=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight;for(let i=0;i<skin.count;i++){let total=0;for(let k=0;k<4;k++)if(/^Tail/.test(mesh.skeleton.bones[skin.getComponent(i,k)].name))total+=weights.getComponent(i,k);if(total>.0001)points.push({mesh,index:i})}}
function minimum(){runtime.scene.updateMatrixWorld(true);for(const m of meshes)m.skeleton.update();let gap=Infinity,missing=0,witness=null;for(const p of points){const v=p.mesh.getVertexPosition(p.index,new THREE.Vector3()).applyMatrix4(p.mesh.matrixWorld),hit=patch.sample(v.x,v.z,v.y+1);if(!hit){missing++;continue}if(v.y-hit.height<gap){gap=v.y-hit.height;witness={point:v.toArray(),mesh:p.mesh.name,vertex:p.index,support:hit.mesh}}}return{gap,missing,witness}}
const rows=[];

for(const night of [false,true])for(const time of [0,1,2,4,8,14.4167,18.8007,23.5357,32,48,64,80,96,112,128]){
 runtime.wildlife.update(time,night?"evening":"noon",{force:true});runtime.scene.updateMatrixWorld(true);
 const original=tail.quaternion.clone(),row={night,time,state:runtime.wildlife.evidence().raccoon.state,vertices:points.length,baseline:minimum(),iterations:[]};
 for(let i=0;i<12;i++){
  const m=minimum();if(m.gap>=.0006){row.final=m;break}
  const pivot=tail.getWorldPosition(new THREE.Vector3()),v=new THREE.Vector3(...m.witness.point).sub(pivot),axis=v.clone().cross(new THREE.Vector3(0,1,0)).normalize();
  const angle=Math.min(.22,Math.atan2(.00065-m.gap,Math.hypot(v.x,v.z))*1.03),p=tail.parent.getWorldQuaternion(new THREE.Quaternion());
  tail.quaternion.premultiply(p.clone().invert().multiply(new THREE.Quaternion().setFromAxisAngle(axis,angle)).multiply(p));
  row.iterations.push({angle,axis:axis.toArray(),minimum:m.gap});
 }
 row.final=minimum();row.quaternionDelta=original.angleTo(tail.quaternion);rows.push(row);tail.quaternion.copy(original);
}
fs.writeFileSync(new URL("./tail-axis-prototype.json",import.meta.url),JSON.stringify(rows,null,2));
for(const row of rows)console.log(JSON.stringify({night:row.night,time:row.time,state:row.state,gap:row.baseline.gap,final:row.final.gap,delta:row.quaternionDelta,steps:row.iterations.length}));
