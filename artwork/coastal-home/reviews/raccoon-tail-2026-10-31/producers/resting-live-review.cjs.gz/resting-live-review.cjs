const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const engine=process.env.ANIMAL_ENGINE||'chromium';
const api=require(engine==='webkit'?'C:/dev/dylantao.github.io/.jekyll-cache/visual-qa/takeover-archives/walk-audit-20261028-cache/visual-qa/walk-audit-20261028/pw165/node_modules/@playwright/test':'C:/dev/dylantao.github.io/node_modules/@playwright/test');
const {expect}=api,{preparePage,collectRuntimeErrors,screenshotMetrics}=require('../../../test/visual/helpers.js');
const q=__dirname,out=path.join(q,'resting-live-v1');fs.mkdirSync(out,{recursive:true});
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
 const browser=engine==='webkit'?await api.webkit.launch({headless:true}):await api.chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
 const rows=[];
 try{for(const variant of ['baseline','candidate']){
  const context=await browser.newContext({viewport:{width:engine==='webkit'?390:2560,height:engine==='webkit'?1000:1440},deviceScaleFactor:1,reducedMotion:'no-preference',hasTouch:engine==='webkit',isMobile:engine==='webkit',timezoneId:'America/Los_Angeles'}),page=await context.newPage(),errors=collectRuntimeErrors(page);
  page.setDefaultTimeout(90000);await preparePage(page,'light');await page.clock.setFixedTime(new Date('2026-10-31T13:20:00-07:00'));
  await page.goto(`http://127.0.0.1:${variant==='baseline'?4158:4163}/al-folio/?scene-lab=1&quality=high&resolution=fixed`,{waitUntil:'domcontentloaded'});
  const activate=l=>engine==='webkit'?l.tap():l.click();await activate(page.locator('[data-home-desk-mode="3d"]'));
  const host=page.locator('[data-home-desk-scene]'),canvas=host.locator('canvas'),ui=page.locator('[data-home-world-controls]');
  await host.scrollIntoViewIfNeeded();await expect(host).toHaveAttribute('data-scene-state','ready',{timeout:240000});await activate(ui.locator('[data-world-fullscreen]'));await canvas.focus();
  const order=await host.evaluate(e=>e.getSceneEvidence().neighbours.map(n=>n.id));
  async function select(id){const current=await host.evaluate(e=>e.getSceneEvidence().inspection?.id),from=order.indexOf(current),to=order.indexOf(id);for(let i=0;i<(to-from+order.length)%order.length;i++)await canvas.press('n');await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().inspection?.id)).toBe(id);await page.waitForTimeout(1800)}
  async function record(label,index,capture){
   const before=await host.evaluate(e=>{const ev=e.getSceneEvidence(),c=e.querySelector('canvas'),gl=c.getContext('webgl2'),d=gl.getExtension('WEBGL_debug_renderer_info');return{performanceNow:performance.now(),evidence:ev,backend:{renderer:gl.getParameter(d?.UNMASKED_RENDERER_WEBGL||gl.RENDERER),buffer:[gl.drawingBufferWidth,gl.drawingBufferHeight]}}});
   const row={engine,variant,label,index,...before,errors:[...errors],scope:'Public N inspection, arrow-key orbit and native uninterrupted RAF/performance. Authoring flag permits read-only geometry access. Date alone is fixed; PNG is bracketed by actual frame/time evidence, not an identical-pose pixel comparison.'};
   if(capture){row.file=`${engine}-${variant}-${label}-${index}.png`;const b=await canvas.screenshot({path:path.join(out,row.file)});row.pngSha256=sha(b);row.metrics=screenshotMetrics(b);row.screenshotEnd=await host.evaluate(e=>({frame:e.getSceneEvidence().frames,active:e.getSceneEvidence().animationSeconds,performanceNow:performance.now()}));expect(row.metrics.luminanceVariance).toBeGreaterThan(4)}
   rows.push(row);fs.writeFileSync(path.join(out,engine+'-frames.json'),JSON.stringify(rows,null,2));
  }
  await select('raccoon-0');await record('sleep-front',0,true);
  for(let i=0;i<6;i++)await canvas.press('ArrowLeft');await page.waitForTimeout(700);await record('sleep-side',0,true);
  for(let i=0;i<6;i++)await canvas.press('ArrowLeft');await page.waitForTimeout(700);await record('sleep-back',0,true);
  await activate(page.locator('[data-world-exit]:visible'));await activate(page.locator('[data-theme-toggle]:visible').first());await activate(page.locator('[data-theme-mode-option="evening"]:visible').first());
  await activate(ui.locator('[data-world-fullscreen]'));await canvas.focus();await select('raccoon-0');
  for(let i=0;i<25;i++){await record('evening',i,i%8===0);await page.waitForTimeout(220)}
  expect(errors).toEqual([]);console.log(JSON.stringify({engine,variant,states:[...new Set(rows.filter(r=>r.variant===variant).map(r=>r.evidence.ecology.wildlife.raccoon.state))],captures:rows.filter(r=>r.variant===variant&&r.file).length,errors:errors.length}));await context.close();
 }}finally{await browser.close()}
})().catch(e=>{fs.writeFileSync(path.join(out,engine+'-failure.txt'),String(e.stack||e));console.error(e);process.exitCode=1});
