import hashlib
import json
import subprocess
from pathlib import Path
q=Path(__file__).parent
root=q.parents[2]
binding=json.loads((root/'artwork/coastal-home/reviews/rabbit-contact-2026-10-31/SOURCE_BINDINGS.json').read_text())
for row in binding['candidateServedBindings']:
    blob=subprocess.check_output(['git','show',binding['sourceCommit']+':'+row['path']],cwd=root)
    candidates=[blob,blob.replace(b'\n',b'\r\n')]
    data=next((b for b in candidates if hashlib.sha256(b).hexdigest()==row['sha256']),None)
    assert data is not None,row['path']
    target=q/'sealed-rabbit'/row['path']
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(data)
source=(q/'proxy.py').read_text()
(q/'proxy-frozen-rabbit.py').write_text(source.replace("root/'assets/js/home-scene'/name","q/'sealed-rabbit/assets/js/home-scene'/name"),encoding='utf-8')
source=source.replace("['wildlife.mjs','wildlife-rabbit-contact.mjs']","['wildlife.mjs','wildlife-rabbit-contact.mjs','wildlife-resting-contact.mjs']").replace("4162","4163")
(q/'proxy-resting.py').write_text(source,encoding='utf-8')
print('Reconstructed both exact sealed rabbit source byte hashes; resting preview is 4163.')
