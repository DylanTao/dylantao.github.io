const {chromium,expect:baseExpect}=require('playwright/test');
const expect=baseExpect.configure({timeout:15000});
const fs=require('node:fs/promises'),path=require('node:path'),crypto=require('node:crypto');
const root='C:/dev/dylantao.github.io';
const helper=name=>{const frozen=path.join(__dirname,'source-12e','test__visual__'+name);return require('node:fs').existsSync(frozen)?frozen:root+'/test/visual/'+name};
const {preparePage,collectRuntimeErrors}=require(helper('helpers.js'));
const {useNativeSceneFrames}=require(helper('scene-clock.js'));
const software=process.argv.includes('--software'),name=software?'software-read-comparison':'native-read-comparison';
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
(async()=>{
 const output=path.join(__dirname,name);await fs.mkdir(output,{recursive:true});
 const browser=await chromium.launch({args:software?['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']:['--use-angle=d3d11','--ignore-gpu-blocklist']});
 const context=await browser.newContext({viewport:{width:768,height:1024},deviceScaleFactor:1,timezoneId:'America/Los_Angeles'});
 const page=await context.newPage();page.setDefaultTimeout(120000);
 const errors=collectRuntimeErrors(page),reads=[],phases=[];
 const metadata={scope:'Isolated hidden work-to-sleep transition using the same installed Date/timer clock and native RAF. Concurrent protocol observation diagnostic, not an isolated benchmark, official test pass or pixel proof.',softwareFunctionalProof:software,browser:browser.version(),width:768,height:1024,reads,phases,errors};
 const save=()=>fs.writeFile(path.join(output,'results.json'),JSON.stringify(metadata,null,2)+'\n');
 let origin=performance.now();
 const phase=async label=>{const state=await page.evaluate(()=>{const s=document.querySelector('[data-home-desk-scene]'),e=s.getSceneEvidence();return {frames:e.frames,framePending:e.framePending,seconds:e.animationSeconds,activity:e.activity,room:e.currentRoom,hidden:document.hidden,rect:s.getBoundingClientRect().toJSON()}});phases.push({label,hostSinceOriginMs:performance.now()-origin,...state});await save();console.log(label,state.frames,state.activity,state.framePending);return state};
 try{
  const response=await fetch('http://127.0.0.1:4137/al-folio/assets/js/module-build.json');const bytes=Buffer.from(await response.arrayBuffer()),build=JSON.parse(bytes);metadata.moduleReceipt={sha256:crypto.createHash('sha256').update(bytes).digest('hex'),controller:build.modules['assets/js/home-scene/controller.mjs']};
  await preparePage(page,'light');await page.emulateMedia({reducedMotion:'reduce'});await page.clock.install({time:new Date('2026-09-11T17:45:00-07:00')});await page.goto('http://127.0.0.1:4137/al-folio/?scene-lab=1',{waitUntil:'domcontentloaded'});await useNativeSceneFrames(page);
  await page.locator('[data-home-desk-mode="3d"]').click();const scene=page.locator('[data-home-desk-scene]'),canvas=scene.locator('canvas');await scene.scrollIntoViewIfNeeded();await expect(scene).toHaveAttribute('data-scene-state','ready',{timeout:150000});await canvas.scrollIntoViewIfNeeded();await phase('ready-reduced');
  await page.emulateMedia({reducedMotion:'no-preference'});await expect(page.locator('[data-world-pause]')).toBeEnabled();await sleep(500);await phase('live-before-hidden');
  await page.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,get:()=>true});document.dispatchEvent(new Event('visibilitychange'))});const hidden=await phase('hidden');await sleep(350);await page.clock.setSystemTime(new Date('2026-09-12T12:00:00-07:00'));await page.evaluate(()=>{delete document.hidden;document.dispatchEvent(new Event('visibilitychange'))});origin=performance.now();
  const methods={
   directPrimitive:()=>page.evaluate(()=>document.querySelector('[data-home-desk-scene]').getSceneEvidence().frames),
   locatorPrimitive:()=>scene.evaluate(node=>node.getSceneEvidence().frames),
   locatorFullEvidence:()=>scene.evaluate(node=>node.getSceneEvidence()).then(e=>({frames:e.frames,serializedBytes:Buffer.byteLength(JSON.stringify(e))})),
  };
  const jobs=Object.entries(methods).map(async([method,read])=>{for(let i=0;i<4;i++){const started=performance.now(),row={method,index:i,startedMs:started-origin};reads.push(row);await save();try{const value=await read();Object.assign(row,{completedMs:performance.now()-origin,callMs:performance.now()-started,...(typeof value==='number'?{frames:value}:value),advanced:(typeof value==='number'?value:value.frames)>hidden.frames});console.log(method,i,JSON.stringify(row));await save()}catch(error){row.error=error.message;await save();return}await sleep(250)}});
  metadata.observationFinished=await Promise.race([Promise.allSettled(jobs).then(()=>true),sleep(60000).then(()=>false)]);await save();
 }catch(error){metadata.error=error.stack;await save();throw error}finally{await context.close();await browser.close()}
})().catch(error=>{console.error(error);process.exitCode=1});
