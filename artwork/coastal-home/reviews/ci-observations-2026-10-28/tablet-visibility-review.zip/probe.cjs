const { chromium, expect } = require('playwright/test');
const fs=require('node:fs/promises'),path=require('node:path');
const root='C:/dev/dylantao.github.io';
const helper=name=>{const frozen=path.join(__dirname,'source-12e','test__visual__'+name);return require('node:fs').existsSync(frozen)?frozen:root+'/test/visual/'+name};
const {preparePage,collectRuntimeErrors,screenshotDiffRatio}=require(helper('helpers.js'));
const {useNativeSceneFrames}=require(helper('scene-clock.js'));
const software=process.argv.includes('--software'),noCaptures=process.argv.includes('--no-captures'),name=(software?'software':'native')+(noCaptures?'-state-only':'');
const output=path.join(__dirname,name);
(async()=>{
 await fs.mkdir(output,{recursive:true});
 const browser=await chromium.launch({args:software?['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']:['--use-angle=d3d11','--ignore-gpu-blocklist']});
 const page=await browser.newPage({viewport:{width:768,height:1024},deviceScaleFactor:1,timezoneId:'America/Los_Angeles'});
 page.setDefaultTimeout(software?120000:30000);
 const errors=collectRuntimeErrors(page),states=[];
 const save=async(label)=>{
  const state=await page.evaluate(label=>{
   const scene=document.querySelector('[data-home-desk-scene]'),e=scene?.getSceneEvidence?.(),canvas=scene?.querySelector('canvas');
   return {label,date:Date.now(),perf:performance.now(),hidden:document.hidden,visibility:document.visibilityState,scrollY,scene:scene?.getBoundingClientRect().toJSON(),canvas:canvas?.getBoundingClientRect().toJSON(),state:e?{frames:e.frames,framePending:e.framePending,seconds:e.animationSeconds,room:e.currentRoom,activity:e.activity,following:e.following,animation:e.animation,loading:e.loading,resources:e.resources}:null,pause:document.querySelector('[data-world-pause]')?.getAttribute('aria-pressed'),probe:window.visibilityProbe};
  },label);states.push(state);await fs.writeFile(path.join(output,'states.json'),JSON.stringify({browser:browser.version(),softwareFunctionalProof:software,performanceBenchmark:false,states,errors},null,2)+'\n');console.log(label,JSON.stringify({frames:state.state?.frames,pending:state.state?.framePending,activity:state.state?.activity,rect:state.canvas?.y,hidden:state.hidden,io:state.probe?.intersections?.slice(-3)}));return state;
 };
 try{
  await preparePage(page,'light');await page.emulateMedia({reducedMotion:'reduce'});await page.clock.install({time:new Date('2026-09-11T17:45:00-07:00')});
  await page.addInitScript(()=>{
   window.visibilityProbe={intersections:[],events:[],raf:[],cancels:[]};
   const IO=window.IntersectionObserver;
   window.IntersectionObserver=class extends IO{constructor(callback,opts){super((entries,observer)=>{for(const e of entries)if(e.target.matches('[data-home-desk-scene]')){window.visibilityProbe.intersections.push({date:Date.now(),perf:performance.now(),intersecting:e.isIntersecting,ratio:e.intersectionRatio,rect:e.boundingClientRect.toJSON(),hidden:document.hidden});}callback(entries,observer)},opts)}};
   for(const type of ['visibilitychange','pageshow','pagehide'])addEventListener(type,e=>window.visibilityProbe.events.push({type,hidden:document.hidden,date:Date.now(),perf:performance.now(),persisted:e.persisted}));
  });
  await page.goto('http://127.0.0.1:4137/al-folio/?scene-lab=1',{waitUntil:'domcontentloaded'});
  await useNativeSceneFrames(page);
  await page.evaluate(()=>{const request=requestAnimationFrame,cancel=cancelAnimationFrame;window.requestAnimationFrame=callback=>{let id;id=request(now=>{window.visibilityProbe.raf.push({kind:'fire',id,now,hidden:document.hidden});if(window.visibilityProbe.raf.length>100)window.visibilityProbe.raf.shift();callback(now)});window.visibilityProbe.raf.push({kind:'request',id,hidden:document.hidden});if(window.visibilityProbe.raf.length>100)window.visibilityProbe.raf.shift();return id};window.cancelAnimationFrame=id=>{window.visibilityProbe.cancels.push({id,hidden:document.hidden,perf:performance.now()});if(window.visibilityProbe.cancels.length>100)window.visibilityProbe.cancels.shift();return cancel(id)}});
  await page.locator('[data-home-desk-mode="3d"]').click();
  const scene=page.locator('[data-home-desk-scene]'),canvas=scene.locator('canvas'),ui=page.locator('[data-home-world-controls]');
  await scene.scrollIntoViewIfNeeded();await expect(scene).toHaveAttribute('data-scene-state','ready',{timeout:150000});await canvas.scrollIntoViewIfNeeded();
  const details=ui.locator('details').first();if(!await details.evaluate(e=>e.open))await details.locator('summary').first().click();await canvas.scrollIntoViewIfNeeded();
  await page.emulateMedia({reducedMotion:'no-preference'});await expect(ui.locator('[data-world-pause]')).toBeEnabled();
  if(noCaptures)await page.waitForTimeout(800);else{const before=await canvas.screenshot();let diff=0;for(let i=0;i<6&&diff<=.0002;i++){await page.waitForTimeout(650);diff=screenshotDiffRatio(before,await canvas.screenshot())}};await save('live');
  await ui.locator('[data-world-pause]').click();await canvas.scrollIntoViewIfNeeded();await expect.poll(()=>scene.evaluate(e=>e.getSceneEvidence().framePending)).toBe(false);await save('paused');await page.waitForTimeout(400);await page.clock.fastForward(30000);await expect.poll(()=>scene.evaluate(e=>e.getSceneEvidence().framePending)).toBe(false);await save('paused-clock-refresh');
  await ui.locator('[data-world-pause]').click();await canvas.scrollIntoViewIfNeeded();await page.waitForTimeout(250);await page.evaluate(()=>window.scrollTo({top:document.body.scrollHeight,behavior:'instant'}));await expect.poll(()=>canvas.evaluate(n=>n.getBoundingClientRect().bottom)).toBeLessThanOrEqual(0);if(!noCaptures)await page.screenshot({path:path.join(output,'offscreen.png')});await expect.poll(()=>scene.evaluate(e=>e.getSceneEvidence().framePending)).toBe(false);await save('offscreen');await page.waitForTimeout(350);await canvas.scrollIntoViewIfNeeded();await save('onscreen-before-hidden');
  await page.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,get:()=>true});document.dispatchEvent(new Event('visibilitychange'))});const hidden=await save('hidden');await page.waitForTimeout(350);await page.clock.setSystemTime(new Date('2026-09-12T12:00:00-07:00'));await page.evaluate(()=>{delete document.hidden;document.dispatchEvent(new Event('visibilitychange'))});await save('recovered-immediate');
  await page.waitForTimeout(500);await save('recovered-500ms');await page.waitForTimeout(2000);await save('recovered-2500ms');await page.waitForTimeout(3000);await save('recovered-5500ms');
  if(!noCaptures)await page.screenshot({path:path.join(output,'recovered.png')});await save('recovered-after-paint');
  await page.evaluate(()=>{window.dispatchEvent(new PageTransitionEvent('pagehide',{persisted:true}));window.dispatchEvent(new PageTransitionEvent('pageshow',{persisted:true}))});await page.waitForTimeout(500);await save('bfcache');
 }catch(error){await save('failure').catch(()=>{});throw error}finally{await browser.close()}
})().catch(error=>{console.error(error);process.exitCode=1});
