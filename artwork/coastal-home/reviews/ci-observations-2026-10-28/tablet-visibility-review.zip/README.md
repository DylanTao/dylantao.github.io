# Tablet visibility recovery: read-only diagnosis

The observed failure is an obsolete observation path/budget in the live fixture under a busy software renderer. The evidence does not show the product freezing on recovery. No controller, test or public source edits were made; sealed coffee commit `3412fda4f` is unchanged.

The downloaded CI artifact is exactly17,367,876 bytes with SHA-256 `99c6a9e5b4391d3c8d762c63840981a86d5ad833c67e34355e68a19bc300524b`, matching GitHub's upload receipt. It belongs to source12e724a1c069199007dd975c2833898c7a05c26b/run40739790466/job122997968617. The portable packet retains the original inner trace, raw job log, frozen source, exact timeline and three unmodified trace JPEGs.

The full CI case restores visibility at95.198s and observes the sleep attribute by95.349s. Its first two frame reads still see27. The third locator wait starts95.944s and remains pending when the15s assertion expires at110.372s. Meanwhile the screencast changes from study at97.993s to the sleep room at104.790s and a later sleep view at109.534s. The renderer therefore continues submitting new recovered views while the assertion cannot finish another observation. These trace-relative times describe test execution, not an isolated rendering benchmark.

The complete local native768×1024 probe runs the same installed Date/timer clock plus native RAF/performance, live/pause/30-second refresh/offscreen/hidden change to sleep and persisted-page round trip. It records hidden111 frames, immediate recovery112,500ms144,2.5s265,5.5s445, and post-persisted-page490. IO correctly returns true, even while the synthetic hidden property is set; the visibility handler then resumes. There are no actionable page/console errors. This is an instrumented scenario, not a replacement official test result.

The bounded software comparison isolates the same hidden work-to-sleep transition. It uses the complete served4137 build and native RAF, without repeating screenshots after a software screenshot stability timeout. Served controller source SHA-256 `f16b75875257919658941d1c607b170a132c1ffca6d8835edd582449d554bccc` matches frozen12e; compiled SHA is `612fd60b74786c5cfd30a37a41e6006de811b1132d6c7c32156aad30d0354e4b`.

| Observation starting after visibility restore | Call started | Call completed | Frames returned |
| --- | --- | --- | --- |
| Direct page.evaluate primitive |0.270s |0.292s |22 |
| Direct page.evaluate primitive |0.550s |9.342s |23 |
| Direct page.evaluate primitive |9.594s |13.210s |24 |
| Locator primitive |0.291s |39.741s |27 |
| Locator full evidence |0.348s |49.278s |28 |

The methods are observed concurrently under shared machine load, not randomized isolated timings. They establish advancing product frames and a locator observation that outlasts the15s window. A primitive locator also takes39.45s, so serialization alone is not the cause. The full evidence returned around82KB. Remaining locator requests are deliberately closed at the60s observation bound; those closure errors are diagnostic cleanup, not product page errors. Direct reads can also be delayed by the renderer (8.79s here); they still returned advancing frames within the existing window.

Two retained probe setup failures are explicitly excluded from acceptance: an ambiguous nested summary locator was corrected to the fixture's summary.first(); a software screenshot exceeded its30s stability timeout and was not retried. The subsequent state-only full-sequence probe inherited standalone expect's5s default at the paused refresh and stopped there. Its state is retained, and it is not presented as a hidden recovery failure. The final comparison uses the fixture's15s expectation setting and a separate60s bounded observation.

Minimal suggested fixture repair, owned by the coordinator:

1. Read only needed primitives directly in the page, such as `page.evaluate(() => document.querySelector('[data-home-desk-scene]').getSceneEvidence().frames)`. This avoids the locator's repeated utility-world resolution/adoption and full evidence transfer. A small `{frames, animationSeconds, framePending}` snapshot can serve related checks.
2. Give only positive recovery frame observations a bounded60s timeout, consistent with the existing software functional proof budget. Keep actual pixel motion, paused animation-time equality, offscreen/hidden stillness windows, sleep activity and persisted-page recovery assertions.
3. Make no controller change without evidence of a stopped render loop. These results support a fixture fix and do not establish any startup/FPS/physical-device performance improvement.

`probe.cjs` is the full instrumented scenario; `probe-reads.cjs --software` is the bounded direct-versus-locator comparison. Run with NODE_PATH pointing to the installed repository dependencies and the frozen complete site served at 4137. The packet's scripts prefer its matching `12e` helper/source snapshots; otherwise they read the helpers from C:/dev/dylantao.github.io. No Windows UI automation was used, and both diagnostic browsers are closed.
