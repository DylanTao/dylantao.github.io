import gzip
import hashlib
import json
from pathlib import Path
root=Path.cwd();q=Path(__file__).resolve().parent
packet=root/'artwork/coastal-home/reviews/overlap-visibility-2026-11-02'
index=packet/'MANIFEST.json';d=json.loads(index.read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
for row in d['files']:
    assert sha((packet/row['path']).read_bytes())==row['sha256']
def deposit(relative,body):
    target=packet/(relative+'.gz');assert not target.exists()
    target.parent.mkdir(parents=True,exist_ok=True)
    stored=gzip.compress(body,mtime=0);target.write_bytes(stored)
    d['files'].append({'path':target.relative_to(packet).as_posix(),'bytes':len(stored),'sha256':sha(stored),'encoding':'gzip','bodyBytes':len(body),'bodySha256':sha(body)})
for mode in ['python','build']:
    receipt=json.loads((q/'overlap-tool-checkpoint'/(mode+'-final.json')).read_bytes())
    assert receipt['exitCode']==0
    for ext in ['json','log']:
        deposit('final-gates/'+mode+'-final.'+ext,(q/'overlap-tool-checkpoint'/(mode+'-final.'+ext)).read_bytes())
assert b'Ran 404 tests'in(q/'overlap-tool-checkpoint/python-final.log').read_bytes()
for name in ['EXPORTER-DELIVERY.json','check-exporter-delivery.py','run-overlap-checkpoint-gate.py','finalize-overlap-checkpoint.py']:
    deposit('final-gates/'+name,(q/name).read_bytes())
delivery=json.loads((q/'EXPORTER-DELIVERY.json').read_bytes())
assert delivery['visual']['conclusion']=='success'and len(delivery['visual']['jobs'])==42
assert all(j['conclusion']=='success'for j in delivery['visual']['jobs'])
old=q/'exporter-checkpoint/site/al-folio';new=q/'overlap-tool-checkpoint/site/al-folio'
paths=[p.relative_to(old).as_posix()for p in sorted((old/'assets/js').rglob('*.mjs'))]
paths+=['assets/js/module-build.json','assets/models/home/manifest.json','assets/models/home/static-light-field.json']
rows=[]
for name in paths:
    a=(old/name).read_bytes();b=(new/name).read_bytes();assert a==b,name
    rows.append({'path':name,'bytes':len(b),'sha256':sha(b)})
deposit('FINAL-PRODUCTION-PARITY.json',(json.dumps({'scope':'Complete current production build and preceding exporter build have exact compiled .mjs bodies, module build inventory, manifest and official cache. No public runtime geometry/appearance change in this checker checkpoint.','responses':rows},indent=2)+'\n').encode())
source=json.loads(gzip.decompress((packet/'SOURCE.json.gz').read_bytes()))
for row in source['files']:
    assert sha((root/row['path']).read_bytes().replace(b'\r\n',b'\n'))==row['gitLfSha256'],row['path']
index.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
print(json.dumps({'payloads':len(d['files']),'storedBytes':sum(r['bytes']for r in d['files']),'exactProductionBodies':len(rows)}))
