from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
root=Path.cwd();q=Path(__file__).resolve().parent/'overlap-tool-checkpoint';work=Path('C:/dev/cqa1102')
mode=sys.argv[1]
assert mode in ['python','build']
out=q/(mode+'-final.json');assert not out.exists()
env=dict(os.environ,BUNDLE_PATH='C:/tools/site-gems-ruby33',JEKYLL_ENV='production',MAGICK_THREAD_LIMIT='4')
env['PATH']='C:/tools/site-bin;'+env['PATH']
if mode=='python':
    command=[sys.executable,'-X','utf8','-m','unittest','discover','-s','test','-p','test_*.py']
else:
    target=q/'site/al-folio'
    assert not target.exists()
    target.mkdir(parents=True)
    shutil.copytree(q.parent/'exporter-checkpoint/site/al-folio/assets/img',target/'assets/img')
    command=['C:/tools/Ruby33/bin/ruby.exe','C:/tools/Ruby33/bin/bundle','exec','jekyll','build','--baseurl','/al-folio','--destination',str(target),'--trace']
start=time.monotonic()
with(q/(mode+'-final.log')).open('wb')as log:
    result=subprocess.run(command,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={'at':datetime.now(timezone.utc).isoformat(),'mode':mode,'command':command,'worktree':str(work),'seconds':time.monotonic()-start,'exitCode':result.returncode,'scope':'Selected checker/report/doc checkpoint; pending native/builder/coffee source work excluded. Complete production build reuses unchanged derived images without omitting any assets.'}
out.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps(receipt,indent=2));assert result.returncode==0
