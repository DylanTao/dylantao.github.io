from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess
import urllib.request
root=Path.cwd()
q=Path(__file__).resolve().parent
source='badf7449d06df2c1d6e9821c516c79779e68480e'
pages='1ff9a07d013a37ea8fcfe639b8356b9beb6bb76f'
assert source in subprocess.check_output(['git','log','-1','--format=%s',pages],text=True)
paths=['index.html','assets/js/home-scene/walk-controls.mjs','assets/js/home-scene/controller.mjs','assets/js/home-scene/arrival-rill.mjs','assets/js/home-scene/static-light-field.mjs','assets/models/home/manifest.json','assets/models/home/static-light-field.json','assets/js/module-build.json']
sha=lambda b:hashlib.sha256(b).hexdigest()
def check(path):
    expected=subprocess.check_output(['git','show',pages+':'+path])
    url='https://dylantao.github.io/'+(''if path=='index.html'else path)+'?exporter='+source[:9]
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Sirui-site-delivery-check/1.0','Cache-Control':'no-cache'}),timeout=45)as r:
        body=r.read();row={'path':path,'url':url,'status':r.status,'bytes':len(body),'sha256':sha(body),'pinnedSha256':sha(expected),'exact':body==expected}
    assert row['status']==200 and row['exact'],row
    return row
with ThreadPoolExecutor(max_workers=4)as pool:
    rows=list(pool.map(check,paths))
runs=json.loads(subprocess.check_output(['gh','run','list','--commit',source,'--limit','20','--json','databaseId,workflowName,status,conclusion'],text=True))
visual=json.loads(subprocess.check_output(['gh','run','view','41490889765','--json','status,conclusion,jobs'],text=True))
receipt={'at':datetime.now(timezone.utc).isoformat(),'source':source,'pages':pages,'responses':rows,'workflows':runs,'visual':{k:visual[k]for k in ['status','conclusion','jobs']},'scope':'Exact live body readback of pinned deployed exporter/Walk source checkpoint; CI state is recorded directly. Public native/models remain1e10. Does not admit private fin, garden or coffee work.'}
out=q/('EXPORTER-DELIVERY.json'if visual['conclusion']=='success'else'EXPORTER-DELIVERY-INTERIM.json')
assert not out.exists()
out.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps({'source':source,'pages':pages,'exactResponses':len(rows),'visualStatus':visual['status'],'visualConclusion':visual['conclusion'],'greenJobs':sum(j['conclusion']=='success'for j in visual['jobs'])}))
