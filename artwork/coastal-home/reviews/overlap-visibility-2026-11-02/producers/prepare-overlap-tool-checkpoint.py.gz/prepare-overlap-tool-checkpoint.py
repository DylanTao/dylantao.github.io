from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
root=Path.cwd()
q=Path(__file__).resolve().parent
out=q/'overlap-tool-checkpoint'
assert not out.exists()
out.mkdir()
old=root/'artwork/coastal-home/reviews/house-2026-10-24/overlap-audit.json'
shutil.copyfile(old,out/'prior-overlap-audit.json')
command=[sys.executable,'bin/summarize_coastal_overlaps.py',
         '--audit='+str(q/'overlap-tool-current-canonical-v1/native/AUDIT.json'),
         '--delivered='+str(q/'overlap-tool-current-canonical-v1/decoded/AUDIT.json'),
         '--before='+str(out/'prior-overlap-audit.json'),
         '--out='+str(out/'overlap-audit.json')]
with(out/'summarize.log').open('wb')as log:
    result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0
d=json.loads((out/'overlap-audit.json').read_bytes())
assert d['sourceSha256']=='1e10b25d5cf0eec87d7001acbf9d938d65ba33af6076380d5a8e5d45cf3d23e7'
assert d['totals']['deepSitesOver5cm']<=350 and d['totals']['deepSeverity']<=50250
assert d['totals']['zFightingVisibleAreaM2']<=2.2 and d['delivered']['totals']['zFightingVisibleAreaM2']<=2.5
work=Path('C:/dev/cqa1102')
files=['bin/audit_coastal_overlaps.py','bin/test_coastal_overlap_visibility.py','test/test_coastal_overlap_closure.py','test/test_coastal_overlap_witness.py']
for rel in files:
    shutil.copyfile(root/rel,work/rel)
shutil.copyfile(out/'overlap-audit.json',work/old.relative_to(root))
command=[sys.executable,'-X','utf8','-m','unittest','test.test_coastal_overlap_audit','test.test_coastal_overlap_closure','test.test_coastal_overlap_witness']
with(out/'targeted-python.log').open('wb')as log:
    result=subprocess.run(command,cwd=work,stdout=log,stderr=subprocess.STDOUT)
receipt={'at':datetime.now(timezone.utc).isoformat(),'command':command,'exitCode':result.returncode,
         'source':d['sourceSha256'],'nativeTotals':d['totals'],'deliveredTotals':d['delivered']['totals']}
(out/'TARGETED.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps(receipt,indent=2))
assert result.returncode==0
