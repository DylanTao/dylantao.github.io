import gzip
import hashlib
import json
from pathlib import Path
import shutil
root=Path.cwd();q=Path(__file__).resolve().parent
packet=root/'artwork/coastal-home/reviews/overlap-visibility-2026-11-02'
assert sorted(p.name for p in packet.iterdir())==['README.md']
sha=lambda b:hashlib.sha256(b).hexdigest()
records=[]
def deposit(relative,body):
    target=packet/(relative+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
    assert not target.exists()
    stored=gzip.compress(body,mtime=0);target.write_bytes(stored)
    records.append({'path':target.relative_to(packet).as_posix(),'bytes':len(stored),'sha256':sha(stored),'encoding':'gzip','bodyBytes':len(body),'bodySha256':sha(body)})
for mode in ['native','decoded']:
    for name in ['AUDIT.json','PROCESS.json','INVOCATION.json','AUDIT.log']:
        deposit('canonical/'+mode+'/'+name,(q/'overlap-tool-current-canonical-v1'/mode/name).read_bytes())
for name in ['prior-overlap-audit.json','prior-overlap-verdicts.json','TARGETED.json','targeted-python.log','TARGETED-DISCOVERY.json','targeted-discovery.log','reviewed-summarize.log']:
    deposit('gates/'+name,(q/'overlap-tool-checkpoint'/name).read_bytes())
for name in ['OVERLAP-PORTABLE-CONTROLS.json','OVERLAP-OPTIONAL-NATIVE-CONTROLS.json','overlap-portable-controls.log','overlap-optional-native-controls.log','EXPORTER-DELIVERY-INTERIM.json']:
    deposit(name,(q/name).read_bytes())
files=['bin/audit_coastal_overlaps.py','bin/test_coastal_overlap_visibility.py','test/test_coastal_overlap_closure.py','test/test_coastal_overlap_witness.py','test/test_resting_review_custody.py','artwork/coastal-home/reviews/house-2026-10-24/overlap-audit.json','artwork/coastal-home/reviews/house-2026-10-24/overlap-verdicts.json','docs/october-2026-handoff.md']
sources=[]
for name in files:
    body=(root/name).read_bytes();deposit('selected-source/'+name,body)
    sources.append({'path':name,'gitLfSha256':sha(body.replace(b'\r\n',b'\n'))})
for name in ['launch-final-audit.py','prepare-overlap-tool-checkpoint.py','review-canonical-overlap-pairs.py','check-exporter-delivery.py','archive-overlap-checkpoint.py']:
    deposit('producers/'+name,(q/name).read_bytes())
deposit('SOURCE.json',(json.dumps({'parent':'badf7449d06df2c1d6e9821c516c79779e68480e','scope':'Exact selected overlap-checker/report/test/doc paths; native/assets/cache and pending builder work are excluded. Every current global threshold remains unchanged.','files':sources},indent=2)+'\n').encode())
(packet/'MANIFEST.json').write_text(json.dumps({'schema':'coastal-overlap-visibility-v1','scope':'Actual unmodified canonical native and decoded audits; portableBlendercontrols, optional private-source witness clearly separate, exact selected programs, original test-import failure and corrected discovery, pinned exporter deployment/live receipt. Final gates appended before first publication; README is editorial.','files':records},indent=2)+'\n',encoding='utf8')
work=Path('C:/dev/cqa1102')
for name in files:
    shutil.copyfile(root/name,work/name)
assert not(work/packet.relative_to(root)).exists()
shutil.copytree(packet,work/packet.relative_to(root))
print(json.dumps({'payloads':len(records),'storedBytes':sum(r['bytes']for r in records)}))
