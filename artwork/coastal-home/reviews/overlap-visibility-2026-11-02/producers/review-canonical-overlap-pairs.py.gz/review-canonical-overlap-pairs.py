"""Retain newly measurable furniture pairs as bounded follow-ups, not repairs."""
import json
from pathlib import Path
import shutil
import subprocess
import sys
root=Path.cwd();q=Path(__file__).resolve().parent
packet=q/'overlap-tool-checkpoint'
path=root/'artwork/coastal-home/reviews/house-2026-10-24/overlap-verdicts.json'
before=path.read_bytes()
assert not(packet/'prior-overlap-verdicts.json').exists()
(packet/'prior-overlap-verdicts.json').write_bytes(before)
d=json.loads(before);pairs=d['pairs']
key='furniture:kitchen-glass-fridge/glass-fridge.lod0__fridge bottle | furniture:kitchen-glass-fridge/glass-fridge.lod0__fridge label '
assert pairs[key]['verdict']=='follow-up' and 'maxDepthM'not in pairs[key]
pairs[key].update(maxDepthM=.039,maxSeamM=7.506)
pairs[key]['reason']+=' November2 exact-position closure also measures the retained capped label cylinders inside bottle bodies (builder radii51.5mm/50mm). The newly recorded depth/seam limits bound this existing overlap; no furniture repair or blanket label exemption is claimed.'
key='furniture:living-sofa/cloud-sofa.lod0__cloud boucle textile | furniture:living-sofa/cloud-sofa.lod0__honey ash'
assert key not in pairs
pairs[key]={'verdict':'follow-up','reason':'Exact-position closure makes six retained cushion/plinth crossings measurable in the unchanged cloud sofa. The source uses puffy seats over honey-ash plinths, and the worst site is at the low base. This checkpoint records the finite existing overlap for a future owning furniture fit; it does not establish that every crossing is intentional or repaired.','maxDepthM':.101,'maxSeamM':2.553}
key='furniture:kitchen-glass-fridge/glass-fridge.lod0::fridge door_ | furniture:kitchen-glass-fridge/glass-fridge.lod0__furniture pol'
assert key not in pairs
pairs[key]={'verdict':'follow-up','reason':'Four existing lower glass-fridge door/frame crossings become measurable with exact-position closure. The unchanged delivered component pair and worst low hinge/threshold site remain in the raw report. Review the owning door/frame fit at the next furniture export; no contact-rule exemption or repair is inferred.','maxDepthM':.04,'maxSeamM':3.107}
path.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
command=[sys.executable,'bin/summarize_coastal_overlaps.py','--audit='+str(q/'overlap-tool-current-canonical-v1/native/AUDIT.json'),'--delivered='+str(q/'overlap-tool-current-canonical-v1/decoded/AUDIT.json'),'--before='+str(packet/'prior-overlap-audit.json'),'--out='+str(packet/'reviewed-overlap-audit.json')]
with(packet/'reviewed-summarize.log').open('wb')as log:
    result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0
work=Path('C:/dev/cqa1102')
shutil.copyfile(path,work/path.relative_to(root))
shutil.copyfile(packet/'reviewed-overlap-audit.json',work/'artwork/coastal-home/reviews/house-2026-10-24/overlap-audit.json')
command=[sys.executable,'-X','utf8','-m','unittest','discover','-s','test','-p','test_coastal_overlap*.py']
with(packet/'targeted-discovery.log').open('wb')as log:
    result=subprocess.run(command,cwd=work,stdout=log,stderr=subprocess.STDOUT)
(packet/'TARGETED-DISCOVERY.json').write_text(json.dumps({'command':command,'exitCode':result.returncode,'priorImportFailureRetained':'targeted-python.log','boundsPolicy':'Onlythree unchanged furniture pair follow-ups newly need depth/seam bounds. All global and individual ratchets unchanged; no sites or severity removed.'},indent=2)+'\n',encoding='utf8')
assert result.returncode==0
shutil.copyfile(packet/'reviewed-overlap-audit.json',root/'artwork/coastal-home/reviews/house-2026-10-24/overlap-audit.json')
print('All15 overlap tests pass with unchanged global gates and three bounded existing-furniture follow-ups.')
