import gzip
import hashlib
import json
import struct
from pathlib import Path

q = Path(__file__).resolve().parent
root = Path.cwd()
(q / "baseline-models").mkdir(exist_ok=True)
for room in ["sleep", "kitchen"]:
    data = (root / f"assets/models/home/room-{room}.glb").read_bytes()
    (q / "baseline-models" / f"room-{room}.glb").write_bytes(data)
    control = (q / f"control-{room}" / f"room-{room}.glb").read_bytes()
    def binary(body): return body[28 + struct.unpack_from("<I", body, 12)[0]:]
    assert binary(data) == binary(control), room
raw = root / "artwork/coastal-home/reviews/nook-olive-2026-11-01/raw"
for name in ["NATIVE-TWIG-OWNERSHIP.json.gz"]:
    (q / name).write_bytes((raw / name).read_bytes())
(q / "qualify-wood-quantization.py").write_bytes(gzip.decompress((raw / "qualify-wood-quantization.py.gz").read_bytes()))


def adapt(name, replacements):
    packet = "nook-olive-2026-11-01" if "plant" in name else "bedroom-ambience-2026-11-01"
    source = gzip.decompress((root / "artwork/coastal-home/reviews" / packet / "raw" / (name + ".gz")).read_bytes()).decode("utf8").replace("\r\n", "\n")
    original = source
    for before, after in replacements:
        assert source.count(before) == 1, before
        source = source.replace(before, after)
    (q / name).write_text(source, encoding="utf8", newline="\n")
    return {"producer": name, "originalSourceLF": hashlib.sha256(original.encode()).hexdigest(),
            "adaptedSourceLF": hashlib.sha256(source.encode()).hexdigest(),
            "changes": [{"before": a, "after": b} for a, b in replacements]}


rows = [adapt("compare-shade-delivered.mjs", [
    ('.jekyll-cache/visual-qa/interior-ambience-20261101', '.jekyll-cache/visual-qa/house-ambience-integration-20261102'),
    ('served/assets/models/home/room-sleep.glb', 'baseline-models/room-sleep.glb'),
    ('shade-before-level10/room-sleep.glb', 'control-sleep/room-sleep.glb'),
    ('shade-after-level10/room-sleep.glb', 'exports-sleep/room-sleep.glb'),
    ('served/assets/models/home', 'baseline-models'),
    ('shade-after-level10', 'exports-sleep'),
]), adapt("compare-plant-delivered.mjs", [
    ('.jekyll-cache/visual-qa/nook-plant-20261101', '.jekyll-cache/visual-qa/house-ambience-integration-20261102'),
    ('C:/dev/site-takeover-worktrees/interior-ambience-20261101/.jekyll-cache/visual-qa/interior-ambience-20261101/candidate-site/al-folio/assets/models/home',
     (q / 'baseline-models').as_posix()),
    ('candidate-site/al-folio/assets/models/home', 'exports-kitchen'),
])]
(q / "comparison-producer-bindings.json").write_text(json.dumps({"scope": "Only input/output directory substitutions in the retained original comparison sources; assertions unchanged.", "rows": rows, "noEditBinsExact": ["sleep", "kitchen"]}, indent=2) + "\n", encoding="utf8")
print(json.dumps({"noEditBinsExact": ["sleep", "kitchen"], "adaptedProducers": len(rows)}))
