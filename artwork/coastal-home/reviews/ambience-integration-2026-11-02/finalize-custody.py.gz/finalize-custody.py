import hashlib
import json
from pathlib import Path

for folder in ["bedroom-ambience-2026-11-01", "nook-olive-2026-11-01"]:
    base = Path("artwork/coastal-home/reviews") / folder
    rows = []
    for path in sorted(base.rglob("*")):
        if not path.is_file() or path.name == "MANIFEST.json" or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        data = path.read_bytes()
        rows.append({"path": path.relative_to(base).as_posix(), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    (base / "MANIFEST.json").write_text(json.dumps({"schemaVersion": 1, "scope": "Actual portable payloads after the explicit CUSTODY-CORRECTION; original failed index retained compressed.", "files": rows}, indent=2) + "\n", encoding="utf8", newline="\n")
    print(json.dumps({"folder": folder, "payloads": len(rows)}))
