"""Retain the defective original indices and correct their portable payload inventory."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path.cwd()


def digest(data):
    return hashlib.sha256(data).hexdigest()


for folder, helper in [("bedroom-ambience-2026-11-01", "replay_lighting.py"),
                       ("nook-olive-2026-11-01", "replay_nook_olive.py")]:
    base = ROOT / "artwork/coastal-home/reviews" / folder
    assert not (base / "original-working-index.json.gz").exists()
    index_bytes = (base / "MANIFEST.json").read_bytes()
    original = json.loads(index_bytes)
    (base / "original-working-index.json.gz").write_bytes(gzip.compress(index_bytes, mtime=0))
    row = next(row for row in original["files"] if row["path"] == helper)
    lf = (base / helper).read_bytes().replace(b"\r\n", b"\n")
    crlf = lf.replace(b"\n", b"\r\n")
    assert len(crlf) == row["bytes"] and digest(crlf) == row["sha256"], folder
    (base / ("original-working-" + helper + ".gz")).write_bytes(gzip.compress(crlf, mtime=0))
    readme = (base / "README.md").read_bytes()
    readme_row = next(row for row in original["files"] if row["path"] == "README.md")
    assert len(readme) == readme_row["bytes"] and digest(readme) == readme_row["sha256"]
    (base / "original-readme.md.gz").write_bytes(gzip.compress(readme, mtime=0))
    omitted = [row for row in original["files"] if "__pycache__" in row["path"] or row["path"].endswith(".pyc")]
    note = {
        "recordedAt": "2026-11-02", "status": "Original working-tree seal was not portable; retained as a failed custody control.",
        "originalIndex": {"path": "original-working-index.json.gz", "uncompressedSha256": digest(index_bytes)},
        "lineEndingRepair": {"path": helper, "originalWorkingBytes": row["bytes"], "originalWorkingSha256": row["sha256"],
            "committedLFBytes": len(lf), "committedLFSha256": digest(lf),
            "verifiedReconstruction": "Restoring only CRLF exactly reproduces the original index size/hash; compressed original working helper retained. Current executable helper remains the committed LF source."},
        "omittedInterpreterCache": omitted,
        "omissionReason": "Ignored generated interpreter bytecode was listed by a filesystem sweep but was absent from the worker commit. It is not supplied or required as source/evidence; the original missing entry remains in the retained failed index.",
        "originalReadme": {"path": "original-readme.md.gz", "uncompressedSha256": digest(readme)},
        "unchangedEvidence": "All other original payload bytes are unchanged and checked against the original index. The new manifest binds actual portable payloads and this correction, not the absent cache. Native/render validation remains separate.",
    }
    # Assert every actually retained original payload before revising the inventory.
    for old in original["files"]:
        if old["path"] in {helper, "README.md"} or old in omitted:
            continue
        data = (base / old["path"]).read_bytes()
        assert len(data) == old["bytes"] and digest(data) == old["sha256"], old["path"]
    (base / "CUSTODY-CORRECTION.json").write_text(json.dumps(note, indent=2) + "\n", encoding="utf8", newline="\n")
    suffix = "\n## Coordinator portability correction, November 2 UTC\n\nThe original working-tree seal failed against the committed payload: it hashed\nCRLF helper bytes and, for the bedroom packet, listed an ignored interpreter\ncache. [The correction](CUSTODY-CORRECTION.json) retains that original failed\nindex, verifies the line-ending-only difference and seals the supplied LF source\nand evidence. The original native/render findings are unchanged; the old seal\nis not relabeled as passing.\n"
    (base / "README.md").write_bytes(readme + suffix.encode())
    print(json.dumps({"folder": folder, "helperOriginalBytes": len(crlf), "helperLFBytes": len(lf), "omittedCaches": len(omitted)}))
