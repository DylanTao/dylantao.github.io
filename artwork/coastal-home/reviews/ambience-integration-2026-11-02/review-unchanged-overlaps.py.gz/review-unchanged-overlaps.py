import json
from pathlib import Path

root = Path.cwd()
q = Path(__file__).resolve().parent
audit = json.loads((root / "artwork/coastal-home/reviews/house-2026-10-24/overlap-audit.json").read_text(encoding="utf8"))
native = json.loads((q / "native-delta-audit.json").read_text(encoding="utf8"))
path = root / "artwork/coastal-home/reviews/house-2026-10-24/overlap-verdicts.json"
verdicts = json.loads(path.read_text(encoding="utf8"))
reviewed = []
for row in audit["deepOffenderPairs"][:60]:
    pair = row["pair"]
    selected = {
        "core_estate_library_liftaway_roof | core_flora_yucca_skirt",
        "core_arrival_paths__travertine paving stone | core_estate_garden_flora_grass",
    }
    if pair in verdicts["pairs"] and pair not in selected:
        continue
    owners = pair.split(" | ")
    assert len(owners) == 2 and all(name in native["unowned"] for name in owners), pair
    assert all(native["unowned"][name]["before"] == native["unowned"][name]["after"] for name in owners)
    assert pair in selected, pair
    verdicts["pairs"][pair] = {
        "verdict": "follow-up",
        "maxDepthM": row["maxDepthM"],
        "maxSeamM": row["seamM"],
        "reason": f"Both original owners' complete geometry, normals, numeric attributes, material slots and world matrix remain exact from de217 to the lighting/olive source1e10 (the independent native-delta audit). The refreshed seeded audit ranks {row['sites']} retained sites here, maximum sampled depth {row['maxDepthM']}m and seam{row['seamM']}m, worst native point{row['worstSite']}. This is an existing bounded plant/roof or plant/path intersection to inspect with the pending exterior/arrival composition; the lighting/olive checkpoint neither repairs it nor claims whole-plant contact or solid overlap volume. No ratchet or geometric exclusion is changed.",
        "evidence": "artwork/coastal-home/reviews/ambience-integration-2026-11-02/README.md",
    }
    reviewed.append(row)
assert len(reviewed) == 2
path.write_text(json.dumps(verdicts, indent=2, ensure_ascii=False) + "\n", encoding="utf8", newline="\n")
(q / "unchanged-overlap-review.json").write_text(json.dumps({"scope": "Two newly ranked existing pairs, independently unchanged native fields. Follow-up, not a clearance or repair claim.", "nativeUnownedExact": native["unownedExact"], "pairs": reviewed}, indent=2) + "\n", encoding="utf8")
print(json.dumps({"reviewedExistingPairs": len(reviewed), "ratchetsUnchanged": True}))
