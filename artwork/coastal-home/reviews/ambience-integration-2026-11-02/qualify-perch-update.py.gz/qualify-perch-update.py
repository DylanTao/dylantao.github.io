import hashlib
import json
from pathlib import Path

root = Path.cwd()
q = Path(__file__).resolve().parent
target = root / "assets/models/home/wildlife-perch-support.json"
original_bytes = target.read_bytes()
new_bytes = (q / "wildlife-perch-support.json").read_bytes()
before, after = json.loads(original_bytes), json.loads(new_bytes)
old_source, new_source = before.pop("coastSha256"), after.pop("coastSha256")
assert old_source == "de217984242f77903145dd6d16f277923b57fd5e3eb2469c906c2507b494ad87"
assert new_source == hashlib.sha256((root / "artwork/coastal-home/coastal-home.blend").read_bytes()).hexdigest()
assert before == after, "Actual regenerated perch geometry or decoded contacts changed"
target.write_bytes(new_bytes)
(q / "perch-regeneration.json").write_text(json.dumps({
    "scope": "Official regeneration on the new canonical source; all patch/sole/ankle/tarsus/delivered geometry and fields exact, only source-file binding changes.",
    "beforeSource": old_source, "afterSource": new_source,
    "beforeSha256": hashlib.sha256(original_bytes).hexdigest(), "afterSha256": hashlib.sha256(new_bytes).hexdigest(),
    "patches": len(after["patches"]), "allOtherFieldsExact": True,
}, indent=2) + "\n", encoding="utf8", newline="\n")
print(json.dumps({"patches": len(after["patches"]), "allOtherFieldsExact": True}))
