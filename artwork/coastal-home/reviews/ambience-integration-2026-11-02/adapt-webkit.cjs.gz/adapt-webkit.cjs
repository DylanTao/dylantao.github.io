const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const q = __dirname, server = JSON.parse(fs.readFileSync(path.join(q, 'server.json'))), records = [];
function adapt(input, output, oldPort) {
  let source = fs.readFileSync(path.join(q,input),'utf8');
  const originalSha256 = crypto.createHash('sha256').update(source).digest('hex');
  const pattern = new RegExp('port:\\s*'+oldPort+'(?=[,}])','g');
  if ((source.match(pattern)||[]).length !== 1) throw Error('upstream port count');
  source = source.replace(pattern, 'port: '+server.port);
  source = source.replaceAll('own'+oldPort, 'integrated'+server.port).replaceAll('owned'+oldPort, 'owned'+server.port);
  source = source.replace('Final combined native AO remains required.', 'Official24sample owned leaf/branch AO and indirect bake is included; other461 native meshes exact.');
  fs.writeFileSync(path.join(q,output),source);
  records.push({input,output,originalSha256,adaptedSha256:crypto.createHash('sha256').update(source).digest('hex')});
}
adapt('reference-capture-shade-webkit-clean.cjs','capture-integrated-shade-webkit.cjs',4203);
adapt('reference-capture-plant-webkit-qualified.cjs','capture-integrated-plant-webkit.cjs',4206);
fs.writeFileSync(path.join(q,'webkit-producer-bindings.json'),JSON.stringify({scope:'Only upstream preview address and evidence captions changed. Complete product, public touch controls and assertions preserved; Linux software appearance/function only.',server,records},null,2));
console.log(JSON.stringify({port:server.port,producers:records.length}));
