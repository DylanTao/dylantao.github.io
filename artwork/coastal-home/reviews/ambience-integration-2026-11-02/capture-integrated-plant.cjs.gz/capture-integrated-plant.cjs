const fs = require("node:fs"),
  path = require("node:path"),
  crypto = require("node:crypto");
const {
  chromium,
  expect,
} = require("C:/dev/dylantao.github.io/node_modules/@playwright/test");
const q = __dirname,
  rows = [],
  errors = [],
  failures = [],
  responses = [];
async function evidence(page) {
  return page
    .locator("[data-home-desk-scene]")
    .evaluate((e) => e.getSceneEvidence());
}
async function settled(page) {
  let previous;
  for (let n = 0; n < 80; n++) {
    const e = await evidence(page);
    if (
      previous &&
      !e.traveling &&
      Math.hypot(...e.camera.map((v, i) => v - previous[i])) < 1e-5
    )
      return e;
    previous = e.camera;
    await page.waitForTimeout(150);
  }
  throw Error("Camera did not settle");
}
async function theme(page, mode) {
  await page.locator("[data-theme-toggle]:visible").first().click();
  await page
    .locator(`[data-theme-mode-option="${mode}"]:visible`)
    .first()
    .click();
  await page.locator("[data-theme-toggle]:visible").first().click();
}
(async () => {
  const browser = await chromium.launch({
    headless: true,
    args: ["--use-angle=d3d11", "--ignore-gpu-blocklist"],
  });
  try {
    for (const [variant, port] of [
      ["baseline", 55012],
      ["v4", 55608],
    ]) {
      const context = await browser.newContext({
        viewport: { width: 2560, height: 1440 },
        deviceScaleFactor: 1,
        timezoneId: "America/Los_Angeles",
        reducedMotion: "no-preference",
      });
      await context.addInitScript(() => {
        globalThis.__plantContexts = [];
        const original = HTMLCanvasElement.prototype.getContext;
        HTMLCanvasElement.prototype.getContext = function (...args) {
          const value = original.apply(this, args);
          if (
            value &&
            /^webgl/.test(args[0]) &&
            !globalThis.__plantContexts.includes(value)
          )
            globalThis.__plantContexts.push(value);
          return value;
        };
      });
      const page = await context.newPage();
      page.setDefaultTimeout(120000);
      page.on("pageerror", (e) =>
        errors.push({ variant, type: "page", message: e.message }),
      );
      page.on("console", (m) => {
        if (m.type() === "error")
          errors.push({ variant, type: "console", message: m.text() });
      });
      page.on("requestfailed", (r) =>
        failures.push({ variant, url: r.url(), error: r.failure() }),
      );
      page.on("response", async (r) => {
        if (
          new URL(r.url()).port === String(port) &&
          /\.(mjs|glb|json)(?:\?|$)/.test(r.url())
        )
          try {
            const b = await r.body();
            responses.push({
              variant,
              url: r.url(),
              status: r.status(),
              sha256: crypto.createHash("sha256").update(b).digest("hex"),
              bytes: b.length,
              owner: r.headers()["x-sirui-preview"],
            });
          } catch (e) {
            responses.push({ variant, url: r.url(), readError: String(e) });
          }
      });
      await page.route(
        /https:\/\/(?:plausible\.io|www\.google-analytics\.com|www\.googletagmanager\.com)\//,
        (r) => r.fulfill({ status: 200, body: "" }),
      );
      await page.goto(
        `http://127.0.0.1:${port}/al-folio/?scene-lab=1&quality=high&resolution=fixed&msaa=2&weather=clear`,
        { waitUntil: "domcontentloaded" },
      );
      await page.evaluate(() => document.fonts.ready);
      await theme(page, "noon");
      await page.locator('[data-home-desk-mode="3d"]').click();
      const scene = page.locator("[data-home-desk-scene]"),
        ui = page.locator("[data-home-world-controls]");
      await scene.scrollIntoViewIfNeeded();
      await expect(scene).toHaveAttribute("data-scene-state", "ready", {
        timeout: 150000,
      });
      await page.waitForTimeout(700);
      async function motion(paused) {
        const button = ui.locator("[data-world-pause]");
        if ((await button.getAttribute("aria-pressed")) === String(paused))
          return;
        await ui.locator("[data-world-lab]>summary").click();
        await button.click();
        await expect(button).toHaveAttribute("aria-pressed", String(paused));
        await ui.locator("[data-world-lab]>summary").click();
      }
      async function snapshot(mode, view) {
        const e = await settled(page);
        expect(e.simulation.lightField.cacheHit).toBe(true);
        const info = await scene.evaluate((el) => ({
          contexts: globalThis.__plantContexts
            .filter((gl) => gl.canvas.closest("[data-home-desk-scene]"))
            .map((gl) => {
              const ext = gl.getExtension("WEBGL_debug_renderer_info");
              return {
                drawingBuffer: [gl.drawingBufferWidth, gl.drawingBufferHeight],
                renderer: gl.getParameter(
                  ext?.UNMASKED_RENDERER_WEBGL || gl.RENDERER,
                ),
                attributes: gl.getContextAttributes(),
              };
            }),
          clocks: {
            Date: Date.toString(),
            performance: performance.now.toString(),
            raf: requestAnimationFrame.toString(),
            pwClock: Boolean(globalThis.__pwClock),
          },
        }));
        expect(info.contexts[0].drawingBuffer).toEqual([2560, 1440]);
        expect(info.clocks.pwClock).toBe(false);
        await scene
          .locator("canvas")
          .screenshot({
            path: path.join(q, `qualified-${variant}-${mode}-${view}-2k.png`),
          });
        rows.push({
          variant,
          mode,
          view,
          at: new Date().toISOString(),
          viewport: page.viewportSize(),
          pauseAria: await ui
            .locator("[data-world-pause]")
            .getAttribute("aria-pressed"),
          ...info,
          evidence: e,
        });
        fs.writeFileSync(
          path.join(q, "V4-QUALIFIED-APPEARANCE-ROWS.json"),
          JSON.stringify(rows, null, 2),
        );
        console.log(
          JSON.stringify({
            variant,
            mode,
            view,
            buffer: info.contexts[0].drawingBuffer,
            cache: e.simulation.lightField.cacheHit,
            errors: errors.length,
          }),
        );
      }
      for (const mode of ["noon", "evening"]) {
        if (mode !== "noon") await theme(page, mode);
        await ui.locator("[data-world-fullscreen]").click();
        await expect
          .poll(async () => Boolean((await evidence(page)).fullscreen))
          .toBe(true);
        await motion(false);
        await ui.locator("[data-world-places]>summary").click();
        await ui.locator('[data-world-destination="kitchen"]').click();
        await expect
          .poll(async () => (await evidence(page)).currentRoom)
          .toBe("kitchen");
        await page.waitForTimeout(1200);
        await settled(page);
        await motion(true);
        await snapshot(mode, "public-kitchen");
        for (const [view, yaw] of [
          ["front", 0.875],
          ["quarter", 1.35],
        ]) {
          await scene.evaluate(
            (el, yaw) =>
              el.setLabCamera({
                target: [-4.68, 0.45, 3.85],
                yaw,
                pitch: 0.16,
                radius: 3.2,
                free: true,
              }),
            yaw,
          );
          await expect
            .poll(async () =>
              Math.abs((await evidence(page)).cameraOrbit.yaw - yaw),
            )
            .toBeLessThan(0.001);
          await page.waitForTimeout(200);
          await snapshot(mode, view);
        }
        await page.locator("[data-world-exit]").click();
        await page.waitForTimeout(300);
      }
      await page.waitForLoadState("networkidle", { timeout: 30000 });
      await context.close();
    }
    expect(errors).toEqual([]);
    expect(failures).toEqual([]);
  } finally {
    fs.writeFileSync(
      path.join(q, "V4-QUALIFIED-CAPTURE-RECEIPT.json"),
      JSON.stringify(
        {
          scope:
            "Complete frozen rain baseline55012 and integrated shade+fresh-baked-olive product55608; no asset routes/omissions. Native clocks, high/fixed/MSAA2, actual viewport/buffer recorded. Public Noon/Evening Rooms/fullscreen then Pause after normal settled visit. Public kitchen view plus disclosed read-only lab plant angles. Current candidate uses the official24sample owned leaf/branch AO+indirect bake; all461 other native mesh fields exact. Comparison covers the combined checkpoint, not isolated foliage causality. Concurrent appearance/functional only, no timing claim. Original failed producer tried the global theme button while fullscreen; replacement exits through the real public button before selecting theme and re-enters. No source change or forced click.",
          rows: rows.length,
          errors,
          failures,
          responses,
        },
        null,
        2,
      ),
    );
    await browser.close();
  }
})().catch((e) => {
  fs.writeFileSync(
    path.join(q, "V4-QUALIFIED-CAPTURE-FAILURE.txt"),
    String(e.stack || e),
  );
  console.error(e);
  process.exitCode = 1;
});
