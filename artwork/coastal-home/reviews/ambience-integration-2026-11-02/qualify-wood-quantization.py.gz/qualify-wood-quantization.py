from pathlib import Path
import json,gzip,numpy as np
q=Path(__file__).resolve().parent
data=json.loads(gzip.decompress((q/'UNOWNED-WOOD-EXACT-CONTROL.json.gz').read_bytes()));reports=[];mappings=[]
for side,other in [('original','candidate'),('candidate','original')]:
 av=data[side]['vertices'];bv=data[other]['vertices'];a=[json.loads(x)for x in av];b=[json.loads(x)for x in bv];ap=np.array([x['position']for x in a]);bp=np.array([x['position']for x in b]);mapping={};errors={};pairs=[]
 for offset in range(0,len(a),128):
  delta=ap[offset:offset+128,None,:]-bp[None,:,:];squared=np.einsum('ijk,ijk->ij',delta,delta)
  for k,distances in enumerate(squared):
   i=offset+k;minimum=float(distances.min());ids=np.flatnonzero(distances<=minimum+1e-18);j=min(ids,key=lambda j:sum(np.max(np.abs(np.array(a[i][key])-np.array(b[j][key])))for key in a[i]if key!='position'));mapping[av[i]]=bv[j];pairErrors={}
   for key in a[i]:
    error=float(np.max(np.abs(np.array(a[i][key])-np.array(b[j][key]))));errors[key]=max(errors.get(key,0),error);pairErrors[key]=error
   pairs.append({'sourceVertex':i,'mappedVertex':int(j),'errors':pairErrors,'coincidentCandidates':len(ids)})
 actual=[]
 for key in data[side]['triangles']:
  values=[mapping[v]for v in json.loads(key)];actual.append(min(json.dumps(values[k:]+values[:k],separators=(',',':'))for k in range(3)))
 expected=[]
 for key in data[other]['triangles']:
  values=json.loads(key);expected.append(min(json.dumps(values[k:]+values[:k],separators=(',',':'))for k in range(3)))
 assert sorted(actual)==sorted(expected)
 assert errors['position']<=.000322342 and all(value==0 for key,value in errors.items()if key!='position')
 reports.append({'direction':side+'-to-'+other,'unownedVertices':len(av),'unownedTriangles':len(actual),'maximumErrors':errors,'windingPreservedAfterDisclosedMapping':True,'ownedVertices':data[side]['ownedVertices'],'ownedTriangles':data[side]['ownedTriangles'],'maximumOwnedDecodeErrorM':data[side]['maxOwnedDecodeError'],'nearestUnownedToOwnedNativeM':data[side]['nearestUnownedToOwnedNative']});mappings.append({'direction':side+'-to-'+other,'pairs':pairs})
(q/'FINAL-WOOD-QUALIFICATION.json').write_text(json.dumps({'scope':'Native unowned fields exact separately. This is a bounded export quantization proof, not exact delivered POSITION identity. All vertices/faces retained; no tolerance changed in product or existing gates.','controls':reports},indent=2)+'\n',encoding='utf8')
(q/'FINAL-WOOD-MAPPINGS.json.gz').write_bytes(gzip.compress(json.dumps(mappings).encode('utf8'),mtime=0));print(reports)
