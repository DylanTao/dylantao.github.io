"""Run the owning baker on only the newly authored leaves and branches, then audit."""
import array
import gzip
import hashlib
import json
import runpy
import sys
from pathlib import Path

import bpy

ROOT = Path.cwd()
Q = Path(__file__).resolve().parent
ORIGINAL = Q / "olive-replay-v1/candidate.blend"
TARGET = Q / "olive-baked-v1.blend"
OWNED = {"kitchen__olive leaf", "kitchen_nook_olive__honey ash"}
assert bpy.app.version == (4, 5, 9)
assert not TARGET.exists()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


ns = runpy.run_path(str(ROOT / "artwork/coastal-home/reviews/bedroom-ambience-2026-11-01/replay_lighting.py"))


def shape(obj):
    mesh = obj.data
    h = hashlib.sha256()
    h.update(repr(tuple(v for row in obj.matrix_world for v in row)).encode())
    for collection, field, width, kind in [
        (mesh.vertices, "co", 3, "f"), (mesh.vertices, "normal", 3, "f"),
        (mesh.edges, "vertices", 2, "i"), (mesh.loops, "vertex_index", 1, "i"),
        (mesh.polygons, "loop_start", 1, "i"), (mesh.polygons, "loop_total", 1, "i"),
        (mesh.polygons, "material_index", 1, "i"), (mesh.polygons, "use_smooth", 1, "b"),
        (mesh.corner_normals, "vector", 3, "f"),
    ]:
        h.update(ns["stream"](collection, field, width, kind))
    for attr in sorted(mesh.attributes, key=lambda a: a.name):
        if attr.data_type in {"FLOAT_COLOR", "BYTE_COLOR"}:
            continue
        if attr.data_type == "FLOAT_VECTOR": field, width, kind = "vector", 3, "f"
        elif attr.data_type == "FLOAT2": field, width, kind = "vector", 2, "f"
        elif attr.data_type in {"INT16_2D", "INT32_2D", "INT32_4D"}: field, width, kind = "value", 4 if attr.data_type == "INT32_4D" else 2, "i"
        elif attr.data_type in {"FLOAT", "INT", "BOOLEAN", "INT8"}: field, width, kind = "value", 1, "f" if attr.data_type == "FLOAT" else "i"
        else: raise RuntimeError(f"Unhandled shape attribute {attr.name}/{attr.data_type}")
        h.update(repr((attr.name, attr.domain, attr.data_type)).encode())
        h.update(ns["stream"](attr.data, field, width, kind))
    h.update(repr([m.name if m else None for m in mesh.materials]).encode())
    return h.hexdigest()


def world_state(scene):
    inputs = {}
    for node in scene.world.node_tree.nodes:
        for index, socket in enumerate(node.inputs):
            if hasattr(socket, "default_value"):
                value = socket.default_value
                inputs[f"{node.name}|{index}"] = list(value) if hasattr(value, "__len__") and not isinstance(value, str) else value
    return inputs


bpy.ops.wm.open_mainfile(filepath=str(ORIGINAL))
before = ns["native_state"]()
before_materials = ns["materials"]()
owned_shape = {name: shape(bpy.context.scene.objects[name]) for name in OWNED}
assert OWNED.issubset(before)
scene = bpy.context.scene
settings = {"engine": scene.render.engine, "samples": scene.cycles.samples, "device": scene.cycles.device,
            "max_bounces": scene.cycles.max_bounces, "bake_target": scene.render.bake.target}
world = world_state(scene)
hidden = {o.name: o.hide_render for o in scene.objects}
TARGET.write_bytes(ORIGINAL.read_bytes())
assert sha(TARGET) == sha(ORIGINAL)
sys.argv = ["bake_coastal_light.py", "--", f"--source={TARGET}",
            f"--manifest={Q / 'shade-replay-v1/manifest.json'}",
            "--prefixes=kitchen__olive leaf,kitchen_nook_olive__honey ash",
            f"--report={Q / 'owned-olive-bake.json'}"]
runpy.run_path(str(ROOT / "bin/bake_coastal_light.py"), run_name="__main__")
scene = bpy.context.scene
for key, value in world.items():
    name, index = key.rsplit("|", 1)
    scene.world.node_tree.nodes[name].inputs[int(index)].default_value = value
scene.render.engine = settings["engine"]
scene.cycles.samples = settings["samples"]
scene.cycles.device = settings["device"]
scene.cycles.max_bounces = settings["max_bounces"]
scene.render.bake.target = settings["bake_target"]
for name, value in hidden.items(): scene.objects[name].hide_render = value
bpy.ops.wm.save_as_mainfile(filepath=str(TARGET), compress=True)
bpy.ops.wm.open_mainfile(filepath=str(TARGET))
after = ns["native_state"]()
assert set(before) == set(after)
unowned_changes = [name for name in before if name not in OWNED and before[name] != after[name]]
assert not unowned_changes, unowned_changes
assert ns["materials"]() == before_materials
assert world_state(bpy.context.scene) == world
for name in OWNED: assert shape(bpy.context.scene.objects[name]) == owned_shape[name], name
stats = json.loads((Q / "owned-olive-bake.json").read_text(encoding="utf8"))
assert {row["mesh"] for row in stats["surfaces"]} == OWNED
receipt = {"scope": "Official24sample AO/indirect bake of exactly the40replacement leaves and6newbranches. All other native mesh fields/materials exact; owned shape/normals/UV/materialslots exact. Original world/render settings restored after the owning baker.",
           "inputSha256": sha(ORIGINAL), "outputSha256": sha(TARGET), "blender": bpy.app.version_string,
           "owned": sorted(OWNED), "unownedMeshesExact": len(before) - len(OWNED), "unownedChanges": unowned_changes,
           "ownedShapeHashes": owned_shape, "bake": stats,
           "bakerSha256": sha(ROOT / "bin/bake_coastal_light.py"), "producerSha256": sha(Path(__file__))}
(Q / "owned-olive-bake-audit.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf8")
print(json.dumps({"unownedMeshesExact": receipt["unownedMeshesExact"], "outputSha256": receipt["outputSha256"], "surfaces": stats["surfaces"]}))
