const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const q=__dirname,server=JSON.parse(fs.readFileSync(path.join(q,'server.json'))),rows=[];
const digest=s=>crypto.createHash('sha256').update(s).digest('hex');
function adapt(input,output,fn){const original=fs.readFileSync(path.join(q,input),'utf8'),source=fn(original);fs.writeFileSync(path.join(q,output),source);rows.push({input,output,originalSha256:digest(original),adaptedSha256:digest(source)});}
function once(s,a,b){if(s.split(a).length!==2)throw Error('Changed capture anchor '+a);return s.replace(a,b);}
adapt('reference-capture-shade-qualified.cjs','capture-integrated-shade.cjs',s=>{
 s=once(s,'http://127.0.0.1:4203/al-folio/',server.url);
 const regex=/for \(const room of \[\s*"sleep",\s*"library-upper",\s*"bath-bedroom",\s*"onsen",\s*"kitchen",\s*\]\)/;
 if(!regex.test(s))throw Error('Changed room-scope loop');s=s.replace(regex,'for (const room of ["sleep", "library-upper"])');
 s=once(s,'Actual complete own4203 exact native shade-role control plus prior coverage/anchor changes','Actual complete integrated shade+fresh-baked-olive product on'+server.port+'; two affected rooms, six views each');return s;
});
adapt('reference-capture-v4-qualified.cjs','capture-integrated-plant.cjs',s=>{
 s=once(s,'["baseline", 4203]','["baseline", 55012]');s=once(s,'["v4", 4206]','["v4", '+server.port+']');
 s=once(s,'Complete1364-file products4203 sealed shade baseline and4206 plant control','Complete frozen rain baseline55012 and integrated shade+fresh-baked-olive product'+server.port);
 s=once(s,'Existing leaf vertex modulation copied, final combined native AO remains required.','Current candidate uses the official24sample owned leaf/branch AO+indirect bake; all461 other native mesh fields exact. Comparison covers the combined checkpoint, not isolated foliage causality.');return s;
});
fs.writeFileSync(path.join(q,'capture-producer-bindings.json'),JSON.stringify({scope:'Only server addresses, declared affected-room scope and evidence captions adapted from retained qualified producers. Public UI/actions and assertions remain; observer-only GL readback, no clocks/shader/geometry replacement.',rows},null,2));
console.log(JSON.stringify({port:server.port,producers:rows.length}));
