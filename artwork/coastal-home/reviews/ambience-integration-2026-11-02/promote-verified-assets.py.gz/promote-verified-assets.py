import hashlib
import json
from pathlib import Path

root = Path.cwd()
q = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
native = root / "artwork/coastal-home/coastal-home.blend"
assert sha(native.read_bytes()) == "de217984242f77903145dd6d16f277923b57fd5e3eb2469c906c2507b494ad87"
assert sha((q / "olive-baked-v1.blend").read_bytes()) == "1e10b25d5cf0eec87d7001acbf9d938d65ba33af6076380d5a8e5d45cf3d23e7"
for room in ["sleep", "kitchen"]:
    assert (root / f"assets/models/home/room-{room}.glb").read_bytes() == (q / "baseline-models" / f"room-{room}.glb").read_bytes()
manifest = root / "assets/models/home/manifest.json"
assert manifest.read_bytes() == (q / "base-manifest.json").read_bytes()
assert json.loads((q / "SHADE-DECODED-PRESERVATION.json").read_text())["control10BinExact"]
wood = json.loads((q / "FINAL-WOOD-QUALIFICATION.json").read_text())
assert len(wood["controls"]) == 2 and all(row["windingPreservedAfterDisclosedMapping"] for row in wood["controls"])
paths = [(q / "olive-baked-v1.blend", native),
         (q / "exports-sleep/room-sleep.glb", root / "assets/models/home/room-sleep.glb"),
         (q / "exports-kitchen/room-kitchen.glb", root / "assets/models/home/room-kitchen.glb"),
         (q / "shade-replay-v1/manifest.json", manifest)]
receipt = []
for source, target in paths:
    data = source.read_bytes()
    receipt.append({"path": target.relative_to(root).as_posix(), "beforeSha256": sha(target.read_bytes()), "afterSha256": sha(data), "bytes": len(data)})
for source, target in paths: target.write_bytes(source.read_bytes())
(q / "asset-promotion.json").write_text(json.dumps({"scope": "Four explicit guarded assets. Cache payload/descriptor unchanged here; official baker must regenerate after source integration.", "files": receipt}, indent=2) + "\n", encoding="utf8", newline="\n")
print(json.dumps({"assets": len(receipt), "canonicalNativeSha256": receipt[0]["afterSha256"]}))
