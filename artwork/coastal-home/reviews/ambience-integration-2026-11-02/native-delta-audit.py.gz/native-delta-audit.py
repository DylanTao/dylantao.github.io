import hashlib
import json
import runpy
from pathlib import Path

import bpy

root = Path.cwd()
q = Path(__file__).resolve().parent
ns = runpy.run_path(str(root / "artwork/coastal-home/reviews/bedroom-ambience-2026-11-01/replay_lighting.py"))
baseline = q / "base-de217.blend"
candidate = root / "artwork/coastal-home/coastal-home.blend"
bpy.ops.wm.open_mainfile(filepath=str(baseline))
before = ns["native_state"]()
bpy.ops.wm.open_mainfile(filepath=str(candidate))
after = ns["native_state"]()
owned = {"sleep__linen", "kitchen__olive leaf", "kitchen__honey ash"}
added = {"kitchen_nook_olive__honey ash"}
assert set(after) == set(before) | added
unowned = sorted(set(before) - owned)
changed = [name for name in unowned if before[name] != after[name]]
assert not changed, changed
report = {"scope": "Every original unowned native mesh geometry/normals/attributes/matrix/material-slot/index fingerprint versus exact de217, not just the pre-bake stage.",
          "baselineSha256": hashlib.sha256(baseline.read_bytes()).hexdigest(), "candidateSha256": hashlib.sha256(candidate.read_bytes()).hexdigest(),
          "owned": sorted(owned), "added": sorted(added), "unownedExact": len(unowned), "unownedChanged": changed,
          "unowned": {name: {"before": before[name], "after": after[name]} for name in unowned}}
(q / "native-delta-audit.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf8")
print(json.dumps({"unownedExact": len(unowned), "unownedChanged": changed}))
