const fs = require("node:fs"),
  path = require("node:path"),
  crypto = require("node:crypto"),
  zlib = require("node:zlib");
const {
  webkit,
  expect,
  devices,
} = require("/deps/node_modules/@playwright/test");
const http = require("node:http"),
  proxyErrors = [];
const q = __dirname,
  base = "http://127.0.0.1:8426/al-folio/",
  errors = [],
  failures = [],
  responses = [],
  rows = [];
function observe(page) {
  page.on("pageerror", (e) => errors.push({ type: "page", text: e.message }));
  page.on("console", (m) => {
    if (m.type() === "error") errors.push({ type: "console", text: m.text() });
  });
  page.on("requestfailed", (r) =>
    failures.push({ url: r.url(), error: r.failure() }),
  );
  page.on("response", async (r) => {
    if (
      r.url().startsWith(base) &&
      /\.(?:mjs|glb|json)(?:\?|$)/.test(r.url())
    ) {
      try {
        const b = await r.body();
        responses.push({
          url: r.url(),
          status: r.status(),
          bytes: b.length,
          sha256: crypto.createHash("sha256").update(b).digest("hex"),
          owner: r.headers()["x-sirui-preview"],
        });
      } catch (e) {
        responses.push({ url: r.url(), readError: String(e) });
      }
    }
  });
}
async function evidence(page) {
  return page
    .locator("[data-home-desk-scene]")
    .evaluate((e) => e.getSceneEvidence());
}
async function stable(page) {
  let last = null;
  for (let i = 0; i < 50; i++) {
    const e = await evidence(page);
    if (
      last &&
      !e.traveling &&
      Math.hypot(...e.camera.map((v, j) => v - last[j])) < 1e-5
    )
      return e;
    last = e.camera;
    await page.waitForTimeout(200);
  }
  throw Error("camera did not settle");
}
async function snapshot(page, label) {
  const scene = page.locator("[data-home-desk-scene]"),
    e = await stable(page);
  await page.waitForFunction(
    () => {
      const el = document.querySelector("[data-home-desk-scene]"),
        e = el.getSceneEvidence();
      return globalThis.__plantDraws.some(
        (d) =>
          d.stage === globalThis.__ambienceStage &&
          d.viewport.join(",") === "0,0,390,1000" &&
          Math.max(...d.camera.map((x, i) => Math.abs(x - e.camera[i]))) < 1e-6,
      );
    },
    {},
    { timeout: 30000 },
  );
  await page.waitForTimeout(250);
  if (
    e.simulation.practicals.nativeDiffuserMeshes !== 1 ||
    !e.simulation.lightField.cacheHit
  )
    throw Error("Native shade binding or signed cache restore missing");
  const info = await scene.evaluate((el) => {
    const gls = (globalThis.__ambienceContexts || []).filter((gl) =>
      gl.canvas.closest("[data-home-desk-scene]"),
    );
    return {
      stage: globalThis.__ambienceStage,
      gpu: [],
      rect: (() => {
        const r = el.querySelector("canvas").getBoundingClientRect();
        return { x: r.x, y: r.y, width: r.width, height: r.height };
      })(),
      contexts: gls.map((gl) => {
        const ext = gl.getExtension("WEBGL_debug_renderer_info");
        return {
          drawingBuffer: [gl.drawingBufferWidth, gl.drawingBufferHeight],
          canvas: [gl.canvas.width, gl.canvas.height],
          renderer: gl.getParameter(
            ext?.UNMASKED_RENDERER_WEBGL || gl.RENDERER,
          ),
          attributes: gl.getContextAttributes(),
        };
      }),
      clocks: {
        Date: Date.toString(),
        performance: performance.now.toString(),
        raf: requestAnimationFrame.toString(),
        pwClock: Boolean(globalThis.__pwClock),
      },
    };
  });
  await page.screenshot({
    path: path.join(q, "webkit-plant-qualified-" + label + ".png"),
  });
  const shade = await page.evaluate(() =>
    globalThis.__plantDraws.filter(
      (d) => d.stage === globalThis.__ambienceStage,
    ),
  );
  fs.writeFileSync(
    path.join(q, "webkit-plant-qualified-" + label + "-globe.json.gz"),
    zlib.gzipSync(JSON.stringify(shade)),
  );
  const gpu = info.gpu;
  delete info.gpu;
  fs.writeFileSync(
    path.join(q, "webkit-plant-qualified-" + label + "-gpu.json.gz"),
    zlib.gzipSync(JSON.stringify(gpu)),
  );
  const row = {
    nativeGlobeDraws: shade.length,
    gpuPrograms: gpu.length,
    pauseAria: await page
      .locator("[data-world-pause]")
      .getAttribute("aria-pressed"),
    label,
    url: page.url(),
    at: new Date().toISOString(),
    viewport: page.viewportSize(),
    ...info,
    evidence: e,
  };
  rows.push(row);
  fs.writeFileSync(
    path.join(q, "webkit-plant-qualified-appearance-rows.json"),
    JSON.stringify(rows, null, 2),
  );
  console.log(
    JSON.stringify({
      label,
      room: e.currentRoom,
      buffer: info.contexts[0]?.drawingBuffer,
      pauseAria: row.pauseAria,
      orbit: e.cameraOrbit,
      quality: e.quality?.tier,
    }),
  );
  return row;
}
(async () => {
  const proxy = http.createServer((req, res) => {
    const upstream = http.request(
      {
        host: "host.docker.internal",
        port: 55608,
        path: req.url,
        method: req.method,
        headers: req.headers,
      },
      (response) => {
        res.writeHead(response.statusCode, response.headers);
        response.pipe(res);
      },
    );
    upstream.on("error", (error) => {
      proxyErrors.push({ url: req.url, error: String(error) });
      res.writeHead(502);
      res.end("Local proxy upstream failed");
    });
    req.pipe(upstream);
  });
  await new Promise((resolve, reject) => {
    proxy.once("error", reject);
    proxy.listen(8426, "127.0.0.1", resolve);
  });
  proxy.unref();
  const browser = await webkit.launch({ headless: true });
  const browserVersion = browser.version();
  try {
    const context = await browser.newContext({
      ...devices["iPhone 13"],
      viewport: { width: 390, height: 1000 },
      deviceScaleFactor: 1,
      timezoneId: "America/Los_Angeles",
      reducedMotion: "no-preference",
    });
    await context.addInitScript(() => {
      globalThis.__ambienceContexts = [];
      globalThis.__ambienceStage = 0;
      const original = HTMLCanvasElement.prototype.getContext;
      HTMLCanvasElement.prototype.getContext = function (...args) {
        const result = original.apply(this, args);
        if (
          result &&
          /^webgl/.test(args[0]) &&
          !globalThis.__ambienceContexts.includes(result)
        )
          globalThis.__ambienceContexts.push(result);
        return result;
      };
    });
    const page = await context.newPage();
    observe(page);
    page.setDefaultTimeout(120000);
    await page.route(
      /https:\/\/(?:plausible\.io|www\.google-analytics\.com|www\.googletagmanager\.com)\//,
      (r) => r.fulfill({ status: 200, body: "" }),
    );
    async function theme(mode) {
      await page.locator("[data-theme-toggle]:visible").first().tap();
      await page
        .locator(`[data-theme-mode-option="${mode}"]:visible`)
        .first()
        .tap();
      await page.locator("[data-theme-toggle]:visible").first().tap();
    }
    async function ready(url) {
      await page.goto(url, { waitUntil: "domcontentloaded" });
      await page.evaluate(() => document.fonts.ready);
      await theme("noon");
      await page.locator('[data-home-desk-mode="3d"]').tap();
      const scene = page.locator("[data-home-desk-scene]");
      await scene.scrollIntoViewIfNeeded();
      await expect(scene).toHaveAttribute("data-scene-state", "ready", {
        timeout: 120000,
      });
      await page.waitForTimeout(800);
    }
    await ready(base + "?scene-lab=1&quality=high&msaa=2");
    const ui = page.locator("[data-home-world-controls]");
    await ui.locator("[data-world-lab] > summary").tap();
    await ui.locator("[data-world-avatar]").selectOption("ghibli");
    await expect
      .poll(async () => (await evidence(page)).avatarId, { timeout: 120000 })
      .toBe("ghibli");
    await page.waitForTimeout(800);
    await ui.locator("[data-world-lab] > summary").tap();
    async function motion(paused) {
      const button = ui.locator("[data-world-pause]");
      if ((await button.getAttribute("aria-pressed")) === String(paused))
        return;
      await ui.locator("[data-world-lab] > summary").tap();
      await button.tap();
      await expect(button).toHaveAttribute("aria-pressed", String(paused));
      await ui.locator("[data-world-lab] > summary").tap();
      await page.waitForTimeout(100);
    }

    await page.locator("[data-home-desk-scene]").evaluate((el) => {
      globalThis.__plantDraws = [];
      let count = 0;
      el.labScene.scene.traverse((mesh) => {
        if (!mesh.isMesh || mesh.userData.name !== "kitchen__olive leaf")
          return;
        count++;
        const previous = mesh.onAfterRender;
        mesh.onAfterRender = function (
          renderer,
          scene,
          camera,
          geometry,
          material,
          group,
        ) {
          previous?.call(
            this,
            renderer,
            scene,
            camera,
            geometry,
            material,
            group,
          );
          const w = camera.matrixWorld.elements,
            gl = renderer.getContext();
          globalThis.__plantDraws.push({
            stage: globalThis.__ambienceStage,
            camera: [w[12], w[13], w[14]],
            viewport: Array.from(gl.getParameter(gl.VIEWPORT)),
            vertices: geometry.attributes.position.count,
            triangles: geometry.index.count / 3,
          });
          if (globalThis.__plantDraws.length > 2000)
            globalThis.__plantDraws.splice(0, 500);
        };
      });
      if (count !== 1)
        throw Error("Exact current leaf draw owner not unique: " + count);
    });
    for (const mode of ["noon", "evening"]) {
      if (mode !== "noon") await theme(mode);
      await ui.locator("[data-world-fullscreen]").tap();
      await expect
        .poll(async () => Boolean((await evidence(page)).fullscreen), {
          timeout: 30000,
        })
        .toBe(true);
      await page.waitForTimeout(500);
      for (const room of ["kitchen"]) {
        await motion(false);
        await page.evaluate(() => globalThis.__ambienceStage++);
        await ui.locator("[data-world-places] > summary").tap();
        await ui.locator(`[data-world-destination="${room}"]`).tap();
        await expect
          .poll(async () => (await evidence(page)).currentRoom, {
            timeout: 30000,
          })
          .toBe(room);
        await page.waitForTimeout(500);
        await stable(page);
        if (room === "gym")
          await expect
            .poll(
              async () =>
                (await evidence(page)).simulation.installations.levels.gym,
            )
            .toBeGreaterThanOrEqual(0.65);
        if (room === "library-upper")
          await expect
            .poll(
              async () =>
                (await evidence(page)).simulation.installations.levels
                  .privateReading,
            )
            .toBeGreaterThanOrEqual(0.65);
        await motion(true);
        await snapshot(page, mode + "-" + room + "-default");
        await page.evaluate(() => globalThis.__ambienceStage++);
        await page
          .locator("[data-home-desk-scene]")
          .evaluate((el) =>
            el.setLabCamera({
              target: [-4.68, 0.62, 3.85],
              yaw: 0.875,
              pitch: 0.12,
              radius: 1.7,
              free: true,
            }),
          );
        const fresh = page.locator("[data-home-desk-scene] canvas");
        await fresh.focus();
        await fresh.press("ArrowRight");
        await fresh.press("ArrowLeft");
        await page.waitForTimeout(300);
        await snapshot(page, mode + "-" + room + "-plant-detail");
      }
      await page.locator("[data-world-exit]").tap();
      await page.waitForTimeout(500);
    }
    fs.writeFileSync(
      path.join(q, "webkit-plant-qualified-capture-receipt.json"),
      JSON.stringify(
        {
          scope:
            "Complete integrated55608 rounded olive candidate via byte-preserving container-local localhost8426 proxy to the Windows-owned55608 server. Modern Playwright1.58.2 WebKit phone viewport390x1000,DPR1; actual buffers/quality recorded. Native clocks, actual touch Rooms/theme/fullscreen/Pause. Each view requires actual native leaf onAfterRender camera/viewport match; lab detail also receives public canvas ArrowRight/ArrowLeft input. Original cached Noon detail retained separately. No GPU uniform-location observer; buffer/renderer/native clocks and complete body readbacks only. Close plant angle is a disclosed read-only lab camera, no source camera change. Official24sample owned leaf/branch AO and indirect bake is included; other461 native meshes exact. Linux software functional/appearance proof only; no PC GPU or physical-phone timing claim.",
          browserVersion,
          proxyErrors,
          errors,
          failures,
          responses,
          rows: rows.length,
        },
        null,
        2,
      ),
    );
    console.log(
      JSON.stringify({ complete: true, rows: rows.length, errors, failures }),
    );
  } finally {
    fs.writeFileSync(
      path.join(q, "webkit-plant-qualified-terminal-receipt.json"),
      JSON.stringify(
        {
          browserVersion,
          proxyErrors,
          errors,
          failures,
          responses,
          rows: rows.length,
        },
        null,
        2,
      ),
    );
    await browser.close();
    proxy.closeAllConnections?.();
    await new Promise((resolve) => proxy.close(resolve));
  }
})().catch((e) => {
  fs.writeFileSync(
    path.join(q, "webkit-plant-qualified-capture-failure.txt"),
    String(e.stack || e),
  );
  console.error(e);
  process.exitCode = 1;
});
