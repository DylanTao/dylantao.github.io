const fs = require("node:fs"),
  path = require("node:path"),
  crypto = require("node:crypto"),
  zlib = require("node:zlib");
const {
  chromium,
  expect,
} = require("C:/dev/dylantao.github.io/node_modules/@playwright/test");
const q = __dirname,
  base = "http://127.0.0.1:55608/al-folio/",
  errors = [],
  failures = [],
  responses = [],
  rows = [],
  network = [];
function observe(page) {
  page.on("pageerror", (e) => errors.push({ type: "page", text: e.message }));
  page.on("console", (m) => {
    if (m.type() === "error") errors.push({ type: "console", text: m.text() });
  });
  page.on("requestfailed", (r) =>
    failures.push({ url: r.url(), error: r.failure() }),
  );
  page.on("response", async (r) => {
    if (
      r.url().startsWith(base) &&
      /\.(?:mjs|glb|json)(?:\?|$)/.test(r.url())
    ) {
      try {
        const b = await r.body();
        responses.push({
          url: r.url(),
          status: r.status(),
          bytes: b.length,
          sha256: crypto.createHash("sha256").update(b).digest("hex"),
          owner: r.headers()["x-sirui-preview"],
        });
      } catch (e) {
        responses.push({ url: r.url(), readError: String(e) });
      }
    }
  });
}
async function evidence(page) {
  return page
    .locator("[data-home-desk-scene]")
    .evaluate((e) => e.getSceneEvidence());
}
async function stable(page) {
  let last = null;
  for (let i = 0; i < 50; i++) {
    const e = await evidence(page);
    if (
      last &&
      !e.traveling &&
      Math.hypot(...e.camera.map((v, j) => v - last[j])) < 1e-5
    )
      return e;
    last = e.camera;
    await page.waitForTimeout(200);
  }
  throw Error("camera did not settle");
}
async function snapshot(page, label) {
  const scene = page.locator("[data-home-desk-scene]"),
    e = await stable(page);
  const info = await scene.evaluate((el) => {
    const gls = (globalThis.__ambienceContexts || []).filter((gl) =>
      gl.canvas.closest("[data-home-desk-scene]"),
    );
    return {
      stage: globalThis.__ambienceStage,
      gpu: (globalThis.__ambiencePrograms || [])
        .filter(
          (r) =>
            r.stage === globalThis.__ambienceStage &&
            r.gl.canvas.closest("[data-home-desk-scene]") &&
            r.gl.isProgram(r.program),
        )
        .map((r) => ({
          id: r.id,
          stage: r.stage,
          uniforms: Object.fromEntries(
            [...r.names]
              .filter(([n]) =>
                /^(toneMappingExposure|roughness|metalness|envMapIntensity|viewMatrix|normalMatrix|slfReady|installActive|install(?:Line|Point)Color|pointLights)/.test(
                  n,
                ),
              )
              .map(([n, l]) => {
                const v = r.gl.getUniform(r.program, l);
                return [n, ArrayBuffer.isView(v) ? Array.from(v) : v];
              }),
          ),
          sources: (r.gl.getAttachedShaders(r.program) || []).map((shader) =>
            r.gl.getShaderSource(shader),
          ),
        })),
      rect: (() => {
        const r = el.querySelector("canvas").getBoundingClientRect();
        return { x: r.x, y: r.y, width: r.width, height: r.height };
      })(),
      contexts: gls.map((gl) => {
        const ext = gl.getExtension("WEBGL_debug_renderer_info");
        return {
          drawingBuffer: [gl.drawingBufferWidth, gl.drawingBufferHeight],
          canvas: [gl.canvas.width, gl.canvas.height],
          renderer: gl.getParameter(
            ext?.UNMASKED_RENDERER_WEBGL || gl.RENDERER,
          ),
          attributes: gl.getContextAttributes(),
        };
      }),
      clocks: {
        Date: Date.toString(),
        performance: performance.now.toString(),
        raf: requestAnimationFrame.toString(),
        pwClock: Boolean(globalThis.__pwClock),
      },
    };
  });
  await page.screenshot({
    path: path.join(q, "shade-qualified-" + label + ".png"),
  });
  const gpu = info.gpu;
  delete info.gpu;
  fs.writeFileSync(
    path.join(q, "shade-qualified-" + label + "-gpu.json.gz"),
    zlib.gzipSync(JSON.stringify(gpu)),
  );
  const shade = await page.evaluate(() =>
    globalThis.__ambienceShadeDraws.filter(
      (row) => row.stage === globalThis.__ambienceStage,
    ),
  );
  fs.writeFileSync(
    path.join(q, "shade-qualified-" + label + "-globe.json.gz"),
    zlib.gzipSync(JSON.stringify(shade)),
  );
  const row = {
    nativeGlobeDraws: shade.length,
    gpuPrograms: gpu.length,
    pauseAria: await page
      .locator("[data-world-pause]")
      .getAttribute("aria-pressed"),
    label,
    url: page.url(),
    at: new Date().toISOString(),
    viewport: page.viewportSize(),
    ...info,
    evidence: e,
  };
  rows.push(row);
  fs.writeFileSync(
    path.join(q, "shade-qualified-appearance-rows.json"),
    JSON.stringify(rows, null, 2),
  );
  console.log(
    JSON.stringify({
      label,
      room: e.currentRoom,
      buffer: info.contexts[0]?.drawingBuffer,
      pauseAria: row.pauseAria,
      orbit: e.cameraOrbit,
      quality: e.quality?.tier,
    }),
  );
  return row;
}
(async () => {
  const browser = await chromium.launch({
    headless: true,
    args: ["--use-angle=d3d11", "--ignore-gpu-blocklist"],
  });
  try {
    const context = await browser.newContext({
      viewport: { width: 2560, height: 1440 },
      deviceScaleFactor: 1,
      timezoneId: "America/Los_Angeles",
      reducedMotion: "no-preference",
    });
    await context.addInitScript(() => {
      globalThis.__ambienceContexts = [];
      globalThis.__ambienceStage = 0;
      globalThis.__ambiencePrograms = [];
      const byProgram = new WeakMap();
      for (const proto of [
        globalThis.WebGL2RenderingContext?.prototype,
        globalThis.WebGLRenderingContext?.prototype,
      ].filter(Boolean)) {
        const location = proto.getUniformLocation,
          use = proto.useProgram;
        const record = (gl, program) => {
          let r = byProgram.get(program);
          if (!r) {
            r = {
              gl,
              program,
              id: globalThis.__ambiencePrograms.length + 1,
              names: new Map(),
              stage: -1,
            };
            byProgram.set(program, r);
            globalThis.__ambiencePrograms.push(r);
          }
          return r;
        };
        proto.getUniformLocation = function (program, name) {
          const result = location.call(this, program, name);
          if (result) record(this, program).names.set(name, result);
          return result;
        };
        proto.useProgram = function (program) {
          if (program) record(this, program).stage = globalThis.__ambienceStage;
          return use.call(this, program);
        };
      }
      const original = HTMLCanvasElement.prototype.getContext;
      HTMLCanvasElement.prototype.getContext = function (...args) {
        const result = original.apply(this, args);
        if (
          result &&
          /^webgl/.test(args[0]) &&
          !globalThis.__ambienceContexts.includes(result)
        )
          globalThis.__ambienceContexts.push(result);
        return result;
      };
    });
    const page = await context.newPage();
    observe(page);
    const cdp = await context.newCDPSession(page);
    await cdp.send("Network.enable");
    for (const type of [
      "Network.requestWillBeSent",
      "Network.loadingFailed",
      "Network.responseReceived",
    ])
      cdp.on(type, (event) => network.push({ type, at: Date.now(), event }));
    page.setDefaultTimeout(120000);
    await page.route(
      /https:\/\/(?:plausible\.io|www\.google-analytics\.com|www\.googletagmanager\.com)\//,
      (r) => r.fulfill({ status: 200, body: "" }),
    );
    async function theme(mode) {
      await page.locator("[data-theme-toggle]:visible").first().click();
      await page
        .locator(`[data-theme-mode-option="${mode}"]:visible`)
        .first()
        .click();
      await page.locator("[data-theme-toggle]:visible").first().click();
    }
    async function ready(url) {
      await page.goto(url, { waitUntil: "domcontentloaded" });
      await page.evaluate(() => document.fonts.ready);
      await theme("noon");
      await page.locator('[data-home-desk-mode="3d"]').click();
      const scene = page.locator("[data-home-desk-scene]");
      await scene.scrollIntoViewIfNeeded();
      await expect(scene).toHaveAttribute("data-scene-state", "ready", {
        timeout: 120000,
      });
      await page.waitForTimeout(800);
    }
    await ready(base + "?scene-lab=1&quality=high&msaa=2");
    const ui = page.locator("[data-home-world-controls]");
    await ui.locator("[data-world-lab] > summary").click();
    await ui.locator("[data-world-avatar]").selectOption("ghibli");
    await expect
      .poll(async () => (await evidence(page)).avatarId, { timeout: 120000 })
      .toBe("ghibli");
    await page.waitForTimeout(800);
    await ui.locator("[data-world-lab] > summary").click();
    async function motion(paused) {
      const button = ui.locator("[data-world-pause]");
      if ((await button.getAttribute("aria-pressed")) === String(paused))
        return;
      await ui.locator("[data-world-lab] > summary").click();
      await button.click();
      await expect(button).toHaveAttribute("aria-pressed", String(paused));
      await ui.locator("[data-world-lab] > summary").click();
      await page.waitForTimeout(100);
    }
    await page.locator("[data-home-desk-scene]").evaluate((el) => {
      globalThis.__ambienceShadeDraws = [];
      let count = 0;
      el.labScene.scene.traverse((mesh) => {
        if (
          !mesh.isMesh ||
          ![mesh.material]
            .flat()
            .some(
              (m) =>
                m.name === "sleep bedside linen diffuser" &&
                m.userData.practicalSourceId === "sleep",
            )
        )
          return;
        count++;
        const previous = mesh.onAfterRender;
        mesh.onAfterRender = function (
          renderer,
          scene,
          camera,
          geometry,
          material,
          group,
        ) {
          previous?.call(
            this,
            renderer,
            scene,
            camera,
            geometry,
            material,
            group,
          );
          if (
            material.name !== "sleep bedside linen diffuser" ||
            material.userData.practicalSourceId !== "sleep"
          )
            return;
          const gl = renderer.getContext(),
            program = gl.getParameter(gl.CURRENT_PROGRAM),
            names = [
              "emissive",
              "diffuse",
              "roughness",
              "toneMappingExposure",
              "viewMatrix",
            ],
            uniforms = {};
          for (const name of names) {
            const location = gl.getUniformLocation(program, name);
            if (location) {
              const value = gl.getUniform(program, location);
              uniforms[name] = ArrayBuffer.isView(value)
                ? Array.from(value)
                : value;
            }
          }
          const w = camera.matrixWorld.elements;
          globalThis.__ambienceShadeDraws.push({
            stage: globalThis.__ambienceStage,
            camera: [w[12], w[13], w[14]],
            viewport: Array.from(gl.getParameter(gl.VIEWPORT)),
            material: material.name,
            emissiveIntensity: material.emissiveIntensity,
            emissiveColor: material.emissive.toArray(),
            baseColor: material.color.toArray(),
            roughness: material.roughness,
            uniforms,
          });
          if (globalThis.__ambienceShadeDraws.length > 10000)
            globalThis.__ambienceShadeDraws.splice(0, 1000);
        };
      });
      if (count !== 1)
        throw Error("Expected one actual native shade mesh, got" + count);
    });
    for (const mode of ["noon", "evening"]) {
      if (mode !== "noon") await theme(mode);
      await ui.locator("[data-world-fullscreen]").click();
      await expect
        .poll(async () => Boolean((await evidence(page)).fullscreen), {
          timeout: 30000,
        })
        .toBe(true);
      await page.waitForTimeout(500);
      for (const room of ["sleep", "library-upper"]) {
        await motion(false);
        await page.evaluate(() => globalThis.__ambienceStage++);
        await ui.locator("[data-world-places] > summary").click();
        await ui.locator(`[data-world-destination="${room}"]`).click();
        await expect
          .poll(async () => (await evidence(page)).currentRoom, {
            timeout: 30000,
          })
          .toBe(room);
        await page.waitForTimeout(500);
        await stable(page);
        if (room === "gym")
          await expect
            .poll(
              async () =>
                (await evidence(page)).simulation.installations.levels.gym,
            )
            .toBeGreaterThanOrEqual(0.65);
        if (room === "library-upper")
          await expect
            .poll(
              async () =>
                (await evidence(page)).simulation.installations.levels
                  .privateReading,
            )
            .toBeGreaterThanOrEqual(0.65);
        await motion(true);
        await snapshot(page, mode + "-" + room + "-default");
        const canvas = page.locator("[data-home-desk-scene] canvas");
        await canvas.focus();
        await page.evaluate(() => globalThis.__ambienceStage++);
        for (let n = 0; n < 2; n++) await canvas.press("ArrowLeft");
        await snapshot(page, mode + "-" + room + "-left");
        await page.evaluate(() => globalThis.__ambienceStage++);
        for (let n = 0; n < 4; n++) await canvas.press("ArrowRight");
        await snapshot(page, mode + "-" + room + "-right");
      }
      await page.locator("[data-world-exit]").click();
      await page.waitForTimeout(500);
    }
    fs.writeFileSync(
      path.join(q, "shade-qualified-capture-receipt.json"),
      JSON.stringify(
        {
          scope:
            "Actual complete integrated shade+fresh-baked-olive product on55608; two affected rooms, six views each, native clocks/no source substitutions, pinned high/MSAA2; actual per-room visit first runs normally before scene-lab Pause and avatar UI disclosed for matched appearance; public Rooms and theme controls. Concurrent functional/appearance only, no performance claim.",
          errors,
          failures,
          responses,
          rows: rows.length,
        },
        null,
        2,
      ),
    );
    console.log(
      JSON.stringify({ complete: true, rows: rows.length, errors, failures }),
    );
  } finally {
    if (typeof network !== "undefined")
      fs.writeFileSync(
        path.join(q, "shade-qualified-network.json.gz"),
        zlib.gzipSync(JSON.stringify(network)),
      );
    fs.writeFileSync(
      path.join(q, "shade-qualified-terminal-receipt.json"),
      JSON.stringify(
        { errors, failures, responses, rows: rows.length },
        null,
        2,
      ),
    );
    await browser.close();
  }
})().catch((e) => {
  fs.writeFileSync(
    path.join(q, "shade-qualified-capture-failure.txt"),
    String(e.stack || e),
  );
  console.error(e);
  process.exitCode = 1;
});
