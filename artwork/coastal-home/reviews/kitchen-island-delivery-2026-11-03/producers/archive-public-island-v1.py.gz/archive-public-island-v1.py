"""Portable actual receipts; the native source stays in its canonical tracked path."""
from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, shutil

root=Path.cwd();q=Path(__file__).parent;packet=root/'artwork/coastal-home/reviews/kitchen-island-delivery-2026-11-03'
assert (packet/'README.md').is_file()and not(packet/'MANIFEST.json').exists()
sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
def deposit(name,file,compressed=True):
    data=file.read_bytes();stored=gzip.compress(data,mtime=0)if compressed else data
    path=packet/(name+('.gz'if compressed else''));assert not path.exists();path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(stored)
    row={'path':path.relative_to(packet).as_posix(),'bytes':len(stored),'sha256':sha(stored)}
    if compressed:row.update(encoding='gzip',bodyBytes=len(data),bodySha256=sha(data))
    rows.append(row)

mapping={
 'raw/native-replay.json':'public-island-native-v1/REPLAY.json',
 'raw/owned-ao.json':'public-island-owning-ao-v1/OWNED-ISLAND-AO.json',
 'raw/official-native-bake.json':'public-island-owning-ao-v1/BAKE.json',
 'raw/cache-capacity.json':'public-island-preview-v1/CAPACITY-AND-CUSTODY.json',
 'raw/preview-source.json':'public-island-preview-v1/SOURCE-SNAPSHOT.json',
 'raw/native-overlaps.json':'public-island-overlap-v1/native/AUDIT.json',
 'raw/decoded-overlaps.json':'public-island-overlap-v1/decoded/AUDIT.json',
 'raw/overlap-processes.json':'public-island-overlap-v1/SUMMARY.json',
 'raw/decoded-dimensions-floor.json':'public-island-decoded-v2/AUDIT.json',
 'raw/drawings.json':'public-island-sketch-v2/PROCESS.json',
 'raw/drawings.log':'public-island-sketch-v2/build.log',
 'raw/first-drawing-path-failure.json':'public-island-sketch-v1/FAILURE.json',
 'raw/first-native-zero-assumption.log':'audit-public-island-decoded-v1.log',
 'raw/straight-crossing-failure.json':'public-island-walk-v1/FAILURE.json',
 'raw/short-return-assertion-failure.json':'public-island-walk-v2/FAILURE.json',
 'raw/walk.json':'public-island-walk-v3/WALK.json',
 'raw/install.json':'public-island-install-v1/INSTALL.json',
 'raw/complete-build.json':'island-checkpoint/BUILD-GATES.json',
 'raw/complete-build.log':'island-checkpoint/production-build.log',
 'raw/unit-gates.json':'island-checkpoint/UNIT-GATES.json',
 'raw/python.log':'island-checkpoint/python.log',
 'raw/node.log':'island-checkpoint/node.log',
 'raw/style.log':'island-checkpoint/style.log',
 'raw/validation-source.json':'island-checkpoint/VALIDATION-SOURCE.json',
 'raw/model-review.json':'public-island-model-review-v1/model-contacts.json',
 'raw/model-review.log':'public-island-model-review-v1.log',
}
for preset in ('2k','4k','phone-webkit'):mapping['raw/appearance-'+preset+'.json']='public-island-appearance-v1-'+preset+'/CAPTURE.json'
for width in ('1440','1280','768','390'):mapping['raw/production-'+width+'.json']='public-island-production-v1-'+width+'/CAPTURE.json'
for name,rel in mapping.items():deposit(name,q/rel)
for rel in ['audit-public-island-v1.py','audit-public-island-decoded-v1.py','audit-public-island-decoded-v2.py','bake-public-island-v1.py','export-public-island-v1.py','prepare-public-island-preview-v1.py','prepare-public-island-sketch-v1.py','prepare-public-island-sketch-v2.py','install-public-island-v1.py','capture-public-island-v1.cjs','capture-production-island-v1.cjs','walk-public-island-v1.cjs','walk-public-island-v2.cjs','walk-public-island-v3.cjs','run-island-validation-v1.py','archive-public-island-v1.py']:
    deposit('producers/'+rel,q/rel)
for sub in ['command.json','PROCESS.json']:
    file=q/'public-island-export-v1'/sub
    if file.is_file():deposit('raw/export-'+sub,file)
views={
 'west-aisle.png':'public-island-walk-v3/west-aisle.png',
 'east-aisle.png':'public-island-walk-v3/east-aisle.png',
 'walk-return.png':'public-island-walk-v3/complete-return.png',
 'phone-noon.png':'public-island-appearance-v1-phone-webkit/noon-default-canvas.png',
 'phone-evening.png':'public-island-appearance-v1-phone-webkit/evening-default-canvas.png',
 'desktop-2k-noon.png':'public-island-appearance-v1-2k/noon-default-canvas.png',
 'desktop-4k-noon.png':'public-island-appearance-v1-4k/noon-default-canvas.png',
 'production-1440.png':'public-island-production-v1-1440/noon-default-canvas.png',
 'production-390.png':'public-island-production-v1-390/noon-default-canvas.png',
}
for name,rel in views.items():deposit('views/'+name,q/rel,False)
source_paths=['artwork/coastal-home/coastal-home.blend','artwork/coastal-home/PROVENANCE.md','artwork/coastal-home/reviews/model-contacts.json','artwork/coastal-home/reviews/house-2026-10-24/overlap-audit.json','docs/homepage-desk-scene-brief.md','docs/october-2026-handoff.md','bin/coastal_kitchen.py','bin/coastal_kitchen_island.py','bin/refresh_coastal_kitchen_island.py','test/test_kitchen_island.py','bin/audit_coastal_overlaps.py','bin/summarize_coastal_overlaps.py','bin/bake_coastal_light.py','bin/build_coastal_perch_support.py','bin/build_loading_sketch.cjs','assets/models/home/manifest.json','assets/models/home/static-light-field.json','assets/models/home/wildlife-perch-support.json','assets/models/home/room-kitchen.glb','assets/models/home/loading-sketch.json','assets/models/home/loading-sketch/kitchen.json','assets/models/home/loading-sketch/sleep.json']
sources=[]
for rel in source_paths:
    body=(root/rel).read_bytes();sources.append({'path':rel,'bytes':len(body),'sha256':sha(body),'gitLfSha256':sha(body if rel.endswith(('.blend','.glb'))else body.replace(b'\r\n',b'\n'))})
source={'at':datetime.now(timezone.utc).isoformat(),'scope':'Current canonical source/assets and exact producers. Text also records normalized Git-LF digest for portable checkout verification. Actual build/served body and native-source digests stay raw bytes in their own receipts.','files':sources}
p=packet/'SOURCE.json';p.write_text(json.dumps(source,indent=2)+'\n',encoding='utf8');rows.append({'path':'SOURCE.json','bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
manifest={'at':datetime.now(timezone.utc).isoformat(),'scope':'Exact retained native/decoded/cache/Walk/appearance/production receipts and representative actual renders. CI/live publication and complete-world cliff/entrance/garden/coffee remain separate. No credentials, private analytics or private source references.', 'files':rows}
(packet/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
print(json.dumps({'files':len(rows),'storedBytes':sum(r['bytes']for r in rows)}))
