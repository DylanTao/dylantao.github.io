"""Complete isolated production seed + one new room and the official cache producer."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,sys,time,urllib.request
root=Path.cwd();q=Path(__file__).parent;out=q/'public-island-preview-v1';assert not out.exists();out.mkdir()
seed=q/'gym-directed-checkpoint/site';models=q/'public-island-export-v1/models';source=out/'source'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(models/'room-kitchen.glb')=='6f8ef82b59c58a8a296d5fb795993e8ad599fba51764c56cd82934a8fe1e0697'
canonical={p.relative_to(root).as_posix():sha(p)for p in(root/'assets/models/home').rglob('*')if p.is_file()}
canonical_native=sha(root/'artwork/coastal-home/coastal-home.blend')
assert canonical_native=='1e10b25d5cf0eec87d7001acbf9d938d65ba33af6076380d5a8e5d45cf3d23e7'
shutil.copytree(seed,out/'site')
shutil.copytree(root/'assets/js',source/'assets/js')
shutil.copytree(models,source/'assets/models/home')
shutil.copytree(models,out/'site/al-folio/assets/models/home',dirs_exist_ok=True)
for rel in ['_plugins/site_module_assets.rb','Gemfile.lock','bin/coastal_static_light_inputs.cjs','bin/bake_coastal_static_light.cjs']:
    p=source/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,p)
built=out/'site/al-folio';inventory=json.loads((built/'assets/js/module-build.json').read_bytes())['modules']
assert len(inventory)==189
for rel,row in inventory.items():
    assert hashlib.sha256((source/rel).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==row['sourceSha256']
    assert sha(built/rel)==row['outputSha256']
files=[{'path':p.relative_to(source).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(source.rglob('*'))if p.is_file()]
(out/'SOURCE-SNAPSHOT.json').write_text(json.dumps({'at':datetime.now(timezone.utc).isoformat(),'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'nativeSourceSha256':'cb531e3839358ec96b3da21ea09c3b2b69891e507bcf12d220b9a5e35e503fff','scope':'Complete production seed with all189unchanged current compiled modules and exactly one new kitchen model; no omission/response-routing replacement/experimental venue. Newly compiled whole production build follows this candidate proof.','files':files},indent=2)+'\n',encoding='utf8')
shutil.copyfile(q/'private-serve-template.py',out/'serve.py')
with(out/'server.log').open('wb')as log:child=subprocess.Popen([sys.executable,str(out/'serve.py')],cwd=root,stdout=log,stderr=subprocess.STDOUT,creationflags=0x08000000)
for _ in range(150):
    if(out/'server.json').exists():break
    assert child.poll()is None;time.sleep(.1)
server=json.loads((out/'server.json').read_bytes());assert server['pid']==child.pid
with urllib.request.urlopen(server['url'],timeout=10)as response:assert response.headers['X-Sirui-Preview']==server['header']
env=dict(os.environ,COASTAL_CACHE_URL=server['url'],NODE_PATH=str(root/'node_modules'))
command=[shutil.which('node'),str(source/'bin/bake_coastal_static_light.cjs')];start=time.monotonic()
with(out/'official-bake.log').open('wb')as log:r=subprocess.run(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
receipt={'at':datetime.now(timezone.utc).isoformat(),'server':server,'command':command,'exitCode':r.returncode,'seconds':time.monotonic()-start}
(out/'PROCESS.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');assert r.returncode==0
cache=source/'assets/models/home/static-light-field.json';data=json.loads(cache.read_bytes());configuration=json.loads(data['configuration']);m=json.loads((source/'assets/models/home/manifest.json').read_bytes())
assert m['staticLightFieldCache']['signature']==data['signature']and m['staticLightFieldCache']['sha256']==sha(cache)
stats=data['statistics'];pre=stats['triangles']+stats['skippedTriangles']
assert stats['ready']and pre<=750000 and cache.stat().st_size<=800000
assert len(configuration['regions'])==16 and len(configuration['practicalSources'])==28 and len(data['probes'])==128
for rel in ['assets/models/home/manifest.json','assets/models/home/static-light-field.json']:shutil.copyfile(source/rel,built/rel)
changed=[row['path']for row in files if sha(source/row['path'])!=row['sha256']]
assert set(changed)<=set(['assets/models/home/manifest.json','assets/models/home/static-light-field.json'])
assert all(sha(root/rel)==digest for rel,digest in canonical.items())and sha(root/'artwork/coastal-home/coastal-home.blend')==canonical_native
receipt.update(cacheBytes=cache.stat().st_size,cacheSha256=sha(cache),signature=data['signature'],preROITriangles=pre,regions=16,probes=128,practicals=28,modules=189,changedPrivatePaths=changed,canonicalModelsAndNativeUnchanged=True,scope='Complete isolated production-seed island candidate and unmodified official cache; no geometry/viewport/quality omissions. New whole production/render/overlap/Walk/publication gates remain separate.')
(out/'CAPACITY-AND-CUSTODY.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps(receipt,indent=2))
