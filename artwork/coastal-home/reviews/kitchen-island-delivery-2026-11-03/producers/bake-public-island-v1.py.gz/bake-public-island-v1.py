"""Official neutral24sample bake, replaying only explicitly owned island corners."""
from pathlib import Path
import array,ast,hashlib,json,runpy,shutil,sys
import bpy
root=Path.cwd();q=Path(__file__).parent;out=q/'public-island-owning-ao-v1'
assert not out.exists();out.mkdir()
source=q/'public-island-native-v1/candidate.blend';proof_path=source.parent/'REPLAY.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source_sha='1458de30e10865a75e925814d24d4a74afec2ccb974896d6b40b6fca70cd4237'
assert sha(source)==source_sha and bpy.app.version==(4,5,9)
proof=json.loads(proof_path.read_bytes());assert proof['outputSha256']==source_sha and proof['savedReopenExact']and proof['manifestUntouched']
masks=proof['ownedBakeCorners'];assert sorted(map(len,masks.values()))==[384,384,1040,1152,2432,14208]
manifest=root/'assets/models/home/manifest.json';manifest_sha=sha(manifest)
ns=runpy.run_path(str(root/'artwork/coastal-home/reviews/bedroom-ambience-2026-11-01/replay_lighting.py'))
tree=ast.parse((q/'bake-owned-exterior.py').read_text(encoding='utf8'))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in {'shape','colors'}],type_ignores=[]),'qualified-shape-colors','exec'))
bpy.ops.wm.open_mainfile(filepath=str(source));before=ns['native_state']();materials=ns['materials']()
shapes={name:shape(bpy.data.objects[name])for name in masks};tags={name:bpy.data.objects[name].get('bakedLighting')for name in masks}
for name,loops in masks.items():
    obj=bpy.data.objects[name];a=obj.data.color_attributes.active_color
    assert a and a.domain=='CORNER'and a.data_type=='FLOAT_COLOR'
    assert loops and len(loops)==len(set(loops))and all(type(i)is int and 0<=i<len(a.data)for i in loops)
work=out/'bake-work.blend';shutil.copyfile(source,work)
sys.argv=['bake_coastal_light.py','--','--cpu','--source='+str(work),'--manifest='+str(manifest),'--prefixes='+','.join(sorted(masks)),'--report='+str(out/'BAKE.json')]
runpy.run_path(str(root/'bin/bake_coastal_light.py'),run_name='__main__')
stats=json.loads((out/'BAKE.json').read_bytes());assert stats['samples']==24 and {r['mesh']for r in stats['surfaces']}==set(masks)
baked={}
for name in masks:
    obj=bpy.data.objects[name]
    if tags[name]is None:
        if 'bakedLighting'in obj:del obj['bakedLighting']
    else:obj['bakedLighting']=tags[name]
    assert shape(obj)==shapes[name],name
    baked[name]=colors(obj.data.color_attributes.active_color)
bpy.ops.wm.open_mainfile(filepath=str(source));changes=[]
for name,loops in masks.items():
    obj=bpy.data.objects[name];a=obj.data.color_attributes.active_color;old=colors(a);values=array.array('f',old)
    assert len(old)==len(baked[name])
    for i in loops:values[4*i:4*i+4]=baked[name][4*i:4*i+4]
    a.data.foreach_set('color',values);actual=colors(a)
    changed=[i for i in range(len(a.data))if old[4*i:4*i+4]!=actual[4*i:4*i+4]]
    assert set(changed)<=set(loops)and shape(obj)==shapes[name]
    changes.append({'owner':name,'eligibleCorners':len(loops),'changedCorners':len(changed),'protectedCornersExact':len(a.data)-len(loops),'shapeSha256':shapes[name]})
after=ns['native_state']();assert set(before)==set(after)
assert all(before[name]==after[name]for name in before if name not in masks)
assert ns['materials']()==materials and sha(manifest)==manifest_sha
target=out/'candidate.blend';bpy.context.preferences.filepaths.save_version=0;bpy.ops.wm.save_as_mainfile(filepath=str(target),compress=True)
bpy.ops.wm.open_mainfile(filepath=str(target));assert ns['native_state']()==after and ns['materials']()==materials
assert sha(source)==source_sha
receipt={'scope':'Official24sampleCPU neutral AO/indirect on six island owners, replaying only explicitly owned post-remap CORNER IDs. Every other candidate geometry, normal, UV, typed field, role, material and corner color is exact, including east flutes and floor. No floor color was added. Source/export/cache/overlap/Walk/appearance admission remains separate.','sourceSha256':source_sha,'candidateSha256':sha(target),'proofSha256':sha(proof_path),'bakerSha256':sha(root/'bin/bake_coastal_light.py'),'producerSha256':sha(Path(__file__)),'manifestSha256':manifest_sha,'changes':changes,'unownedMeshesExact':len(before)-len(masks),'bake':stats}
(out/'OWNED-ISLAND-AO.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps({'candidateSha256':receipt['candidateSha256'],'unownedMeshesExact':receipt['unownedMeshesExact'],'changes':changes},indent=2))
