"""Regenerate current-source drawings with the unchanged owning producer."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, subprocess, time

root = Path.cwd()
q = Path(__file__).parent
out = q / 'public-island-sketch-v2'
assert not out.exists()
out.mkdir()
preview = q / 'public-island-preview-v1'
source = preview / 'source'
models = source / 'assets/models/home'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
canonical = {p.relative_to(root).as_posix(): sha(p) for p in (root / 'assets/models/home').rglob('*') if p.is_file()}
canonical['artwork/coastal-home/coastal-home.blend'] = sha(root / 'artwork/coastal-home/coastal-home.blend')
old = json.loads((root / 'assets/models/home/wildlife-perch-support.json').read_bytes())
new_path = q / 'public-island-export-v1/models/wildlife-perch-support.json'
new = json.loads(new_path.read_bytes())
assert new['coastSha256'] == 'cb531e3839358ec96b3da21ea09c3b2b69891e507bcf12d220b9a5e35e503fff'
def normalized(value):
    value = json.loads(json.dumps(value))
    value.pop('coastSha256')
    for patch in value['patches']:
        for key in ('triangles', 'nativeTriangles'):
            if key in patch:
                patch[key] = sorted(patch[key])
    return value
assert normalized(old) == normalized(new), 'A perch changed beyond deterministic triangle order/source binding'
for target in (models, preview / 'site/al-folio/assets/models/home'):
    shutil.copyfile(new_path, target / new_path.name)
producer = root / 'bin/build_loading_sketch.cjs'
shutil.copyfile(producer, source / 'bin/build_loading_sketch.cjs')
inputs = {p.relative_to(source).as_posix(): sha(p) for base in ('assets/js', 'assets/models/home') for p in (source / base).rglob('*') if p.is_file() and 'loading-sketch' not in p.as_posix()}
server = json.loads((preview / 'server.json').read_bytes())
env = dict(os.environ, NODE_PATH=str(root / 'node_modules'), VISUAL_BASE_URL=server['url'].rstrip('/'))
command = [shutil.which('node'), str(source / 'bin/build_loading_sketch.cjs')]
start = time.monotonic()
with (out / 'build.log').open('wb') as log:
    result = subprocess.run(command, cwd=source, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=1200)
record = {'at': datetime.now(timezone.utc).isoformat(), 'command': command, 'producerSha256': sha(producer), 'exitCode': result.returncode, 'seconds': time.monotonic() - start, 'server': server, 'scope': 'All views from the unchanged owning three-pass source-tracing producer, complete private production preview. This is authoring evidence with the producer own controller instrumentation, not public renderer/performance acceptance.', 'perchContactPayloadExactModuloTriangleOrder': normalized(old) == normalized(new), 'inputs': inputs}
(out / 'PROCESS.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf8')
assert result.returncode == 0
outputs = [models / 'loading-sketch.json', *sorted((models / 'loading-sketch').glob('*.json'))]
record['outputs'] = [{'path': p.relative_to(source).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in outputs]
for p in outputs:
    target = preview / 'site/al-folio' / p.relative_to(source)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(p, target)
assert all(sha(root / rel) == digest for rel, digest in canonical.items())
record['canonicalModelsAndNativeUnchanged'] = True
(out / 'PROCESS.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf8')
print(json.dumps({k: v for k, v in record.items() if k != 'inputs'}, indent=2))
