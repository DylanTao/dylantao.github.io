"""Read-only full native and actual decoded overlap gates for the public island."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, sys, time

root = Path.cwd()
q = Path(__file__).parent
out = q / 'public-island-overlap-v1'
assert not out.exists()
out.mkdir()
source = q / 'public-island-owning-ao-v1/candidate.blend'
models = q / 'public-island-preview-v1/source/assets/models/home'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
expected = 'cb531e3839358ec96b3da21ea09c3b2b69891e507bcf12d220b9a5e35e503fff'
assert sha(source) == expected
canonical = root / 'artwork/coastal-home/coastal-home.blend'
canonical_sha = sha(canonical)
assert canonical_sha == '1e10b25d5cf0eec87d7001acbf9d938d65ba33af6076380d5a8e5d45cf3d23e7'
sys.path.insert(0, str(root / 'bin'))
import summarize_coastal_overlaps as compact
records = []
for kind, delivered in [('native', '0'), ('decoded', '1')]:
    dest = out / kind
    dest.mkdir()
    command = ['D:/tools/blender-4.5.9-windows-x64/blender.exe', '--background', '--factory-startup', '--python-exit-code', '1', '-t', '4', '--python', str(root / 'bin/audit_coastal_overlaps.py'), '--', '--source=' + str(source), '--manifest=' + str(models / 'manifest.json'), '--models=' + str(models), '--delivered=' + delivered, '--out=' + str(dest / 'AUDIT.json')]
    start = time.monotonic()
    with (dest / 'audit.log').open('wb') as log:
        result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT, timeout=900)
    record = {'at': datetime.now(timezone.utc).isoformat(), 'kind': kind, 'command': command, 'exitCode': result.returncode, 'seconds': time.monotonic() - start, 'sourceSha256': sha(source), 'canonicalUnchanged': sha(canonical) == canonical_sha}
    (dest / 'PROCESS.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf8')
    assert result.returncode == 0 and record['canonicalUnchanged'] and sha(source) == expected
    audit = json.loads((dest / 'AUDIT.json').read_bytes())
    totals = compact.totals(audit)
    (dest / 'TOTALS.json').write_text(json.dumps(totals, indent=2) + '\n', encoding='utf8')
    record['totals'] = totals
    assert totals['zFightingVisibleAreaM2'] <= (2.5 if delivered == '1' else 2.2), totals
    assert totals['grazingSeamM'] <= 5.6 and totals['deepSitesOver5cm'] <= 350 and totals['deepSeverity'] <= 50250, totals
    records.append(record)
    print(json.dumps({'kind': kind, 'seconds': record['seconds'], 'totals': totals}), flush=True)
(out / 'SUMMARY.json').write_text(json.dumps({'scope': 'Unmodified full native and decoded audits with all delivered furniture, unchanged thresholds and no owner exclusions. Appearance, public Walk, source/codec custody and final production publication remain separate.', 'records': records}, indent=2) + '\n', encoding='utf8')
