"""Install only the independently qualified island, preserving the previous source."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, subprocess, sys

root=Path.cwd();q=Path(__file__).parent;out=q/'public-island-install-v1'
assert not out.exists();out.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
preview=q/'public-island-preview-v1';source=preview/'source'
native=q/'public-island-owning-ao-v1/candidate.blend'
assert sha(native)=='cb531e3839358ec96b3da21ea09c3b2b69891e507bcf12d220b9a5e35e503fff'
assert sha(root/'artwork/coastal-home/coastal-home.blend')=='1e10b25d5cf0eec87d7001acbf9d938d65ba33af6076380d5a8e5d45cf3d23e7'
assert json.loads((q/'public-island-decoded-v2/AUDIT.json').read_bytes())['pass']
assert len(json.loads((q/'public-island-overlap-v1/SUMMARY.json').read_bytes())['records'])==2
walk=json.loads((q/'public-island-walk-v3/WALK.json').read_bytes())
assert len(walk['samples'])==9 and walk['final']['walk']['distance']>11 and not walk['errors']and not walk['failed']
for preset in ('2k','4k','phone-webkit'):
    d=json.loads((q/('public-island-appearance-v1-'+preset)/'CAPTURE.json').read_bytes())
    assert not d['errors']and not d['failed']and all(r.get('exact')and r['status']<400 for r in d['responses'])
old_manifest=json.loads((root/'assets/models/home/manifest.json').read_bytes());new_manifest=json.loads((source/'assets/models/home/manifest.json').read_bytes())
assert {k:v for k,v in old_manifest.items()if k!='staticLightFieldCache'}=={k:v for k,v in new_manifest.items()if k!='staticLightFieldCache'}
files=['assets/models/home/room-kitchen.glb','assets/models/home/manifest.json','assets/models/home/static-light-field.json','assets/models/home/wildlife-perch-support.json','assets/models/home/loading-sketch.json','assets/models/home/loading-sketch/kitchen.json','assets/models/home/loading-sketch/sleep.json']
before={p.relative_to(root).as_posix():sha(p)for p in(root/'assets/models/home').rglob('*')if p.is_file()}
rows=[]
for rel in ['artwork/coastal-home/coastal-home.blend',*files,'artwork/coastal-home/reviews/house-2026-10-24/overlap-audit.json']:
    p=root/rel;backup=out/'before'/rel;backup.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,backup)
    rows.append({'path':rel,'beforeSha256':sha(p)})
shutil.copyfile(native,root/'artwork/coastal-home/coastal-home.blend')
for rel in files:shutil.copyfile(source/rel,root/rel)
command=[sys.executable,'-X','utf8',str(root/'bin/summarize_coastal_overlaps.py'),'--audit='+str(q/'public-island-overlap-v1/native/AUDIT.json'),'--delivered='+str(q/'public-island-overlap-v1/decoded/AUDIT.json'),'--before='+str(out/'before/artwork/coastal-home/reviews/house-2026-10-24/overlap-audit.json'),'--manifest='+str(root/'assets/models/home/manifest.json'),'--out='+str(root/'artwork/coastal-home/reviews/house-2026-10-24/overlap-audit.json')]
r=subprocess.run(command,cwd=root,capture_output=True,text=True)
(out/'compact.log').write_text(r.stdout+r.stderr,encoding='utf8');assert r.returncode==0
report=root/'artwork/coastal-home/reviews/house-2026-10-24/overlap-audit.json';data=json.loads(report.read_bytes())
assert data['sourceSha256']==sha(root/'artwork/coastal-home/coastal-home.blend')
audited=data['source'];data['source']='artwork/coastal-home/coastal-home.blend'
data['installation']={'auditedSource':audited,'canonicalSource':data['source'],'exactBytesInstalled':True,'evidence':'artwork/coastal-home/reviews/kitchen-island-delivery-2026-11-03/README.md'}
report.write_text(json.dumps(data,indent=1)+'\n',encoding='utf8',newline='\n')
for row in rows:row['afterSha256']=sha(root/row['path'])
assert {rel for rel,digest in before.items()if sha(root/rel)!=digest}==set(files)
receipt={'at':datetime.now(timezone.utc).isoformat(),'scope':'Exact qualified island native and one room export; generated official cache, unchanged-contact perch source binding, regenerated loading drawings and source/asset-bound compact overlap report. No entrance, cliff, pavilion, experimental coffee venue, actor, anchor or runtime module installation.', 'sourceSha256':sha(native),'unrelatedModelFilesExact':len(before)-len(files),'files':rows,'compactCommand':command}
(out/'INSTALL.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');print(json.dumps({'installedFiles':len(rows),'sourceSha256':receipt['sourceSha256'],'unrelatedModelFilesExact':receipt['unrelatedModelFilesExact']}))
