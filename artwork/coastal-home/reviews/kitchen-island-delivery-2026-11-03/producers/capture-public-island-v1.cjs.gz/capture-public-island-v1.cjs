const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const root = process.cwd(), q = __dirname, preset = process.argv[2];
if (!['2k', '4k', 'phone-webkit'].includes(preset)) throw Error('Select capture preset');
const phone = preset === 'phone-webkit';
const sdk = phone ? require(path.join(q, 'webkit-1.65-alpha-20261028/node_modules/@playwright/test')) : require('@playwright/test');
const { expect } = sdk, preview = path.join(q, 'public-island-preview-v1'), built = path.join(preview, 'site/al-folio');
const server = JSON.parse(fs.readFileSync(path.join(preview, 'server.json'))), base = server.url;
const out = path.join(q, 'public-island-appearance-v1-' + preset);
if (fs.existsSync(out)) throw Error('Fresh evidence required');
fs.mkdirSync(out);
const hash = b => crypto.createHash('sha256').update(b).digest('hex'), errors = [], failed = [], responses = [], pending = [], rows = [];
const state = p => p.evaluate(() => document.querySelector('[data-home-desk-scene]').getSceneEvidence());
async function settle(p) {
  let prior;
  for (let i = 0; i < 100; i++) {
    const e = await state(p);
    if (prior && !e.traveling && Math.hypot(...e.camera.map((v, n) => v - prior[n])) < 1e-5) return e;
    prior = e.camera;
    await p.waitForTimeout(120);
  }
  throw Error('Camera did not settle');
}
(async () => {
  const browser = await sdk[phone ? 'webkit' : 'chromium'].launch({headless: true, ...(phone ? {} : {args: ['--use-angle=d3d11', '--ignore-gpu-blocklist']})});
  try {
    const viewport = phone ? {width: 390, height: 1000} : preset === '4k' ? {width: 3840, height: 2160} : {width: 2560, height: 1440};
    const context = await browser.newContext({...phone ? sdk.devices['iPhone 13'] : {}, viewport, deviceScaleFactor: 1, timezoneId: 'America/Los_Angeles', colorScheme: 'light', reducedMotion: 'reduce'});
    const p = await context.newPage(); p.setDefaultTimeout(45000);
    await p.clock.setFixedTime(new Date('2026-10-23T14:00:00-07:00'));
    await p.route(/https:\/\/(?:analytics\.google\.com|www\.google-analytics\.com|www\.googletagmanager\.com|plausible\.io)\//, r => r.fulfill({status: 204, body: ''}));
    const modules = JSON.parse(fs.readFileSync(path.join(built, 'assets/js/module-build.json'))).modules;
    expect(Object.keys(modules)).toHaveLength(189);
    for (const [rel, row] of Object.entries(modules)) {
      expect(hash(fs.readFileSync(path.join(root, rel)).toString().replaceAll('\r\n', '\n'))).toBe(row.sourceSha256);
      expect(hash(fs.readFileSync(path.join(built, rel)))).toBe(row.outputSha256);
    }
    p.on('pageerror', e => errors.push(e.message));
    p.on('console', m => {if (m.type() === 'error') errors.push(m.text());});
    p.on('requestfailed', r => failed.push({url: r.url(), failure: r.failure()}));
    p.on('response', r => {
      if (!r.url().startsWith(base) || !/\.(?:mjs|glb|json)(?:\?|$)/.test(r.url())) return;
      pending.push((async () => {
        try {
          const body = await r.body(), rel = decodeURIComponent(new URL(r.url()).pathname.slice(new URL(base).pathname.length));
          responses.push({path: rel, status: r.status(), bytes: body.length, sha256: hash(body), exact: body.equals(fs.readFileSync(path.join(built, rel))), owner: r.headers()['x-sirui-preview']});
        } catch (e) { responses.push({url: r.url(), error: String(e)}); }
      })());
    });
    const click = async locator => phone ? locator.tap() : locator.click();
    const theme = async mode => {await click(p.locator('[data-theme-toggle]:visible').first()); await click(p.locator(`[data-theme-mode-option="${mode}"]:visible`).first()); await click(p.locator('[data-theme-toggle]:visible').first());};
    await p.goto(base + (phone ? '' : '?quality=high&resolution=fixed'), {waitUntil: 'domcontentloaded'});
    await p.evaluate(() => document.fonts.ready);
    await theme('noon');
    await click(p.locator('[data-home-desk-mode="3d"]'));
    const scene = p.locator('[data-home-desk-scene]'), canvas = scene.locator('canvas:not(.home-world-sketch)');
    await scene.scrollIntoViewIfNeeded();
    await expect(scene).toHaveAttribute('data-scene-state', 'ready', {timeout: 180000});
    for (const mode of preset === '4k' ? ['noon'] : ['noon', 'evening']) {
      if (mode === 'evening') {await click(p.locator('[data-world-exit]')); await theme(mode);}
      await click(p.locator('[data-world-places]>summary'));
      await click(p.locator('[data-world-destination="kitchen"]'));
      expect((await settle(p)).currentRoom).toBe('kitchen');
      const embed = await state(p);
      await canvas.screenshot({path: path.join(out, mode + '-embed.png')});
      await click(p.locator('[data-world-fullscreen]'));
      for (const [label, dx, dy] of [['default', 0, 0], ...preset === '4k' ? [] : [['side', phone ? -60 : -140, phone ? 30 : 60]]]) {
        if (dx || dy) {
          const b = await canvas.boundingBox(), x = b.x + b.width * .5, y = b.y + b.height * .48;
          await p.mouse.move(x, y); await p.mouse.down(); await p.mouse.move(x + dx, y + dy, {steps: 16}); await p.mouse.up();
        }
        const e = await settle(p);
        expect(e.simulation.lightField.cacheHit).toBe(true);
        const image = await canvas.screenshot({path: path.join(out, mode + '-' + label + '-canvas.png')});
        expect(image.length).toBeGreaterThan(phone ? 30000 : 150000);
        const backend = await canvas.evaluate(c => {const g = c.getContext('webgl2'), ext = g?.getExtension('WEBGL_debug_renderer_info'); return g ? {renderer: g.getParameter(ext?.UNMASKED_RENDERER_WEBGL || g.RENDERER), buffer: [g.drawingBufferWidth, g.drawingBufferHeight]} : null;});
        rows.push({mode, label, embed, evidence: e, backend, pngSha256: hash(image)});
        console.log(JSON.stringify({preset, mode, label, backend}));
      }
    }
    await Promise.all(pending);
    fs.writeFileSync(path.join(out, 'CAPTURE.json'), JSON.stringify({scope: 'Complete source-bound production-seed candidate. Public theme, Rooms and fullscreen controls with trusted input; fixed Date, otherwise normal animation clocks. Native desktop high/fixed detail is disclosed; phone WebKit uses its automatic tier. No Lab, Pause or model/module response substitutions. This is visual evidence, not frame-rate or physical-phone acceptance. A fresh whole production build follows.', at: new Date().toISOString(), preset, server, browserVersion: browser.version(), rows, errors, failed, responses}, null, 2) + '\n');
    expect(errors).toEqual([]); expect(failed).toEqual([]);
    expect(responses.filter(r => r.error || !r.exact || r.status >= 400 || r.owner !== server.header)).toEqual([]);
    await context.close();
  } finally {await browser.close();}
})().catch(e => {fs.writeFileSync(path.join(out, 'FAILURE.json'), JSON.stringify({error: String(e), rows, errors, failed, responses}, null, 2)); console.error(e); process.exitCode = 1;});
