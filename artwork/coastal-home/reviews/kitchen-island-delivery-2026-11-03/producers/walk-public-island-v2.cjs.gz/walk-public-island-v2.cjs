const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {chromium,expect}=require('@playwright/test');
const root=process.cwd(),q=__dirname,preview=path.join(q,'public-island-preview-v1'),built=path.join(preview,'site/al-folio');
const server=JSON.parse(fs.readFileSync(path.join(preview,'server.json'))),base=server.url,out=path.join(q,'public-island-walk-v2');
if(fs.existsSync(out))throw Error('Fresh evidence required');fs.mkdirSync(out);
const {pauseSceneClock,useSoftwareSceneCadence}=require(path.join(root,'test/visual/scene-clock.js'));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),errors=[],failed=[],responses=[],pending=[],samples=[];
const evidence=p=>p.evaluate(()=>document.querySelector('[data-home-desk-scene]').getSceneEvidence());
const wrap=a=>Math.atan2(Math.sin(a),Math.cos(a));
(async()=>{const browser=await chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']});try{
 const context=await browser.newContext({viewport:{width:2560,height:1440},deviceScaleFactor:1,timezoneId:'America/Los_Angeles',colorScheme:'light',reducedMotion:'reduce'}),p=await context.newPage();p.setDefaultTimeout(45000);
 await p.clock.setFixedTime(new Date('2026-10-23T14:00:00-07:00'));
 await p.route(/https:\/\/(?:analytics\.google\.com|www\.google-analytics\.com|www\.googletagmanager\.com|plausible\.io)\//,r=>r.fulfill({status:204,body:''}));
 p.on('pageerror',e=>errors.push(e.message));p.on('console',m=>{if(m.type()==='error')errors.push(m.text());});p.on('requestfailed',r=>failed.push({url:r.url(),failure:r.failure()}));
 p.on('response',r=>{if(!r.url().startsWith(base)||!/\.(?:mjs|glb|json)(?:\?|$)/.test(r.url()))return;pending.push((async()=>{try{const body=await r.body(),rel=decodeURIComponent(new URL(r.url()).pathname.slice(new URL(base).pathname.length));responses.push({path:rel,status:r.status(),bytes:body.length,sha256:hash(body),exact:body.equals(fs.readFileSync(path.join(built,rel))),owner:r.headers()['x-sirui-preview']});}catch(e){responses.push({url:r.url(),error:String(e)});}})());});
 await p.goto(base+'?quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});
 await p.locator('[data-theme-toggle]:visible').first().click();await p.locator('[data-theme-mode-option="noon"]:visible').first().click();await p.locator('[data-theme-toggle]:visible').first().click();
 await p.locator('[data-home-desk-mode="3d"]').click();const scene=p.locator('[data-home-desk-scene]'),canvas=scene.locator('canvas:not(.home-world-sketch)');await scene.scrollIntoViewIfNeeded();await expect(scene).toHaveAttribute('data-scene-state','ready',{timeout:180000});
 await p.locator('[data-world-places]>summary').click();await p.locator('[data-world-destination="kitchen"]').click();await expect.poll(async()=>(await evidence(p)).currentRoom).toBe('kitchen');await p.waitForTimeout(1800);
 await p.locator('[data-world-fullscreen]').click();await p.waitForTimeout(1500);
 await pauseSceneClock(p);await useSoftwareSceneCadence(p,{continuousHz:10,force:true});await canvas.press('v');
 let initial;for(let i=0;i<120;i++){await p.clock.runFor(200);initial=await evidence(p);if(initial.walk?.active&&initial.walk?.ready)break;await p.waitForTimeout(50);}
 expect(initial.walk?.active).toBe(true);expect(initial.walk?.ready).toBe(true);console.log('initial',JSON.stringify(initial.walk));
 const progress=()=>fs.writeFileSync(path.join(out,'PROGRESS.json'),JSON.stringify({initial:initial.walk,samples,errors,failed},null,2)+'\n');progress();
 const pose=async()=>(await evidence(p)).walk;
 async function turnTo(yaw){for(let i=0;i<40;i++){const s=await pose(),d=wrap(yaw-s.yaw);if(Math.abs(d)<.045)return;const key=d>0?'ArrowLeft':'ArrowRight';await p.keyboard.down(key);await p.clock.runFor(Math.min(260,Math.abs(d)/1.9*1000));await p.keyboard.up(key);await p.clock.runFor(40);}throw Error('Turn budget');}
 async function walkTo(target,label){let blocked=0;for(let i=0;i<180;i++){const s=await pose(),dx=target[0]-s.position[0],dz=target[2]-s.position[2],distance=Math.hypot(dx,dz);if(distance<.12){expect(Math.abs(s.position[1]-target[1]),label+' floor').toBeLessThan(.18);samples.push({label,target,walk:s});progress();console.log(JSON.stringify({label,position:s.position,distance:s.distance}));return;}
  const d=wrap(Math.atan2(dx,dz)-s.yaw);if(Math.abs(d)>.10){await turnTo(Math.atan2(dx,dz));continue;}await p.keyboard.down('KeyW');await p.clock.runFor(Math.max(35,Math.min(220,(distance-.05)/2*1000)));await p.keyboard.up('KeyW');await p.clock.runFor(50);const n=await pose();blocked=Math.hypot(n.position[0]-s.position[0],n.position[2]-s.position[2])<.012?blocked+1:0;if(blocked>8)break;}
  throw Error(label+': stopped before '+JSON.stringify(target)+' at '+JSON.stringify(await pose()));}
 const route=[['authored kitchen exit',[-3.15,0,5.7]],['authored kitchen egress',[-3.45,0,6.6]],['west aisle',[-3.48,0,7.25]],['west end',[-3.48,0,8.95]],['rear crossing',[-1.35,0,8.95]],['east aisle',[-1.35,0,7.25]],['east end',[-1.35,0,5.55]],['front return',[-2.05,0,5.55]]];
 for(const [label,target]of route){await walkTo(target,label);if(/aisle/.test(label)){await turnTo(label==='west aisle'?Math.PI/2:-Math.PI/2);await p.clock.runFor(300);await canvas.screenshot({path:path.join(out,label.replace(' ','-')+'.png')});}}
 await turnTo(Math.PI/2);await p.clock.runFor(300);await canvas.screenshot({path:path.join(out,'complete-return.png')});
 const final=await evidence(p);expect(final.walk.distance-initial.walk.distance).toBeGreaterThan(11);expect(final.walk.position[1]).toBeGreaterThan(-.18);expect(final.simulation.lightField.cacheHit).toBe(true);
 await Promise.all(pending);const receipt={scope:'Actual complete private production candidate. Public Kitchen -> full screen -> Walk here spawn, then ordinary keyboard steering around both sides and back; ZERO Lab placements or geometry/door/camera overrides. Functional controlled clock at10Hz, disclosed test helper; this is collision/circulation/pixel evidence, not native frame-rate performance. Whole model and requested scene bodies are bound to the served build.',at:new Date().toISOString(),server,initial:initial.walk,final,samples,errors,failed,responses};fs.writeFileSync(path.join(out,'WALK.json'),JSON.stringify(receipt,null,2)+'\n');expect(errors).toEqual([]);expect(failed).toEqual([]);expect(responses.filter(r=>r.error||!r.exact||r.status>=400||r.owner!==server.header)).toEqual([]);await context.close();
}finally{await browser.close();}})().catch(e=>{fs.writeFileSync(path.join(out,'FAILURE.json'),JSON.stringify({error:String(e),samples,errors,failed,responses},null,2));console.error(e);process.exitCode=1;});
