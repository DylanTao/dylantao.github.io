"""Qualified F4 producer plus maintained lossless geology adapter; private2asset control."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import time
root=Path.cwd();q=Path(__file__).resolve().parent
wq=Path('C:/dev/site-takeover-worktrees/f6-native-20261029/.jekyll-cache/visual-qa/f6-native-20261029')
out=q/'public-island-export-v1';assert not out.exists();out.mkdir()
source=q/'public-island-owning-ao-v1/candidate.blend'
expected='cb531e3839358ec96b3da21ea09c3b2b69891e507bcf12d220b9a5e35e503fff'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(source)==expected
seed=root/'assets/models/home'
shutil.copytree(seed,out/'models')
prior=json.loads((wq/'final-v567-exterior-current/command.json').read_bytes())
producer=Path('C:/dev/site-takeover-worktrees/straight-arrival-20261101/bin/optimize_coastal_exports.py')
assert sha(producer)==prior['owningExporterCode'][str(producer)]
assert all(sha(p)==h for p,h in prior['owningExporterCode'].items())
helper=root/'bin/coastal_geology_export_custody.py'
driver='''from pathlib import Path
import sys,hashlib
sys.path.insert(0,BIN)
from coastal_geology_export_custody import install_geology_export_custody
helper=Path(HELPER);assert hashlib.sha256(helper.read_bytes()).hexdigest()==HELPERSHA
producer=Path(PRODUCER);assert hashlib.sha256(producer.read_bytes()).hexdigest()==PRODUCERSHA
custody=install_geology_export_custody(SOURCE,SOURCESHA,ARCHIVE)
exec(compile(producer.read_text(),str(producer),'exec'),{'__file__':str(producer),'__name__':'__main__'})
custody.finish()
'''
for key,value in {'BIN':str(root/'bin'),'HELPER':str(helper),'HELPERSHA':sha(helper),'PRODUCER':str(producer),'PRODUCERSHA':sha(producer),'SOURCE':str(source),'SOURCESHA':expected,'ARCHIVE':str(out/'custody')}.items():
    driver=re.sub(r'\b'+key+r'\b',lambda _:repr(value),driver)
adapter=out/'adapter.py';compile(driver,str(adapter),'exec');adapter.write_text(driver,encoding='utf8')
command=prior['command'].copy();command[command.index('--python')+1]=str(adapter)
for i,s in enumerate(command):
    if s.startswith('--source='):command[i]='--source='+str(source)
    elif s.startswith('--manifest='):command[i]='--manifest='+str(out/'models/manifest.json')
    elif s.startswith('--models-out='):command[i]='--models-out='+str(out/'models')
    elif s.startswith('--only='):command[i]='--only=room-kitchen'
    elif s.startswith('--report='):command[i]='--report='+str(out/'export.json')
    elif s.startswith('--prepared-source='):command[i]='--prepared-source='+str(out/'prepared.blend')
assert '--python-exit-code'in command and'--active-geology-ao'in command
files=lambda d:{p.relative_to(d).as_posix():sha(p)for p in d.rglob('*')if p.is_file()}
before=files(out/'models')
receipt={'source':str(source),'sourceSha256':expected,'seedModels':str(seed),'owningExporterCode':prior['owningExporterCode'],'geologyHelper':str(helper),'geologyHelperSha256':sha(helper),'command':command,'scope':'Private actual public1e10 plus island-width source, official owning AO. Exactly room-kitchen exported with the maintained production codecs; all other canonical model/metadata bytes remain exact. No canonicalasset/cache write or physical/appearance admission.','allModelsBefore':before}
(out/'command.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
start=time.monotonic()
with(out/'export.log').open('wb')as log:
    result=subprocess.run(command,cwd=producer.parents[1],stdout=log,stderr=subprocess.STDOUT,timeout=600)
after=files(out/'models');changed=[n for n in after if after[n]!=before.get(n)]
allowed={'room-kitchen.glb'}
receipt={'sourceSha256':expected,'sourceUnchanged':sha(source)==expected,'exitCode':result.returncode,'seconds':time.monotonic()-start,'changedModelFiles':changed,'allOtherModelsExact':set(changed)<=allowed,'helperUnchanged':sha(helper)==receipt['geologyHelperSha256'],'owningCodeUnchanged':all(sha(p)==h for p,h in receipt['owningExporterCode'].items()),'modelsDirectory':str(out/'models'),'actualModels':{n:{'bytes':(out/'models'/n).stat().st_size,'sha256':sha(out/'models'/n)}for n in allowed}}
receipt['passed']=result.returncode==0 and all(receipt[k]for k in ['sourceUnchanged','allOtherModelsExact','helperUnchanged','owningCodeUnchanged'])
(out/'PROCESS.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps(receipt,indent=2));assert receipt['passed']
