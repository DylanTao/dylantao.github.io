import argparse,json,os,subprocess,sys,sysconfig,time
from pathlib import Path
root=Path.cwd();q=Path(__file__).parent;out=q/'island-checkpoint';work=Path('C:/dev/cqa1102')
parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['build','unit','python']);args=parser.parse_args()
env=dict(os.environ,BUNDLE_PATH='C:/tools/site-gems-ruby33',JEKYLL_ENV='production',MAGICK_THREAD_LIMIT='4',OPENBLAS_NUM_THREADS='1')
env['PATH']='C:/tools/site-bin;C:/tools/Ruby33/bin;'+sysconfig.get_path('scripts')+';'+env['PATH']
if args.mode=='build':commands=[('production-build',['C:/tools/Ruby33/bin/ruby.exe','C:/tools/Ruby33/bin/bundle','exec','jekyll','build','--baseurl','/al-folio','--destination',str(out/'site/al-folio')])]
else:commands=[('python',[sys.executable,'-X','utf8','-m','unittest','discover','-s','test','-p','test_*.py']),('node',['node','--test',*[str(p.relative_to(work))for p in sorted((work/'test').glob('*.test.mjs'))]]),('style',['node','test/style_contract.js'])]
if args.mode=='python':commands=commands[:1]
rows=[]
for name,command in commands:
 started=time.monotonic()
 with(out/(name+'.log')).open('wb')as log:r=subprocess.run(command,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':command,'exitCode':r.returncode,'seconds':time.monotonic()-started};rows.append(row)
 (out/(args.mode.upper()+'-GATES.json')).write_text(json.dumps({'processes':rows},indent=2)+'\n');print(json.dumps({k:row[k]for k in ['name','exitCode','seconds']}),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
