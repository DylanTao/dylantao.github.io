"""Independent actual delivered island dimensions, finite samples and floor bearing."""
from pathlib import Path
import hashlib, json, math
import bpy
from mathutils import Vector
from mathutils.bvhtree import BVHTree

root = Path.cwd(); q = Path(__file__).parent; out = q / 'public-island-decoded-v2'
assert not out.exists(); out.mkdir()
assert bpy.app.version == (4, 5, 9)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = q / 'public-island-owning-ao-v1/candidate.blend'
old = root / 'assets/models/home/room-kitchen.glb'
new = q / 'public-island-preview-v1/source/assets/models/home/room-kitchen.glb'
shell = root / 'assets/models/home/home-shell.glb'
assert sha(source) == 'cb531e3839358ec96b3da21ea09c3b2b69891e507bcf12d220b9a5e35e503fff'
assert sha(new) == '6f8ef82b59c58a8a296d5fb795993e8ad599fba51764c56cd82934a8fe1e0697'
def world(obj, index):
    p = obj.matrix_world @ obj.data.vertices[index].co
    return Vector((p.x, p.z, -p.y))
def selected(points):
    return all(-3.1 < p.x < -1.8 and -.001 <= p.y < 1.2 and 5.9 < p.z < 8.6 for p in points)
def gather():
    rows = []; points = []; faces = []; objects = []; zeros = []
    for obj in bpy.context.scene.objects:
        if obj.type != 'MESH' or not obj.name.startswith(('kitchen__', 'kitchen_island_')): continue
        mesh = obj.data; mesh.calc_loop_triangles(); count = 0
        for tri in mesh.loop_triangles:
            p = [world(obj, i) for i in tri.vertices]
            if not selected(p): continue
            assert all(math.isfinite(x) for v in p for x in v)
            if (p[1] - p[0]).cross(p[2] - p[0]).length_squared == 0: zeros.append({'owner':obj.name,'face':tri.index})
            start = len(points); points.extend(p); faces.append((start, start+1, start+2)); count += 1
        if count:
            objects.append({'owner': obj.name, 'triangles': count})
    assert len(faces) > 16000
    low = [min(p[k] for p in points) for k in range(3)]; high = [max(p[k] for p in points) for k in range(3)]
    return {'bounds': [low, high], 'triangles': len(faces), 'owners': objects, 'zeroTriangles': zeros}, points, faces
rows = []
for label, file in [('native-old', root/'artwork/coastal-home/coastal-home.blend'), ('native', source), ('old-decoded', old), ('new-decoded', new)]:
    if label.startswith('native'): bpy.ops.wm.open_mainfile(filepath=str(file))
    else:
        bpy.ops.wm.read_factory_settings(use_empty=True)
        bpy.ops.import_scene.gltf(filepath=str(file))
    bpy.context.view_layer.update()
    record, points, faces = gather()
    if label == 'native':
        native_tree = BVHTree.FromPolygons(points, faces, all_triangles=True)
        native_points = points
    if label == 'new-decoded':
        decoded_tree = BVHTree.FromPolygons(points, faces, all_triangles=True)
        record['maxDecodedVertexToNativeSurfaceM'] = max(native_tree.find_nearest(p)[3] for p in points)
        record['maxNativeVertexToDecodedSurfaceM'] = max(decoded_tree.find_nearest(p)[3] for p in native_points)
        assert record['maxDecodedVertexToNativeSurfaceM'] < .003 and record['maxNativeVertexToDecodedSurfaceM'] < .003
    record.update(label=label, fileSha256=sha(file)); rows.append(record)
assert len(rows[0]['zeroTriangles']) == len(rows[1]['zeroTriangles'])
assert len(rows[3]['zeroTriangles']) <= len(rows[2]['zeroTriangles'])
old_bounds, new_bounds = rows[2]['bounds'], rows[3]['bounds']
assert abs((new_bounds[0][0] - old_bounds[0][0]) - .15) < .003
assert abs(new_bounds[1][0] - old_bounds[1][0]) < .003
assert abs((new_bounds[1][0]-new_bounds[0][0])-1.02) < .003
assert abs((new_bounds[1][2]-new_bounds[0][2])-2.51) < .003
assert max(abs(new_bounds[i][k]-old_bounds[i][k]) for i in (0,1) for k in (1,2)) < .003
# Read the real unchanged delivered floor, not a plane/manifest height substitute.
bpy.ops.wm.read_factory_settings(use_empty=True); bpy.ops.import_scene.gltf(filepath=str(shell)); bpy.context.view_layer.update()
floor_points=[]; floor_faces=[]
for obj in bpy.context.scene.objects:
    if obj.type != 'MESH': continue
    obj.data.calc_loop_triangles()
    for tri in obj.data.loop_triangles:
        p=[world(obj,i)for i in tri.vertices]
        if not all(-.08 <= v.y <= .04 for v in p): continue
        if (p[1]-p[0]).cross(p[2]-p[0]).y <= 0: continue
        start=len(floor_points);floor_points.extend(p);floor_faces.append((start,start+1,start+2))
tree=BVHTree.FromPolygons(floor_points,floor_faces,all_triangles=True)
samples=[]
for i in range(9):
    for j in range(9):
        x=new_bounds[0][0]+.08+(new_bounds[1][0]-new_bounds[0][0]-.16)*i/8
        z=new_bounds[0][2]+.08+(new_bounds[1][2]-new_bounds[0][2]-.16)*j/8
        hit,normal,face,distance=tree.ray_cast(Vector((x,.1,z)),Vector((0,-1,0)),.2)
        assert hit is not None
        assert abs(new_bounds[0][1]-hit.y) <= .006
        samples.append({'x':x,'z':z,'floorY':hit.y,'bottomGapM':new_bounds[0][1]-hit.y,'decodedFloorFace':face})
receipt={'scope':'Read-only actual source and Draco-delivered island envelope, finite triangles and explicit genuine-zero census (native count preserved, no new decoded zeros), bidirectional VERTEX-to-surface samples and81actual decoded-floor contacts. Vertex samples are not a continuous Hausdorff/closed-solid certificate. Saved native83-part directed closure/field audit and unmodified full native+decoded overlap audit supply separate gates. No model, source, manifest or tolerance changes.','sourceSha256':sha(source),'producerSha256':sha(Path(__file__)),'rows':rows,'floorSha256':sha(shell),'floorBearing':samples,'pass':True}
(out/'AUDIT.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps({'rows':rows,'floorContacts':len(samples),'maxBottomGapM':max(abs(x['bottomGapM'])for x in samples)},indent=2))
