from pathlib import Path
import sys,hashlib
sys.path.insert(0,'C:\\dev\\dylantao.github.io\\bin')
from coastal_geology_export_custody import install_geology_export_custody
helper=Path('C:\\dev\\dylantao.github.io\\bin\\coastal_geology_export_custody.py');assert hashlib.sha256(helper.read_bytes()).hexdigest()=='a9424a87a50480af9d6331b45483e869fd3d95f18dd619eedf5b6dc1d3967f71'
producer=Path('C:\\dev\\site-takeover-worktrees\\straight-arrival-20261101\\bin\\optimize_coastal_exports.py');assert hashlib.sha256(producer.read_bytes()).hexdigest()=='1d5f07faa95df93e8fd4e3583715ee5e5e5ac079cbacf84d9080b0c2439e5e1d'
custody=install_geology_export_custody('C:\\dev\\dylantao.github.io\\.jekyll-cache\\visual-qa\\final-house-integration-20261102\\public-island-owning-ao-v1\\candidate.blend','cb531e3839358ec96b3da21ea09c3b2b69891e507bcf12d220b9a5e35e503fff','C:\\dev\\dylantao.github.io\\.jekyll-cache\\visual-qa\\final-house-integration-20261102\\public-island-export-v1\\custody')
exec(compile(producer.read_text(),str(producer),'exec'),{'__file__':str(producer),'__name__':'__main__'})
custody.finish()
