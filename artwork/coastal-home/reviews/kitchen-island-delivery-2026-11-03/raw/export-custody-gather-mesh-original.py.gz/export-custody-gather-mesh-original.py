def __gather_mesh(vnode, blender_object, export_settings):
    if vnode.blender_type == VExportNode.COLLECTION:
        return None
    if blender_object and blender_object.type in ['CURVE', 'SURFACE', 'FONT']:
        return __gather_mesh_from_nonmesh(blender_object, export_settings)
    if blender_object is None and type(vnode.data).__name__ not in ["Mesh"]:
        return None  # TODO
    if blender_object is None:
        # GN instance
        blender_mesh = vnode.data
        # Keep materials from the tmp mesh, but if no material, keep from object
        materials = tuple(mat for mat in blender_mesh.materials)
        __keep_material_info(materials, False, export_settings)
        if len(materials) == 1 and materials[0] is None:
            materials = tuple(ms.material for ms in vnode.original_object.material_slots)
            __keep_material_info(materials, True, export_settings)

        uuid_for_skined_data = None
        modifiers = None

        if blender_mesh is None:
            return None

    else:
        if blender_object.type != "MESH":
            return None
        # For duplis instancer, when show is off -> export as empty
        if vnode.force_as_empty is True:
            return None
        # Be sure that object is valid (no NaN for example)
        res = blender_object.data.validate()
        if res is True:
            export_settings['log'].warning("Mesh " + blender_object.data.name +
                                           " is not valid, and may be exported wrongly")

        modifiers = blender_object.modifiers
        if len(modifiers) == 0:
            modifiers = None

        if export_settings['gltf_apply']:
            if modifiers is None:  # If no modifier, use original mesh, it will instance all shared mesh in a single glTF mesh
                blender_mesh = blender_object.data
                # Keep materials from object, as no modifiers are applied, so no risk that
                # modifiers changed them
                materials = tuple(ms.material for ms in blender_object.material_slots)
                __keep_material_info(materials, True, export_settings)
            else:
                armature_modifiers = {}
                if export_settings['gltf_skins']:
                    # temporarily disable Armature modifiers if exporting skins
                    for idx, modifier in enumerate(blender_object.modifiers):
                        if modifier.type == 'ARMATURE':
                            armature_modifiers[idx] = modifier.show_viewport
                            modifier.show_viewport = False

                depsgraph = bpy.context.evaluated_depsgraph_get()
                blender_mesh_owner = blender_object.evaluated_get(depsgraph)
                blender_mesh = blender_mesh_owner.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
                # Seems now (from 4.2) the custom properties are Statically Typed
                # so no need to copy them in that case, because overwriting them will crash
                if len(blender_mesh.keys()) == 0:
                    # Copy custom properties
                    for prop in [p for p in blender_object.data.keys() if ((p not in BLACK_LIST) or p.startswith("gltf"))]:
                        blender_mesh[prop] = blender_object.data[prop]
                else:
                    # But we need to remove some properties that are not needed
                    for prop in [p for p in blender_object.data.keys() if (p in BLACK_LIST and not p.startswith("gltf"))]:
                        del blender_mesh[prop]
                # Store that this evaluated mesh has been created by the exporter, and is not a GN instance mesh
                blender_mesh['gltf2_mesh_applied'] = True

                if export_settings['gltf_skins']:
                    # restore Armature modifiers
                    for idx, show_viewport in armature_modifiers.items():
                        blender_object.modifiers[idx].show_viewport = show_viewport

                # Keep materials from the newly created tmp mesh, but if no materials, keep from object
                materials = tuple(mat for mat in blender_mesh.materials)
                # We need to store link between the original material and the tmp mesh material,
                # Because of animation pointer NLA that will still have the original
                __keep_material_info(materials, False, export_settings)
                if len(materials) == 1 and materials[0] is None:
                    materials = tuple(ms.material for ms in blender_object.material_slots)
                    __keep_material_info(materials, True, export_settings)

        else:
            blender_mesh = blender_object.data
            if not export_settings['gltf_skins']:
                modifiers = None
            else:
                # Check if there is an armature modidier
                if len([mod for mod in blender_object.modifiers if mod.type == "ARMATURE"]) == 0:
                    modifiers = None

            # Keep materials from object, as no modifiers are applied, so no risk that
            # modifiers changed them
            materials = tuple(ms.material for ms in blender_object.material_slots)
            __keep_material_info(materials, True, export_settings)

        # retrieve armature
        # Because mesh data will be transforms to skeleton space,
        # we can't instantiate multiple object at different location, skined by same armature
        uuid_for_skined_data = None
        if export_settings['gltf_skins']:
            for idx, modifier in enumerate(blender_object.modifiers):
                if modifier.type == 'ARMATURE':
                    uuid_for_skined_data = vnode.uuid

    result = gltf2_blender_gather_mesh.gather_mesh(blender_mesh,
                                                   uuid_for_skined_data,
                                                   blender_object.vertex_groups if blender_object else None,
                                                   modifiers,
                                                   materials,
                                                   None,
                                                   export_settings)

    if export_settings['gltf_apply'] and modifiers is not None:
        blender_mesh_owner.to_mesh_clear()

    return result
