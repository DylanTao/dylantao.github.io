﻿from pathlib import Path
import json,hashlib
root=Path.cwd();q=root/'.jekyll-cache/visual-qa/gym-dashboard-20261101';site=q/'site/al-folio';private=q/'bake-workspace'
sha=lambda b:hashlib.sha256(b).hexdigest()
r={'files':{},'sourceBindings':{},'publicBindings':{},'canonical':{},'moduleReceipt':{},'seedDiff':{}}
for f in ['public-dashboard-chromium-2k.json','public-dashboard-webkit-phone.json','walk-screen-chromium.json','walk-screen-webkit.json','gpu-training.json']:
 j=json.loads((q/f).read_text('utf8'));bs=j['bindings'];r['publicBindings'][f]=bs
 for rel,b in bs.items():
  body=(site/rel).read_bytes();assert sha(body)==b['sha256'] and len(body)==b['bytes'],(f,rel)
receipt=json.loads((site/'assets/js/module-build.json').read_text('utf8'))
for name in ['controller.mjs','gym-props.mjs','gym-dashboard.mjs','walk-controls.mjs','walk-presence.mjs']:
 rel='assets/js/home-scene/'+name;b=(root/rel).read_bytes().replace(b'\r\n',b'\n');p=(private/rel).read_bytes().replace(b'\r\n',b'\n');assert b==p,rel
 r['sourceBindings'][rel]={'sha256':sha(b),'bytesLf':len(b),'privateBakeExact':True}
 cr=receipt['modules'][rel];assert cr['sourceSha256']==sha(b) and cr['outputSha256']==sha((site/rel).read_bytes());r['moduleReceipt'][rel]=cr
for rel,old in json.loads((q/'canonical-assets-before.json').read_text('utf8')).items():
 now=sha((root/rel).read_bytes());assert now==old;r['canonical'][rel]={'sha256':now,'unchanged':True}
for rel in ['assets/models/home/manifest.json','assets/models/home/static-light-field.json']:
 assert (private/rel).read_bytes()==(site/rel).read_bytes(),rel
 r['files'][rel]={'sha256':sha((site/rel).read_bytes()),'bytes':(site/rel).stat().st_size,'privateBakeServedExact':True}
producer='bin/bake_coastal_static_light.cjs';r['officialProducerSha256']=sha((root/producer).read_bytes());assert (root/producer).read_bytes()==(private/producer).read_bytes()
seed=Path('C:/dev/dylantao.github.io/.jekyll-cache/visual-qa/pinniped-integration-20261101/site/al-folio')
base={p.relative_to(seed).as_posix():sha(p.read_bytes()) for p in seed.rglob('*') if p.is_file()};now={p.relative_to(site).as_posix():sha(p.read_bytes()) for p in site.rglob('*') if p.is_file()}
r['seedDiff']={'seedFiles':len(base),'currentFiles':len(now),'missing':sorted(base.keys()-now.keys()),'added':sorted(now.keys()-base.keys()),'changed':sorted(p for p in base.keys()&now.keys() if base[p]!=now[p])}
assert not r['seedDiff']['missing']
allowed={'assets/js/home-scene/'+n for n in ['controller.mjs','gym-props.mjs','walk-controls.mjs','walk-presence.mjs']}|{'assets/css/main.css','assets/css/main.css.map','assets/js/module-build.json','assets/models/home/manifest.json','assets/models/home/static-light-field.json'}
assert set(r['seedDiff']['changed'])<=allowed,r['seedDiff']['changed']
assert r['seedDiff']['added']==['assets/js/home-scene/gym-dashboard.mjs']
(q/'final-byte-bindings.json').write_text(json.dumps(r,indent=2)+'\n','utf8')
print(json.dumps({'seedDiff':r['seedDiff'],'sourceBodies':len(r['sourceBindings']),'sourceReceiptExact':True,'publicReadbacks':len(r['publicBindings']),'canonicalUnchanged':True,'officialProducerSha256':r['officialProducerSha256']},indent=2))
