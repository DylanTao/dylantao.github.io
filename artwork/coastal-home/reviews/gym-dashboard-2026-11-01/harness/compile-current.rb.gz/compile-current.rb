require 'jekyll'
require_relative '../../../_plugins/site_module_assets'
require 'fileutils'
root=Dir.pwd
dest=File.join(__dir__,'site/al-folio')
receipt_path=File.join(dest,'assets/js/module-build.json')
receipt=JSON.parse(File.read(receipt_path)); changed=[]
%w[gym-props.mjs gym-dashboard.mjs controller.mjs walk-controls.mjs walk-presence.mjs].each do |name|
 relative='assets/js/home-scene/'+name
 source=File.read(File.join(root,relative),encoding:'UTF-8')
 compiled=SiruiSite::ModuleAssets.compile(source)
 File.binwrite(File.join(dest,relative),compiled)
 receipt['modules'][relative]={'sourceSha256'=>Digest::SHA256.hexdigest(source.gsub("\r\n","\n")),'outputSha256'=>Digest::SHA256.hexdigest(compiled),'bytes'=>compiled.bytesize}
 changed << relative
end
File.binwrite(receipt_path,JSON.generate(receipt)+"\n")
# Run the actual Jekyll page renderer and its registered Sass converter, not a
# separately configured Sass approximation. Other complete product bodies stay sealed.
config=Jekyll.configuration({'source'=>root,'destination'=>dest,'baseurl'=>'/al-folio','quiet'=>true})
site=Jekyll::Site.new(config)
page=Jekyll::Page.new(site,site.source,'assets/css','main.scss')
page.render(site.layouts,site.site_payload)
page.write(dest)
site.pages.select{|p| p.path.end_with?('.css.map')}.each{|p| p.write(dest)}
changed << 'assets/css/main.css'
report={'method'=>'Unmodified Jekyll/Terser module compiler and Jekyll Page.render Sass converter over a complete seeded production product','base'=>'dd677652f','changed'=>changed,'files'=>changed.to_h{|p| b=File.binread(File.join(dest,p)); [p,{'bytes'=>b.bytesize,'sha256'=>Digest::SHA256.hexdigest(b)}]}}
File.binwrite(File.join(__dir__,'compiled-product.json'),JSON.pretty_generate(report)+"\n")
puts JSON.pretty_generate(report)
