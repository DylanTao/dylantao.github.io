from pathlib import Path
import shutil,json,hashlib
root=Path.cwd(); q=root/'.jekyll-cache/visual-qa/gym-dashboard-20261101'; work=q/'bake-workspace'
for rel in ['assets/js/home-scene','assets/js/vendor/three-r164','assets/models/home']:
 shutil.copytree(root/rel,work/rel,dirs_exist_ok=True)
for rel in ['assets/js/three.module.min.js','_plugins/site_module_assets.rb','Gemfile.lock','bin/bake_coastal_static_light.cjs','bin/coastal_static_light_inputs.cjs']:
 out=work/rel; out.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(root/rel,out)
(q/'canonical-assets-before.json').write_text(json.dumps({p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in ['assets/models/home/manifest.json','assets/models/home/static-light-field.json']},indent=2))
print(work)
