from pathlib import Path
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from functools import partial
import socket
import os

root = Path(__file__).parent / 'site'
class Handler(SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass
    def end_headers(self):
        self.send_header('X-Visual-Owner', f'interior-finish/gym4195/{os.getpid()}')
        self.send_header('Cache-Control', 'no-store')
        super().end_headers()
class Server(ThreadingHTTPServer):
    allow_reuse_address = False
    daemon_threads = True
    request_queue_size = 128
    def server_bind(self):
        if hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()
s = Server(('127.0.0.1', 4195), partial(Handler, directory=str(root)))
print({'pid': os.getpid(), 'root': str(root.resolve()), 'exclusive': True}, flush=True)
s.serve_forever()
