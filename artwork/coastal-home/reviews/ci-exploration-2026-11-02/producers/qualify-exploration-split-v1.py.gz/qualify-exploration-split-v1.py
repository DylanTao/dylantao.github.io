from pathlib import Path
import hashlib,json,subprocess,time
import yaml
root=Path.cwd();q=Path(__file__).parent;out=q/'ci-exploration-split-v1'
p=root/'.github/workflows/visual-regression.yml';before=subprocess.check_output(['git','show','HEAD:.github/workflows/visual-regression.yml']);after=p.read_bytes()
(out/'BEFORE-WORKFLOW.yml').write_bytes(before)
a=yaml.safe_load(before);b=yaml.safe_load(after)
streams=b['jobs']['visual-checkpoints']['strategy']['matrix']['stream'];assert streams.count('scene-rooms')==1;streams.remove('scene-rooms')
assert a==b and b['jobs']['visual-checkpoints']['timeout-minutes']==75
cmd=['node','bin/run_visual_scene_group.cjs','scene-rooms','--project','all','--verify-only'];start=time.monotonic()
with(out/'inventory.log').open('wb')as log:r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
receipt={'command':cmd,'exitCode':r.returncode,'seconds':time.monotonic()-start,'workflowOnlyNewMatrixStream':True,'unchangedTimeoutMinutes':75,'unchangedCaseRoster':149,'registrySha256':hashlib.sha256((root/'test/visual/scene-groups.json').read_bytes()).hexdigest()}
(out/'INVENTORY-QUALIFICATION.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
job=json.loads((q/'ci-runner-result-v1/exploration-job.json').read_bytes())
url=job['check_run_url'];prefix='https://api.github.com/repos/DylanTao/dylantao.github.io/'
assert url.startswith(prefix)
cmd=['gh','api',url[len('https://api.github.com/'): ]+'/annotations']
r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert r.returncode==0,r.stderr
(out/'CANCELLATION-ANNOTATIONS.json').write_bytes(r.stdout)
print(r.stdout.decode('utf8').encode('ascii','backslashreplace').decode())
