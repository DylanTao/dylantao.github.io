from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path.cwd();q=Path(__file__).parent;out=q/'ci-exploration-split-v1';packet=root/'artwork/coastal-home/reviews/ci-exploration-2026-11-02'
assert sorted(p.name for p in packet.iterdir())==['README.md']
cmd=['node','--test','test/visual_scene_groups.test.mjs']
with(out/'focused-node.log').open('wb')as log:r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
rows=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def deposit(rel,p):
 target=packet/(rel+'.gz');assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True)
 body=Path(p).read_bytes();stored=gzip.compress(body,mtime=0);target.write_bytes(stored)
 rows.append({'path':target.relative_to(packet).as_posix(),'bytes':len(stored),'sha256':sha(stored),'encoding':'gzip','bodyBytes':len(body),'bodySha256':sha(body)})
for p in sorted((q/'ci-runner-result-v1').iterdir()):
 if p.is_file():deposit('original-run/'+p.name,p)
for n in ['BEFORE-MANIFEST.json','BEFORE-WORKFLOW.yml','PARTITION.json','inventory.log','INVENTORY-QUALIFICATION.json','CANCELLATION-ANNOTATIONS.json','focused-node.log']:deposit('qualification/'+n,out/n)
for n in ['.github/workflows/visual-regression.yml','test/visual/scene-groups.json','test/test_resting_review_custody.py','docs/october-2026-handoff.md']:deposit('selected-source/'+n,root/n)
for n in ['capture-runner-ci-result.py','split-exploration-ci-v1.py','qualify-exploration-split-v1.py','archive-exploration-ci-v1.py']:deposit('producers/'+n,q/n)
(packet/'MANIFEST.json').write_text(json.dumps({'schema':'coastal-ci-exploration-partition-v1','scope':'Unchanged149-case registry at four widths; actual cancelled75-minute run and all26executed exploration passes/3intentional skips retained. Original workflow remains cancelled; new46-job run requires separate qualification.','files':rows},indent=2)+'\n',encoding='utf8')
print(json.dumps({'payloads':len(rows),'storedBytes':sum(r['bytes']for r in rows)}))
