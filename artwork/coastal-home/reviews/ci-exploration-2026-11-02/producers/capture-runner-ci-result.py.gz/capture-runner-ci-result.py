from pathlib import Path
import json,subprocess
q=Path(__file__).parent;out=q/'ci-runner-result-v1';assert not out.exists();out.mkdir()
commands={
 'visual.json':['gh','run','view','41543873377','--json','status,conclusion,jobs'],
 'exploration.log':['gh','run','view','41543873377','--job','125614481188','--log'],
 'exploration-job.json':['gh','api','repos/DylanTao/dylantao.github.io/actions/jobs/125614481188'],
 'workflows.json':['gh','run','list','--commit','0b63eb5793ae0399a2de3931cbc386fb7e096543','--limit','15','--json','databaseId,name,status,conclusion,headSha']}
for name,cmd in commands.items():
 r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (out/name).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr)
 assert r.returncode==0,(name,r.stderr)
d=json.loads((out/'visual.json').read_bytes())
print(json.dumps({'conclusion':d['conclusion'],'passed':sum(j['conclusion']=='success'for j in d['jobs']),'other':[{'name':j['name'],'conclusion':j['conclusion']}for j in d['jobs']if j['conclusion']!='success']},indent=2))
lines=(out/'exploration.log').read_text(encoding='utf8').splitlines();print('\n'.join(lines[-35:]))
