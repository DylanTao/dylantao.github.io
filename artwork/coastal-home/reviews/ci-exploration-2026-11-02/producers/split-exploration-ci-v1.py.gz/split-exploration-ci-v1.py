from pathlib import Path
import collections,hashlib,json,subprocess
root=Path.cwd();q=Path(__file__).parent;out=q/'ci-exploration-split-v1';assert not out.exists();out.mkdir()
p=root/'test/visual/scene-groups.json';raw=p.read_bytes();before=json.loads(raw);after=json.loads(raw)
(out/'BEFORE-MANIFEST.json').write_bytes(raw)
wanted={
 ('architecture-finish.spec.js','finished house: adjacent bedchamber, library patio leaf and composed exterior remain visible through public room visits'),
 ('desk-scene.spec.js','coastal home: every Rooms destination receives pointer input above following content'),
 ('desk-scene.spec.js','coastal home: public room navigation works in the embed and starts a safe walk from the chosen room'),
 ('desk-scene.spec.js','coastal home: a public desktop turn continues looking safely after either orbit axis reaches furniture')}
key=lambda r:(r['file'],r['title'])
members=after['groups']['scene-exploration'];assert len(members)==29
selected=[r for r in members if key(r)in wanted];remaining=[r for r in members if key(r)not in wanted]
assert len(selected)==4 and len(remaining)==25 and {key(r)for r in selected}==wanted
assert 'scene-rooms'not in after['groups']
groups={}
for name,value in after['groups'].items():
 groups[name]=remaining if name=='scene-exploration'else value
 if name=='scene-exploration':groups['scene-rooms']=selected
after['groups']=groups;after['head']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
old=collections.Counter(key(r)for members in before['groups'].values()for r in members)
new=collections.Counter(key(r)for members in after['groups'].values()for r in members)
assert old==new and all(n==1 for n in new.values()) and before['manifestOrder']==after['manifestOrder']
p.write_text(json.dumps(after,indent=2)+'\n',encoding='utf8')
receipt={'scope':'Exact unchanged registered case membership. Only four existing costly public room cases move to an independent same-engine/same-viewport process; same one-worker limits, fixtures, assertions, assets, intentional skips and75minute job cap. No test deletion or new scene case.','beforeSha256':hashlib.sha256(raw).hexdigest(),'parent':after['head'],'beforeCount':sum(old.values()),'afterCount':sum(new.values()),'moved':selected,'remainingExploration':25,'rooms':4,'matrixJobsBefore':42,'matrixJobsAfter':46,'exactDuplicateFreeRosterPreserved':True}
(out/'PARTITION.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
