const { chromium } = require('playwright');
const fs = require('node:fs/promises');
const { preparePage, collectRuntimeErrors } = require('../../../test/visual/helpers');
(async()=>{
 const browser=await chromium.launch({args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
 const page=await browser.newPage({viewport:{width:1440,height:1000},deviceScaleFactor:1,timezoneId:'America/Los_Angeles'});
 const origin=process.argv[2],output=process.argv[3],warnings=[],states=[],started=performance.now();let stage='navigation';
 try{
  await page.addInitScript(()=>{
   for(const cls of [globalThis.WebGLRenderingContext,globalThis.WebGL2RenderingContext]){
    if(!cls)continue;const proto=cls.prototype,error=proto.getError;
    for(const name of ['deleteProgram','linkProgram','useProgram','getProgramParameter','getUniformLocation','getActiveUniform','getActiveAttrib','getAttribLocation','getProgramInfoLog','getAttachedShaders']){
     const original=proto[name];if(!original)continue;
     proto[name]=function(...args){const result=original.apply(this,args);if(globalThis.__traceProgramErrors){const value=error.call(this);if(value)console.warn('__GL_METHOD__'+JSON.stringify({method:name,error:value,stack:new Error('GL error attribution').stack,lost:this.isContextLost()}))}return result};
    }
   }
  });
  const errors=collectRuntimeErrors(page);
  page.on('console',m=>{if(m.type()==='warning'||m.type()==='error')warnings.push({stage,atMs:performance.now()-started,type:m.type(),text:m.text(),location:m.location()})});
  await preparePage(page,'light');await page.emulateMedia({reducedMotion:'reduce'});await page.clock.setFixedTime(new Date('2026-10-28T13:20:00-07:00'));
  await page.goto(origin+'?scene-lab=1&quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});stage='initial-load';
  await page.locator('[data-home-desk-mode="3d"]').click();const scene=page.locator('[data-home-desk-scene]'),ui=page.locator('[data-home-world-controls]');
  await scene.scrollIntoViewIfNeeded();await page.waitForFunction(()=>document.querySelector('[data-home-desk-scene]')?.dataset.sceneState==='ready',null,{timeout:180000});
  const record=async()=>states.push({stage,atMs:performance.now()-started,evidence:await scene.evaluate(e=>e.getSceneEvidence())});
  stage='ready-before-selection';await record();await page.evaluate(()=>window.__traceProgramErrors=true);const lab=ui.locator('[data-world-lab]');if(!(await lab.evaluate(e=>e.open)))await lab.locator('summary').first().click();
  for(const id of ['south-park','lizard','south-park']){stage='select-'+id;await ui.locator('[data-world-avatar]').selectOption(id);await page.waitForFunction(id=>{const e=document.querySelector('[data-home-desk-scene]').getSceneEvidence();return e.avatarId===id&&e.bedTransfer.bound},id,{timeout:60000});await page.waitForTimeout(3500);await record()}
  stage='outside-fullscreen';await ui.locator('[data-world-fullscreen]').click();await ui.locator('[data-world-view]').click();if(await lab.evaluate(e=>e.open))await lab.locator('summary').first().click();await page.waitForTimeout(3500);await record();
  const invalid=warnings.filter(m=>/INVALID_(VALUE|OPERATION)/i.test(m.text)&&/getProgramParameter|glGetProgramiv/i.test(m.text));
  await fs.writeFile(output,JSON.stringify({at:new Date().toISOString(),origin,browser:browser.version(),scope:'No module/model/identity overrides, native RAF/timers with fixedDate and reduced motion. Public avatar selector changes; this is a lifetime/GL-state diagnostic, not a timing benchmark.',states,warnings,invalidProgramWarnings:invalid.length,errors},null,2));
  console.log(JSON.stringify({origin,invalidProgramWarnings:invalid.length,errors,states:states.map(s=>({stage:s.stage,avatar:s.evidence.avatarId,shadow:s.evidence.shadowCache}))},null,2));
  if(errors.length||invalid.length)process.exitCode=1;
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
