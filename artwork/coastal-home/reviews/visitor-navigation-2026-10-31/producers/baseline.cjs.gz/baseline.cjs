const { chromium, expect } = require('@playwright/test');
const fs = require('node:fs/promises');
const path = require('node:path');
const { preparePage, collectRuntimeErrors } = require(path.resolve('test/visual/helpers.js'));
(async () => {
  const out = path.resolve('.jekyll-cache/visual-qa/room-navigation-20261031/baseline');
  await fs.mkdir(out, { recursive: true });
  const browser = await chromium.launch({ args: ['--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  try {
    const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
    await preparePage(page, 'light');
    const errors = collectRuntimeErrors(page);
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.clock.setFixedTime(new Date('2026-10-29T14:45:00-07:00'));
    await page.goto('http://127.0.0.1:4155/al-folio/', { waitUntil: 'domcontentloaded' });
    await page.locator('[data-home-desk-mode="3d"]').click();
    const scene = page.locator('[data-home-desk-scene]');
    const canvas = scene.locator('canvas');
    const stage = page.locator('[data-home-hero-media]');
    await expect(scene).toHaveAttribute('data-scene-state', 'ready', { timeout: 180000 });
    await canvas.scrollIntoViewIfNeeded();
    const rows = [];
    const read = () => scene.evaluate(e => e.getSceneEvidence());
    async function capture(id, png = true) {
      const evidence = await read();
      rows.push({ id, evidence });
      if (png) await (id === 'embed' ? canvas.locator('..').locator('..') : canvas).screenshot({ path: path.join(out, id + '.png') });
      await fs.writeFile(path.join(out, 'receipt.json'), JSON.stringify({ source: '70ee4eac5 complete build; real mouse inputs; no lab or state injection', errors, rows }, null, 2));
      console.log(JSON.stringify({ id, room: evidence.currentRoom, orbit: evidence.cameraOrbit, arm: evidence.cameraArm }));
    }
    await capture('embed');
    await page.locator('[data-world-fullscreen]').click();
    await capture('fullscreen');
    for (let i = 0; i < 5; i++) {
      await page.mouse.move(500, 450); await page.mouse.down();
      await page.mouse.move(1050, 450, { steps: 16 }); await page.mouse.up();
      await capture('yaw-' + i, i === 4);
    }
    for (const [i, a, b] of [[0, 350, 800], [1, 800, 250], [2, 700, 250]]) {
      await page.mouse.move(720, a); await page.mouse.down();
      await page.mouse.move(720, b, { steps: 16 }); await page.mouse.up();
      await capture('pitch-' + i);
    }
    expect(errors).toEqual([]);
  } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exitCode = 1; });
