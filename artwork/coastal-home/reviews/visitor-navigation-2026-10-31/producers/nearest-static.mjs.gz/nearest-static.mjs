import {readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';import {pathToFileURL} from 'node:url';
import * as THREE from '../../../assets/js/three.module.min.js';
import {nativeGeometry} from '../../../test/helpers/coastal-native-geometry.mjs';
const config=JSON.parse(readFileSync('assets/models/home/manifest.json','utf8'));
const base=pathToFileURL(resolve('assets/models/home')+'/');
const receipt=JSON.parse(readFileSync('.jekyll-cache/visual-qa/room-navigation-20261031/high-and-dark-before-header/receipt.json','utf8'));
const point=receipt.rows.find(r=>r.evidence.freeLook)?.evidence.freeLook.position;
const at=new THREE.Vector3(...point),a=new THREE.Vector3(),b=new THREE.Vector3(),c=new THREE.Vector3(),closest=new THREE.Vector3(),triangle=new THREE.Triangle(),rows=[];
for(const file of [config.shell,...config.rooms.map(r=>r.file)]){
 const root=await nativeGeometry(file,base);
 root.traverse(o=>{
  if(!o.isMesh||!o.geometry)return;
  let ancestor=o;while(ancestor){if(ancestor.userData.caveRoof||(ancestor.userData.renderStyle&&ancestor.userData.renderStyle!=='realistic'))return;ancestor=ancestor.parent}
  const p=o.geometry.attributes.position,index=o.geometry.index;let distance=Infinity,witness=null;
  for(let i=0;i<(index?.count??p.count);i+=3){
   a.fromBufferAttribute(p,index?index.getX(i):i).applyMatrix4(o.matrixWorld);b.fromBufferAttribute(p,index?index.getX(i+1):i+1).applyMatrix4(o.matrixWorld);c.fromBufferAttribute(p,index?index.getX(i+2):i+2).applyMatrix4(o.matrixWorld);
   triangle.set(a,b,c).closestPointToPoint(at,closest);const d=at.distanceTo(closest);if(d<distance){distance=d;witness=closest.toArray()}
  }
  rows.push({file,object:o.name,distance,witness});
 });
}
rows.sort((a,b)=>a.distance-b.distance);
writeFileSync('.jekyll-cache/visual-qa/room-navigation-20261031/nearest-static.json',JSON.stringify({point,closest:rows.slice(0,12)},null,2)+'\n');
console.log(JSON.stringify({point,closest:rows.slice(0,5)},null,2));
