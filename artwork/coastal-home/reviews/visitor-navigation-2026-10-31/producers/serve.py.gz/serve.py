import http.server,functools
from pathlib import Path
class Server(http.server.ThreadingHTTPServer):
    request_queue_size=128
    daemon_threads=True
class Handler(http.server.SimpleHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def log_message(self,*args):pass
Server(('127.0.0.1',4158),functools.partial(Handler,directory=str(Path(__file__).resolve().parent/'site'))).serve_forever()
