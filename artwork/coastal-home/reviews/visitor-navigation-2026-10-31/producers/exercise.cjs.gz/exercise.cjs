const { chromium, expect } = require('@playwright/test');
const fs = require('node:fs/promises'), path = require('node:path');
const { preparePage, collectRuntimeErrors } = require(path.resolve('test/visual/helpers.js'));
(async () => {
  const out = path.resolve('.jekyll-cache/visual-qa/room-navigation-20261031/candidate');
  await fs.mkdir(out, {recursive: true});
  const browser = await chromium.launch({args: ['--use-angle=d3d11', '--ignore-gpu-blocklist']});
  try {
    const page = await browser.newPage({viewport: {width: 1440, height: 1000}});
    await preparePage(page, 'light');
    await page.emulateMedia({reducedMotion: 'reduce'});
    await page.clock.setFixedTime(new Date('2026-10-29T14:45:00-07:00'));
    const errors = collectRuntimeErrors(page), rows = [];
    await page.goto('http://127.0.0.1:4158/al-folio/', {waitUntil: 'domcontentloaded'});
    await page.locator('[data-home-desk-mode="3d"]').click();
    const scene = page.locator('[data-home-desk-scene]'), canvas = scene.locator('canvas');
    await expect(scene).toHaveAttribute('data-scene-state','ready',{timeout:180000});
    await canvas.scrollIntoViewIfNeeded();
    const read = () => scene.evaluate(e => e.getSceneEvidence());
    const menu = page.locator('[data-world-places]');
    async function capture(id, image=true) {
      const evidence=await read(); rows.push({id,evidence});
      if(image) await page.locator('[data-home-artifact-stage]').screenshot({path:path.join(out,id+'.png')});
      await fs.writeFile(path.join(out,'receipt.json'),JSON.stringify({scope:'Complete full production build, plain public URL, real native mouse/keyboard/clicks; no placement or scene visibility writes',rows,errors},null,2));
      console.log(JSON.stringify({id,room:evidence.currentRoom,look:evidence.freeLook,walk:evidence.walk&&{active:evidence.walk.active,position:evidence.walk.position,room:evidence.walk.room,provisional:evidence.walk.provisional}}));
    }
    await menu.locator('summary').click(); await capture('embed-menu');
    await page.locator('[data-world-destination="study"]').click();
    await page.locator('[data-world-fullscreen]').click(); await capture('fullscreen');
    for(let i=0;i<6;i++) {
      await page.mouse.move(500,450); await page.mouse.down();
      await page.mouse.move(1050,450,{steps:16}); await page.mouse.up();
      await capture('yaw-'+i,i>=4);
    }
    expect((await read()).freeLook).not.toBeNull();
    for(const [i,a,b] of [[0,350,800],[1,800,200],[2,800,200],[3,800,200]]) {
      await page.mouse.move(720,a); await page.mouse.down();await page.mouse.move(720,b,{steps:16}); await page.mouse.up();
      await capture('pitch-'+i);
    }
    for(const room of ['study','kitchen','gym','onsen','lounge','sleep','library','library-upper','bath-living','bath-bedroom','outside','entrance']) {
      await menu.locator('summary').click();
      await page.locator(`[data-world-destination="${room}"]`).click();
      await page.locator('[data-world-walk]').click();
      await expect.poll(async()=> (await read()).walk?.active,{timeout:120000}).toBe(true);
      await expect.poll(async()=> (await read()).walk?.ready,{timeout:120000}).toBe(true);
      expect((await read()).walk.provisional).toBe(false);
      await capture('walk-'+room);
      await canvas.press('v');
    }
    expect(errors).toEqual([]);
  } finally {await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
