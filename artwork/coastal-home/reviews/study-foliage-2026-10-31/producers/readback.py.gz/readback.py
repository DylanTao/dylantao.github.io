import concurrent.futures,hashlib,json,struct,urllib.request
from pathlib import Path
q=Path(__file__).parent
site=q/'site/al-folio'
def check(file):
    rel=file.relative_to(site).as_posix()
    with urllib.request.urlopen('http://127.0.0.1:4156/al-folio/'+rel,timeout=30)as response:body=response.read()
    assert body==file.read_bytes(),rel
    return {'path':rel,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
files=sorted(p for p in (site/'assets/models/home').rglob('*')if p.is_file())
with concurrent.futures.ThreadPoolExecutor(max_workers=6)as pool:rows=list(pool.map(check,files))
baseline=json.loads((q/'compiled-baseline.json').read_text())
before={r['path']:r for r in baseline['files']}
changes=[r['path']for r in rows if r['sha256']!=before[r['path']]['sha256']]
assert changes==['assets/models/home/room-library.glb','assets/models/home/room-study.glb']
def glbjson(path):
    b=path.read_bytes();size,kind=struct.unpack_from('<II',b,12)
    assert kind==0x4e4f534a
    return json.loads(b[20:20+size])
materials=[]
for name in ['room-study.glb','room-library.glb']:
    old=glbjson(q/'original-delivered'/name)
    new=glbjson(q/'combined-level10/models'/name)
    assert old['materials']==new['materials'],name
    materials.append({'file':name,'materialDefinitionsExact':len(old['materials'])})
out={'base':'http://127.0.0.1:4156/al-folio/','completeCompiledFiles':len(baseline['files']),
     'homeHttpBodies':rows,'onlyChangedHomeFiles':changes,'exactGlbMaterialDefinitions':materials,
     'scope':'Complete70ee4eac5compiledsite; two completeGLB substitutions only. No official new light/AO acceptance.'}
(q/'http-readback.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'homeHttpBodies':len(rows),'changes':changes,'materials':materials}))
