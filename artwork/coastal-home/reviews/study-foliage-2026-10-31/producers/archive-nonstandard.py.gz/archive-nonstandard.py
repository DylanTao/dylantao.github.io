from pathlib import Path
import hashlib,json,shutil
q=Path(__file__).parent
out=q/'exploratory-viewports'
out.mkdir(exist_ok=True)
paths=[q/'capture-public.cjs']
for width in (1280,768):
    paths.extend(q.glob(f'*{width}*'))
rows=[]
for file in sorted(set(paths)):
    if not file.is_file():continue
    target=out/file.name
    if target.exists():raise RuntimeError('Preserve existing custody')
    shutil.copy2(file,target)
    rows.append({'name':file.name,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
(out/'scope.json').write_text(json.dumps({'scope':'Additional1280x1000/768x1000frames from initial height mapping; not the required1280x800/768x1024checkpoint. Retained before correcting producer and recapturing.','files':rows},indent=2)+'\n',encoding='utf-8')
