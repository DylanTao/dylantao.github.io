import hashlib,json,shutil
from pathlib import Path
q=Path(__file__).parent
old=q.parent/'study-hardware-20261029'
text=(old/'verify-native.py').read_text(encoding='utf-8')
text=text.replace("source=q/'baseline.blend'", "source=q.parent/'study-hardware-20261029/baseline.blend'")
text=text.replace("candidate=q/'candidate-final/candidate.blend'", "candidate=q/'hardware-315/candidate.blend'")
text=text.replace("q/'candidate-final/receipt.json'", "q/'hardware-315/receipt.json'")
(q/'verify-hardware.py').write_text(text,encoding='utf-8',newline='\n')
src=Path('C:/dev/dylantao.github.io/.jekyll-cache/visual-qa/pc-camera-audit-20261029/candidate-site/al-folio')
dst=q/'site/al-folio'
if dst.exists():raise RuntimeError('Refusing to overwrite preview custody')
shutil.copytree(src,dst)
rows=[]
for file in sorted(src.rglob('*')):
    if not file.is_file():continue
    rel=file.relative_to(src)
    digest=hashlib.sha256(file.read_bytes()).hexdigest()
    assert hashlib.sha256((dst/rel).read_bytes()).hexdigest()==digest
    rows.append({'path':rel.as_posix(),'bytes':file.stat().st_size,'sha256':digest})
(q/'compiled-baseline.json').write_text(json.dumps({'source':str(src),'files':rows},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'completeCompiledFiles':len(rows),'bytes':sum(x['bytes']for x in rows)}))
