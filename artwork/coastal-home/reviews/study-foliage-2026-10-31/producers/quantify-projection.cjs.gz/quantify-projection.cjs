const fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url');
const q=__dirname;
(async()=>{
 const T=await import(pathToFileURL(path.resolve(q,'../../../assets/js/three.module.min.js')).href);
 const states=JSON.parse(fs.readFileSync(path.join(q,'chromium-public-2560.json'),'utf8'));
 const data=JSON.parse(fs.readFileSync(path.join(q,'decoded-exports.json'),'utf8'));
 const rows=[];
 for(const variant of ['baseline','candidate']){
  const state=states.find(r=>r.variant===variant&&r.label==='day'),e=state.evidence;
  const [width,height]=state.backend.buffer;
  const camera=new T.PerspectiveCamera(e.cameraFov,width/height,e.cameraClip.near,e.cameraClip.far);
  camera.position.fromArray(e.camera);camera.lookAt(new T.Vector3().fromArray(e.target));camera.updateMatrixWorld(true);camera.updateProjectionMatrix();
  const m=data.find(r=>r.room==='library'&&r.variant===variant).meshes.find(m=>m.name==='library_refined_botanical__interior Epipremnum leaf');
  const points=[];
  for(let i=0;i<m.positions.length;i+=3)points.push(new T.Vector3(m.positions[i],m.positions[i+2],-m.positions[i+1]));
  const pixels=points.map(p=>{const v=p.clone().project(camera);return[(v.x*.5+.5)*width,(-v.y*.5+.5)*height]});
  let area=0;const dots=[];
  for(let i=0;i<m.indices.length;i+=3){
   const ids=m.indices.slice(i,i+3),[a,b,c]=ids.map(k=>pixels[k]);
   area+=Math.abs((b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))*.5;
   const [pa,pb,pc]=ids.map(k=>points[k]),normal=pb.clone().sub(pa).cross(pc.clone().sub(pa)).normalize(),center=pa.clone().add(pb).add(pc).multiplyScalar(1/3);
   dots.push(Math.abs(normal.dot(camera.position.clone().sub(center).normalize())));
  }
  rows.push({variant,triangleCount:m.indices.length/3,summedProjectedTriangleAreaPx2:area,absoluteViewNormalDotRange:[Math.min(...dots),Math.max(...dots)],
   pixelBounds:[[Math.min(...pixels.map(p=>p[0])),Math.min(...pixels.map(p=>p[1]))],[Math.max(...pixels.map(p=>p[0])),Math.max(...pixels.map(p=>p[1]))]],
   camera:e.camera,target:e.target,fov:e.cameraFov,buffer:[width,height],scope:'Actual deliveredDraco arrays projected through the recorded public camera. Sum includes overlapping/occluded triangles; geometric orientation evidence, not an occlusion-corrected raster area or aesthetic score.'});
 }
 fs.writeFileSync(path.join(q,'leaf-projection.json'),JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));
})().catch(e=>{console.error(e);process.exitCode=1});
