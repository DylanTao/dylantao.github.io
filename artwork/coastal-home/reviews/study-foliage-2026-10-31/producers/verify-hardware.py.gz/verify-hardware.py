"""Reopen both real saves and qualify hardware transforms and support."""
import hashlib
import json
import math
from pathlib import Path
import sys

import bpy
import numpy as np
from mathutils import Vector

q=Path(__file__).parent
sys.path.insert(0,str(q.parents[2]/'bin'))
import refresh_coastal_study_hardware as r

source=q.parent/'study-hardware-20261029/baseline.blend'
candidate=q/'hardware-315/candidate.blend'
receipt=json.loads((q/'hardware-315/receipt.json').read_text())
bpy.ops.wm.open_mainfile(filepath=str(source))
scene=bpy.context.scene
groups=r.select(scene)
selected={}
pieces=[]
before_points={}
before_normals={}
for group,objects in groups.items():
    for name,indices in objects.items():
        selected.setdefault(name,[]).extend(indices)
        obj=scene.objects[name]
        before_points[(group,name)]=r.world_points(obj,indices)
        allowed=set(indices)
        for component in r.islands(obj.data):
            if not set(component)<=allowed:continue
            points=r.world_points(obj,component)
            pieces.append({'group':group,'object':name,'indices':component,'lo':points.min(axis=0),'hi':points.max(axis=0)})
for name in selected:
    before_normals[name]=np.array([n.vector[:]for n in scene.objects[name].data.corner_normals],dtype=np.float32)
before=r.immutable_scene_digest(scene,selected)
bpy.ops.wm.open_mainfile(filepath=str(candidate))
scene=bpy.context.scene
after=r.immutable_scene_digest(scene,selected)
assert before==after==receipt['unchangedSceneDigestAfter']
transforms=[]
for (group,name),points in before_points.items():
    info=receipt['assemblies'][group]
    pivot=np.array(info['nativePivot'])
    expected=pivot+info['uniformScale']*(points-pivot)+info['nativeTranslation']
    actual=r.world_points(scene.objects[name],groups[group][name])
    error=float(np.linalg.norm(expected-actual,axis=1).max())
    assert error<.000001,(group,name,error)
    transforms.append({'group':group,'object':name,'vertices':len(actual),'maximumTransformErrorM':error})

normals=[]
for piece in pieces:
    mesh=scene.objects[piece['object']].data
    inside=set(piece['indices'])
    corners=[loop.index for loop in mesh.loops if loop.vertex_index in inside]
    actual=np.array([mesh.corner_normals[i].vector[:]for i in corners],dtype=np.float32)
    delta=np.linalg.norm(actual-before_normals[piece['object']][corners],axis=1)
    degrees=math.degrees(2*math.asin(min(1.,float(delta.max(initial=0))/2)))
    assert degrees<=.05,(piece['group'],piece['object'],degrees)
    normals.append({'group':piece['group'],'object':piece['object'],'vertices':len(inside),'corners':len(corners),'maximumAngleDegrees':degrees})
outside=[]
for name,indices in selected.items():
    obj=scene.objects[name];inside=set(indices)
    corners=[loop.index for loop in obj.data.loops if loop.vertex_index not in inside]
    actual=np.array([obj.data.corner_normals[i].vector[:]for i in corners],dtype=np.float32).reshape((-1,3))
    delta=float(np.linalg.norm(actual-before_normals[name][corners],axis=1).max(initial=0))
    assert delta==0,(name,delta)
    outside.append({'object':name,'corners':len(corners),'maximumDelta':delta})

def downward(obj,x,y,high):
    inverse=obj.matrix_world.inverted()
    origin=inverse@Vector((x,y,high))
    direction=inverse.to_3x3()@Vector((0,0,-1))
    ok,point,normal,face=obj.ray_cast(origin,direction,distance=2)
    if not ok:return None
    return {'object':obj.name,'point':list(obj.matrix_world@point),'face':face}

supports=[]
for piece in pieces:
    group=piece['group'];lo=piece['lo'];hi=piece['hi']
    owner=None
    if group=='tower' and piece['object']=='study__matte black device' and abs(lo[2])<1e-6 and hi[2]<.017:
        owner=scene.objects['core_retreat_library__pale oak']
    if group in ('primary','secondary') and piece['object']=='study__matte black device' and abs(lo[2]-.88)<1e-6 and hi[2]<.893:
        owner=scene.objects['study__milky veined marble']
    if group=='laptop' and piece['object']=='study__black magnesium laptop' and abs(lo[2]-.88)<1e-6:
        owner=scene.objects['study__milky veined marble']
    if owner is None:continue
    points=r.world_points(scene.objects[piece['object']],piece['indices'])
    bottom=points[:,2].min()
    samples=points[np.abs(points[:,2]-bottom)<.000001]
    errors=[]
    for point in samples:
        hit=downward(owner,float(point[0]),float(point[1]),float(bottom+.05))
        assert hit is not None,(group,piece['object'],point.tolist())
        gap=float(bottom-hit['point'][2]);assert abs(gap)<.000002,(group,gap)
        errors.append(gap)
    supports.append({'group':group,'object':piece['object'],'supportOwner':owner.name,'samples':len(samples),'maximumAbsGapM':max(map(abs,errors)),'bounds':[points.min(axis=0).tolist(),points.max(axis=0).tolist()]})
assert len([x for x in supports if x['group']=='tower'])==4
assert len([x for x in supports if x['group']=='primary'])==1
assert len([x for x in supports if x['group']=='secondary'])==1
assert len([x for x in supports if x['group']=='laptop'])==1

try:r.migrate(scene)
except RuntimeError as exc:
    assert str(exc)=='Study hardware has already been fitted'
    repeat=str(exc)
else:raise RuntimeError('Double application unexpectedly allowed')

out={'inputSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'candidateSha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),
     'immutableSceneBefore':before,'immutableSceneAfterReopen':after,'transforms':transforms,
     'perComponentEffectiveNormalsAfterReopen':normals,'unselectedCornerNormalsAfterReopen':outside,
     'actualSupportsAfterReopen':supports,'doubleApplicationRejected':repeat}
(q/'native-verification.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'transformMaximumM':max(x['maximumTransformErrorM']for x in transforms),'selectedNormalMaximumDegrees':max(x['maximumAngleDegrees']for x in normals),'unselectedNormalMaximumDelta':max(x['maximumDelta']for x in outside),'supports':[(x['group'],x['samples'],x['maximumAbsGapM'])for x in supports],'replayGuard':repeat}),flush=True)
