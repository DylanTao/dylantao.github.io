import hashlib,json,sys
from pathlib import Path
import bpy
q=Path(__file__).parent
source=q.parents[2]/'artwork/coastal-home/coastal-home.blend'
bpy.ops.wm.open_mainfile(filepath=str(source))
o=bpy.context.scene.objects['library_refined_botanical__interior Epipremnum leaf']
m=o.data
out={'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'object':o.name,'matrix':[list(r)for r in o.matrix_world],
     'materials':[x.name for x in m.materials],'attributes':[(x.name,x.domain,x.data_type,len(x.data))for x in m.attributes],
     'vertices':[list(o.matrix_world@v.co)for v in m.vertices],
     'faces':[list(p.vertices)for p in m.polygons], 'normals':[list(p.normal)for p in m.polygons]}
(q/'leaf-survey.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in out.items()if k not in ('vertices','faces','normals')}))
print(json.dumps({'firstVertices':out['vertices'][:8], 'firstFaces':out['faces'][:2], 'firstNormals':out['normals'][:2]}))
