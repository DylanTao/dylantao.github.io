from pathlib import Path
q=Path(__file__).parent
old=q.parent/'study-hardware-20261029'
s=(old/'verify-decoded.py').read_text(encoding='utf-8')
s=s.replace("q/'baseline.blend'", "q.parent/'study-hardware-20261029/baseline.blend'")
s=s.replace("q/'candidate-final/receipt.json'", "q/'hardware-315/receipt.json'")
s=s.replace("q/'baseline-room-study.glb'", "q/'original-delivered/room-study.glb'")
s=s.replace("q/'candidate-level10/models/room-study.glb'", "q/'combined-level10/models/room-study.glb'")
s+='''
library=[row for row in data if row['room']=='library']
old={m['name']:m for m in library[0]['meshes']}
new={m['name']:m for m in library[1]['meshes']}
assert old.keys()==new.keys()
leaf='library_refined_botanical__interior Epipremnum leaf'
unchanged=[]
for name,m in old.items():
    if name==leaf:continue
    assert m==new[name],name
    unchanged.append(name)
assert old[leaf]['material']==new[leaf]['material']=='interior Epipremnum leaf'
points=np.asarray(new[leaf]['positions']).reshape((-1,3))
root_data=json.loads((q/'pothos-v2/receipt.json').read_text())['bladeRoots']
native_roots=np.asarray([x['nativeRoot']for x in root_data])
errors=np.linalg.norm(native_roots[:,None,:]-points[None,:,:],axis=2).min(axis=1)
span=float(np.ptp(points,axis=0).max())
bound=math.sqrt(3)*.5*span/16383+.000002
assert errors.max()<=bound,(errors.max(),bound)
out={'decoder':'Deliveredthree-r164GLTFLoader+same-originDracoWASM',
     'unchangedLibraryMeshesExact':unchanged,'leafOwner':leaf,
     'baselineTriangles':len(old[leaf]['indices'])//3,'candidateTriangles':len(new[leaf]['indices'])//3,
     'decodedRootMaximumErrorM':float(errors.max()),'derivedPosition14HalfStepBoundM':bound,
     'candidateLibraryBytes':(q/'combined-level10/models/room-library.glb').stat().st_size,
     'candidateLibrarySha256':hashlib.sha256((q/'combined-level10/models/room-library.glb').read_bytes()).hexdigest()}
(q/'decoded-library-verification.json').write_text(json.dumps(out,indent=2)+'\\n',encoding='utf-8')
print(json.dumps(out),flush=True)
'''
(q/'verify-decoded.py').write_text(s,encoding='utf-8',newline='\n')
