const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const engine=process.env.INTERIOR_ENGINE||'chromium';
const modern='C:/dev/dylantao.github.io/.jekyll-cache/visual-qa/takeover-archives/walk-audit-20261028-cache/visual-qa/walk-audit-20261028/pw165/node_modules/@playwright/test';
const api=require(engine==='webkit'?modern:'C:/dev/dylantao.github.io/node_modules/@playwright/test');
const {expect}=api;
const {preparePage,collectRuntimeErrors,screenshotMetrics}=require('../../../test/visual/helpers.js');
const q=__dirname,width=Number(process.argv[2]||2560),height=({3840:2160,2560:1440,1440:1000,1280:800,768:1024,390:1000})[width];
const variants=process.argv[3]?[process.argv[3]]:['baseline','candidate'];
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
 const browser=await (engine==='webkit'?api.webkit.launch({headless:true}):api.chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']}));
 const rows=[];
 try{
  for(const variant of variants)for(const [label,time]of [['day','2026-10-29T13:00:00-07:00'],['night','2026-10-29T23:00:00-07:00']]){
   const context=await browser.newContext({viewport:{width,height},deviceScaleFactor:1,reducedMotion:'reduce',timezoneId:'America/Los_Angeles',hasTouch:engine==='webkit',isMobile:engine==='webkit'});
   const page=await context.newPage(),errors=collectRuntimeErrors(page);page.setDefaultTimeout(90000);
   await preparePage(page,label==='day'?'light':'dark');
   await page.addInitScript(()=>{sessionStorage.setItem('theme-manual','false')});
   await page.clock.setFixedTime(new Date(time));
   if(variant==='baseline')for(const name of ['room-study.glb','room-library.glb'])await page.route('**/assets/models/home/'+name,r=>r.fulfill({path:path.join(q,'original-delivered',name),contentType:'model/gltf-binary'}));
   await page.goto('http://127.0.0.1:4156/al-folio/?quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});
   const activate=locator=>engine==='webkit'?locator.tap():locator.click();
   await activate(page.locator('[data-home-desk-mode="3d"]'));
   const host=page.locator('[data-home-desk-scene]'),canvas=host.locator('canvas'),ui=page.locator('[data-home-world-controls]');
   await host.scrollIntoViewIfNeeded();
   await expect(host).toHaveAttribute('data-scene-state','ready',{timeout:240000});
   await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().currentRoom),{timeout:120000}).toBe('study');
   await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().simulation.lightField.ready),{timeout:180000}).toBe(true);
   const embedded=await canvas.screenshot({path:path.join(q,`${engine}-${variant}-${label}-embed-${width}.png`)});
   const before=await host.evaluate(e=>e.getSceneEvidence().frames);
   await activate(ui.locator('[data-world-fullscreen]'));
   await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().frames)).toBeGreaterThan(before);
   await page.waitForTimeout(500);
   const image=await canvas.screenshot({path:path.join(q,`${engine}-${variant}-${label}-fullscreen-${width}.png`)});
   const backend=await canvas.evaluate(c=>{const gl=c.getContext('webgl2'),d=gl.getExtension('WEBGL_debug_renderer_info');return{renderer:gl.getParameter(d?.UNMASKED_RENDERER_WEBGL||gl.RENDERER),buffer:[gl.drawingBufferWidth,gl.drawingBufferHeight]}});
   const evidence=await host.evaluate(e=>e.getSceneEvidence());
   expect(evidence.currentRoom).toBe('study');expect(errors).toEqual([]);
   const lab=await ui.locator('[data-world-lab]').evaluate(e=>({hidden:e.hidden,inert:e.inert}));
   expect(lab.hidden&&lab.inert).toBe(true);
   rows.push({variant,label,time,engine,browser:browser.version(),backend,url:page.url(),evidence,lab,errors,pngSha256:sha(image),embeddedSha256:sha(embedded),metrics:screenshotMetrics(image),scope:'Plain public route; ordinary3D/fullscreen controls and actual Pacific clock. Complete1360-file build, exactly two whole candidateGLB replacements; transported leaf contacts and pre-final official static-light bake.'});
   fs.writeFileSync(path.join(q,`${engine}-public-${width}.json`),JSON.stringify(rows,null,2));
   console.log(JSON.stringify({variant,label,engine,width,room:evidence.currentRoom,activity:evidence.activity,field:evidence.simulation.lightField.ready,cache:evidence.loading.lightCache,backend,errors:errors.length}));
   await context.close();
  }
 }finally{await browser.close()}
})().catch(e=>{fs.writeFileSync(path.join(q,`${engine}-capture-failure-${width}.txt`),String(e.stack||e));console.error(e);process.exitCode=1});
