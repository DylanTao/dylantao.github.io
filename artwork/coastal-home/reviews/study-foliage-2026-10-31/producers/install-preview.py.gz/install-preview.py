import hashlib,json,shutil
from pathlib import Path
q=Path(__file__).parent
folder=q/'site/al-folio/assets/models/home'
out=q/'original-delivered'
out.mkdir(exist_ok=True)
for name in ('room-study.glb','room-library.glb'):
    original=out/name
    if original.exists():raise RuntimeError('Refusing to overwrite baseline custody')
    shutil.copy2(folder/name,original)
    shutil.copy2(q/'combined-level10/models'/name,folder/name)
changed=[]
for row in json.loads((q/'compiled-baseline.json').read_text())['files']:
    file=q/'site/al-folio'/row['path']
    digest=hashlib.sha256(file.read_bytes()).hexdigest()
    if digest!=row['sha256']:changed.append({'path':row['path'],'before':row['sha256'],'after':digest,'bytes':file.stat().st_size})
assert sorted(r['path']for r in changed)==['assets/models/home/room-library.glb','assets/models/home/room-study.glb']
(q/'preview-substitution.json').write_text(json.dumps({'completeCompiledFiles':1360,'scope':'Two complete delivered room GLBs only; exact unchanged70ee4eac5 runtime; transported leaf contact field and pre-final official static-light bake','changes':changed},indent=2)+'\n',encoding='utf-8')
print(json.dumps(changed))
