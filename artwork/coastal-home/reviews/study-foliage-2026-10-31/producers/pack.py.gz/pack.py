import gzip,hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path.cwd();q=Path(__file__).parent
out=root/'artwork/coastal-home/reviews/study-foliage-2026-10-31'
out.mkdir(parents=True,exist_ok=True)
def copy(source,target,packed=True):
    p=out/target;p.parent.mkdir(parents=True,exist_ok=True)
    b=source.read_bytes();p.write_bytes(gzip.compress(b,mtime=0)if packed else b)
if '--seal-only'not in sys.argv:
    for name in ['native-verification','pothos-native-verification','decoded-verification','decoded-library-verification',
                 'compiled-baseline','preview-substitution','http-readback','leaf-projection']:
        copy(q/(name+'.json'),'data/'+name+'.json.gz')
    copy(q/'decoded-exports.json','data/actual-browser-decoded-arrays.json.gz')
    for name in ['hardware-315','pothos-v2']:
        copy(q/name/'receipt.json','data/'+name+'-receipt.json.gz')
    copy(q/'combined-level10/export.json','data/export.json.gz')
    for engine,width in [('chromium',2560),('chromium',3840),('chromium',1440),('chromium',1280),('chromium',768),('webkit',390)]:
        copy(q/f'{engine}-public-{width}.json',f'data/{engine}-public-{width}.json.gz')
    for file in sorted(q.glob('*.png')):
        copy(file,'views/'+file.name,False)
    for variant,folder in [('delivered','original-delivered'),('candidate','combined-level10/models')]:
        for name in ['room-study.glb','room-library.glb']:
            copy(q/folder/name,'models/'+variant+'-'+name+'.gz')
    for name in ['prepare.py','survey-leaves.py','verify-hardware.py','verify-pothos.py','prepare-decode-verification.py',
                 'verify-decoded.py','decode-exports.cjs','quantify-projection.cjs','capture-public.cjs','install-preview.py',
                 'archive-nonstandard.py','serve.py','readback.py','pack.py']:
        copy(q/name,'producers/'+name+'.gz')
    for name in ['hardware-315.log','verify-hardware.log','pothos-v1.log','pothos-v2.log','verify-pothos.log',
                 'combined-level10.log','decode-exports.log','verify-decoded.log','python-tests.log','style-contract.log',
                 'capture-public-2560.log','capture-public-3840.log','capture-public-1440.log','capture-public-1280.log',
                 'capture-public-768.log','capture-public-webkit-390.log','navigation.log']:
        copy(q/name,'logs/'+name+'.gz')
    for file in sorted((q/'navigation').rglob('*')):
        if not file.is_file():continue
        rel=file.relative_to(q/'navigation').as_posix()
        copy(file,'navigation/'+rel+(''if file.suffix=='.png'else'.gz'),file.suffix!='.png')
    for name in ['index.html','assets/models/home/manifest.json','assets/js/home-scene/controller.mjs','assets/js/home.js']:
        copy(q/'site/al-folio'/name,'compiled/'+Path(name).name+'.gz')
    bindings=[]
    for name in ['bin/refresh_coastal_study_hardware.py','bin/refresh_coastal_pothos_blades.py','bin/coastal_interior_refinement.py',
                 'bin/coastal_office.py','bin/coastal_landscape.py','bin/optimize_coastal_exports.py',
                 'artwork/coastal-home/coastal-home.blend','assets/models/home/room-library.glb','assets/models/home/room-study.glb']:
        b=subprocess.run(['git','show','HEAD:'+name],check=True,stdout=subprocess.PIPE).stdout
        raw=(root/name).read_bytes()
        bindings.append({'path':name,'gitBlobSha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),
                         'workingBytesSha256':hashlib.sha256(raw).hexdigest(),
                         'workingEqualsGitAfterLineEndingNormalization':raw.replace(b'\r\n',b'\n')==b.replace(b'\r\n',b'\n')})
    route_bindings=[]
    coordinator=Path('C:/dev/dylantao.github.io')
    for name in ['test/visual/estate-redesign.spec.js','test/visual/helpers.js','test/visual/scene-clock.js',
                 'test/visual/public.config.js','bin/visual_scene_environment.cjs']:
        b=subprocess.run(['git','-C',str(coordinator),'show','70ee4eac5:'+name],check=True,stdout=subprocess.PIPE).stdout
        raw=(coordinator/name).read_bytes()
        assert raw.replace(b'\r\n',b'\n')==b.replace(b'\r\n',b'\n'),name
        path=out/'producers'/(Path(name).name+'.gz');path.write_bytes(gzip.compress(b,mtime=0))
        route_bindings.append({'path':name,'sourceCommit':'70ee4eac5','gitBlobSha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
    source={'sourceCommit':subprocess.run(['git','rev-parse','HEAD'],check=True,stdout=subprocess.PIPE,text=True).stdout.strip(),
            'sourceBindings':bindings,
            'coordinatorRouteAndHarnessBindings':route_bindings,
            'canonicalNativeSha256':hashlib.sha256((root/'artwork/coastal-home/coastal-home.blend').read_bytes()).hexdigest(),
            'privateCombinedNativeSha256':hashlib.sha256((q/'pothos-v2/candidate.blend').read_bytes()).hexdigest(),
            'scope':'Geometry/controls private qualification; no canonicalmodel/output/cache writes or publication; final AO/staticlight rebuild required.',
            'completeCompiledSource':'70ee4eac5 production111.568sbuild supplied by coordinator; all1360file hashes bound in compiled-baseline. Two wholeGLBs differ.'}
    (out/'SOURCE_BINDINGS.json').write_text(json.dumps(source,indent=2)+'\n',encoding='utf-8',newline='\n')
payloads=[]
for file in sorted(out.rglob('*')):
    if not file.is_file()or file.name=='MANIFEST.json':continue
    b=file.read_bytes();payloads.append({'path':file.relative_to(out).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(out/'MANIFEST.json').write_text(json.dumps({'schema':1,'scope':'Source-bound geometry/controls evidence; final combined native+lighting acceptance and publication remain coordinator-owned','files':payloads},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'payloads':len(payloads),'bytes':sum(x['bytes']for x in payloads)}))
