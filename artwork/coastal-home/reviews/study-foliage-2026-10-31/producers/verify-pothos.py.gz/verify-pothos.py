import hashlib,json,sys
from pathlib import Path
from types import SimpleNamespace
import bpy,numpy as np
from mathutils import Vector
from mathutils.kdtree import KDTree
q=Path(__file__).parent
sys.path.insert(0,str(q.parents[2]/'bin'))
import refresh_coastal_pothos_blades as r
from refresh_coastal_study_hardware import immutable_scene_digest
source=q/'hardware-315/candidate.blend'
candidate=q/'pothos-v2/candidate.blend'
receipt=json.loads((q/'pothos-v2/receipt.json').read_text())
bpy.ops.wm.open_mainfile(filepath=str(source))
scene=bpy.context.scene
old=scene.objects[r.OWNER]
roots=[old.matrix_world@old.data.vertices[p.vertices[0]].co for p in old.data.polygons]
digest=immutable_scene_digest(SimpleNamespace(objects=[o for o in scene.objects if o!=old]),{})
# A same-count perturbation must fail before any output save.
old.data.vertices[0].co.x+=.0001
try:r.migrate(scene)
except RuntimeError as exc:
    assert str(exc).startswith('Retained Epipremnum input changed:')
    negative=str(exc)
else:raise RuntimeError('Perturbed source was accepted')
bpy.ops.wm.open_mainfile(filepath=str(candidate))
scene=bpy.context.scene
obj=scene.objects[r.OWNER]
after=immutable_scene_digest(SimpleNamespace(objects=[o for o in scene.objects if o!=obj]),{})
assert digest==after==receipt['unchangedSceneDigestAfter']
stem=scene.objects['library_refined_botanical__interior botanical leaf stem']
tree=KDTree(len(stem.data.vertices))
for v in stem.data.vertices:tree.insert(stem.matrix_world@v.co,v.index)
tree.balance()
root_rows=[]
for root,row in zip(roots,receipt['bladeRoots']):
    point=obj.matrix_world@obj.data.vertices[row['rootVertex']].co
    moved=(point-root).length
    hit,vertex,distance=tree.find(point)
    assert moved==0
    assert distance<.003
    root_rows.append({'index':row['index'],'rootMovementM':moved,'stemSurfaceNearestVertexM':distance,'stemVertex':vertex})
obj.data.calc_loop_triangles()
normals=np.asarray([t.normal[:]for t in obj.data.loop_triangles])
areas=np.asarray([t.area for t in obj.data.loop_triangles])
light=np.array((0,1,.65));light/=np.linalg.norm(light)
dot=normals@light
assert np.all(dot>0),'A blade turns away from the glazing/sky light'
assert len(obj.data.vertices)==420 and len(obj.data.polygons)==300 and len(obj.data.loop_triangles)==480
assert len(obj.data.color_attributes)==1
try:r.migrate(scene)
except RuntimeError as exc:
    assert str(exc)=='Pothos blades have already been refreshed'
    repeat=str(exc)
else:raise RuntimeError('Double application accepted')
out={'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'candidateSha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),
     'unchangedOthersDigest':digest,'unchangedOthersAfterReopen':after,'rootRows':root_rows,
     'vertices':len(obj.data.vertices),'polygons':len(obj.data.polygons),'triangles':len(obj.data.loop_triangles),
     'minimumTriangleAreaM2':float(areas.min()),'windowSkyNormalDotRange':[float(dot.min()),float(dot.max())],
     'sameCountPerturbationRejected':negative,'doubleApplicationRejected':repeat,
     'scope':'Every other scene mesh, topology, raw attribute and object transform exact, including all stems/pots/hardware;30unchanged petiole roots. New leaf-only topology and transported contact colors await final bake.'}
(q/'pothos-native-verification.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in out.items()if k!='rootRows'}),flush=True)
