﻿from pathlib import Path
import json,gzip,hashlib,subprocess
q=Path('.jekyll-cache/visual-qa/contact-cpu-20261101');p=Path('artwork/coastal-home/reviews/contact-cpu-2026-11-01');assert not p.exists();p.mkdir(parents=True)
def put(name,b,zip=False):
 f=p/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(gzip.compress(b,mtime=0) if zip else b)
def copy(src,name,zip=False):put(name,src.read_bytes(),zip)
put('.gitattributes',b'# Preserve measured archive bytes and metadata hashes.\n* -text\n')
source='8ef8696236c0233504f626976783b6dabbb0433d';baseline='d36672bda0b3ee557989853f51665b1893da398a';files=['assets/js/home-scene/wildlife-ground-contact.mjs','assets/js/home-scene/wildlife-raccoon-contact.mjs','assets/js/home-scene/wildlife-resting-contact.mjs','test/wildlife-ground-bounds.test.mjs'];bindings=[]
for name in files:
 b=Path(name).read_bytes();gitbytes=subprocess.check_output(['git','show',source+':'+name]);copy(Path(name),'source/'+name+'.gz',True);bindings.append({'path':name,'sourceCommit':source,'gitBlob':subprocess.check_output(['git','rev-parse',source+':'+name],text=True).strip(),'gitSha256':hashlib.sha256(gitbytes).hexdigest(),'measuredBytes':len(b),'measuredSha256':hashlib.sha256(b).hexdigest(),'lineEndingNormalizedEqual':b.replace(b'\r\n',b'\n')==gitbytes.replace(b'\r\n',b'\n')})
put('SOURCE_BINDINGS.json',(json.dumps({'source':source,'baseline':baseline,'files':bindings},indent=2)+'\n').encode())
for f in (q/'baseline-source').rglob('*'):
 if f.is_file():copy(f,'reference/d366/'+f.relative_to(q/'baseline-source').as_posix()+'.gz',True)
copy(q/'BASELINE-SOURCE.json','reference/BASELINE-SOURCE.json.gz',True)
for name in ['raccoon-dense-candidate.json','raccoon-dense-dawn-candidate.json','RACCOON-TEMPORAL-COMPARISON.json','PINNIPED-TEMPORAL-COMPARISON.json','REUSED-PAYLOAD-CHECK.json','NATIVE-COMPARISON-v1.json','BENCHMARK-SERVED-BINDING.json','INITIAL-SERVED-BINDING.json','actual-gpu-raccoon.json','actual-gpu-pinniped.json']:
 copy(q/name,'data/'+name+'.gz',True)
# The complete recaptured outputs below are byte-identical to retained accepted
# packets. Bind them directly rather than duplicating tens of megabytes.
reused=json.loads((q/'REUSED-PAYLOAD-CHECK.json').read_text());assert all(r['byteEqual'] for r in reused['files']);put('REUSED_PAYLOADS.json',(json.dumps(reused,indent=2)+'\n').encode())
for attempt in ['numeric-cell-only','exact-query-cache']:
 root=q/'attempts'/attempt
 for f in root.rglob('*'):
  if f.is_file() and not f.name.endswith('.json.gz'):copy(f,'attempts/'+attempt+'/'+f.relative_to(root).as_posix()+'.gz',True)
for view in ['raccoon','pinniped']:
 for f in (q/('native-benchmark-'+view)).rglob('*'):
  if f.is_file():copy(f,'benchmark/'+view+'/'+f.name+('' if f.suffix=='.png' else '.gz'),f.suffix!='.png')
for f in q.glob('benchmark-*.mjs'):copy(f,'benchmark/executed/'+f.name+'.gz',True)
copy(q/'BENCHMARK-SOURCE-BINDINGS.json','benchmark/BENCHMARK-SOURCE-BINDINGS.json.gz',True)
for f in (q/'public-cache-v1').rglob('*'):
 if f.is_file() and (f.suffix=='.png' or f.name.endswith('-frames.json')):copy(f,'views/'+f.name+('' if f.suffix=='.png' else '.gz'),f.suffix!='.png')
for name in ['wildlife-ground-contact.mjs','wildlife-raccoon-contact.mjs','wildlife-resting-contact.mjs']:copy(q/'served-final/candidate/assets/js/home-scene'/name,'served/assets/js/home-scene/'+name+'.gz',True)
for name in ['raccoon-dense-proof.mjs','pinniped-dense-proof.mjs','raccoon-temporal.mjs','raccoon-frame-trajectory.mjs','pinniped-temporal-proof.mjs','native-benchmark.cjs','public-cache-v1.cjs','gpu-raccoon.cjs','gpu-pinniped.cjs','proxy-contact-cpu.py']:
 copy(q/name,'producers/'+name+'.gz',True)
for name in ['numeric-cell-focused-v1.log','numeric-cell-bounds-v2.log','vertical-cache-focused-v1.log','vertical-cache-focused-v2.log','wildlife-tests-cache-final.log','cache-raccoon-temporal.log','cache-raccoon-frame-trajectory.log','cache-pinniped-temporal.log','native-raccoon-baseline.log','native-raccoon-candidate.log','native-pinniped-baseline.log','native-pinniped-candidate.log','gpu-raccoon-v1.log','gpu-pinniped-v1.log','public-cache-v1-chromium.log','public-cache-v1-webkit.log']:
 copy(q/name,'logs/'+name+'.gz',True)
print({'files':sum(f.is_file() for f in p.rglob('*')),'bytes':sum(f.stat().st_size for f in p.rglob('*') if f.is_file())})
