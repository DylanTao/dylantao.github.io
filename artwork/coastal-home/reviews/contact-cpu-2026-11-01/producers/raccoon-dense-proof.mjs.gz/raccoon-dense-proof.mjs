import crypto from "node:crypto";
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { THREE, loadNativeModel } from "file:///C:/dev/site-takeover-worktrees/identity-footer/test/helpers/coastal-native-avatar.mjs";
import { nativeGeometry } from "file:///C:/dev/site-takeover-worktrees/identity-footer/test/helpers/coastal-native-geometry.mjs";
const {createWildlife}=await import(process.argv.includes("--baseline")?new URL("./baseline-source/assets/js/home-scene/wildlife.mjs",import.meta.url).href:"file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife.mjs");
import { createGroundPatch } from "./baseline-source/assets/js/home-scene/wildlife-ground-contact.mjs";
import { rabbitActing, rabbitSchedule } from "file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife-motion.mjs";

const models = new URL("file:///C:/dev/site-takeover-worktrees/identity-footer/.jekyll-cache/visual-qa/animal-readonly-20261031/inputs/assets/models/home/");
const config = JSON.parse(fs.readFileSync(new URL("manifest.json", models)));
const perches = JSON.parse(fs.readFileSync(new URL("wildlife-perch-support.json", models)));
const species = ["BrushRabbit", "CaliforniaSeaLion", "HarborSeal", "Raccoon", "WesternGull", "Sandpiper", "BrownPelican", "BrandtsCormorant"];
const masters = await Promise.all(species.map((name) => loadNativeModel(name + ".glb", models)));
async function world(manifest, grounds) {
  const scene = new THREE.Group(), environment = new THREE.Group(); scene.add(environment, ...grounds);
  const wildlife = createWildlife(environment, manifest, {
    createModelLoader: () => ({ loader: { loadAsync: async (url) => masters[species.indexOf(url.split("/").at(-1).replace(".glb", ""))] }, decoder: { dispose() {} } }),
    loadPerchSupport: async () => perches,
  });
  for (let i = 0; i < 100 && !wildlife.evidence().modelsReady; i++) await new Promise(setImmediate);
  assert.equal(wildlife.evidence().modelsReady, true);
  wildlife.captureGround(grounds); scene.updateMatrixWorld(true);
  const paws = [0, 1].map((index) => {
    const list=[];
    scene.traverse((mesh) => {
      if (!mesh.isSkinnedMesh || mesh.userData.action?.id !== `rabbit-${index}`) return;
      const skin=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight;
      for(let i=0;i<skin.count;i++) {
        const names=new Map();
        for(let k=0;k<4;k++){const name=mesh.skeleton.bones[skin.getComponent(i,k)].name;names.set(name,(names.get(name)||0)+weights.getComponent(i,k));}
        for(const [name,weight]of names)if(/^(Front|Hind)Paw[LR]$/.test(name)&&weight>=.999)list.push({mesh,index:i,name});
      }
    });
    assert.ok(list.length>1000);return list;
  });
  const patches=["rabbitWest","rabbitEast"].map((key)=>{const p=createGroundPatch(manifest.terrain.habitats[key].path,1);p.capture(grounds);assert.ok(p.evidence().ready);return p});
  function measure(index) {
    scene.updateMatrixWorld(true);
    for(const mesh of new Set(paws[index].map(p=>p.mesh)))mesh.skeleton.update();
    const feet=Object.fromEntries(["FrontPawL","FrontPawR","HindPawL","HindPawR"].map(n=>[n,{minimum:Infinity,missing:0,points:[]} ]));
    for(const p of paws[index]){
      const v=p.mesh.getVertexPosition(p.index,new THREE.Vector3()).applyMatrix4(p.mesh.matrixWorld),hit=patches[index].sample(v.x,v.z,v.y+.5),foot=feet[p.name];
      foot.points.push(v.toArray());if(!hit)foot.missing++;else foot.minimum=Math.min(foot.minimum,v.y-hit.height);
    }
    return feet;
  }
  return {scene,wildlife,paws,measure};
}

const grounds=await Promise.all([nativeGeometry("home-shell.glb",models),nativeGeometry("coast.glb",models)]);
config.terrain.habitats.seaLion.path[0]=[-9.7,-6.6382,-14.8115];
const runtime=await world(structuredClone(config),grounds),rows=[],rigs={},otherRows=[];
const patches=Object.fromEntries(["seaLion","seal","raccoon"].map(key=>{const p=createGroundPatch(config.terrain.habitats[key].path,key==="seal"?3:2);p.capture(grounds);return[key,p]}));
const ids=["raccoon-0"];
const subjects=ids.map(id=>{const meshes=[];runtime.scene.traverse(o=>{if(o.isSkinnedMesh&&o.userData.action?.id===id)meshes.push(o)});if(!meshes.length)return null;const patch=patches[id.split("-")[0]];let group=meshes[0];while(group.parent&&group.parent.name!=="Coastal neighbours")group=group.parent;return{id,meshes,patch,group}}).filter(Boolean);
for(const subject of subjects){
  const list=[];subject.group.traverse(o=>{if(o.isBone)list.push({name:o.name,parent:o.parent?.name,position:o.position.toArray(),quaternion:o.quaternion.toArray()})});
  rigs[subject.id]={bones:list};
}
const times=Array.from({length:361},(_,i)=>i*.5);if(process.argv.includes("--dawn")){runtime.wildlife.update(0,"evening",{force:true});runtime.wildlife.update(95,"evening",{force:true})}
for(const night of (process.argv.includes("--dawn")?[false]:[false,true]))for(const time of times.filter(t=>!process.argv.includes("--dawn")||t>=95)){
 runtime.wildlife.update(time,night?"evening":"noon",{force:true});runtime.scene.updateMatrixWorld(true);
 const other={};runtime.scene.traverse(o=>{const id=o.userData.action?.id;if(!o.isSkinnedMesh||!id||id==="raccoon-0"||other[id])return;other[id]=o.skeleton.bones.map(b=>[b.name,...b.matrixWorld.elements])});otherRows.push({time,night,count:Object.keys(other).length,sha256:crypto.createHash("sha256").update(JSON.stringify(other)).digest("hex")});
 for(const subject of subjects){
  const {id,meshes,patch,group}=subject,byBone={},worldPoints=[],rootHit=patch.sample(group.position.x,group.position.z,group.position.y+.5);
  for(const mesh of meshes){
   mesh.skeleton.update();const weights=mesh.geometry.attributes.skinWeight,skin=mesh.geometry.attributes.skinIndex;
   for(let i=0;i<skin.count;i++){
    let dominant=0;for(let k=1;k<4;k++)if(weights.getComponent(i,k)>weights.getComponent(i,dominant))dominant=k;
    const owner=mesh.skeleton.bones[skin.getComponent(i,dominant)].name;
    const v=mesh.getVertexPosition(i,new THREE.Vector3()).applyMatrix4(mesh.matrixWorld),hit=patch.sample(v.x,v.z,v.y+1);
    worldPoints.push(v.x,v.y,v.z);const r=byBone[owner]||(byBone[owner]={count:0,missing:0,below:0,minimum:null});r.count++;
    if(!hit){r.missing++;continue}
    const gap=v.y-hit.height;if(gap<-.002)r.below++;
    if(!r.minimum||gap<r.minimum.gap)r.minimum={gap,vertex:i,mesh:mesh.name,point:v.toArray(),support:{height:hit.height,normal:hit.normal.toArray(),mesh:hit.mesh,triangle:hit.triangle,visible:hit.visible}};
   }
  }
  const bones=Object.fromEntries(meshes[0].skeleton.bones.map(b=>[b.name,{position:b.position.toArray(),quaternion:b.quaternion.toArray(),scale:b.scale.toArray(),world:b.matrixWorld.toArray()}]));
  rows.push({id,time,night,bones,worldVerticesSha256:crypto.createHash("sha256").update(Buffer.from(Float64Array.from(worldPoints).buffer)).digest("hex"),bodyContact:runtime.wildlife.evidence().raccoon.bodyContact||null,bodyAccommodation:runtime.wildlife.evidence().raccoon.bodyAccommodation,state:group.userData.state,rootPosition:group.position.toArray(),rootQuaternion:group.quaternion.toArray(),rootHit:rootHit?{height:rootHit.height,normal:rootHit.normal.toArray(),mesh:rootHit.mesh}:null,byBone,tailContact:id==="raccoon-0"?runtime.wildlife.evidence().raccoon.tailContact:null});
 }
}
fs.writeFileSync(new URL(process.argv.includes("--baseline")?"./raccoon-dense-"+(process.argv.includes("--dawn")?"dawn-":"")+"baseline.json":"./raccoon-dense-"+(process.argv.includes("--dawn")?"dawn-":"")+"candidate.json",import.meta.url),JSON.stringify({rigs,rows,otherRows},null,2));
for(const id of ids){const list=rows.filter(r=>r.id===id);if(!list.length)continue;console.log(JSON.stringify({id,states:[...new Set(list.map(r=>r.state))],worst:list.flatMap(r=>Object.entries(r.byBone).map(([bone,b])=>({bone,time:r.time,state:r.state,night:r.night,root:r.rootHit,...b.minimum}))).filter(r=>Number.isFinite(r.gap)).sort((a,b)=>a.gap-b.gap).slice(0,8)}))}
