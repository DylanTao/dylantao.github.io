import copy,hashlib,json,subprocess,urllib.request
from pathlib import Path
import yaml
root=Path.cwd();q=Path(__file__).parent;out=q/'ci-runner-pin-v1';assert not out.exists();out.mkdir()
names=['axe','broken-links-site','copilot-setup-steps','deploy','unit-tests','upgrade-check','visual-regression'];rows=[]
for name in names:
 rel='.github/workflows/'+name+'.yml';before=yaml.safe_load(subprocess.check_output(['git','show','HEAD:'+rel],cwd=root));after=yaml.safe_load((root/rel).read_bytes());restored=copy.deepcopy(after);changes=[]
 for key,job in after['jobs'].items():
  if any(step.get('uses','').startswith('ruby/setup-ruby@')for step in job.get('steps',[])):
   assert before['jobs'][key]['runs-on']=='ubuntu-latest'and job['runs-on']=='ubuntu-24.04'
   changes.append(key);restored['jobs'][key]['runs-on']='ubuntu-latest'
 assert changes and restored==before,rel
 rows.append({'path':rel,'jobs':changes,'onlyRunnerChanged':True,'rubyVersionsUnchanged':True,'sourceSha256':hashlib.sha256((root/rel).read_bytes()).hexdigest()})
downloads=[]
for version in ['3.3.5','3.2.2']:
 url=f'https://github.com/ruby/ruby-builder/releases/download/ruby-{version}/ruby-{version}-ubuntu-24.04-x64.tar.gz'
 with urllib.request.urlopen(urllib.request.Request(url,method='HEAD'),timeout=30)as r:assert r.status==200;downloads.append({'rubyVersion':version,'publicReleaseURL':url,'status':r.status})
proof={'scope':'Semantic YAML comparison proves only the runner label changes in all seven pinned-Ruby jobs; all Ruby patches, job steps, permissions, matrix coverage and test assertions remain unchanged. Both actual official release downloads return200 forUbuntu24. OriginalCIUbuntu26 Ruby3.3.5 setup404 failures retained separately.','workflows':rows,'officialDownloads':downloads,'primaryDocumentation':['https://github.com/ruby/setup-ruby#supported-platforms','https://github.com/actions/runner-images#available-images']}
(out/'QUALIFICATION.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
