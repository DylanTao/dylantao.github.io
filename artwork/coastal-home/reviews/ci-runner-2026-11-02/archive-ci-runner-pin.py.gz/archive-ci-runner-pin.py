import gzip,hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();q=Path(__file__).parent;out=q/'ci-runner-pin-v1';packet=root/'artwork/coastal-home/reviews/ci-runner-2026-11-02';assert not packet.exists();packet.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
def deposit(relative,body):
 p=packet/(relative+'.gz');p.parent.mkdir(parents=True,exist_ok=True);stored=gzip.compress(body,mtime=0);p.write_bytes(stored);rows.append({'path':p.relative_to(packet).as_posix(),'bytes':len(stored),'sha256':sha(stored),'encoding':'gzip','bodyBytes':len(body),'bodySha256':sha(body)})
for label,run in [('integration',41540118934),('deploy',41540119067),('upgrade',41540118957)]:
 r=subprocess.run(['gh','run','view',str(run),'--log-failed'],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert not r.returncode,r.stderr
 (out/(label+'-failed.log')).write_bytes(r.stdout);deposit('failed/'+label+'.log',r.stdout)
body=subprocess.check_output(['gh','run','view','41540118811','--json','jobs,status,conclusion,headSha'],cwd=root);(out/'visual-run.json').write_bytes(body);deposit('failed/visual-run.json',body)
visual=json.loads(body);jobs=visual['jobs'];summary={'source':'8aa13ce086d50a7783e1094797c050e6e5f4895d','visualStatus':visual['status'],'visualConclusion':visual['conclusion'],'jobs':len(jobs),'failed':sum(j['conclusion']=='failure'for j in jobs),'setupFailures':sum(any(s['conclusion']=='failure'and 'Ruby'in s['name']for s in j.get('steps',[]))for j in jobs),'scope':'Actual CI failure snapshot. Original setup failures remain; application tests did not run in those failed jobs. No skipped-as-passed or source failure claim.'};deposit('FAILURE-SUMMARY.json',(json.dumps(summary,indent=2)+'\n').encode())
deposit('QUALIFICATION.json',(out/'QUALIFICATION.json').read_bytes());deposit('qualify-ci-runner-pin.py',(q/'qualify-ci-runner-pin.py').read_bytes());deposit('archive-ci-runner-pin.py',Path(__file__).read_bytes())
qualification=json.loads((out/'QUALIFICATION.json').read_bytes())
for row in qualification['workflows']:deposit('selected-source/'+row['path'],(root/row['path']).read_bytes())
(packet/'MANIFEST.json').write_text(json.dumps({'schema':'coastal-ci-runner-v1','scope':'Actual original Ubuntu26.04 setup failures and semantic-only seven Ruby-runner pins; no application/render/native/data code changes. Official24.04 downloads verified. SubsequentCI/live delivery stillrequired.','files':rows},indent=2)+'\n')
print(json.dumps({'payloads':len(rows),'failureSnapshot':summary},indent=2))
