const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const zlib = require("node:zlib");
const { spawn } = require("node:child_process");
const { chromium } = require("C:/dev/dylantao.github.io/node_modules/playwright");

const q = __dirname;
const baseURL = process.env.DRIVER_URL;
const preflightOnly = process.env.DRIVER_PREFLIGHT === "1";
if (!baseURL) throw Error("DRIVER_URL must identify the coordinator's frozen combined production build");
if (!preflightOnly && process.env.DRIVER_QUIET !== "1") throw Error("An explicit coordinated quiet window is required (DRIVER_QUIET=1)");
const run = process.env.DRIVER_RUN || "steady-native-2k";
const out = path.join(q, run);
fs.mkdirSync(out, { recursive: true });
const write = (name, data) => fs.writeFileSync(path.join(out, name), JSON.stringify(data, null, 2) + "\n");
const hash = b => crypto.createHash("sha256").update(b).digest("hex");
const result = { baseURL, viewport: [2560, 1440], dpr: 1, started: new Date().toISOString(), phases: [], errors: [], warnings: [], productModuleOverrides: [], conditioning: { routineDate: "2026-10-23T13:20:00-07:00", randomSeed: 7, avatar: "South Park via public selector", nativeRAFPerformanceTimers: true, movingScene: true } };
const summarize = values => {
  const a = values.filter(Number.isFinite).sort((a, b) => a - b);
  return { n: a.length, median: a[Math.floor(a.length / 2)] ?? null, p95: a[Math.min(a.length - 1, Math.floor(a.length * .95))] ?? null };
};

(async () => {
  let browser, page, nvidia, tracing = false, browserCDP, cdp;
  let nvidiaLog = "", nvidiaError = "";
  const watchdog = setTimeout(() => {
    if (!result.timedSectionsComplete && !preflightOnly) {
      result.boundedDeadline = "80-second producer deadline reached before timed sections completed";
      console.error(result.boundedDeadline);
      void browser?.close().catch(() => {});
    }
  }, 80000);
  try {
    browser = await chromium.launch({ headless: true, args: ["--use-angle=d3d11", "--ignore-gpu-blocklist"] });
    const context = await browser.newContext({ viewport: { width: 2560, height: 1440 }, deviceScaleFactor: 1, timezoneId: "America/Los_Angeles", reducedMotion: "no-preference" });
    page = await context.newPage();
    page.setDefaultTimeout(45000);
    page.on("pageerror", e => result.errors.push(e.message));
    page.on("console", m => { if (["error", "warning"].includes(m.type())) result.warnings.push(m.text()); });
    await page.route(/https:\/\/(?:plausible\.io|www\.google-analytics\.com|www\.googletagmanager\.com)\//, r => r.fulfill({ status: 200, body: "" }));
    await page.addInitScript(() => {
      let state = 7;
      Math.random = () => ((state = (state * 1664525 + 1013904223) >>> 0) / 4294967296);
      const NativeDate = Date, fixed = NativeDate.parse("2026-10-23T13:20:00-07:00");
      window.Date = new Proxy(NativeDate, {
        apply() { return new NativeDate(fixed).toString(); },
        construct(target, args) { return Reflect.construct(target, args.length ? args : [fixed]); },
        get(target, key) { return key === "now" ? () => fixed : Reflect.get(target, key); },
      });
    });
    await page.addInitScript({ path: path.join(q, "driver-hooks.js") });
    browserCDP = await browser.newBrowserCDPSession();
    cdp = await context.newCDPSession(page);
    result.system = await browserCDP.send("SystemInfo.getInfo");
    result.browser = browser.version();
    result.categoriesAvailable = (await browserCDP.send("Tracing.getCategories")).categories;
    await cdp.send("Performance.enable");
    const processCPU = () => browserCDP.send("SystemInfo.getProcessInfo");
    const h = page.locator("[data-home-desk-scene]");
    const evidence = () => h.evaluate(h => h.getSceneEvidence());
    const atomicSnapshot = () => h.evaluate(h => ({ evidence: h.getSceneEvidence(), wall: performance.now() }));
    const url = new URL(baseURL);
    for (const [key, value] of Object.entries({ "scene-lab": "1", quality: "high", resolution: "fixed" })) url.searchParams.set(key, value);
    await page.goto(url.href, { waitUntil: "domcontentloaded" });
    await page.locator('[data-home-desk-mode="3d"]').click();
    await page.waitForFunction(() => document.querySelector("[data-home-desk-scene]")?.dataset.sceneState === "ready");
    console.log("STARTUP_READY");
    await page.locator("[data-world-lab] summary").first().click();
    await page.locator("[data-world-avatar]").selectOption("south-park");
    await page.waitForFunction(() => {
      const e = document.querySelector("[data-home-desk-scene]").getSceneEvidence();
      return e.avatarId === "south-park" && e.actorCount === 1 && e.roomCount >= 6 && e.simulation?.lightField?.ready;
    });
    await page.locator("[data-world-lab] summary").first().click();
    await page.locator("[data-world-fullscreen]").click();
    await page.locator("[data-world-view]").click();
    console.log("OUTSIDE_CONTROL_CLICKED", JSON.stringify(await h.evaluate(h => ({room:h.getSceneEvidence().currentRoom,frames:h.getSceneEvidence().frames,profile:h.getSceneEvidence().resolution.profile}))));
    await page.waitForFunction(() => {
      const h = document.querySelector("[data-home-desk-scene]"), e = h.getSceneEvidence();
      return e.currentRoom === "outside" && h.labScene.scene.getObjectByName("coastal-hinterland")?.visible && h.labScene.scene.getObjectByName("clifftop-flora")?.visible && e.ecology.farField.near.complete;
    });
    const settled = (await evidence()).frames;
    await page.waitForFunction(({ n, count }) => document.querySelector("[data-home-desk-scene]").getSceneEvidence().frames >= n + count, { n: settled, count: preflightOnly ? 10 : 90 });
    result.ready = await evidence();
    result.pagePerformanceOrigin = await page.evaluate(() => performance.timeOrigin);
    if (result.ready.resolution.pixels !== 2560 * 1440 || result.ready.resolution.factor !== 1) throw Error("Native full 2K pixel count was not preserved");
    await h.evaluate(h => {
      const s = h.labScene.scene, before = s.onBeforeRender;
      s.onBeforeRender = function (r, scene, c) {
        if (c.up.y !== -1) {
          s.onBeforeRender = before;
          window.__coastalDriver.install(r, c, s);
        }
        return before.apply(this, arguments);
      };
      h.labScene.requestFrame();
    });
    await page.waitForFunction(() => !!window.__coastalDriver.renderer);
    if (!await page.evaluate(() => window.__coastalDriver.sceneCallbackCount > 0)) throw Error("Could not identify the scene's native RAF callback");
    result.gpu = await page.evaluate(() => {
      const g = window.__coastalDriver.gl, x = g.getExtension("WEBGL_debug_renderer_info");
      return { vendor: x && g.getParameter(x.UNMASKED_VENDOR_WEBGL), renderer: x && g.getParameter(x.UNMASKED_RENDERER_WEBGL), buffer: [g.drawingBufferWidth, g.drawingBufferHeight] };
    });
    if (!/RTX 3080 Ti/.test(result.gpu.renderer)) throw Error("Expected native RTX 3080 Ti, received " + result.gpu.renderer);
    if (result.gpu.buffer.join(",") !== "2560,1440") throw Error("Actual native drawing buffer dimensions differ from 2K");
    const contractResponse = await page.request.get(new URL("assets/models/home/manifest.json", baseURL).href);
    const contract = await contractResponse.json();
    if (result.ready.roomCount !== contract.rooms.length) throw Error("Incomplete authored room roster");
    if (result.ready.currentRoom !== "outside" || result.ready.quality.tier !== "high" || !result.ready.quality.pinned) throw Error("Unexpected authored view or quality");
    if (!result.ready.simulation.lightField.ready || result.ready.loading.lightCache.state !== "restored") throw Error("Official light cache was not restored");
    if (preflightOnly) {
      result.preflight = { nativeBuffer: result.gpu.buffer, pixels: result.ready.resolution.pixels, renderer: result.gpu.renderer, roomCount: result.ready.roomCount, expectedRooms: contract.rooms.length, view: result.ready.currentRoom, quality: result.ready.quality.tier, cache: result.ready.loading.lightCache.state, sceneCallbackCount: await page.evaluate(() => window.__coastalDriver.sceneCallbackCount), programCount: await page.evaluate(() => window.__coastalDriver.renderer.info.programs.length) };
      await page.evaluate(() => window.__coastalDriver.restore());
      write("preflight.json", result);
      console.log(JSON.stringify({ status: "STARTUP_ASSERTIONS_PASS_NO_PERFORMANCE_SAMPLING", ...result.preflight }));
      return;
    }
    nvidia = spawn("C:/Windows/System32/nvidia-smi.exe", ["--query-gpu=timestamp,index,utilization.gpu,utilization.memory,clocks.current.graphics,clocks.current.sm,clocks.current.memory,power.draw,pstate", "--format=csv,noheader,nounits", "--loop-ms=200"], { windowsHide: true });
    nvidia.stdout.on("data", b => nvidiaLog += b.toString());
    nvidia.stderr.on("data", b => nvidiaError += b.toString());
    const phase = async (name, mode, milliseconds) => {
      await page.evaluate(({ name, mode }) => window.__coastalDriver.setMode(mode, name), { name, mode });
      const before = { metrics: await cdp.send("Performance.getMetrics"), cpu: await processCPU(), ...await atomicSnapshot(), wallUTC: new Date().toISOString() };
      await page.waitForTimeout(milliseconds);
      const after = { ...await atomicSnapshot(), wallUTC: new Date().toISOString(), metrics: await cdp.send("Performance.getMetrics"), cpu: await processCPU() };
      result.phases.push({ name, mode, requestedMs: milliseconds, before, after, fps: (after.evidence.frames - before.evidence.frames) * 1000 / (after.wall - before.wall) });
      console.log(JSON.stringify({ phase: name, fps: result.phases.at(-1).fps, frames: after.evidence.frames - before.evidence.frames, elapsedMs: after.wall - before.wall, programs: after.evidence.resources?.programs }));
      write("result.partial.json", result);
    };
    await phase("untraced-before", "off", 3500);
    await phase("whole-frame-query", "frame", 3500);
    await phase("render-pass-query", "passes", 3500);
    const requestedCategories = ["toplevel", "devtools.timeline", "blink.user_timing", "v8", "gpu", "gpu.angle", "viz", "renderer.scheduler", "disabled-by-default-gpu.service", "disabled-by-default-gpu.device", "disabled-by-default-devtools.timeline"];
    result.categoriesRequested = requestedCategories;
    await browserCDP.send("Tracing.start", { transferMode: "ReturnAsStream", streamFormat: "json", streamCompression: "gzip", traceConfig: { recordMode: "recordUntilFull", traceBufferSizeInKb: 65536, includedCategories: requestedCategories, excludedCategories: ["*"] } });
    tracing = true;
    await cdp.send("Profiler.enable");
    await cdp.send("Profiler.setSamplingInterval", { interval: 1000 });
    await cdp.send("Profiler.start");
    await page.evaluate(() => window.__coastalDriver.tracing = true);
    await phase("driver-trace-cpu-profile", "frame", 6500);
    await page.evaluate(() => window.__coastalDriver.tracing = false);
    const profile = await cdp.send("Profiler.stop");
    fs.writeFileSync(path.join(out, "steady.cpuprofile.gz"), zlib.gzipSync(JSON.stringify(profile.profile), { mtime: 0 }));
    const complete = new Promise(resolve => browserCDP.once("Tracing.tracingComplete", resolve));
    await browserCDP.send("Tracing.end");
    const event = await complete;
    tracing = false;
    result.traceComplete = event;
    if (event.dataLossOccurred) throw Error("Chrome trace lost events");
    const chunks = [];
    while (true) {
      const chunk = await browserCDP.send("IO.read", { handle: event.stream, size: 1 << 20 });
      chunks.push(Buffer.from(chunk.data, chunk.base64Encoded ? "base64" : "utf8"));
      if (chunk.eof) break;
    }
    await browserCDP.send("IO.close", { handle: event.stream });
    fs.writeFileSync(path.join(out, "steady.chrome-trace.json.gz"), Buffer.concat(chunks));
    await page.evaluate(() => { window.__driverAttribStart = window.__coastalDriver.frames.length; window.__coastalDriver.setMode("attribution", "program-attribution"); });
    await page.waitForFunction(() => window.__coastalDriver.frames.length >= window.__driverAttribStart + 6);
    await page.evaluate(() => window.__coastalDriver.setMode("off"));
    await page.waitForTimeout(1000);
    await phase("untraced-after", "off", 3500);
    await page.emulateMedia({ reducedMotion: "reduce" });
    await page.waitForTimeout(350);
    await page.evaluate(() => { window.__coastalDriver.pollQueries(); window.__coastalDriver.restore(); });
    nvidia.kill(); nvidia = null;
    fs.writeFileSync(path.join(out, "nvidia-smi.csv"), nvidiaLog);
    result.nvidiaError = nvidiaError;
    result.timedSectionsComplete = new Date().toISOString();
    console.log("TIMED_PHASES_COMPLETE_RENDERING_STOPPED");
    const data = await page.evaluate(() => window.__coastalDriver.snapshot());
    write("submission-attribution.json", data);
    const shaders = await page.evaluate(() => window.__coastalDriver.shaderCensus());
    fs.writeFileSync(path.join(out, "program-census.json.gz"), zlib.gzipSync(JSON.stringify(shaders), { mtime: 0 }));
    write("uniform-census.json", await page.evaluate(() => window.__coastalDriver.uniformCensus()));
    result.frameSummary = Object.fromEntries([...new Set(data.frames.map(f => f.phase))].map(name => {
      const frames = data.frames.filter(f => f.phase === name);
      return [name, { frames: frames.length, submitMs: summarize(frames.map(f => f.submitMs)), gpuElapsedMs: summarize(frames.map(f => f.gpuMs)), drawCalls: summarize(frames.map(f => f.draws)) }];
    }));
    const screenshot = path.join(out, "native-2k-full-scene.png");
    await h.locator("canvas").screenshot({ path: screenshot });
    result.imageSha256 = hash(fs.readFileSync(screenshot));
    result.final = await evidence();
    result.resources = await page.evaluate(() => performance.getEntriesByType("resource").map(e => ({ name: e.name, bytes: e.encodedBodySize, start: e.startTime, duration: e.duration })));
    const receiptResponse = await page.request.get(new URL("assets/js/module-build.json", baseURL).href);
    if (!receiptResponse.ok()) throw Error("No combined production module receipt");
    const receipt = await receiptResponse.body();
    fs.writeFileSync(path.join(out, "module-build.json"), receipt);
    result.moduleReceiptSha256 = hash(receipt);
    const manifestResponse = await page.request.get(new URL("assets/models/home/manifest.json", baseURL).href);
    const manifest = await manifestResponse.body();
    fs.writeFileSync(path.join(out, "manifest.json"), manifest);
    result.manifestSha256 = hash(manifest);
    result.deliveredBindings = {};
    const measuredURLs = [...new Set(result.resources.map(r => r.name).filter(name => {
      const u = new URL(name);
      return u.origin === new URL(baseURL).origin && (/\/assets\/js\/.+\.m?js(?:\?|$)/.test(name) || /\/assets\/models\/home\/.+\.(?:glb|json)(?:\?|$)/.test(name));
    }))];
    // Exact served-response hashes, read only after all timed sections end.
    for (const name of measuredURLs) {
      const response = await page.request.get(name);
      if (!response.ok()) throw Error("Could not read back served source/model: " + name);
      const bytes = await response.body();
      result.deliveredBindings[new URL(name).pathname] = { bytes: bytes.length, sha256: hash(bytes) };
    }
    result.programs = { compiled: shaders.length, used: new Set(data.drawGroups.map(g => g.program)).size, attributedFrames: data.frames.filter(f => f.phase === "program-attribution").length };
    result.finished = new Date().toISOString();
    write("result.json", result);
    console.log(JSON.stringify({ output: out, phases: result.phases.map(p => ({ name: p.name, fps: p.fps })), frames: result.frameSummary, programs: result.programs, errors: result.errors }));
    if (result.errors.length) throw Error("Page errors present");
  } finally {
    clearTimeout(watchdog);
    if (page && !page.isClosed()) result.exitState = await page.evaluate(() => {
      const h = document.querySelector("[data-home-desk-scene]");
      if (!h?.getSceneEvidence) return { missingScene: true };
      const s = h.labScene?.scene;
      return { evidence: h.getSceneEvidence(), hinterland: s?.getObjectByName("coastal-hinterland")?.visible, flora: s?.getObjectByName("clifftop-flora")?.visible, driverFrames: window.__coastalDriver?.frames?.length, sceneCallbacks: window.__coastalDriver?.sceneCallbackCount };
    }).catch(error => ({ diagnosticError: error.message }));
    if (tracing && browserCDP) await browserCDP.send("Tracing.end").catch(() => {});
    if (nvidia) nvidia.kill();
    if (nvidiaLog) fs.writeFileSync(path.join(out, "nvidia-smi.csv"), nvidiaLog);
    if (browser) await browser.close();
    write("producer-state.json", { closed: new Date().toISOString(), result, nvidiaError });
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
