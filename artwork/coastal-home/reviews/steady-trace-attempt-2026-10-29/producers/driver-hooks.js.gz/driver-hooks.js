// Diagnostic-only injection. Does not replace any served scene module.
(() => {
  const d = (window.__coastalDriver = {
    mode: "off", phase: "setup", frames: [], passes: [], glCalls: {},
    drawGroups: new Map(), materialRecords: new Map(), pending: [],
    queriesSkipped: 0, disjointQueries: 0, serial: 0, passSerial: 0, sceneCallbackCount: 0,
  });
  const nativeRAF = window.requestAnimationFrame;
  const callbackKinds = new WeakMap();
  const targets = new WeakMap();
  const programs = new WeakMap();
  const locations = new WeakMap();
  const restores = [];
  let nextTarget = 1, nextProgram = 1, nextLocation = 1, frame = null, activeProgram = null;
  const programId = (p) => {
    if (!p) return null;
    if (!programs.has(p)) programs.set(p, nextProgram++);
    return programs.get(p);
  };
  const locationId = (location) => {
    if (!location || typeof location !== "object") return null;
    if (!locations.has(location)) locations.set(location, nextLocation++);
    return locations.get(location);
  };
  const targetInfo = () => {
    const t = d.renderer.getRenderTarget();
    if (!t) return { id: "screen", width: d.gl.drawingBufferWidth, height: d.gl.drawingBufferHeight, samples: 0 };
    if (!targets.has(t)) targets.set(t, nextTarget++);
    return { id: targets.get(t), width: t.width, height: t.height, samples: t.samples, name: t.texture?.name || "" };
  };
  function pollQueries() {
    if (!d.timer) return;
    const g = d.gl;
    if (g.getParameter(d.timer.GPU_DISJOINT_EXT)) {
      for (const entry of d.pending.splice(0)) { g.deleteQuery(entry.query); entry.record.gpuDisjoint = true; d.disjointQueries++; }
      return;
    }
    for (let i = d.pending.length - 1; i >= 0; i--) {
      const entry = d.pending[i];
      if (!g.getQueryParameter(entry.query, g.QUERY_RESULT_AVAILABLE)) continue;
      entry.record.gpuMs = g.getQueryParameter(entry.query, g.QUERY_RESULT) / 1e6;
      g.deleteQuery(entry.query);
      d.pending.splice(i, 1);
    }
  }
  function beginQuery() {
    if (!d.timer || d.pending.length >= 64 || d.gl.getQuery(d.timer.TIME_ELAPSED_EXT, d.gl.CURRENT_QUERY)) {
      d.queriesSkipped++;
      return null;
    }
    const query = d.gl.createQuery();
    if (query) d.gl.beginQuery(d.timer.TIME_ELAPSED_EXT, query);
    return query;
  }
  function endQuery(query, record) {
    if (!query) return;
    d.gl.endQuery(d.timer.TIME_ELAPSED_EXT);
    d.pending.push({ query, record });
  }
  window.requestAnimationFrame = function (callback) {
    if (!callbackKinds.has(callback)) {
      const scene = /\.info\.reset\(\)/.test(String(callback));
      callbackKinds.set(callback, scene);
      if (scene) d.sceneCallbackCount++;
    }
    if (!callbackKinds.get(callback)) return nativeRAF.call(this, callback);
    return nativeRAF.call(this, (timestamp) => {
      if (!d.renderer || d.mode === "off") return callback(timestamp);
      pollQueries();
      const record = frame = {
        serial: ++d.serial, phase: d.phase, mode: d.mode, timestamp,
        start: performance.now(), drawsBefore: d.renderer.info.render.calls,
      };
      const query = d.mode === "frame" && d.serial % 4 === 0 ? beginQuery() : null;
      if (d.tracing) performance.mark("coastal.frame.start");
      try { return callback(timestamp); }
      finally {
        record.end = performance.now();
        record.submitMs = record.end - record.start;
        record.draws = d.renderer.info.render.calls;
        endQuery(query, record);
        d.frames.push(record);
        if (d.tracing) {
          performance.mark("coastal.frame.end");
          performance.measure("coastal.whole-frame", "coastal.frame.start", "coastal.frame.end");
        }
        frame = null;
        if (record.mode === "attribution" && ++d.attributedFrames >= 6) d.setMode("off");
      }
    });
  };
  d.install = (renderer, main, scene) => {
    d.renderer = renderer; d.main = main; d.scene = scene;
    d.gl = renderer.getContext();
    d.timer = d.gl.getExtension("EXT_disjoint_timer_query_webgl2");
    const render = renderer.render;
    renderer.render = function (s, c) {
      if (d.mode === "off") return render.apply(this, arguments);
      const record = {
        phase: d.phase, frame: frame?.serial ?? null, serial: ++d.passSerial,
        target: targetInfo(), scene: s === scene ? "coastal-main" : s.name || "post-scene",
        camera: c === main ? "main" : c.up.y === -1 ? "sea-mirror" : c.type,
        override: s.overrideMaterial?.type || null, start: performance.now(),
      };
      const previous = d.currentPass;
      d.currentPass = record;
      const before = renderer.info.render.calls;
      const query = d.mode === "passes" && (frame?.serial ?? 0) % 2 === 0 ? beginQuery() : null;
      const mark = `coastal.render.${record.serial}`;
      if (d.tracing) performance.mark(mark + ".start");
      try { return render.apply(this, arguments); }
      finally {
        record.end = performance.now(); record.submitMs = record.end - record.start;
        record.draws = renderer.info.render.calls - before;
        endQuery(query, record);
        d.passes.push(record);
        if (d.tracing) {
          performance.mark(mark + ".end");
          performance.measure(`coastal.render/${record.camera}/${record.target.id}`, mark + ".start", mark + ".end");
        }
        d.currentPass = previous;
      }
    };
    const renderHook = renderer.render;
    restores.push(() => renderer.render = render);
    const draw = renderer.renderBufferDirect;
    renderer.renderBufferDirect = function (camera, s, geometry, material, object, group) {
      if (d.mode !== "attribution") return draw.apply(this, arguments);
      const before = renderer.info.render.calls, start = performance.now();
      try { return draw.apply(this, arguments); }
      finally {
        const calls = renderer.info.render.calls - before;
        if (calls) {
          const p = renderer.properties.get(material).currentProgram;
          const id = programId(p?.program), t = targetInfo();
          const view = camera === main ? "main" : camera.up.y === -1 ? "sea-mirror" : camera.type;
          const key = `${id}/${t.id}/${view}/${material.id}`;
          let item = d.drawGroups.get(key);
          if (!item) {
            item = {
              program: id, threeProgram: p?.id ?? null, material: material.id,
              target: t, camera: view, materialName: material.name, materialType: material.type,
              drawCalls: 0, directCalls: 0, instrumentedSubmitMs: 0, objects: new Set(),
            };
            d.drawGroups.set(key, item);
          }
          item.drawCalls += calls; item.directCalls++;
          item.instrumentedSubmitMs += performance.now() - start;
          item.objects.add(object.name || `object#${object.id}`);
          if (!d.materialRecords.has(material.id)) d.materialRecords.set(material.id, {
            id: material.id, name: material.name, type: material.type,
            transparent: material.transparent, transmission: material.transmission ?? 0,
            side: material.side, depthWrite: material.depthWrite, toneMapped: material.toneMapped,
            customProgramCacheKey: material.customProgramCacheKey?.(),
          });
        }
      }
    };
    const drawHook = renderer.renderBufferDirect;
    restores.push(() => renderer.renderBufferDirect = draw);
    const glHooks = [];
    const methods = [
      "useProgram", "bindVertexArray", "bindBuffer", "bindTexture", "activeTexture", "bindFramebuffer",
      "blendFuncSeparate", "depthFunc", "depthMask", "colorMask", "enable", "disable", "cullFace", "frontFace",
      "drawArrays", "drawElements", "drawArraysInstanced", "drawElementsInstanced",
      "uniform1f", "uniform1fv", "uniform1i", "uniform1iv", "uniform2f", "uniform2fv", "uniform2iv",
      "uniform3f", "uniform3fv", "uniform3iv", "uniform4f", "uniform4fv", "uniform4iv",
      "uniformMatrix2fv", "uniformMatrix3fv", "uniformMatrix4fv", "bufferData", "bufferSubData",
      "compileShader", "linkProgram", "getProgramParameter", "getShaderParameter",
    ];
    for (const method of methods) {
      const original = d.gl[method];
      if (typeof original !== "function") continue;
      d.gl[method] = function () {
        if (method === "useProgram") activeProgram = arguments[0];
        if (d.mode === "attribution") {
          const pass = d.currentPass;
          const uniform = method.startsWith("uniform") ? locationId(arguments[0]) : null;
          const key = `${method}/${programId(activeProgram)}/${pass?.camera ?? "other"}/${targetInfo().id}/${uniform}`;
          const item = d.glCalls[key] ||= { method, program: programId(activeProgram), camera: pass?.camera ?? "other", target: targetInfo(), uniformLocation: uniform, calls: 0, arrayScalars: 0 };
          item.calls++;
          if (method.startsWith("uniform")) {
            for (let i = 1; i < arguments.length; i++) if (ArrayBuffer.isView(arguments[i]) || Array.isArray(arguments[i])) item.arrayScalars += arguments[i].length;
          }
        }
        return original.apply(this, arguments);
      };
      glHooks.push([method, d.gl[method]]);
      restores.push(() => d.gl[method] = original);
    }
    d.setMode = (mode, phase) => {
      d.mode = "off";
      for (const restore of restores) restore();
      if (mode === "passes" || mode === "attribution" || d.tracing) renderer.render = renderHook;
      if (mode === "attribution") {
        d.attributedFrames = 0;
        activeProgram = d.gl.getParameter(d.gl.CURRENT_PROGRAM);
        renderer.renderBufferDirect = drawHook;
        for (const [method, hook] of glHooks) d.gl[method] = hook;
      }
      if (phase !== undefined) d.phase = phase;
      d.mode = mode;
    };
    d.setMode("off");
  };
  d.pollQueries = pollQueries;
  d.snapshot = () => ({
    frames: d.frames, passes: d.passes, glCalls: Object.values(d.glCalls),
    drawGroups: [...d.drawGroups.values()].map(item => ({ ...item, objects: [...item.objects] })),
    materials: [...d.materialRecords.values()], queriesSkipped: d.queriesSkipped,
    disjointQueries: d.disjointQueries, pendingQueries: d.pending.length,
    timerAvailable: Boolean(d.timer),
  });
  d.shaderCensus = () => {
    const g = d.gl, debug = g.getExtension("WEBGL_debug_shaders");
    return d.renderer.info.programs.map(p => {
      const shaders = g.getAttachedShaders(p.program) || [];
      return {
        program: programId(p.program), threeProgram: p.id, name: p.name, cacheKey: p.cacheKey,
        usedTimes: p.usedTimes, ready: p.isReady?.() ?? null,
        shaders: shaders.map(shader => ({
          type: g.getShaderParameter(shader, g.SHADER_TYPE), source: g.getShaderSource(shader),
          translated: debug?.getTranslatedShaderSource(shader) || null,
        })),
      };
    });
  };
  d.uniformCensus = () => {
    const records = [];
    for (const p of d.renderer.info.programs) {
      const walk = (seq, prefix = "") => {
        for (const entry of seq || []) {
          const name = prefix ? `${prefix}.${entry.id}` : String(entry.id);
          if (entry.addr) records.push({ program: programId(p.program), uniformLocation: locationId(entry.addr), name });
          if (entry.seq) walk(entry.seq, name);
        }
      };
      walk(p.getUniforms().seq);
    }
    return records;
  };
  d.restore = () => {
    d.mode = "off"; d.tracing = false;
    for (const restore of [...restores].reverse()) restore();
    window.requestAnimationFrame = nativeRAF;
  };
})();
