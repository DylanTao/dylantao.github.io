// Producer integrity check only; this synthetic VM is not scene/performance evidence.
const vm = require("node:vm"), fs = require("node:fs"), assert = require("node:assert/strict");
const frames = [];
let time = 0, currentQuery = null, uniforms = 0;
const program = {}, location = {};
const timer = { GPU_DISJOINT_EXT: 1, TIME_ELAPSED_EXT: 2 };
const gl = {
  drawingBufferWidth: 2560, drawingBufferHeight: 1440, CURRENT_QUERY: 3, CURRENT_PROGRAM: 4,
  QUERY_RESULT_AVAILABLE: 5, QUERY_RESULT: 6,
  getExtension: () => timer, getParameter: p => p === 4 ? program : false,
  getQuery: () => currentQuery, createQuery: () => ({}),
  beginQuery: (_, q) => { assert.equal(currentQuery, null); currentQuery = q; },
  endQuery: () => { assert.ok(currentQuery); currentQuery = null; },
  deleteQuery: () => {}, getQueryParameter: (_, p) => p === 5 ? true : 1000000,
  useProgram: () => {}, uniform1f: () => { uniforms++; }, drawElements: () => {},
};
const mat = { id: 1, name: "control", type: "MeshStandardMaterial", customProgramCacheKey: () => "control" };
const object = { name: "whole-object", id: 1 }, scene = { name: "whole-scene" }, camera = { up: { y: 1 }, type: "PerspectiveCamera" };
const renderer = {
  getContext: () => gl, getRenderTarget: () => null,
  info: { render: { calls: 0 }, programs: [], reset() { this.render.calls = 0; } },
  properties: { get: () => ({ currentProgram: { id: 3, program } }) },
  render(s, c) { this.renderBufferDirect(c, s, {}, mat, object, null); },
  renderBufferDirect() { this.info.render.calls++; gl.useProgram(program); gl.uniform1f(location, .5); gl.drawElements(); },
};
const original = { render: renderer.render, draw: renderer.renderBufferDirect, uniform: gl.uniform1f };
const context = vm.createContext({ performance: { now: () => ++time }, ArrayBuffer, WeakMap, Map, Set });
context.window = context;
context.requestAnimationFrame = callback => { frames.push(callback); return frames.length; };
vm.runInContext(fs.readFileSync(__dirname + "/driver-hooks.js", "utf8"), context);
const d = context.__coastalDriver;
d.install(renderer, camera, scene);
const tick = () => { renderer.info.reset(); renderer.render(scene, camera); };
const advance = () => { context.requestAnimationFrame(tick); frames.shift()(time); };
assert.equal(renderer.render, original.render);
assert.equal(renderer.renderBufferDirect, original.draw);
assert.equal(gl.uniform1f, original.uniform);
advance();
assert.equal(d.frames.length, 0);
assert.equal(d.sceneCallbackCount, 1);
d.setMode("frame", "whole-query");
for (let i = 0; i < 5; i++) advance();
assert.equal(renderer.render, original.render);
assert.equal(gl.uniform1f, original.uniform);
assert.equal(d.frames.length, 5);
d.setMode("passes", "pass-query");
assert.notEqual(renderer.render, original.render);
assert.equal(gl.uniform1f, original.uniform);
for (let i = 0; i < 4; i++) advance();
d.setMode("attribution", "program-attribution");
assert.notEqual(renderer.renderBufferDirect, original.draw);
assert.notEqual(gl.uniform1f, original.uniform);
for (let i = 0; i < 7; i++) advance();
assert.equal(d.attributedFrames, 6);
assert.equal(d.mode, "off");
assert.equal(renderer.render, original.render);
assert.equal(renderer.renderBufferDirect, original.draw);
assert.equal(gl.uniform1f, original.uniform);
const snapshot = d.snapshot();
assert.equal(snapshot.frames.filter(f => f.mode === "attribution").length, 6);
assert.equal(snapshot.drawGroups.reduce((n, g) => n + g.drawCalls, 0), 6);
assert.equal(snapshot.glCalls.find(c => c.method === "uniform1f").calls, 6);
assert.equal(uniforms, 17);
d.restore();
console.log("PASS_PRODUCER_LOGIC_ONLY: no GL/draw hooks during controls/whole-frame timing; six attribution frames; exact method restoration");
