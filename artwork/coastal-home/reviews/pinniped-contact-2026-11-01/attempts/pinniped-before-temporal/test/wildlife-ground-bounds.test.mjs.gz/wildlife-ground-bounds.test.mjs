import test from "node:test";
import assert from "node:assert/strict";
import * as THREE from "../assets/js/three.module.min.js";
import { createGroundPatch } from "../assets/js/home-scene/wildlife-ground-contact.mjs";

function plane(gx = 0, gz = 0, width = 4) {
  const geometry = new THREE.PlaneGeometry(width, width).rotateX(-Math.PI / 2),
    p = geometry.attributes.position;
  for (let i = 0; i < p.count; i++) p.setY(i, gx * p.getX(i) + gz * p.getZ(i));
  const mesh = new THREE.Mesh(geometry, new THREE.MeshStandardMaterial());
  mesh.name = "coast_height_bound_fixture";
  return mesh;
}
function patch(roots, margin = 3) {
  const ground = createGroundPatch([[0, 0, 0]], margin);
  ground.capture(roots);
  return ground;
}

test("a bounds query conservatively encloses every supported height on crossed grades", () => {
  for (const [gx, gz] of [
    [0, 0],
    [0.2, -0.15],
    [-0.18, 0.12],
  ]) {
    const ground = patch([plane(gx, gz)]),
      rect = { minX: -0.7, maxX: 0.8, minZ: -0.6, maxZ: 0.9 },
      bound = ground.maximumHeightInBounds(rect);
    assert.equal(bound.covered, true);
    assert.equal(bound.visible, true);
    for (let x = rect.minX; x <= rect.maxX; x += 0.05)
      for (let z = rect.minZ; z <= rect.maxZ; z += 0.05) {
        const actual = ground.sample(x, z);
        assert.ok(actual);
        assert.ok(actual.height <= bound.height);
      }
    // Whole-cell cached ceilings are conservative by at most one cell of
    // horizontal slope per axis on this analytical plane.
    assert.ok(
      bound.height <
        Math.max(...[rect.minX, rect.maxX].flatMap((x) => [rect.minZ, rect.maxZ].map((z) => gx * x + gz * z))) +
          0.35 * (Math.abs(gx) + Math.abs(gz)) +
          2e-7
    );
  }
});

test("a rectangle crossing a shared diagonal has full coverage without inventing a boundary", () => {
  const ground = patch([plane()]);
  assert.equal(ground.maximumHeightInBounds({ minX: -0.5, maxX: 0.5, minZ: -0.5, maxZ: 0.5 }).covered, true);
  ground.capture([]);
  assert.equal(ground.maximumHeightInBounds({ minX: -0.5, maxX: 0.5, minZ: -0.5, maxZ: 0.5 }).covered, true);
});

test("holes and support islands cannot certify an entire query rectangle", () => {
  const roots = [];
  for (const [x, z, width, depth] of [
    [-1.25, 0, 1.5, 4],
    [1.25, 0, 1.5, 4],
    [0, -1.25, 1, 1.5],
    [0, 1.25, 1, 1.5],
  ]) {
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(width, depth).rotateX(-Math.PI / 2), new THREE.MeshStandardMaterial());
    mesh.name = "coast_ring_fixture";
    mesh.position.set(x, 0, z);
    roots.push(mesh);
  }
  const ground = patch(roots);
  assert.equal(ground.maximumHeightInBounds({ minX: -1, maxX: 0.7, minZ: -0.7, maxZ: 0.7 }).covered, false);
  assert.equal(ground.maximumHeightInBounds({ minX: -0.2, maxX: 0.2, minZ: -0.2, maxZ: 0.2 })?.covered || false, false);
  assert.equal(patch([plane(0, 0, 1)]).maximumHeightInBounds({ minX: -0.7, maxX: 0.7, minZ: -0.7, maxZ: 0.7 }).covered, false);
});

test("duplicate triangles on the same side do not cancel a real projected boundary", () => {
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute("position", new THREE.Float32BufferAttribute([-2, 0, -2, -2, 0, 2, 2, 0, -2], 3));
  const a = new THREE.Mesh(geometry, new THREE.MeshStandardMaterial()),
    b = a.clone();
  a.name = b.name = "coast_duplicate_fixture";
  const ground = patch([a, b]);
  assert.equal(ground.maximumHeightInBounds({ minX: -0.4, maxX: 0.2, minZ: -0.4, maxZ: 0.2 }).covered, false);
  assert.equal(ground.maximumHeightInBounds({ minX: -1.5, maxX: -1, minZ: -1.5, maxZ: -1 }).covered, true);
});

test("hidden supports and queries outside captured bounds remain explicitly unqualified", () => {
  const parent = new THREE.Group();
  parent.add(plane());
  parent.visible = false;
  const ground = patch([parent], 1);
  assert.equal(ground.maximumHeightInBounds({ minX: -0.4, maxX: 0.4, minZ: -0.4, maxZ: 0.4 }).visible, false);
  assert.equal(ground.maximumHeightInBounds({ minX: -1.2, maxX: 0.4, minZ: -0.4, maxZ: 0.4 }).covered, false);
  assert.equal(ground.maximumHeightInBounds({ minX: 8, maxX: 9, minZ: 8, maxZ: 9 }), null);
  assert.equal(ground.maximumHeightInBounds({ minX: 1, maxX: -1, minZ: 0, maxZ: 1 }), null);
});

test("a finer index preserves actual point hits, maximum-height selection and triangle order", () => {
  const floor = plane(0.2, -0.15),
    upper = plane(-0.1, 0.08, 1.2);
  upper.position.set(0.2, 0.3, -0.1);
  upper.visible = false;
  const ordinary = patch([floor, upper]),
    fine = createGroundPatch([[0, 0, 0]], 3, 0.0875);
  fine.capture([floor, upper]);
  assert.equal(ordinary.evidence().triangles, fine.evidence().triangles);
  for (let x = -1.9; x < 1.9; x += 0.037)
    for (let z = -1.9; z < 1.9; z += 0.041)
      for (const maximum of [Infinity, 0.15, -0.2]) assert.deepEqual(fine.sample(x, z, maximum), ordinary.sample(x, z, maximum));
  assert.throws(() => createGroundPatch([[0, 0, 0]], 1, 0), RangeError);
});

test("cached ceilings and boundaries refresh after another support is captured", () => {
  const ground = patch([plane()]),
    rectangle = { minX: -0.2, maxX: 0.2, minZ: -0.2, maxZ: 0.2 };
  assert.ok(ground.maximumHeightInBounds(rectangle).height < 1e-6);
  const upper = plane();
  upper.position.y = 0.4;
  ground.capture([upper]);
  assert.ok(ground.maximumHeightInBounds(rectangle).height > 0.399);
  upper.visible = false;
  assert.equal(ground.maximumHeightInBounds(rectangle).visible, false);
});

test("clearance bounds retain the correlation of an inclined shape with its supporting grade", () => {
  const gx = 0.18,
    gz = -0.12,
    ground = patch([plane(gx, gz)]),
    transform = new THREE.Matrix4().set(1, 0, 0, 0, gx, 1, gz, 0, 0, 0, 1, 0, 0, 0, 0, 1),
    corners = Array.from({ length: 8 }, (_, i) =>
      new THREE.Vector3(i & 1 ? 0.6 : -0.6, i & 2 ? 0.09 : 0.04, i & 4 ? 0.5 : -0.5).applyMatrix4(transform)
    ),
    box = new THREE.Box3().setFromPoints(corners),
    rectangle = { minX: box.min.x, maxX: box.max.x, minZ: box.min.z, maxZ: box.max.z, corners },
    bound = ground.maximumHeightInBounds(rectangle, false);
  assert.ok(box.min.y - bound.height < -0.2, "independent extrema should deliberately be loose here");
  assert.ok(bound.gap > 0.0399998 && bound.gap <= 0.04);
  for (let x = -0.6; x <= 0.6; x += 0.03)
    for (let z = -0.5; z <= 0.5; z += 0.03) {
      const p = new THREE.Vector3(x, 0.04, z).applyMatrix4(transform),
        support = ground.sample(p.x, p.z);
      assert.ok(p.y - support.height >= bound.gap);
    }
  assert.equal(bound.covered, undefined, "a height-only query must not claim continuous support");
});
