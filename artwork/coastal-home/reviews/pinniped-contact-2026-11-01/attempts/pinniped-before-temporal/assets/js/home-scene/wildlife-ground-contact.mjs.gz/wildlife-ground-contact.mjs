import * as THREE from "../three.module.min.js";

const CELL = 0.35;
const clock = () => globalThis.performance?.now() || 0;
const EXCLUDED = /plant|flora|foliage|leaf|grass|sage|agave|water|glass|shadow|furniture|placeholder/i;

// The same physical families as the native coast survey. Colour/opacity alone cannot turn
// a leaf card or an indoor table into ground. Visibility is recorded separately: a cutaway
// does not move the physical roof, and the owning scene must keep visible habitat supported.
export function isCoastalGround(mesh) {
  if (!mesh.isMesh || mesh.isSkinnedMesh || !mesh.geometry?.attributes.position || mesh.geometry.attributes.coastalPlantWeight) return false;
  let coast = false,
    core = false,
    roof = false;
  const names = [];
  for (let o = mesh; o; o = o.parent) {
    if (o.userData.action || o.userData.activityProp || o.userData.furnitureAnchor || o.userData.flora || o.userData.shadowOnly) return false;
    names.push(o.name || "");
    coast ||= /^coast_/i.test(o.name);
    core ||= /^core_/i.test(o.name);
    roof ||= Boolean(o.userData.caveRoof);
  }
  const materials = [mesh.material].flat().filter(Boolean);
  if (!materials.length || materials.some((m) => m.transparent || m.opacity < 0.99 || m.transmission > 0)) return false;
  if (EXCLUDED.test(names.join(" ") + " " + materials.map((m) => m.name).join(" "))) return false;
  return coast || roof || (core && materials.some((m) => /golden[ _]coastal[ _]sandstone|La Jolla bluff sandstone/i.test(m.name)));
}

export function createGroundPatch(path, margin = 0.65, cellSize = CELL) {
  if (!Number.isFinite(cellSize) || cellSize <= 0) throw new RangeError("Ground index cell size must be positive and finite");
  const bounds = {
    minX: Math.min(...path.map((p) => p[0])) - margin,
    maxX: Math.max(...path.map((p) => p[0])) + margin,
    minZ: Math.min(...path.map((p) => p[2])) - margin,
    maxZ: Math.max(...path.map((p) => p[2])) + margin,
  };
  const triangles = [],
    cells = new Map(),
    sources = new Set(),
    meshes = new Set(),
    edgeBalances = new Map(),
    boundaryCells = new Map(),
    cellCeilings = new Map(),
    regions = new Map();
  let milliseconds = 0;
  let boundariesDirty = true;
  const a = new THREE.Vector3(),
    b = a.clone(),
    c = a.clone(),
    normal = a.clone(),
    edge = a.clone();
  const cell = (x, z) => `${Math.floor(x / cellSize)},${Math.floor(z / cellSize)}`;
  function registerEdge(ax, az, bx, bz) {
    const a = `${ax},${az}`,
      b = `${bx},${bz}`;
    if (a === b) return;
    const forward = a < b,
      key = forward ? `${a}|${b}` : `${b}|${a}`;
    const record = edgeBalances.get(key) || {
      balance: 0,
      ax,
      az,
      bx,
      bz,
      minX: Math.min(ax, bx),
      maxX: Math.max(ax, bx),
      minZ: Math.min(az, bz),
      maxZ: Math.max(az, bz),
    };
    record.balance += forward ? 1 : -1;
    edgeBalances.set(key, record);
  }
  function indexBoundaries() {
    edgeBalances.clear();
    boundaryCells.clear();
    for (const t of triangles) {
      registerEdge(t.ax, t.az, t.bx, t.bz);
      registerEdge(t.bx, t.bz, t.cx, t.cz);
      registerEdge(t.cx, t.cz, t.ax, t.az);
    }
    for (const e of edgeBalances.values()) {
      if (e.balance === 0) continue;
      const minX = Math.max(bounds.minX, e.minX),
        maxX = Math.min(bounds.maxX, e.maxX),
        minZ = Math.max(bounds.minZ, e.minZ),
        maxZ = Math.min(bounds.maxZ, e.maxZ);
      if (minX > maxX || minZ > maxZ) continue;
      for (let x = Math.floor(minX / cellSize); x <= Math.floor(maxX / cellSize); x++)
        for (let z = Math.floor(minZ / cellSize); z <= Math.floor(maxZ / cellSize); z++) {
          const key = `${x},${z}`;
          if (!boundaryCells.has(key)) boundaryCells.set(key, []);
          boundaryCells.get(key).push(e);
        }
    }
  }
  function capture(roots) {
    const start = clock();
    for (const root of roots) {
      root.updateWorldMatrix(true, true);
      root.traverse((mesh) => {
        if (meshes.has(mesh) || !isCoastalGround(mesh)) return;
        meshes.add(mesh);
        const positions = mesh.geometry.attributes.position,
          indices = mesh.geometry.index;
        if (!mesh.geometry.boundingBox) mesh.geometry.computeBoundingBox();
        const box = mesh.geometry.boundingBox.clone().applyMatrix4(mesh.matrixWorld);
        if (box.max.x < bounds.minX || box.min.x > bounds.maxX || box.max.z < bounds.minZ || box.min.z > bounds.maxZ) return;
        for (let i = 0; i < (indices?.count ?? positions.count); i += 3) {
          a.fromBufferAttribute(positions, indices ? indices.getX(i) : i).applyMatrix4(mesh.matrixWorld);
          b.fromBufferAttribute(positions, indices ? indices.getX(i + 1) : i + 1).applyMatrix4(mesh.matrixWorld);
          c.fromBufferAttribute(positions, indices ? indices.getX(i + 2) : i + 2).applyMatrix4(mesh.matrixWorld);
          const minX = Math.max(bounds.minX, Math.min(a.x, b.x, c.x)),
            maxX = Math.min(bounds.maxX, Math.max(a.x, b.x, c.x)),
            minZ = Math.max(bounds.minZ, Math.min(a.z, b.z, c.z)),
            maxZ = Math.min(bounds.maxZ, Math.max(a.z, b.z, c.z));
          if (minX > maxX || minZ > maxZ) continue;
          normal.subVectors(b, a).cross(edge.subVectors(c, a)).normalize();
          if (normal.y < 0.25) continue;
          const determinant = (b.z - c.z) * (a.x - c.x) + (c.x - b.x) * (a.z - c.z);
          if (Math.abs(determinant) < 1e-10) continue;
          const triangle = {
            ax: a.x,
            az: a.z,
            bx: b.x,
            bz: b.z,
            cx: c.x,
            cz: c.z,
            aX: b.z - c.z,
            aZ: c.x - b.x,
            bX: c.z - a.z,
            bZ: a.x - c.x,
            ay: a.y,
            by: b.y,
            cy: c.y,
            determinant,
            normal: normal.clone(),
            mesh,
            triangle: i / 3,
          };
          triangles.push(triangle);
          sources.add(mesh.name);
          for (let x = Math.floor(minX / cellSize); x <= Math.floor(maxX / cellSize); x++)
            for (let z = Math.floor(minZ / cellSize); z <= Math.floor(maxZ / cellSize); z++) {
              const key = `${x},${z}`;
              if (!cells.has(key)) cells.set(key, []);
              cells.get(key).push(triangle);
            }
        }
      });
    }
    boundariesDirty = true;
    cellCeilings.clear();
    regions.clear();
    milliseconds += clock() - start;
  }
  function sample(x, z, maximum = Infinity) {
    let best = null,
      bestHeight = -Infinity;
    for (const t of cells.get(cell(x, z)) || []) {
      const u = (t.aX * (x - t.cx) + t.aZ * (z - t.cz)) / t.determinant,
        v = (t.bX * (x - t.cx) + t.bZ * (z - t.cz)) / t.determinant;
      if (u < -1e-7 || v < -1e-7 || u + v > 1 + 1e-7) continue;
      const height = u * t.ay + v * t.by + (1 - u - v) * t.cy;
      if (height > maximum || (best && height <= bestHeight)) continue;
      best = t;
      bestHeight = height;
    }
    return supportResult(best, bestHeight);
  }
  function supportResult(t, height) {
    if (!t) return null;
    let visible = true;
    for (let o = t.mesh; o; o = o.parent) visible &&= o.visible;
    return { height, normal: t.normal, mesh: t.mesh.name, triangle: t.triangle, visible };
  }
  function maximumHeightInBounds(query, certify = true) {
    const { minX, maxX, minZ, maxZ } = query;
    if (![minX, maxX, minZ, maxZ].every(Number.isFinite) || minX > maxX || minZ > maxZ) return null;
    if (boundariesDirty) {
      indexBoundaries();
      boundariesDirty = false;
    }
    const x0 = Math.floor(minX / cellSize),
      x1 = Math.floor(maxX / cellSize),
      z0 = Math.floor(minZ / cellSize),
      z1 = Math.floor(maxZ / cellSize),
      regionKey = `${x0},${x1},${z0},${z1}`;
    let region = regions.get(regionKey);
    if (!region) {
      const candidates = new Set(),
        boundaries = new Set(),
        owners = new Set();
      let height = -Infinity;
      for (let x = x0; x <= x1; x++)
        for (let z = z0; z <= z1; z++) {
          const key = `${x},${z}`,
            list = cells.get(key) || [];
          let ceiling = cellCeilings.get(key);
          if (ceiling === undefined) {
            ceiling = -Infinity;
            // The plane is affine: its maximum over the entire cell is at a
            // corner. Caching this slightly looser bound changes no geometry.
            for (const t of list)
              for (const cx of [x * cellSize, (x + 1) * cellSize])
                for (const cz of [z * cellSize, (z + 1) * cellSize])
                  ceiling = Math.max(ceiling, t.cy - (t.normal.x * (cx - t.cx) + t.normal.z * (cz - t.cz)) / t.normal.y);
            cellCeilings.set(key, ceiling);
          }
          height = Math.max(height, ceiling);
          for (const t of list) {
            candidates.add(t);
            owners.add(t.mesh);
          }
          for (const e of boundaryCells.get(key) || []) boundaries.add(e);
        }
      const planes = new Map();
      for (const t of candidates) {
        const x = t.normal.x / t.normal.y,
          z = t.normal.z / t.normal.y,
          offset = t.cy + x * t.cx + z * t.cz;
        planes.set(`${x},${z},${offset}`, { x, z, offset });
      }
      region = { height, triangles: candidates.size, boundaries: [...boundaries], owners: [...owners], planes: [...planes.values()] };
      regions.set(regionKey, region);
    }
    if (!region.triangles) return null;
    let gap = -Infinity;
    if (query.corners) {
      gap = Infinity;
      for (const plane of region.planes)
        for (const p of query.corners)
          gap = Math.min(gap, p.y + plane.x * p.x + plane.z * p.z - plane.offset - 1e-8 * (1 + Math.abs(plane.x) + Math.abs(plane.z)));
    }
    if (!certify) return { height: region.height + 1e-8, gap };
    let visible = true;
    for (const mesh of region.owners) for (let o = mesh; o; o = o.parent) visible &&= o.visible;
    // Oppositely oriented shared edges are interior to the projected support
    // union. A rectangle touching any remaining edge stays uncertified. Exact
    // opposite edges alone cancel; there is no near-edge welding.
    const withinPatch = minX >= bounds.minX && maxX <= bounds.maxX && minZ >= bounds.minZ && maxZ <= bounds.maxZ;
    const crossesBoundary = region.boundaries.some((e) => {
      const dx = e.bx - e.ax,
        dz = e.bz - e.az;
      let start = 0,
        end = 1;
      for (const [p, q] of [
        [-dx, e.ax - minX + 1e-8],
        [dx, maxX - e.ax + 1e-8],
        [-dz, e.az - minZ + 1e-8],
        [dz, maxZ - e.az + 1e-8],
      ]) {
        if (p === 0) {
          if (q < 0) return false;
          continue;
        }
        const t = q / p;
        if (p < 0) start = Math.max(start, t);
        else end = Math.min(end, t);
        if (start > end) return false;
      }
      return true;
    });
    const covered = withinPatch && !crossesBoundary && !!sample((minX + maxX) / 2, (minZ + maxZ) / 2);
    return { height: region.height + 1e-8, gap, covered, visible, triangles: region.triangles };
  }
  return {
    capture,
    sample,
    maximumHeightInBounds,
    evidence: () => ({
      ready: triangles.length > 0,
      triangles: triangles.length,
      cells: cells.size,
      meshes: [...sources],
      bounds,
      captureMilliseconds: milliseconds,
    }),
  };
}

// Rigid paw ownership is read from the delivered skin, in the paw's own frame. A small grid
// keeps its lower envelope; the runtime never substitutes an ellipsoid or a nominal thickness.
export function footSole(model, bone) {
  // SkinnedMesh.updateMatrixWorld refreshes its bind inverse; updateWorldMatrix does not.
  model.updateMatrixWorld(true);
  const points = new Map(),
    inverse = bone.matrixWorld.clone().invert(),
    point = new THREE.Vector3();
  model.traverse((mesh) => {
    if (!mesh.isSkinnedMesh) return;
    const skin = mesh.geometry.attributes.skinIndex,
      weights = mesh.geometry.attributes.skinWeight;
    for (let i = 0; i < skin.count; i++) {
      let owned = 0;
      for (let k = 0; k < 4; k++) if (mesh.skeleton.bones[skin.getComponent(i, k)] === bone) owned += weights.getComponent(i, k);
      if (owned < 0.999) continue;
      mesh.getVertexPosition(i, point);
      point.applyMatrix4(mesh.matrixWorld).applyMatrix4(inverse);
      const key = `${Math.round(point.x / 0.006)},${Math.round(point.z / 0.006)}`;
      if (!points.has(key) || point.y < points.get(key).y) points.set(key, point.clone());
    }
  });
  return [...points.values()];
}

export function groundFootQuaternion(yaw, normal) {
  const forward = new THREE.Vector3(Math.sin(yaw), 0, Math.cos(yaw));
  forward.y = -(normal.x * forward.x + normal.z * forward.z) / normal.y;
  forward.normalize();
  const right = normal.clone().cross(forward).normalize();
  return new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(right, normal, forward));
}

export function fitFootSole(patch, sole, position, quaternion, onlyLift = false) {
  let clearance = Infinity,
    supported = 0,
    visible = true;
  const point = new THREE.Vector3();
  for (const sample of sole) {
    point.copy(sample).applyQuaternion(quaternion).add(position);
    const surface = patch.sample(point.x, point.z, position.y + 0.5);
    if (!surface) continue;
    supported++;
    clearance = Math.min(clearance, point.y - surface.height);
    visible &&= surface.visible;
  }
  const shift = supported ? (onlyLift ? Math.max(0, -clearance) : -clearance) : 0;
  return { position: position.clone().add(new THREE.Vector3(0, shift, 0)), supported, visible, correction: shift };
}
