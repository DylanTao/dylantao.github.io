import * as THREE from "../three.module.min.js";
import { smooth } from "./wildlife-acting.mjs";
import { groundFootQuaternion } from "./wildlife-ground-contact.mjs";

// Only the delivered ringed-tail skin belongs to this contact problem. Its
// trunk and planted paws already have their own independent support solution.
export function createRestingTailFit({ model, group, tail, ground }) {
  const samples = [];
  model.traverse((mesh) => {
    if (!mesh.isSkinnedMesh) return;
    const skin = mesh.geometry.attributes.skinIndex,
      weights = mesh.geometry.attributes.skinWeight;
    for (let i = 0; i < skin.count; i++) {
      let ownership = 0;
      for (let k = 0; k < 4; k++) if (/^Tail/.test(mesh.skeleton.bones[skin.getComponent(i, k)].name)) ownership += weights.getComponent(i, k);
      if (ownership > 1e-4) samples.push({ mesh, index: i });
    }
  });
  const point = new THREE.Vector3(),
    up = new THREE.Vector3(0, 1, 0),
    original = new THREE.Quaternion();
  function measure() {
    group.updateMatrixWorld(true);
    let minimum = null,
      missing = 0,
      visible = true;
    for (const sample of samples) {
      sample.mesh.getVertexPosition(sample.index, point).applyMatrix4(sample.mesh.matrixWorld);
      const support = ground.sample(point.x, point.z, point.y + 0.5);
      if (!support) {
        missing++;
        continue;
      }
      visible &&= support.visible;
      const gap = point.y - support.height;
      if (!minimum || gap < minimum.gap)
        minimum = { gap, point: point.clone(), mesh: sample.mesh.name, vertex: sample.index, supportMesh: support.mesh, triangle: support.triangle };
    }
    return { minimum, missing, visible };
  }
  return {
    update() {
      // The owning acting function restores the authored tail pose each frame.
      original.copy(tail.quaternion);
      const first = measure();
      let current = first,
        iterations = 0,
        reason = null;
      if (!samples.length || first.missing || !first.minimum) reason = "incomplete tail support";
      while (!reason && current.minimum.gap < 0.0006 && iterations < 12) {
        const pivot = tail.getWorldPosition(new THREE.Vector3()),
          radius = current.minimum.point.clone().sub(pivot),
          horizontal = Math.hypot(radius.x, radius.z);
        if (horizontal < 0.03) {
          reason = "contact is too near the tail pivot";
          break;
        }
        // Lift the offending part of the curled tail toward the local ground,
        // about its real hip attachment. A fixed model-x rotation poorly fits
        // a tail that has already curled sideways around the sleeping body.
        const axis = radius.cross(up).normalize(),
          angle = Math.min(0.22, Math.atan2(0.00065 - current.minimum.gap, horizontal) * 1.03),
          parent = tail.parent.getWorldQuaternion(new THREE.Quaternion()),
          correction = parent.clone().invert().multiply(new THREE.Quaternion().setFromAxisAngle(axis, angle)).multiply(parent);
        tail.quaternion.premultiply(correction);
        iterations++;
        if (original.angleTo(tail.quaternion) > 0.65) {
          reason = "tail rotation exceeds the bounded joint fit";
          break;
        }
        current = measure();
        if (current.missing || !current.minimum) reason = "incomplete rotated tail support";
      }
      if (!reason && current.minimum.gap < 0.0006) reason = "tail contact did not converge";
      const attemptedGap = current.minimum?.gap ?? null;
      if (reason) {
        tail.quaternion.copy(original);
        group.updateMatrixWorld(true);
        current = first;
      }
      const witness = current.minimum;
      return {
        supported: !reason,
        reason,
        samples: samples.length,
        missing: current.missing,
        supportVisible: current.visible,
        beforeGap: first.minimum?.gap ?? null,
        gap: witness?.gap ?? null,
        attemptedGap,
        rotation: !reason && iterations ? original.angleTo(tail.quaternion) : 0,
        iterations,
        witness: witness ? { mesh: witness.mesh, vertex: witness.vertex, supportMesh: witness.supportMesh, triangle: witness.triangle } : null,
      };
    },
  };
}

// Cache the exact Float64 joint products once per pose instead of rebuilding
// bone-world * inverse-bind for every skin vertex. The operation order for each
// point is the same as Three's getVertexPosition; no skin samples are removed.
export function createSkinContactSampler(model) {
  const points = [],
    skeletons = new Map(),
    local = new THREE.Vector3();
  model.updateMatrixWorld(true);
  model.traverse((mesh) => {
    if (!mesh.isSkinnedMesh) return;
    if (!skeletons.has(mesh.skeleton))
      skeletons.set(
        mesh.skeleton,
        mesh.skeleton.bones.map(() => new THREE.Matrix4())
      );
    const p = mesh.geometry.attributes.position,
      indices = mesh.geometry.attributes.skinIndex,
      weights = mesh.geometry.attributes.skinWeight;
    for (let i = 0; i < p.count; i++)
      points.push({
        mesh,
        index: i,
        base: new THREE.Vector3().fromBufferAttribute(p, i).applyMatrix4(mesh.bindMatrix),
        channels: Array.from({ length: 4 }, (_, k) => ({
          index: indices.getComponent(i, k),
          weight: weights.getComponent(i, k),
          name: mesh.skeleton.bones[indices.getComponent(i, k)].name,
        })),
      });
  });
  return {
    points,
    refresh() {
      for (const [skeleton, matrices] of skeletons)
        for (let i = 0; i < matrices.length; i++) matrices[i].multiplyMatrices(skeleton.bones[i].matrixWorld, skeleton.boneInverses[i]);
    },
    position(point, result) {
      const { mesh } = point;
      if (mesh.geometry.morphAttributes.position?.length) return mesh.getVertexPosition(point.index, result).applyMatrix4(mesh.matrixWorld);
      result.set(0, 0, 0);
      const matrices = skeletons.get(mesh.skeleton);
      for (const channel of point.channels)
        if (channel.weight !== 0) result.addScaledVector(local.copy(point.base).applyMatrix4(matrices[channel.index]), channel.weight);
      return result.applyMatrix4(mesh.bindMatrixInverse).applyMatrix4(mesh.matrixWorld);
    },
  };
}

export function createPinnipedContactFit({ model, group, bones, ground }) {
  const sampler = createSkinContactSampler(model),
    body = [],
    anchors = [],
    primary = new Map();
  const names = ["FrontFlipperL", "FrontFlipperR", "RearFlipperL", "RearFlipperR"];
  const flippers = Object.fromEntries(names.map((name) => [name, []]));
  const point = new THREE.Vector3(),
    inverse = group.matrixWorld.clone().invert();
  sampler.refresh();
  for (const sample of sampler.points) {
    const owners = new Set(sample.channels.filter((c) => c.weight > 1e-4 && /Flipper/.test(c.name)).map((c) => c.name.replace("Tip", "")));
    if (!owners.size) {
      body.push(sample);
      anchors.push(sample);
    }
    for (const name of owners) {
      if (!flippers[name]) continue;
      flippers[name].push(sample);
      const local = sampler.position(sample, point).clone().applyMatrix4(bones[name].object.matrixWorld.clone().invert());
      if (Math.hypot(local.x, local.z) < 0.05) anchors.push(sample);
    }
    if (sample.channels.reduce((sum, c) => sum + (/^(Hips|Chest)$/.test(c.name) ? c.weight : 0), 0) >= 0.5) {
      const p = sampler.position(sample, point).clone().applyMatrix4(inverse);
      primary.set(`${Math.round(p.x / 0.04)},${Math.round(p.z / 0.04)}`, p);
    }
  }
  const primaryPoints = [...primary.values()],
    up = new THREE.Vector3(0, 1, 0);
  let cachedPlan = null;
  function measure(samples) {
    let minimum = null,
      missing = 0,
      visible = true;
    for (const sample of samples) {
      sampler.position(sample, point);
      const hit = ground.sample(point.x, point.z, point.y + 0.5);
      if (!hit) {
        missing++;
        continue;
      }
      visible &&= hit.visible;
      const gap = point.y - hit.height;
      if (!minimum || gap < minimum.gap)
        minimum = { gap, point: point.clone(), mesh: sample.mesh.name, vertex: sample.index, supportMesh: hit.mesh, triangle: hit.triangle };
    }
    return { minimum, missing, visible, samples: samples.length };
  }
  function refresh() {
    group.updateMatrixWorld(true);
    sampler.refresh();
  }
  function plan(yaw) {
    const p = group.position,
      key = `${p.x},${p.y},${p.z},${yaw}`;
    if (cachedPlan?.key === key) return cachedPlan;
    const centre = ground.sample(p.x, p.z, p.y + 0.6),
      right = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw)),
      forward = new THREE.Vector3(Math.sin(yaw), 0, Math.cos(yaw));
    const radii = [0.18, 0.28],
      hits = [];
    for (const [axis, radius] of [
      [right, radii[0]],
      [forward, radii[1]],
    ])
      for (const sign of [-1, 1]) hits.push(ground.sample(p.x + axis.x * radius * sign, p.z + axis.z * radius * sign, p.y + 0.6));
    if (!centre || hits.some((h) => !h)) return { key, supported: false, reason: "incomplete bearing footprint" };
    const normal = up
      .clone()
      .addScaledVector(right, -(hits[1].height - hits[0].height) / (2 * radii[0]))
      .addScaledVector(forward, -(hits[3].height - hits[2].height) / (2 * radii[1]))
      .normalize();
    let relief = -Infinity,
      supported = 0,
      witness = null;
    for (const local of primaryPoints) {
      point.copy(local).applyMatrix4(group.matrixWorld);
      const hit = ground.sample(point.x, point.z, p.y + 0.6);
      if (!hit) continue;
      supported++;
      const plane = centre.height - (normal.x * (point.x - p.x) + normal.z * (point.z - p.z)) / normal.y,
        residual = hit.height - plane;
      if (residual > relief) {
        relief = residual;
        witness = { mesh: hit.mesh, triangle: hit.triangle, point: [point.x, hit.height, point.z] };
      }
    }
    const reason =
      normal.y < Math.cos(0.35)
        ? "bearing slope exceeds the bounded pose"
        : relief > 0.12
          ? "rest torso crosses a raised rock shoulder"
          : supported < primaryPoints.length * 0.95
            ? "incomplete torso footprint"
            : null;
    cachedPlan = { key, supported: !reason, reason, normal, relief, samples: primaryPoints.length, supportedSamples: supported, witness };
    return cachedPlan;
  }
  return {
    update(pose, yaw) {
      refresh();
      const bearing = plan(yaw);
      const summary = {
        supported: bearing.supported,
        reason: bearing.reason,
        relief: bearing.relief ?? null,
        samples: bearing.samples || 0,
        supportedSamples: bearing.supportedSamples || 0,
        witness: bearing.witness || null,
      };
      if (!bearing.supported) return { supported: false, reason: bearing.reason, bearing: summary, flippers: [], rootCorrection: 0 };
      const originalEuler = group.rotation.clone(),
        originalY = group.position.y;
      group.quaternion.copy(groundFootQuaternion(yaw, bearing.normal));
      refresh();
      const initial = measure(anchors);
      if (!initial.minimum || initial.missing > anchors.length * 0.05) {
        group.rotation.copy(originalEuler);
        refresh();
        return { supported: false, reason: "incomplete body support", bearing: summary, flippers: [], rootCorrection: 0 };
      }
      const correction = Math.max(0, 0.0008 + pose.bodyLift - initial.minimum.gap);
      if (correction > 0.15) {
        group.rotation.copy(originalEuler);
        refresh();
        return {
          supported: false,
          reason: "body correction exceeds the bounded pose",
          bearing: summary,
          flippers: [],
          rootCorrection: 0,
          attemptedRootCorrection: correction,
        };
      }
      group.position.y += correction;
      refresh();
      const contacts = [];
      for (const name of names) {
        const bone = bones[name].object,
          samples = flippers[name],
          pivot = bone.getWorldPosition(new THREE.Vector3()),
          original = bone.quaternion.clone(),
          inverseBone = bone.matrixWorld.clone().invert();
        // Every vertex in a paddle is owned solely by this joint or its tip.
        // Rotating their common parent moves the entire already-posed paddle
        // rigidly, so inner iterations need no repeated skinning or shape loss.
        const localPoints = samples.map((sample) => ({ sample, point: sampler.position(sample, new THREE.Vector3()).applyMatrix4(inverseBone) }));
        function paddle() {
          group.updateMatrixWorld(true);
          let minimum = null,
            missing = 0,
            visible = true,
            farthest = null;
          for (const p of localPoints) {
            point.copy(p.point).applyMatrix4(bone.matrixWorld);
            const radius = point.clone().sub(pivot),
              horizontal = Math.hypot(radius.x, radius.z);
            if (!farthest || horizontal > farthest.distance) farthest = { radius, distance: horizontal };
            const hit = ground.sample(point.x, point.z, point.y + 0.5);
            if (!hit) {
              missing++;
              continue;
            }
            visible &&= hit.visible;
            const gap = point.y - hit.height;
            if (!minimum || gap < minimum.gap)
              minimum = {
                gap,
                point: point.clone(),
                mesh: p.sample.mesh.name,
                vertex: p.sample.index,
                supportMesh: hit.mesh,
                triangle: hit.triangle,
              };
          }
          return { minimum, missing, visible, farthest };
        }
        function solve(onlyLift) {
          let current = paddle(),
            iterations = 0,
            reason = null;
          while (iterations < 16) {
            if (!current.minimum || current.missing > samples.length * 0.05) {
              reason = "incomplete paddle support";
              break;
            }
            const error = 0.00065 - current.minimum.gap;
            if (onlyLift ? error <= 0.0002 : Math.abs(error) < 0.0002) break;
            let radius = current.minimum.point.clone().sub(pivot),
              horizontal = Math.hypot(radius.x, radius.z);
            if (error < 0 && horizontal < 0.02) {
              radius = current.farthest.radius;
              horizontal = current.farthest.distance;
            }
            if (horizontal < 0.02) {
              reason = "contact is too near the attached pivot";
              break;
            }
            const axis = radius.cross(up).normalize(),
              angle = Math.max(-0.14, Math.min(0.14, Math.atan2(error, horizontal))),
              parent = bone.parent.getWorldQuaternion(new THREE.Quaternion());
            const previous = bone.quaternion.clone();
            bone.quaternion.premultiply(parent.clone().invert().multiply(new THREE.Quaternion().setFromAxisAngle(axis, angle)).multiply(parent));
            if (original.angleTo(bone.quaternion) > 0.75) {
              bone.quaternion.copy(previous);
              reason = "paddle correction exceeds the joint bound";
              break;
            }
            iterations++;
            current = paddle();
          }
          return { ...current, iterations, reason };
        }
        const side = name.endsWith("L") ? "L" : "R",
          active = side === pose.flipperSide ? 1 : 0.15;
        const gesture = Math.max(Math.abs(pose.flipper * active), Math.abs(pose.flipperTip * active) * 0.6),
          contactWeight = name.startsWith("Rear") ? 0 : 1 - smooth((gesture - 0.04) / 0.2);
        let result = solve(contactWeight === 0);
        if (contactWeight > 0 && contactWeight < 1) {
          const fitted = bone.quaternion.clone();
          bone.quaternion.copy(original).slerp(fitted, contactWeight);
          result = solve(true);
        }
        const final = paddle(),
          minimum = final.minimum;
        contacts.push({
          name,
          contactWeight,
          supported: !!minimum && minimum.gap >= -0.002 && (contactWeight < 1 || minimum.gap <= 0.002) && final.missing <= samples.length * 0.05,
          reason: result.reason,
          samples: samples.length,
          missing: final.missing,
          supportVisible: final.visible,
          gap: minimum?.gap ?? null,
          rotation: original.angleTo(bone.quaternion),
          witness: minimum ? { mesh: minimum.mesh, vertex: minimum.vertex, supportMesh: minimum.supportMesh, triangle: minimum.triangle } : null,
        });
      }
      refresh();
      const finalBody = measure(body),
        good = !!finalBody.minimum && finalBody.minimum.gap >= -0.002 && contacts.every((c) => c.supported);
      return {
        supported: good,
        reason: good ? null : "body or paddle contact remains unresolved",
        bearing: summary,
        rootCorrection: group.position.y - originalY,
        bodyGap: finalBody.minimum?.gap ?? null,
        bodySamples: body.length,
        flippers: contacts,
      };
    },
  };
}
