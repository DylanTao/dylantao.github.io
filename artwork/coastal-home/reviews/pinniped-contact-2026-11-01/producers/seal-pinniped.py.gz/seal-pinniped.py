from pathlib import Path
import gzip
import hashlib
import json
import subprocess

q = Path(__file__).parent
root = q.parents[2]
source = "b6b2946296f23c8d3e78b281d4914552205f1b1b"
out = root / "artwork/coastal-home/reviews/pinniped-contact-2026-11-01"
assert not out.exists()
analysis = json.loads((q / "pinniped-transfer-analysis.json").read_text())
assert analysis["sourceCommit"] == source
assert analysis["denseFullTerrain"]["fullTerrainTriangleIntersections"] == 0
assert analysis["eventFullTerrain"]["fullTerrainTriangleIntersections"] == 0
assert analysis["temporal"]["uniqueFullSkinPoses"] == 15105
assert analysis["actualGpu"]["maximumBoneMatrixError"] == 0
out.mkdir(parents=True)

def put(path, name, compressed=True):
    body = Path(path).read_bytes()
    target = out / (name + (".gz" if compressed else ""))
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(body, compresslevel=9, mtime=0) if compressed else body)

data = [
    "pinniped-transfer-analysis.json", "pinniped-dense-transfer-candidate.json", "pinniped-dense-transfer-reference.json",
    "pinniped-dense-final-baseline.json", "pinniped-full-terrain-transfer.json", "pinniped-full-terrain-transfer-event.json",
    "pinniped-temporal-transfer-v2.json", "pinniped-transfer-equivalence.json", "actual-gpu-pinniped.json",
    "sea-lion-full-skin-separation-native.json", "sea-lion-full-skin-separation-transfer.json",
    "sealion-native-anchor.json", "sealion-accepted-terrain-inputs.json", "INPUT_BINDINGS.json",
    "pinniped-native-served-readback.json", "pinniped-native-view-manifest.json", "benchmark-compiled-baseline-binding.json",
    "pinniped-triangle-witness.json", "pinniped-edge-custody-before.json", "pinniped-edge-custody-after.json",
]
for name in data:
    put(q / name, "data/" + name)
put(q / "inputs/assets/models/home/manifest.json", "data/original-frozen-manifest.json")

for folder, engine in [("pinniped-live-gravity-native", "chromium"), ("pinniped-live-gravity-native", "webkit"), ("pinniped-roll-live", "chromium")]:
    frames = q / folder / (engine + "-frames.json")
    records = json.loads(frames.read_text())
    put(frames, "data/views/" + folder + "/" + frames.name)
    for row in records:
        put(q / folder / row["file"], "views/" + folder + "/" + row["file"], False)

for folder, prefix in [("pinniped-gravity-native-benchmark", "benchmark/final"), ("before-gravity-seat/pinniped-native-benchmark", "attempts/earlier-public-N-benchmark")]:
    for path in sorted((q / folder).rglob("*")):
        if path.is_file():
            put(path, prefix + "/" + path.relative_to(q / folder).as_posix(), path.suffix != ".png")

for folder in ["node-transfer-surface-reference", "node-accepted-tail984"]:
    for path in sorted((q / folder).rglob("*")):
        if path.is_file():
            put(path, "reference/" + folder + "/" + path.relative_to(q / folder).as_posix())

producers = [
    "analyze-pinniped-transfer.py", "prepare-pinniped-transfer-reference.py", "pinniped-dense-transfer-proof.mjs",
    "pinniped-dense-transfer-reference-proof.mjs", "pinniped-full-terrain-transfer.mjs", "pinniped-full-terrain-transfer-event.mjs",
    "pinniped-temporal-transfer.mjs", "pinniped-gravity-transition-controls.mjs", "sea-lion-full-skin-separation-native.mjs",
    "sea-lion-full-skin-separation-transfer.mjs", "pinniped-live-gravity-native.cjs", "pinniped-live-transfer-native.cjs",
    "pinniped-roll-live.cjs", "gpu-pinniped.cjs", "read-pinniped-native-preview.py", "proxy-pinniped-exclusive.py",
    "prepare-pinniped-benchmark.py", "pinniped-gravity-benchmark.cjs", "seal-pinniped.py", "pinniped-transfer-README.md",
]
for name in producers:
    put(q / name, "producers/" + name)

logs = [
    "pinniped-dense-transfer-v2.log", "pinniped-full-terrain-transfer-v2.log", "pinniped-full-terrain-transfer-event-v2.log",
    "pinniped-temporal-transfer-v2.log", "pinniped-transfer-flat-reference-v2.log", "pinniped-transfer-animal-tests-v2.log",
    "pinniped-transfer-style-contract.log", "pinniped-transfer-colony-v2.log", "pinniped-transfer-colony-extra.log",
    "pinniped-transfer-gpu-readback.log", "pinniped-transfer-live-chromium-v2.log", "pinniped-transfer-live-webkit-v2.log",
    "pinniped-transfer-roll-chromium-v2.log", "pinniped-transfer-benchmark-baseline-v2.log", "pinniped-transfer-benchmark-candidate-v2.log",
    "pinniped-final-registered.log", "pinniped-gravity-sole-v1.log", "pinniped-gravity-sole-v2.log", "pinniped-refined-transition-v1.log",
]
for name in logs:
    put(q / name, "logs/" + name)

attempts = []
for folder in ["pinniped-before-temporal", "rejected-roll-end-weight-overshoot", "rejected-active-corner-axis", "before-gravity-seat", "rejected-gravity-hard-min", "rejected-hierarchy-opt7", "pinniped-source-v1"]:
    directory = q / folder
    if not directory.exists():
        continue
    for path in sorted(directory.rglob("*")):
        if not path.is_file():
            continue
        name = path.name
        wanted = path.suffix in [".mjs", ".cjs", ".py"] or (path.suffix == ".json" and any(k in name.lower() for k in ["rejection", "continuity", "temporal", "failure", "trace"]))
        if folder == "before-gravity-seat" and name == "pinniped-dense-final-candidate.json":
            wanted = True
        if not wanted:
            continue
        relative = "attempts/" + folder + "/" + path.relative_to(directory).as_posix()
        put(path, relative)
        body = path.read_bytes()
        attempts.append({"path": relative + ".gz", "sourceBytes": len(body), "sourceSha256": hashlib.sha256(body).hexdigest()})
put(q / "rejected-paddle-soft-objective.mjs", "attempts/rejected-paddle-soft-objective.mjs")
(out / "ATTEMPTS.json").write_text(json.dumps({"scope": "Retained rejected and superseded controls; not final acceptance or final performance claims.", "files": attempts}, indent=2) + "\n", encoding="utf-8", newline="\n")

owned = ["assets/js/home-scene/" + n for n in ["wildlife.mjs", "wildlife-motion.mjs", "wildlife-ground-contact.mjs", "wildlife-resting-contact.mjs"]] + ["test/wildlife-resting-contact.test.mjs", "test/wildlife-ground-bounds.test.mjs"]
for name in owned:
    body = subprocess.check_output(["git", "show", source + ":" + name], cwd=root)
    target = out / ("source/" + name + ".gz")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(body, compresslevel=9, mtime=0))
for name in ["wildlife.mjs", "wildlife-motion.mjs", "wildlife-ground-contact.mjs", "wildlife-resting-contact.mjs", "wildlife-rabbit-contact.mjs"]:
    put(root / "assets/js/home-scene" / name, "served/assets/js/home-scene/" + name)
bindings = {
    "sourceCommit": source, "sourceFiles": analysis["sourceBindings"],
    "actualServedReadback": "data/pinniped-native-served-readback.json.gz",
    "scope": "Five raw worker module overlays and only the native-surveyed seaLion0 metadata point over the complete frozen503 compiled preview4158, exclusively bound on4173. Source Git blobs and actual served bytes are distinct records. Frozen native geometry and original static cache remain unchanged in this private fixture.",
    "baselineSource": "98474dd24fc8980e6886a7b74633e7494d5f0bc9",
    "nativeSurveySourceSha256": "de217984242f77903145dd6d16f277923b57fd5e3eb2469c906c2507b494ad87",
    "publication": "None by the worker. Coordinator owns native producer/manifest replay, final F6 support checks, official combined cache, full gates, CI and live verification.",
}
(out / "SOURCE_BINDINGS.json").write_text(json.dumps(bindings, indent=2) + "\n", encoding="utf-8", newline="\n")
put(q / "pinniped-transfer-README.md", "README.md", False)
subprocess.run(["node", str(root / "node_modules/prettier/bin/prettier.cjs"), "--write", str(out / "README.md")], cwd=root, check=True)
(out / ".gitattributes").write_text("# Keep sealed review payload bytes identical across Windows and Linux.\n* -text\n", encoding="utf-8", newline="\n")
manifest = {"schema": 1, "scope": "Land pinniped contact and bounded continuous weight transfer; performance and final integrated release remain open.", "files": []}
for path in sorted(out.rglob("*")):
    if path.is_file():
        body = path.read_bytes()
        manifest["files"].append({"path": path.relative_to(out).as_posix(), "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()})
(out / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"source": source, "packet": str(out), "files": len(manifest["files"]), "bytes": sum(r["bytes"] for r in manifest["files"])}))
