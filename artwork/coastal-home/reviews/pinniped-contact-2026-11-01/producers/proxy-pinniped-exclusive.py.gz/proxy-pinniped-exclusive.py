import os,socket,sys
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.request import urlopen,Request
from urllib.error import HTTPError
q=Path(__file__).parent;root=q.parents[2]
OWNED={f'/al-folio/assets/js/home-scene/{name}':root/'assets/js/home-scene'/name for name in ['wildlife.mjs','wildlife-rabbit-contact.mjs','wildlife-resting-contact.mjs','wildlife-ground-contact.mjs','wildlife-motion.mjs']}
OWNED["/al-folio/assets/models/home/manifest.json"]=q/"pinniped-view-manifest.json"
if '--native' in sys.argv:OWNED['/al-folio/assets/models/home/manifest.json']=q/'pinniped-native-view-manifest.json'
if '--profile-current' in sys.argv:OWNED['/al-folio/assets/js/home-scene/wildlife-resting-contact.mjs']=q/'profiled-pinniped-current.mjs'
if '--profile-draft' in sys.argv:OWNED['/al-folio/assets/js/home-scene/wildlife-resting-contact.mjs']=q/'profiled-pinniped-draft.mjs'
if '--benchmark-candidate' in sys.argv:
    OWNED['/al-folio/assets/js/home-scene/wildlife.mjs']=q/'benchmark-candidate-wildlife.mjs'
    OWNED['/al-folio/assets/js/home-scene/wildlife-resting-contact.mjs']=q/'benchmark-candidate-resting.mjs'
if '--benchmark-baseline' in sys.argv:
    OWNED={f'/al-folio/assets/js/home-scene/{name}':q/'sealed-tail/assets/js/home-scene'/name for name in ['wildlife.mjs','wildlife-rabbit-contact.mjs','wildlife-resting-contact.mjs']}
    OWNED['/al-folio/assets/js/home-scene/wildlife.mjs']=q/'benchmark-baseline-wildlife.mjs'
    OWNED['/al-folio/assets/models/home/manifest.json']=q/'pinniped-native-view-manifest.json'
class Handler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def log_message(self,*args):pass
    def do_GET(self):
        name=self.path.split('?',1)[0]
        if name in OWNED:
            body=OWNED[name].read_bytes();status=200;headers={'Content-Type':'application/json' if name.endswith('.json') else 'text/javascript; charset=utf-8'}
        else:
            try:
                with urlopen(Request('http://127.0.0.1:4158'+self.path,headers={'Cache-Control':'no-cache'}),timeout=90)as response:
                    body=response.read();status=response.status;headers=dict(response.headers)
            except HTTPError as error:
                body=error.read();status=error.code;headers={'Content-Type':'text/plain'}
        self.send_response(status)
        self.send_header('X-Visual-Owner',f'interior-finish/{os.getpid()}/pinniped4173')
        for key,value in headers.items():
            if key.lower() in ['content-type','content-encoding','content-range','access-control-allow-origin']:self.send_header(key,value)
        self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(body)
class Server(ThreadingHTTPServer):
    allow_reuse_address=False
    def server_bind(self):
        if hasattr(socket,'SO_EXCLUSIVEADDRUSE'):self.socket.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
        super().server_bind()
    request_queue_size=128
    daemon_threads=True
server=Server(('127.0.0.1',4173),Handler)
print({'pid':os.getpid(),'address':server.server_address,'exclusive':True},flush=True)
server.serve_forever()
