import crypto from "node:crypto";
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { THREE, loadNativeModel } from "file:///C:/dev/site-takeover-worktrees/identity-footer/test/helpers/coastal-native-avatar.mjs";
import { nativeGeometry } from "file:///C:/dev/site-takeover-worktrees/identity-footer/test/helpers/coastal-native-geometry.mjs";
const {createWildlife}=await import(process.argv.includes("--before")?new URL("./node-before-gravity/assets/js/home-scene/wildlife.mjs",import.meta.url).href:"file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife.mjs");
import { createGroundPatch } from "file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife-ground-contact.mjs";
import { rabbitActing, rabbitSchedule } from "file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife-motion.mjs";

const models = new URL("file:///C:/dev/site-takeover-worktrees/identity-footer/.jekyll-cache/visual-qa/animal-readonly-20261031/inputs/assets/models/home/");
const config = JSON.parse(fs.readFileSync(new URL("manifest.json", models)));
const perches = JSON.parse(fs.readFileSync(new URL("wildlife-perch-support.json", models)));
const species = ["BrushRabbit", "CaliforniaSeaLion", "HarborSeal", "Raccoon", "WesternGull", "Sandpiper", "BrownPelican", "BrandtsCormorant"];
const masters = await Promise.all(species.map((name) => loadNativeModel(name + ".glb", models)));
async function world(manifest, grounds) {
  const scene = new THREE.Group(), environment = new THREE.Group(); scene.add(environment, ...grounds);
  const wildlife = createWildlife(environment, manifest, {
    createModelLoader: () => ({ loader: { loadAsync: async (url) => masters[species.indexOf(url.split("/").at(-1).replace(".glb", ""))] }, decoder: { dispose() {} } }),
    loadPerchSupport: async () => perches,
  });
  for (let i = 0; i < 100 && !wildlife.evidence().modelsReady; i++) await new Promise(setImmediate);
  assert.equal(wildlife.evidence().modelsReady, true);
  wildlife.captureGround(grounds); scene.updateMatrixWorld(true);
  const paws = [0, 1].map((index) => {
    const list=[];
    scene.traverse((mesh) => {
      if (!mesh.isSkinnedMesh || mesh.userData.action?.id !== `rabbit-${index}`) return;
      const skin=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight;
      for(let i=0;i<skin.count;i++) {
        const names=new Map();
        for(let k=0;k<4;k++){const name=mesh.skeleton.bones[skin.getComponent(i,k)].name;names.set(name,(names.get(name)||0)+weights.getComponent(i,k));}
        for(const [name,weight]of names)if(/^(Front|Hind)Paw[LR]$/.test(name)&&weight>=.999)list.push({mesh,index:i,name});
      }
    });
    assert.ok(list.length>1000);return list;
  });
  const patches=["rabbitWest","rabbitEast"].map((key)=>{const p=createGroundPatch(manifest.terrain.habitats[key].path,1);p.capture(grounds);assert.ok(p.evidence().ready);return p});
  function measure(index) {
    scene.updateMatrixWorld(true);
    for(const mesh of new Set(paws[index].map(p=>p.mesh)))mesh.skeleton.update();
    const feet=Object.fromEntries(["FrontPawL","FrontPawR","HindPawL","HindPawR"].map(n=>[n,{minimum:Infinity,missing:0,points:[]} ]));
    for(const p of paws[index]){
      const v=p.mesh.getVertexPosition(p.index,new THREE.Vector3()).applyMatrix4(p.mesh.matrixWorld),hit=patches[index].sample(v.x,v.z,v.y+.5),foot=feet[p.name];
      foot.points.push(v.toArray());if(!hit)foot.missing++;else foot.minimum=Math.min(foot.minimum,v.y-hit.height);
    }
    return feet;
  }
  return {scene,wildlife,paws,measure};
}

const {pinnipedActing,pinnipedSchedule,pinnipedFlipperActivation}=await import("file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife-motion.mjs");
const grounds=await Promise.all([nativeGeometry("home-shell.glb",models),nativeGeometry("coast.glb",models)]),manifest=structuredClone(config);manifest.terrain.habitats.seaLion.path[0]=[-9.7,-6.6382,-14.8115];
const runtime=await world(manifest,grounds),subjects=[],seatingDense=JSON.parse(fs.readFileSync(new URL('./pinniped-dense-gravity-candidate.json',import.meta.url))).rows,retained=JSON.parse(fs.readFileSync(new URL('./pinniped-before-temporal/pinniped-continuity-native.json',import.meta.url))).rows;
for(const key of ['seaLion','seal'])for(let index=0;index<3;index++){
 const id=key+'-'+index,meshes=[];runtime.scene.traverse(o=>{if(o.isSkinnedMesh&&o.userData.action?.id===id)meshes.push(o)});
 const vertices=[];for(const mesh of meshes)for(let i=0;i<mesh.geometry.attributes.position.count;i++)vertices.push({mesh:mesh.name,index:i});
 const bones=Object.fromEntries(meshes[0].skeleton.bones.map(b=>[b.name,b]));subjects.push({key,index,id,meshes,vertices,bones});
}
const rows=[],poseList=new Map(),label=process.argv.includes('--before')?'edge-before-gravity':'edge-after-gravity',output=new URL('./pinniped-temporal-'+label+'.json',import.meta.url);
function eventsFor(subject){return [ ['seal-1',29.609660901827738],['seal-1',23.50402294495143],['seaLion-0',35.0166365748737],['seal-2',133.2305416909512],['seaLion-0',21.94291925127618]].filter(([id])=>id===subject.id).map(([,time])=>({time,kinds:['measured contact transition']}))}
function maxDistance(a,b,scale=1){let maximum=0,vertex=0;for(let i=0;i<a.length;i+=3){const distance=Math.hypot(a[i]-b[i],a[i+1]-b[i+1],a[i+2]-b[i+2])*scale;if(distance>maximum){maximum=distance;vertex=i/3}}return{maximum,vertex}}
function maxSecond(a,b,c,scale){let maximum=0,vertex=0;for(let i=0;i<a.length;i+=3){const distance=Math.hypot(a[i]+c[i]-2*b[i],a[i+1]+c[i+1]-2*b[i+1],a[i+2]+c[i+2]-2*b[i+2])*scale;if(distance>maximum){maximum=distance;vertex=i/3}}return{maximum,vertex}}
const extract=(array,index)=>Array.from(array.slice(index*3,index*3+3));
for(const subject of subjects){
 const cache=new Map(),events=eventsFor(subject);let forcedChecks=0,snapshots=0;
 function snapshot(time){const key=time.toFixed(10);if(cache.has(key))return cache.get(key);runtime.wildlife.update(time,'noon');subject.meshes[0].onBeforeRender();runtime.scene.updateMatrixWorld(true);const points=new Float64Array(subject.vertices.length*3),point=new THREE.Vector3();let offset=0;for(const mesh of subject.meshes)for(let i=0;i<mesh.geometry.attributes.position.count;i++){mesh.getVertexPosition(i,point).applyMatrix4(mesh.matrixWorld);points[offset++]=point.x;points[offset++]=point.y;points[offset++]=point.z}
  const contact=runtime.wildlife.evidence().contacts.filter(r=>r.habitat===subject.key)[subject.index],sha256=crypto.createHash('sha256').update(Buffer.from(points.buffer)).digest('hex'),record={time,points,sha256,state:contact.state,fit:contact.surfaceContact};if(snapshots++%100===0){runtime.wildlife.update(time,'noon',{force:true});runtime.scene.updateMatrixWorld(true);const control=new Float64Array(points.length);let n=0;for(const mesh of subject.meshes)for(let i=0;i<mesh.geometry.attributes.position.count;i++){mesh.getVertexPosition(i,point).applyMatrix4(mesh.matrixWorld);control[n++]=point.x;control[n++]=point.y;control[n++]=point.z}assert.equal(crypto.createHash('sha256').update(Buffer.from(control.buffer)).digest('hex'),sha256,'Actual draw catch-up must match a fully forced pose');forcedChecks++;}cache.set(key,record);if(cache.size>64)cache.delete(cache.keys().next().value);poseList.set(subject.id+'/'+key,{id:subject.id,time,sha256});return record;
 }
 for(const event of events){const time=event.time,h=1e-5,a=snapshot(time-h),b=snapshot(time+h),motion=maxDistance(a.points,b.points),vh=1e-4,left=snapshot(time-vh),centre=snapshot(time),right=snapshot(time+vh),velocity=maxSecond(left.points,centre.points,right.points,1/vh),cadences=[];
  for(const hz of [30,60]){const samples=Array.from({length:7},(_,i)=>snapshot(time+(i-3)/hz)),steps=[],changes=[];for(let i=1;i<samples.length;i++){const q=maxDistance(samples[i-1].points,samples[i].points,hz);steps.push({from:samples[i-1].time,to:samples[i].time,speed:q.maximum,witness:subject.vertices[q.vertex],points:[extract(samples[i-1].points,q.vertex),extract(samples[i].points,q.vertex)]})}for(let i=1;i<samples.length-1;i++){const q=maxSecond(samples[i-1].points,samples[i].points,samples[i+1].points,hz);changes.push({at:samples[i].time,velocityDifference:q.maximum,witness:subject.vertices[q.vertex],points:[extract(samples[i-1].points,q.vertex),extract(samples[i].points,q.vertex),extract(samples[i+1].points,q.vertex)]})}cadences.push({hz,samples:samples.map(s=>({time:s.time,sha256:s.sha256,state:s.state,contactFitResolved:s.fit.contactFitResolved??s.fit.supported,contactMissing:s.fit.contactQueryCoverage?.missing??null})),steps,changes});}
  rows.push({id:subject.id,time,kinds:event.kinds,vertices:subject.vertices.length,forcedPoseControlsSoFar:forcedChecks,microstep:{h,maximumVertexMotionM:motion.maximum,witness:subject.vertices[motion.vertex],points:[extract(a.points,motion.vertex),extract(b.points,motion.vertex)],supported:[a.fit.supported,b.fit.supported]},velocity:{h:vh,maximumOneSidedDifferenceMps:velocity.maximum,witness:subject.vertices[velocity.vertex],points:[extract(left.points,velocity.vertex),extract(centre.points,velocity.vertex),extract(right.points,velocity.vertex)]},cadences});
  if(rows.length%100===0){fs.writeFileSync(new URL('./pinniped-temporal-'+label+'-progress.json',import.meta.url),JSON.stringify({completedEvents:rows.length,poses:poseList.size,id:subject.id,time}));console.log(JSON.stringify({label,events:rows.length,poses:poseList.size,id:subject.id,time}));}
 }
}
const result={scope:'All delivered skin vertices sampled at event-centred microsteps and actual 30/60Hz sample intervals. Finite event set includes retained binary-switch and unsupported-roll failures, authored mode boundaries, observed continuous balance/contact/roll thresholds and measured seating-support changes between half-second survey rows through 180s. This is finite sampling, not a proof over every possible time. The selected actor uses its actual onBeforeRender catch-up path, with periodic complete forced-pose hash controls; product scheduling is unchanged. These are numeric active-time trajectories, not native browser FPS or a physical-device claim. Full scene native RAF is a separate benchmark; exact full-terrain geometry checks consume the listed poses.',label,point:manifest.terrain.habitats.seaLion.path[0],rows,poses:[...poseList.values()]};
fs.writeFileSync(output,JSON.stringify(result,null,2));console.log(JSON.stringify({label,events:rows.length,poses:poseList.size,maximumMicrostep:Math.max(...rows.map(r=>r.microstep.maximumVertexMotionM)),maximumOneSidedVelocityDifference:Math.max(...rows.map(r=>r.velocity.maximumOneSidedDifferenceMps)),unresolvedMicrosteps:rows.filter(r=>!r.microstep.supported.every(Boolean)).length}));
