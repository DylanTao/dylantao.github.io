from pathlib import Path
q=Path(__file__).parent;root=q.parents[2]
old='''    breakdown[name] = (breakdown[name] ?? 0) * 0.9 + (clock() - started) * 0.1;'''
new='''    const elapsed=clock()-started;
    breakdown[name] = (breakdown[name] ?? 0) * 0.9 + elapsed * 0.1;
    if(name==="pinnipeds"&&globalThis.__benchActive)(globalThis.__benchStages??=[]).push({stamp:globalThis.__benchStamp,time:lastTime,milliseconds:elapsed});'''
for label,path in [('baseline',q/'sealed-tail/assets/js/home-scene/wildlife.mjs'),('candidate',root/'assets/js/home-scene/wildlife.mjs')]:
    source=path.read_text();assert source.count(old)==1
    source=source.replace(old,new)
    marker='  function update(t, paletteName = null, { force = false } = {}) {'
    assert source.count(marker)==1;source=source.replace(marker,marker+'\n    globalThis.__benchSceneTime=t;')
    (q/f'benchmark-{label}-wildlife.mjs').write_text(source,encoding='utf-8')
source=(root/'assets/js/home-scene/wildlife-resting-contact.mjs').read_text()
assert source.count('export function createPinnipedContactFit(')==1
source=source.replace('export function createPinnipedContactFit(', 'function createBenchPinnipedImplementation(')
source+='''
// Private passive per-call CPU recorder. The implementation above is unchanged.
export function createPinnipedContactFit(options) {
  const fit=createBenchPinnipedImplementation(options);let id=null;
  options.model.traverse(object=>{id??=object.userData.action?.id});
  return {...fit,update(...args){const start=performance.now(),result=fit.update(...args),elapsed=performance.now()-start;
    if(globalThis.__benchActive)(globalThis.__benchFits??=[]).push({stamp:globalThis.__benchStamp,time:globalThis.__benchSceneTime,id,milliseconds:elapsed});
    return result;
  }};
}
'''
(q/'benchmark-candidate-resting.mjs').write_text(source,encoding='utf-8')
