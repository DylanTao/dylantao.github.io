from pathlib import Path,PurePosixPath
import re,subprocess,posixpath,json,hashlib
q=Path(__file__).parent;root=q.parents[2]
def graph(label,revision=None,flat=False):
    out=q/label;bindings=[];visited=set()
    def copy(name):
        if name in visited:return
        visited.add(name)
        body=subprocess.check_output(['git','show',revision+':'+name],cwd=root)if revision else(root/name).read_bytes()
        if flat and name=='assets/js/home-scene/wildlife-resting-contact.mjs':
            source=body.decode();source,n=re.subn(r',\s*hierarchy(?=\s*\))','',source);assert n==2
            body=source.encode()
        target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body)
        bindings.append({'path':name,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()})
        if name.endswith(('.mjs','.js')):
            source=body.decode()
            for dependency in re.findall(r'(?:from\s*|import\s*\(?)\s*["\'](\.[^"\']+)["\']',source):
                child=posixpath.normpath(str(PurePosixPath(name).parent/dependency))
                assert child.startswith('assets/'),child
                if child.endswith(('.js','.mjs')):copy(child)
    copy('assets/js/home-scene/wildlife.mjs')
    (out/'INPUTS.json').write_text(json.dumps({'sourceRevision':revision,'flatSurfaceReference':flat,'files':bindings},indent=2)+'\n',encoding='utf-8',newline='\n')
    return out
reference=graph('node-transfer-surface-reference',flat=True)
baseline=graph('node-accepted-tail984',revision='98474dd24fc8980e6886a7b74633e7494d5f0bc9')
source=(q/'pinniped-dense-transfer-proof.mjs').read_text()
line=next(s for s in source.splitlines()if s.startswith('const {createWildlife}='))
replacement='const {createWildlife}=await import(process.argv.includes("--reference")?new URL("./node-transfer-surface-reference/assets/js/home-scene/wildlife.mjs",import.meta.url).href:process.argv.includes("--baseline")?new URL("./node-accepted-tail984/assets/js/home-scene/wildlife.mjs",import.meta.url).href:"file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife.mjs");'
source=source.replace(line,replacement).replace('const label=process.argv.includes("--baseline")?"baseline":"candidate"','const label=process.argv.includes("--reference")?"reference":process.argv.includes("--baseline")?"baseline":"candidate"').replace('./pinniped-dense-transfer-','./pinniped-dense-transfer-')
source=source.replace('candidate is current private body/flipper source','candidate is current continuous motion and finite-face contact source; reference disables only face-BVH pruning, and baseline is exact tail984 dependency graph')
(q/'pinniped-dense-transfer-reference-proof.mjs').write_text(source,encoding='utf-8')
print({'referenceModules':len(json.loads((reference/'INPUTS.json').read_text())['files']),'baselineModules':len(json.loads((baseline/'INPUTS.json').read_text())['files'])})
