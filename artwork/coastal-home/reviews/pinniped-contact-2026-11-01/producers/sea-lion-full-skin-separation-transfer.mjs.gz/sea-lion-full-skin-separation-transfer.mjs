import crypto from "node:crypto";
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { THREE, loadNativeModel } from "file:///C:/dev/site-takeover-worktrees/identity-footer/test/helpers/coastal-native-avatar.mjs";
import { nativeGeometry } from "file:///C:/dev/site-takeover-worktrees/identity-footer/test/helpers/coastal-native-geometry.mjs";
const {createWildlife}=await import(process.argv.includes("--baseline")?new URL("./baseline-wildlife.mjs",import.meta.url).href:"file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife.mjs");
import { createGroundPatch } from "file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife-ground-contact.mjs";
import { rabbitActing, rabbitSchedule } from "file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife-motion.mjs";

const models = new URL("file:///C:/dev/site-takeover-worktrees/identity-footer/.jekyll-cache/visual-qa/animal-readonly-20261031/inputs/assets/models/home/");
const config = JSON.parse(fs.readFileSync(new URL("manifest.json", models)));
const perches = JSON.parse(fs.readFileSync(new URL("wildlife-perch-support.json", models)));
const species = ["BrushRabbit", "CaliforniaSeaLion", "HarborSeal", "Raccoon", "WesternGull", "Sandpiper", "BrownPelican", "BrandtsCormorant"];
const masters = await Promise.all(species.map((name) => loadNativeModel(name + ".glb", models)));
async function world(manifest, grounds) {
  const scene = new THREE.Group(), environment = new THREE.Group(); scene.add(environment, ...grounds);
  const wildlife = createWildlife(environment, manifest, {
    createModelLoader: () => ({ loader: { loadAsync: async (url) => masters[species.indexOf(url.split("/").at(-1).replace(".glb", ""))] }, decoder: { dispose() {} } }),
    loadPerchSupport: async () => perches,
  });
  for (let i = 0; i < 100 && !wildlife.evidence().modelsReady; i++) await new Promise(setImmediate);
  assert.equal(wildlife.evidence().modelsReady, true);
  wildlife.captureGround(grounds); scene.updateMatrixWorld(true);
  const paws = [0, 1].map((index) => {
    const list=[];
    scene.traverse((mesh) => {
      if (!mesh.isSkinnedMesh || mesh.userData.action?.id !== `rabbit-${index}`) return;
      const skin=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight;
      for(let i=0;i<skin.count;i++) {
        const names=new Map();
        for(let k=0;k<4;k++){const name=mesh.skeleton.bones[skin.getComponent(i,k)].name;names.set(name,(names.get(name)||0)+weights.getComponent(i,k));}
        for(const [name,weight]of names)if(/^(Front|Hind)Paw[LR]$/.test(name)&&weight>=.999)list.push({mesh,index:i,name});
      }
    });
    assert.ok(list.length>1000);return list;
  });
  const patches=["rabbitWest","rabbitEast"].map((key)=>{const p=createGroundPatch(manifest.terrain.habitats[key].path,1);p.capture(grounds);assert.ok(p.evidence().ready);return p});
  function measure(index) {
    scene.updateMatrixWorld(true);
    for(const mesh of new Set(paws[index].map(p=>p.mesh)))mesh.skeleton.update();
    const feet=Object.fromEntries(["FrontPawL","FrontPawR","HindPawL","HindPawR"].map(n=>[n,{minimum:Infinity,missing:0,points:[]} ]));
    for(const p of paws[index]){
      const v=p.mesh.getVertexPosition(p.index,new THREE.Vector3()).applyMatrix4(p.mesh.matrixWorld),hit=patches[index].sample(v.x,v.z,v.y+.5),foot=feet[p.name];
      foot.points.push(v.toArray());if(!hit)foot.missing++;else foot.minimum=Math.min(foot.minimum,v.y-hit.height);
    }
    return feet;
  }
  return {scene,wildlife,paws,measure};
}

const grounds=await Promise.all([nativeGeometry("home-shell.glb",models),nativeGeometry("coast.glb",models)]),manifest=structuredClone(config);
manifest.terrain.habitats.seaLion.path[0]=[-9.7,-6.6382,-14.8115];
const runtime=await world(manifest,grounds),subjects=[0,1].map(index=>{const meshes=[];runtime.scene.traverse(o=>{if(o.isSkinnedMesh&&o.userData.action?.id==="seaLion-"+index)meshes.push(o)});return meshes});
function skin(meshes){const points=[],triangles=[];for(const mesh of meshes){const list=[];for(let i=0;i<mesh.geometry.attributes.position.count;i++){const point=mesh.getVertexPosition(i,new THREE.Vector3()).applyMatrix4(mesh.matrixWorld).toArray();list.push(point);points.push({point,mesh:mesh.name,index:i})}const ix=mesh.geometry.index;for(let i=0;i<(ix?.count||list.length);i+=3){const vs=[0,1,2].map(j=>list[ix?ix.getX(i+j):i+j]),min=[0,1,2].map(k=>Math.min(...vs.map(v=>v[k]))),max=[0,1,2].map(k=>Math.max(...vs.map(v=>v[k])));triangles.push({vs,min,max,centre:min.map((v,k)=>(v+max[k])/2),mesh:mesh.name,index:i/3})}}return{points,triangles}}
function kd(points,depth=0){if(!points.length)return null;const axis=depth%3,list=[...points].sort((a,b)=>a.point[axis]-b.point[axis]),middle=list.length>>1;return{point:list[middle],axis,left:kd(list.slice(0,middle),depth+1),right:kd(list.slice(middle+1),depth+1)}}
function near(node,p,result){if(!node)return;const d=p.point.reduce((sum,v,k)=>sum+(v-node.point.point[k])**2,0);if(d<result.square){result.square=d;result.a=p;result.b=node.point}const delta=p.point[node.axis]-node.point.point[node.axis],first=delta<0?node.left:node.right,second=delta<0?node.right:node.left;near(first,p,result);if(delta*delta<result.square)near(second,p,result)}
const overlaps=(a,b)=>a.min.every((v,k)=>v<=b.max[k]+1e-9&&a.max[k]>=b.min[k]-1e-9);
function bvh(triangles){const min=[0,1,2].map(k=>Math.min(...triangles.map(t=>t.min[k]))),max=[0,1,2].map(k=>Math.max(...triangles.map(t=>t.max[k])));if(triangles.length<=12)return{min,max,triangles};const axis=max.map((v,k)=>v-min[k]).indexOf(Math.max(...max.map((v,k)=>v-min[k]))),list=[...triangles].sort((a,b)=>a.centre[axis]-b.centre[axis]),m=list.length>>1;return{min,max,left:bvh(list.slice(0,m)),right:bvh(list.slice(m))}}
const subtract=(a,b)=>a.map((v,k)=>v-b[k]),cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],dot=(a,b)=>a.reduce((n,v,k)=>n+v*b[k],0);
function intersects(a,b){const ea=[subtract(a.vs[1],a.vs[0]),subtract(a.vs[2],a.vs[1]),subtract(a.vs[0],a.vs[2])],eb=[subtract(b.vs[1],b.vs[0]),subtract(b.vs[2],b.vs[1]),subtract(b.vs[0],b.vs[2])],na=cross(ea[0],ea[1]),nb=cross(eb[0],eb[1]),axes=[na,nb,...ea.flatMap(x=>eb.map(y=>cross(x,y))),...ea.map(e=>cross(na,e)),...eb.map(e=>cross(nb,e))];for(const axis of axes){const length=Math.hypot(...axis);if(length<1e-12)continue;const pa=a.vs.map(v=>dot(v,axis)),pb=b.vs.map(v=>dot(v,axis)),epsilon=1e-9*length;if(Math.max(...pa)<Math.min(...pb)-epsilon||Math.max(...pb)<Math.min(...pa)-epsilon)return false}return true}
function collisions(triangles,tree){let tested=0;const found=[];function visit(a,node){if(!overlaps(a,node))return;if(node.triangles){for(const b of node.triangles)if(overlaps(a,b)){tested++;if(intersects(a,b))found.push({a:{mesh:a.mesh,triangle:a.index},b:{mesh:b.mesh,triangle:b.index}})}}else{visit(a,node.left);visit(a,node.right)}}for(const a of triangles)visit(a,tree);return{tested,found}}
const rows=[];let kdTree=null;
for(const time of [0, 4, 8, 12, 14.4167, 16, 18.8007, 20, 21.94291925127618, 23.5357, 24, 28, 28.5, 29, 30, 30.5, 31, 31.5, 32, 32.5, 33.5, 34, 34.5, 35, 35.0166365748737, 36, 40, 44, 48, 52, 56, 60, 64, 68, 72, 76, 80, 84, 88, 92, 96, 100, 104, 108, 112, 116, 120]){
 runtime.wildlife.update(time,"noon",{force:true});runtime.scene.updateMatrixWorld(true);const a=skin(subjects[0]),b=skin(subjects[1]),result={square:Infinity};for(const point of a.points)near(kdTree||(kdTree=kd(b.points)),point,result);
 const collision=collisions(a.triangles,bvh(b.triangles)),contact=runtime.wildlife.evidence().contacts[0].surfaceContact;
 rows.push({time,state:runtime.wildlife.evidence().contacts[0].state,minimumSkinVertexDistance:Math.sqrt(result.square),closestPair:{a:result.a,b:result.b},triangleCandidatePairs:collision.tested,triangleIntersections:collision.found,surfaceContact:contact,vertices:[a.points.length,b.points.length],triangles:[a.triangles.length,b.triangles.length]});kdTree=null;
}
fs.writeFileSync(new URL("./sea-lion-full-skin-separation-transfer.json",import.meta.url),JSON.stringify({scope:"Native-surveyed +0.30 X/-0.30 Z authoring anchor proposal on exact frozen accepted decoded coast; actual current candidate body/flipper source; no native or manifest product write. Minimum is exact skin-vertex distance, not a continuous soft-tissue distance. Full deformed triangle SAT tests reject actual surface intersections, including coplanar cases.",proposedPoint:manifest.terrain.habitats.seaLion.path[0],rows},null,2));console.log(JSON.stringify({poses:rows.length,minimumSkinVertexDistance:Math.min(...rows.map(r=>r.minimumSkinVertexDistance)),intersectionCount:rows.reduce((n,r)=>n+r.triangleIntersections.length,0),allContactsSupported:rows.every(r=>r.surfaceContact.supported),maxRootCorrection:Math.max(...rows.map(r=>r.surfaceContact.rootCorrection)),failedContacts:rows.filter(r=>!r.surfaceContact.supported).map(r=>({time:r.time,contact:r.surfaceContact}))}));
