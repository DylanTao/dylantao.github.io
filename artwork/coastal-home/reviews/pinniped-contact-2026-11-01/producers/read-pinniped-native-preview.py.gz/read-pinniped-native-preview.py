import hashlib,json
from pathlib import Path
from urllib.request import urlopen
q=Path(__file__).parent;root=q.parents[2]
original=json.loads((q/'INPUT_BINDINGS.json').read_text());rows=[]
owned={f'assets/js/home-scene/{n}':root/'assets/js/home-scene'/n for n in ['wildlife.mjs','wildlife-resting-contact.mjs','wildlife-ground-contact.mjs','wildlife-rabbit-contact.mjs','wildlife-motion.mjs']}
owned['assets/models/home/manifest.json']=q/'pinniped-native-view-manifest.json'
expected={r['path']:(r['bytes'],r['sha256']) for r in original['files'] if r['path'] not in owned}
for path,source in owned.items():
    body=source.read_bytes();expected[path]=(len(body),hashlib.sha256(body).hexdigest())
owners=set()
for path,(size,sha) in expected.items():
    with urlopen('http://127.0.0.1:4173/al-folio/'+path,timeout=90)as response:
        body=response.read();owner=response.headers['X-Visual-Owner'];status=response.status
    actual=hashlib.sha256(body).hexdigest();assert len(body)==size and actual==sha,path
    assert status==200 and owner.startswith('interior-finish/') and owner.endswith('/pinniped4173'),owner
    owners.add(owner);rows.append({'path':path,'bytes':len(body),'sha256':actual,'status':status,'owner':owner})
assert len(owners)==1,owners
before=json.loads((q/'inputs/assets/models/home/manifest.json').read_text());after=json.loads((q/'pinniped-native-view-manifest.json').read_text())
before['terrain']['habitats']['seaLion']['path'][0]=[-9.7,-6.6382,-14.8115];assert before==after
receipt={'port':4173,'exclusiveOwner':list(owners)[0],'files':rows,'onlyManifestSemanticChange':'seaLion.path[0] native-surveyed proposed authoring point [-9.7,-6.6382,-14.8115]; original cache and native products unchanged in this private qualification. Root owns final metadata/source and official cache.'}
(q/'pinniped-native-served-readback.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print({'responses':len(rows),'owner':receipt['exclusiveOwner'],'fullBodiesVerified':True})
