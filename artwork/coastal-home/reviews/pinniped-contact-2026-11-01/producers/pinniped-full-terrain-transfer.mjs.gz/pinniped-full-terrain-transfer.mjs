import crypto from "node:crypto";
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { THREE, loadNativeModel } from "file:///C:/dev/site-takeover-worktrees/identity-footer/test/helpers/coastal-native-avatar.mjs";
import { nativeGeometry } from "file:///C:/dev/site-takeover-worktrees/identity-footer/test/helpers/coastal-native-geometry.mjs";
const {createWildlife}=await import(process.argv.includes("--baseline")?new URL("./baseline-wildlife.mjs",import.meta.url).href:"file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife.mjs");
import { createGroundPatch } from "file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife-ground-contact.mjs";
import { rabbitActing, rabbitSchedule } from "file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife-motion.mjs";

const models = new URL("file:///C:/dev/site-takeover-worktrees/identity-footer/.jekyll-cache/visual-qa/animal-readonly-20261031/inputs/assets/models/home/");
const config = JSON.parse(fs.readFileSync(new URL("manifest.json", models)));
const perches = JSON.parse(fs.readFileSync(new URL("wildlife-perch-support.json", models)));
const species = ["BrushRabbit", "CaliforniaSeaLion", "HarborSeal", "Raccoon", "WesternGull", "Sandpiper", "BrownPelican", "BrandtsCormorant"];
const masters = await Promise.all(species.map((name) => loadNativeModel(name + ".glb", models)));
async function world(manifest, grounds) {
  const scene = new THREE.Group(), environment = new THREE.Group(); scene.add(environment, ...grounds);
  const wildlife = createWildlife(environment, manifest, {
    createModelLoader: () => ({ loader: { loadAsync: async (url) => masters[species.indexOf(url.split("/").at(-1).replace(".glb", ""))] }, decoder: { dispose() {} } }),
    loadPerchSupport: async () => perches,
  });
  for (let i = 0; i < 100 && !wildlife.evidence().modelsReady; i++) await new Promise(setImmediate);
  assert.equal(wildlife.evidence().modelsReady, true);
  wildlife.captureGround(grounds); scene.updateMatrixWorld(true);
  const paws = [0, 1].map((index) => {
    const list=[];
    scene.traverse((mesh) => {
      if (!mesh.isSkinnedMesh || mesh.userData.action?.id !== `rabbit-${index}`) return;
      const skin=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight;
      for(let i=0;i<skin.count;i++) {
        const names=new Map();
        for(let k=0;k<4;k++){const name=mesh.skeleton.bones[skin.getComponent(i,k)].name;names.set(name,(names.get(name)||0)+weights.getComponent(i,k));}
        for(const [name,weight]of names)if(/^(Front|Hind)Paw[LR]$/.test(name)&&weight>=.999)list.push({mesh,index:i,name});
      }
    });
    assert.ok(list.length>1000);return list;
  });
  const patches=["rabbitWest","rabbitEast"].map((key)=>{const p=createGroundPatch(manifest.terrain.habitats[key].path,1);p.capture(grounds);assert.ok(p.evidence().ready);return p});
  function measure(index) {
    scene.updateMatrixWorld(true);
    for(const mesh of new Set(paws[index].map(p=>p.mesh)))mesh.skeleton.update();
    const feet=Object.fromEntries(["FrontPawL","FrontPawR","HindPawL","HindPawR"].map(n=>[n,{minimum:Infinity,missing:0,points:[]} ]));
    for(const p of paws[index]){
      const v=p.mesh.getVertexPosition(p.index,new THREE.Vector3()).applyMatrix4(p.mesh.matrixWorld),hit=patches[index].sample(v.x,v.z,v.y+.5),foot=feet[p.name];
      foot.points.push(v.toArray());if(!hit)foot.missing++;else foot.minimum=Math.min(foot.minimum,v.y-hit.height);
    }
    return feet;
  }
  return {scene,wildlife,paws,measure};
}
function skin(meshes){const points=[],triangles=[];for(const mesh of meshes){const list=[];for(let i=0;i<mesh.geometry.attributes.position.count;i++){const point=mesh.getVertexPosition(i,new THREE.Vector3()).applyMatrix4(mesh.matrixWorld).toArray();list.push(point);points.push({point,mesh:mesh.name,index:i})}const ix=mesh.geometry.index;for(let i=0;i<(ix?.count||list.length);i+=3){const vs=[0,1,2].map(j=>list[ix?ix.getX(i+j):i+j]),min=[0,1,2].map(k=>Math.min(...vs.map(v=>v[k]))),max=[0,1,2].map(k=>Math.max(...vs.map(v=>v[k])));triangles.push({vs,min,max,centre:min.map((v,k)=>(v+max[k])/2),mesh:mesh.name,index:i/3})}}return{points,triangles}}
const overlaps=(a,b)=>a.min.every((v,k)=>v<=b.max[k]+1e-9&&a.max[k]>=b.min[k]-1e-9);
function bvh(triangles){const min=[0,1,2].map(k=>Math.min(...triangles.map(t=>t.min[k]))),max=[0,1,2].map(k=>Math.max(...triangles.map(t=>t.max[k])));if(triangles.length<=12)return{min,max,triangles};const axis=max.map((v,k)=>v-min[k]).indexOf(Math.max(...max.map((v,k)=>v-min[k]))),list=[...triangles].sort((a,b)=>a.centre[axis]-b.centre[axis]),m=list.length>>1;return{min,max,left:bvh(list.slice(0,m)),right:bvh(list.slice(m))}}
const subtract=(a,b)=>a.map((v,k)=>v-b[k]),cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],dot=(a,b)=>a.reduce((n,v,k)=>n+v*b[k],0);
function intersects(a,b){const ea=[subtract(a.vs[1],a.vs[0]),subtract(a.vs[2],a.vs[1]),subtract(a.vs[0],a.vs[2])],eb=[subtract(b.vs[1],b.vs[0]),subtract(b.vs[2],b.vs[1]),subtract(b.vs[0],b.vs[2])],na=cross(ea[0],ea[1]),nb=cross(eb[0],eb[1]),axes=[na,nb,...ea.flatMap(x=>eb.map(y=>cross(x,y))),...ea.map(e=>cross(na,e)),...eb.map(e=>cross(nb,e))];for(const axis of axes){const length=Math.hypot(...axis);if(length<1e-12)continue;const pa=a.vs.map(v=>dot(v,axis)),pb=b.vs.map(v=>dot(v,axis)),epsilon=1e-9*length;if(Math.max(...pa)<Math.min(...pb)-epsilon||Math.max(...pb)<Math.min(...pa)-epsilon)return false}return true}
function collisions(triangles,tree){let tested=0;const found=[];function visit(a,node){if(!overlaps(a,node))return;if(node.triangles){for(const b of node.triangles)if(overlaps(a,b)){tested++;if(intersects(a,b))found.push({a:{mesh:a.mesh,triangle:a.index},b:{mesh:b.mesh,triangle:b.index}})}}else{visit(a,node.left);visit(a,node.right)}}for(const a of triangles)visit(a,tree);return{tested,found}}

const {isCoastalGround}=await import("file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife-ground-contact.mjs"),grounds=await Promise.all([nativeGeometry("home-shell.glb",models),nativeGeometry("coast.glb",models)]),manifest=structuredClone(config);manifest.terrain.habitats.seaLion.path[0]=[-9.7,-6.6382,-14.8115];const runtime=await world(manifest,grounds),subjects=[],surfaces={};
for(const key of ['seaLion','seal']){
 const path=manifest.terrain.habitats[key].path,bounds={minX:Math.min(...path.map(p=>p[0]))-3,maxX:Math.max(...path.map(p=>p[0]))+3,minZ:Math.min(...path.map(p=>p[2]))-3,maxZ:Math.max(...path.map(p=>p[2]))+3},terrain=[],patch=createGroundPatch(path,3);patch.capture(grounds);
 for(const root of grounds)root.traverse(mesh=>{if(!isCoastalGround(mesh))return;const positions=mesh.geometry.attributes.position,ix=mesh.geometry.index;for(let i=0;i<(ix?.count||positions.count);i+=3){const vs=[0,1,2].map(j=>new THREE.Vector3().fromBufferAttribute(positions,ix?ix.getX(i+j):i+j).applyMatrix4(mesh.matrixWorld).toArray()),min=[0,1,2].map(k=>Math.min(...vs.map(v=>v[k]))),max=[0,1,2].map(k=>Math.max(...vs.map(v=>v[k])));if(min[0]>bounds.maxX||max[0]<bounds.minX||min[2]>bounds.maxZ||max[2]<bounds.minZ)continue;const normal=new THREE.Vector3().subVectors(new THREE.Vector3(...vs[1]),new THREE.Vector3(...vs[0])).cross(new THREE.Vector3().subVectors(new THREE.Vector3(...vs[2]),new THREE.Vector3(...vs[0]))).normalize().toArray();terrain.push({vs,min,max,centre:min.map((v,k)=>(v+max[k])/2),mesh:mesh.name,index:i/3,normal})}});
 const query=new THREE.Mesh(new THREE.BufferGeometry().setAttribute('position',new THREE.BufferAttribute(Float64Array.from(terrain.flatMap(t=>t.vs.flat())),3)),new THREE.MeshBasicMaterial({side:THREE.DoubleSide}));query.updateMatrixWorld(true);surfaces[key]={bounds,terrain,patch,tree:bvh(terrain),query};
 for(let index=0;index<3;index++){const id=key+'-'+index,meshes=[];runtime.scene.traverse(o=>{if(o.isSkinnedMesh&&o.userData.action?.id===id)meshes.push(o)});subjects.push({key,index,id,meshes,meshMap:new Map(meshes.map(m=>[m.name,m]))})}
}
const rows=[],triangle=new THREE.Triangle(),p=new THREE.Vector3(),near=new THREE.Vector3(),direction=new THREE.Vector3(),normal=new THREE.Vector3(),flat=new THREE.Vector3(),ray=new THREE.Raycaster();let stoppedEarly=false;
poseLoop:for(let time=0;time<=180;time+=.5){
 runtime.wildlife.update(time,'noon',{force:true});runtime.scene.updateMatrixWorld(true);const ev=runtime.wildlife.evidence();
 for(const subject of subjects){const {key,index,id,meshes,meshMap}=subject,{terrain,patch,tree,query}=surfaces[key],posed=skin(meshes),missing=[];let minimum=null;
  for(const sample of posed.points){p.fromArray(sample.point);const hit=patch.sample(p.x,p.z,p.y+.5);if(hit){const gap=p.y-hit.height;if(!minimum||gap<minimum.gap)minimum={gap,mesh:sample.mesh,index:sample.index,point:sample.point,support:{mesh:hit.mesh,triangle:hit.triangle,height:hit.height}};continue}
   const mesh=meshMap.get(sample.mesh),channels=Array.from({length:4},(_,k)=>({name:mesh.skeleton.bones[mesh.geometry.attributes.skinIndex.getComponent(sample.index,k)].name,weight:mesh.geometry.attributes.skinWeight.getComponent(sample.index,k)}));let closest=null,projection=null;flat.set(p.x,0,p.z);
   for(const t of terrain){triangle.a.fromArray(t.vs[0]);triangle.b.fromArray(t.vs[1]);triangle.c.fromArray(t.vs[2]);triangle.closestPointToPoint(p,near);const distance=p.distanceTo(near);if(!closest||distance<closest.distance)closest={distance,point:near.toArray(),mesh:t.mesh,triangle:t.index,normal:t.normal,pointNormalDot:direction.subVectors(p,near).dot(normal.fromArray(t.normal))};triangle.a.y=triangle.b.y=triangle.c.y=0;triangle.closestPointToPoint(flat,near);const projectedDistance=flat.distanceTo(near);if(!projection||projectedDistance<projection.distance)projection={distance:projectedDistance,point:near.toArray(),mesh:t.mesh,triangle:t.index,normal:t.normal}}
   ray.set(direction.copy(p).add(new THREE.Vector3(0,2,0)),new THREE.Vector3(0,-1,0));ray.far=4;const hits=ray.intersectObject(query,false).map(h=>({point:h.point.toArray(),mesh:terrain[h.faceIndex].mesh,triangle:terrain[h.faceIndex].index,normal:terrain[h.faceIndex].normal}));
   missing.push({...sample,channels,closestFullTerrain:closest,closestProjectedTerrain:projection,fullTerrainVerticalIntersections:hits});
  }
  const collision=collisions(posed.triangles,tree),contact=ev.contacts.filter(r=>r.habitat===key)[index].surfaceContact;
  rows.push({time,id,state:ev.contacts.filter(r=>r.habitat===key)[index].state,vertices:posed.points.length,skinTriangles:posed.triangles.length,minimumAmongProjectedHits:minimum,missingProjectionVertices:missing,fullTerrainTriangleCandidatePairs:collision.tested,fullTerrainSkinIntersections:collision.found,contactFit:contact});
  if(collision.found.length&&process.argv.includes('--fail-fast')){stoppedEarly=true;break poseLoop}
 }
}
const result={scope:'Exact delivered deformed animal skin vs all classified solid terrain triangles, including side and underside faces. Independent upward projections retain every missing mesh/vertex and full all-face nearest/ray custody. A mapped minimum is not complete skin coverage. No terrain welding or invented support.',point:manifest.terrain.habitats.seaLion.path[0],stoppedEarly,terrain:Object.fromEntries(Object.entries(surfaces).map(([k,s])=>[k,{bounds:s.bounds,triangles:s.terrain}])),rows};
for(const s of Object.values(surfaces)){s.query.geometry.dispose();s.query.material.dispose()}
fs.writeFileSync(new URL('./pinniped-full-terrain-transfer.json',import.meta.url),JSON.stringify(result,null,2));const misses=rows.flatMap(r=>r.missingProjectionVertices.map(v=>({id:r.id,time:r.time,...v}))),bad=rows.filter(r=>r.fullTerrainSkinIntersections.length);
console.log(JSON.stringify({rows:rows.length,stoppedEarly,totalVertices:rows.reduce((n,r)=>n+r.vertices,0),rowsWithMissing:rows.filter(r=>r.missingProjectionVertices.length).length,missingVertices:misses.length,maximumMissing:Math.max(...rows.map(r=>r.missingProjectionVertices.length)),minimumAmongMappedHits:Math.min(...rows.map(r=>r.minimumAmongProjectedHits.gap)),collisionRows:bad.length,intersections:bad.reduce((n,r)=>n+r.fullTerrainSkinIntersections.length,0),firstCollision:bad[0]&&{id:bad[0].id,time:bad[0].time,pairs:bad[0].fullTerrainSkinIntersections.slice(0,10)},minimumMissingSurfaceDistance:Math.min(...misses.map(r=>r.closestFullTerrain.distance)),minimumMissingOutwardDot:Math.min(...misses.map(r=>r.closestFullTerrain.pointNormalDot)),negativeMissingDots:misses.filter(r=>r.closestFullTerrain.pointNormalDot<0).length}));
