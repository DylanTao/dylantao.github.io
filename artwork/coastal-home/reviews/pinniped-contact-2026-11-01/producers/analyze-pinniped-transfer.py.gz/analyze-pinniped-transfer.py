from pathlib import Path
import hashlib
import json
import subprocess

q = Path(__file__).parent
root = q.parents[2]
source = "b6b2946296f23c8d3e78b281d4914552205f1b1b"
read = lambda name: json.loads((q / name).read_text())
candidate = read("pinniped-dense-transfer-candidate.json")
reference = read("pinniped-dense-transfer-reference.json")
baseline = read("pinniped-dense-final-baseline.json")
temporal = read("pinniped-temporal-transfer-v2.json")
fields = ["time", "id", "state", "rootPosition", "rootQuaternion", "total", "missing", "minimum", "byPart", "worldVerticesSha256"]
assert len(candidate["rows"]) == len(reference["rows"]) == 2166
assert all(a[k] == b[k] for a, b in zip(candidate["rows"], reference["rows"]) for k in fields)
assert candidate["otherRows"] == baseline["otherRows"]
assert all(r["count"] == 22 for r in candidate["otherRows"])
rows = candidate["rows"]
fins = [f for r in rows for f in r["surfaceContact"]["flippers"]]
reasons = [{"id": r["id"], "time": r["time"], "flipper": f["name"], "reason": f["reason"]} for r in rows for f in r["surfaceContact"]["flippers"] if f["reason"]]
assert not reasons, reasons[:10]
summary = {
    "sourceCommit": source,
    "scope": "Finite actual delivered skin qualification on frozen accepted terrain. Mapped upward hits are not whole-skin support coverage. Event trajectories are numeric active-time samples, not browser FPS.",
    "dense": {
        "poses": len(rows),
        "vertices": sum(r["total"] for r in rows),
        "states": sorted({r["state"] for r in rows}),
        "allWorldSkinHashesAndRootMeasurementsExactAgainstBothFlatFaceQueries": True,
        "other22AnimalSkeletonMatricesExactAgainstAccepted984Times": len(candidate["otherRows"]),
        "minimumAmongMappedHits": min(r["minimum"]["gap"] for r in rows),
        "maximumMappedMinimum": max(r["minimum"]["gap"] for r in rows),
        "maximumPhysicalContactGapAboveIntentionalLift": max(min(r["minimum"]["gap"], r["surfaceContact"]["gravitySeating"]["afterGap"]) - r["surfaceContact"]["gravitySeating"]["targetGap"] + .00065 for r in rows),
        "minimumSignedRootCorrection": min(r["surfaceContact"]["rootCorrection"] for r in rows),
        "maximumSignedRootCorrection": max(r["surfaceContact"]["rootCorrection"] for r in rows),
        "maximumJointCorrectionRadians": max(f["rotation"] for f in fins),
        "maximumMeasuredGravityLowering": max(r["surfaceContact"]["gravitySeating"]["lowering"] for r in rows),
        "seaLion0MaximumAddedLift": max(r["surfaceContact"]["bodyLiftCorrection"] for r in rows if r["id"] == "seaLion-0"),
        "plantedQueryMissingVertices": sum(r["surfaceContact"]["plantedContactQueryCoverage"]["missing"] for r in rows),
        "unresolvedContactConstraints": sum(not r["surfaceContact"]["contactFitResolved"] for r in rows),
        "solverReasons": reasons,
    },
    "temporal": {
        "events": len(temporal["rows"]),
        "uniqueFullSkinPoses": len(temporal["poses"]),
        "maximumTwentyMicrosecondSkinMotionM": max(r["microstep"]["maximumVertexMotionM"] for r in temporal["rows"]),
        "maximumOneSidedVelocityDifferenceMps": max(r["velocity"]["maximumOneSidedDifferenceMps"] for r in temporal["rows"]),
        "unresolvedMicrosteps": sum(not all(r["microstep"]["supported"]) for r in temporal["rows"]),
    },
}
for label, name in [("denseFullTerrain", "pinniped-full-terrain-transfer.json"), ("eventFullTerrain", "pinniped-full-terrain-transfer-event.json")]:
    data = read(name)
    assert not data["stoppedEarly"]
    missing = [v for r in data["rows"] for v in r["missingProjectionVertices"]]
    intersections = sum(len(r["fullTerrainSkinIntersections"]) for r in data["rows"])
    assert intersections == 0
    summary[label] = {
        "rows": len(data["rows"]), "vertices": sum(r["vertices"] for r in data["rows"]),
        "rowsWithMissing": sum(bool(r["missingProjectionVertices"]) for r in data["rows"]),
        "missingVertices": len(missing), "maximumMissing": max(len(r["missingProjectionVertices"]) for r in data["rows"]),
        "fullTerrainTriangleIntersections": intersections,
        "minimumAmongMappedHits": min(r["minimumAmongProjectedHits"]["gap"] for r in data["rows"]),
        "minimumMissing3dSurfaceDistance": min(v["closestFullTerrain"]["distance"] for v in missing),
        "minimumMissingOutwardDot": min(v["closestFullTerrain"]["pointNormalDot"] for v in missing),
        "negativeMissingOutwardDots": sum(v["closestFullTerrain"]["pointNormalDot"] < 0 for v in missing),
    }
    del data, missing

gpu = read("actual-gpu-pinniped.json")
assert not gpu["errors"] and gpu["callbacksRestored"]
summary["actualGpu"] = {"draws": len(gpu["rows"]), "maximumBoneMatrixError": max(b["maximumAbsoluteError"] for r in gpu["rows"] for b in r["bones"]), "callbacksRestored": gpu["callbacksRestored"], "errors": gpu["errors"]}
colony = read("sea-lion-full-skin-separation-transfer.json")
summary["seaLion0And1Separation"] = {"poses": len(colony["rows"]), "minimumSkinVertexDistance": min(r["minimumSkinVertexDistance"] for r in colony["rows"]), "fullTriangleIntersections": sum(len(r["triangleIntersections"]) for r in colony["rows"])}
views = []
for folder, engine in [("pinniped-live-gravity-native", "chromium"), ("pinniped-live-gravity-native", "webkit"), ("pinniped-roll-live", "chromium")]:
    records = read(folder + "/" + engine + "-frames.json")
    for row in records:
        assert not row["errors"]
        assert hashlib.sha256((q / folder / row["file"]).read_bytes()).hexdigest() == row["pngSha256"]
        if row["index"] == 2 and (folder == "pinniped-roll-live" or engine == "webkit"):
            contact = row["evidence"]["ecology"]["wildlife"]["contacts"][0]
            assert contact["state"] == "roll" and contact["surfaceContact"]["gravitySeating"]["lowering"] > .015
    views.append({"folder": folder, "engine": engine, "rows": len(records), "pngs": len(records), "errors": 0})
summary["publicViews"] = views
summary["benchmark"] = read("pinniped-gravity-native-benchmark/PAIRED-CONTROLS.json")
summary["finalRegisteredBrowserRun"] = "Not claimed: the pre-gravity four-width paws/gull run was interrupted when the hovering roll was found. Coordinator owns the final integrated scene groups and full gates."
owned = ["assets/js/home-scene/" + n for n in ["wildlife.mjs", "wildlife-motion.mjs", "wildlife-ground-contact.mjs", "wildlife-resting-contact.mjs"]] + ["test/wildlife-resting-contact.test.mjs", "test/wildlife-ground-bounds.test.mjs"]
summary["sourceBindings"] = [{"path": name, "gitBlobSha256": hashlib.sha256(subprocess.check_output(["git", "show", source + ":" + name], cwd=root)).hexdigest(), "workingTreeRawSha256": hashlib.sha256((root / name).read_bytes()).hexdigest()} for name in owned]
(q / "pinniped-transfer-analysis.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({k: v for k, v in summary.items() if k not in ["benchmark", "sourceBindings"]}, indent=2))
