from pathlib import Path
import json,sys,unittest
root=Path.cwd()
suite=unittest.defaultTestLoader.discover("test",pattern="test_*.py")
module=sys.modules["test_resting_review_custody"]
original=module.REVIEWS
module.REVIEWS=Path("\\\\?\\"+str(original.resolve()))
print("Invocation-only Windows long-path custody root:",module.REVIEWS)
result=unittest.TextTestRunner(verbosity=2).run(suite)
Path(".jekyll-cache/visual-qa/coastal-research-harness-20261101/path-qualified-result.json").write_text(json.dumps({"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped),"custody_root":str(module.REVIEWS),"assertion_changes":False},indent=2))
raise SystemExit(0 if result.wasSuccessful() else 1)
