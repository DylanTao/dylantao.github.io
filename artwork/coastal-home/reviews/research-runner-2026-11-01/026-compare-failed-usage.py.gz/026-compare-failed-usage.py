from pathlib import Path
import gzip,hashlib,importlib.util,json,shutil,sys,types
from unittest.mock import patch
root=Path.cwd();q=root/".jekyll-cache/visual-qa/coastal-research-harness-20261101";out=q/"failed-usage-controls-v2";out.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location("research_tests",root/"test/test_coastal_research.py");tests=importlib.util.module_from_spec(spec);spec.loader.exec_module(tests)
raw=gzip.decompress((q/"before-gated-launcher/bin_coastal_research.py.gz").read_bytes());old=types.ModuleType("retained_v1");retained=q/"rejected-v1-retained.py";retained.write_bytes(raw);old.__file__=str(retained);exec(compile(raw,old.__file__,"exec"),old.__dict__)
current=tests.RESEARCH;rows=[]
for label,module in [("retained-v1",old),("gated-usage-candidate",current)]:
 for mode in ["exit-with-usage","sleep-with-usage","turn-failed-with-usage","invalid-jsonl-with-usage"]:
  with patch.object(tests,"RESEARCH",module):
   case=tests.CoastalResearchTests();case.setUp()
   try:
    directory,receipt=case.run_fixture(mode,max_seconds=2)
    target=out/label/mode;target.mkdir(parents=True)
    for name in ["receipt.json","iteration-01-stdout.jsonl","iteration-01-stderr.log"]:shutil.copyfile(directory/name,target/name)
    row=receipt["iterations"][0]
    rows.append({"label":label,"mode":mode,"status":receipt["status"],"usage_as_reported":row.get("usage_as_reported"),"usage_events":row.get("events",{}).get("usage_events"),"source_sha256":hashlib.sha256(raw if module is old else (root/"bin/coastal_research.py").read_bytes()).hexdigest()})
   finally:case.tearDown()
summary={"qualification":"Synthetic CLI events only. No model execution/token spend. Retained V1 raw CLI usage must remain visible even though its receipt omitted it.","results":rows}
(out/"SUMMARY.json").write_text(json.dumps(summary,indent=2),encoding="utf8")
assert all(r["status"]=="guarded-failure" for r in rows)
assert all(r["usage_as_reported"] is None for r in rows if r["label"]=="retained-v1")
assert all(r["usage_as_reported"]==[{"input_tokens":11,"cached_input_tokens":3,"output_tokens":5}] for r in rows if r["label"]=="gated-usage-candidate")
files=[{"path":p.relative_to(out).as_posix(),"bytes":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob("*")) if p.is_file()]
(out/"MANIFEST.json").write_text(json.dumps({"files":files},indent=2),encoding="utf8")
print("All8 failed/timeout usage controls retained; candidate preserves exactly the reported11/3/5 fixture counts.")
