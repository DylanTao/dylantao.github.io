from pathlib import Path
import gzip,hashlib,importlib.util,json,os,sys,tempfile,time,types
from unittest.mock import patch
root=Path.cwd();q=root/".jekyll-cache/visual-qa/coastal-research-harness-20261101"
spec=importlib.util.spec_from_file_location("research_tests",root/"test/test_coastal_research.py");tests=importlib.util.module_from_spec(spec);spec.loader.exec_module(tests)
old_source=gzip.decompress((q/"before-gated-launcher/bin_coastal_research.py.gz").read_bytes())
old=types.ModuleType("rejected_pre_gate");old.__file__=str(q/"before-gated-launcher/retained.py");exec(compile(old_source,old.__file__,"exec"),old.__dict__)
results=[]
with tempfile.TemporaryDirectory(prefix="coastal-gate-control-") as temporary:
 base=Path(temporary).resolve();assert base.parent==Path(tempfile.gettempdir()).resolve()
 fake=base/"fake_cli.py";fake.write_text(tests.FAKE_CLI,encoding="utf8")
 for label,module in [("retained-v1-race",old),("stdin-gated-candidate",tests.RESEARCH)]:
  marker=base/(label+"-marker");spawned=Path(str(marker)+"-spawned");observed=[]
  original=module.WindowsJob.assign
  def delayed(job,child):
   time.sleep(0.4);observed.append(spawned.exists());return original(job,child)
  with patch.object(module.WindowsJob,"assign",delayed):
   process=module.process([sys.executable,str(fake),"early-child:"+str(marker)],"fixture",base,base/(label+"-stdout"),base/(label+"-stderr"),3)
  time.sleep(1.15)
  results.append({"label":label,"source_sha256":hashlib.sha256(old_source if module is old else (root/"bin/coastal_research.py").read_bytes()).hexdigest(),"spawned_before_assignment":observed,"child_was_created":spawned.exists(),"escaped_child_wrote_after_parent_exit":marker.exists(),"process":process,"qualification":"synthetic immediate child, delayed Job assignment, no model execution"})
receipt={"platform":sys.platform,"results":results,"control_expectation":"V1 escape true; candidate preassignment spawn and escape both false; actual child creation true in both"}
(q/"immediate-child-control.json").write_text(json.dumps(receipt,indent=2),encoding="utf8")
assert results[0]["escaped_child_wrote_after_parent_exit"] and not results[1]["escaped_child_wrote_after_parent_exit"] and results[0]["spawned_before_assignment"]==[True] and results[1]["spawned_before_assignment"]==[False] and all(x["child_was_created"] for x in results)
print(json.dumps(receipt,indent=2))
