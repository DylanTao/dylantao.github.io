"""Independent saved-source scope and outside-field control for the F6 candidate."""
import bpy,bmesh,hashlib,json,sys,math
import numpy as np
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'bin'))
from audit_coastal_export_geometry import compare
import audit_coastal_export_geometry as _kernel
import importlib.util
_spec=importlib.util.spec_from_file_location('stable_native_fields',ROOT/'.jekyll-cache/visual-qa/f6-native-20261029/native_triangle_fields-v1.py');_stable=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_stable)
_kernel.weights=_stable.field_weights;_kernel.triangle_distance=_stable.triangle_distance

from audit_coastal_architecture_finish import triangle_distance
from mathutils import Vector
from mathutils.bvhtree import BVHTree
q=ROOT/'.jekyll-cache/visual-qa/f6-native-20261029'
args={a[2:].split('=',1)[0]:a.split('=',1)[1] for a in sys.argv if a.startswith('--') and '=' in a}
variant=args.get('variant','candidate-v27')
BOXES=[([-33,0,-.26],[36,30,25]),([-33,-3.42,6.2],[36,1.14,24.2]),([-13.5,-8.73,6.2],[-8.,0.,14.]),([-12.72,.2,-1.25],[-10.4,11.,.7]),([-3.5,3.85,-1.5],[3.5,5.3,-.2]),([1.15,3.85,-2.55],[3.48,5.3,-1.5]),([-3.48,3.85,-2.55],[-2.25,5.3,-1.5])]
BOXES=[([float(np.float32(v)) for v in lo],[float(np.float32(v)) for v in hi]) for lo,hi in BOXES]
BASE_BOXES=BOXES.copy()
EXTRA_CORE_BOX=([float(np.float32(v)) for v in [-15.2,-8.73,5.0]],[float(np.float32(v)) for v in [-12.7,0.,14.]])
NAMES={'core__golden coastal sandstone','core_estate_library_liftaway_roof','core_retreat_liftaway_roof','core_bathwing_liftaway_roof','core_liftaway_cave_ceiling'}
OWNERS=json.loads((ROOT/'artwork/coastal-home/reviews/terrain-f6-2026-10-29/plant-ownership.json').read_text(encoding='utf-8'))
ALLOWED=NAMES|{'core__golden coastal sandstone','core_estate_library_liftaway_roof','core_retreat_liftaway_roof','core_liftaway_cave_ceiling'}|set(OWNERS['ordinaryOwnerArrays'])|set(OWNERS['groundcoverOwnerArrays'])|{'core_flora_daisy_leaves','core_flora_daisy_flowers'}

def array(col,prop,width,dtype):
 a=np.empty(len(col)*width,dtype=dtype);col.foreach_get(prop,a);return a.tobytes()
def mesh_hash(m):
 h=hashlib.sha256()
 for col,prop,w,d in [(m.vertices,'co',3,np.float32),(m.edges,'vertices',2,np.int32),(m.loops,'vertex_index',1,np.int32),(m.polygons,'loop_start',1,np.int32),(m.polygons,'loop_total',1,np.int32),(m.polygons,'material_index',1,np.int32),(m.polygons,'use_smooth',1,np.bool_),(m.corner_normals,'vector',3,np.float32)]:h.update(array(col,prop,w,d))
 for a in m.attributes:
  h.update((a.name+a.domain+a.data_type).encode())
  if a.data_type in ['FLOAT','INT','BOOLEAN']:h.update(array(a.data,'value',1,np.float32 if a.data_type=='FLOAT' else np.int32))
  elif a.data_type=='FLOAT_VECTOR':h.update(array(a.data,'vector',3,np.float32))
  elif a.data_type in ['FLOAT_COLOR','BYTE_COLOR']:h.update(array(a.data,'color',4,np.float32))
  elif a.data_type=='FLOAT2':h.update(array(a.data,'vector',2,np.float32))
  elif a.data_type=='INT32_2D':h.update(array(a.data,'value',2,np.int32))
  else:h.update(str([tuple(v.value) if hasattr(v,'value') and not isinstance(v.value,(float,int,bool)) else str(v) for v in a.data]).encode())
 h.update(str([x.name if x else None for x in m.materials]).encode());h.update(str(getattr(m.color_attributes.active_color,'name',None)).encode())
 return h.hexdigest()
def props(o):return json.dumps({'matrix':[list(v) for v in o.matrix_world],'parent':o.parent.name if o.parent else None,'data':o.data.name if o.data else None,'properties':dict(o.items()),'hideRender':o.hide_render,'hideViewport':o.hide_viewport},sort_keys=True,default=str)
def snapshot(path):
 bpy.ops.wm.open_mainfile(filepath=str(path))
 result={'objects':{},'targets':{},'materials':{}}
 for o in bpy.context.scene.objects:
  result['objects'][o.name]={'type':o.type,'props':props(o),'mesh':mesh_hash(o.data) if o.type=='MESH' else None}
  if o.name not in NAMES:continue
  m=o.data;m.calc_loop_triangles();pts=[tuple(o.matrix_world@v.co) for v in m.vertices];ns=[tuple(v.vector) for v in m.corner_normals];a=m.color_attributes.active_color
  colors=[tuple(v.color) for v in a.data] if a else None
  fs=[]
  for t in m.loop_triangles:
   fs.append({'s':int(m.attributes['F6 source triangle'].data[t.polygon_index].value) if m.attributes.get('F6 source triangle') else t.index+1,'p':[pts[i] for i in t.vertices],'n':[ns[i] for i in t.loops],'c':[(colors[j] if a.domain=='CORNER' else colors[i]) if colors else (1.,1.,1.,1.) for i,j in zip(t.vertices,t.loops)],'m':m.materials[t.material_index].name})
  bm=bmesh.new();bm.from_mesh(m);nonmanifold=sum(not e.is_manifold for e in bm.edges);bm.free()
  result['targets'][o.name]={'triangles':fs,'nonmanifold':nonmanifold,'activeColor':getattr(a,'name',None)}
 for m in bpy.data.materials:
  result['materials'][m.name]={'diffuse':list(m.diffuse_color),'roughness':m.roughness,'metallic':m.metallic,'nodes':[(n.name,n.bl_idname,[(s.name,list(s.default_value) if hasattr(s.default_value,'__len__') and not isinstance(s.default_value,str) else str(s.default_value)) for s in n.inputs if hasattr(s,'default_value')]) for n in m.node_tree.nodes] if m.use_nodes else None,'links':[(l.from_node.name,l.from_socket.name,l.to_node.name,l.to_socket.name) for l in m.node_tree.links] if m.use_nodes else None}
 return result
def mix(a,b,t):return {k:tuple(a[k][i]*(1-t)+b[k][i]*t for i in range(len(a[k]))) for k in ['p','n','c']}
def clip(poly,axis,value,sign):
 out=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  da=(a['p'][axis]-value)*sign;db=(b['p'][axis]-value)*sign
  if da>=0:out.append(a)
  if (da<0)!=(db<0):out.append(mix(a,b,da/(da-db)))
 return out
def subtract_box(poly,lo,hi):
 pieces=[]
 for axis,value,sign in [(k,lo[k],1) for k in range(3)]+[(k,hi[k],-1) for k in range(3)]:
  if not poly:break
  outer=clip(poly,axis,value,-sign)
  if len(outer)>=3 and not all(abs(p['p'][axis]-value)<1e-10 for p in outer):pieces.append(outer)
  poly=clip(poly,axis,value,sign)
 return pieces

def outside(snapshot):
 result=[]
 for f in snapshot['triangles']:
  pieces=[[{k:f[k][i] for k in ['p','n','c']} for i in range(3)]]
  for lo,hi in BOXES:
   pieces=[part for poly in pieces for part in subtract_box(poly,lo,hi)]
  for piece in pieces:
   for i in range(1,len(piece)-1):
    tri=[piece[0],piece[i],piece[i+1]]
    a,b,c=[np.array(p['p']) for p in tri]
    if np.linalg.norm(np.cross(b-a,c-a))<1e-12:continue
    result.append({**{k:[p[k] for p in tri] for k in ['p','n','c']},'m':f['m']})
 return {'triangles':result}


from collections import Counter
variant=args.get('variant','candidate-v300')
start_name=args.get('baseline','intake/source')
before_path=q/(start_name+'.blend');after_path=q/(variant+'.blend')
before=snapshot(before_path);after=snapshot(after_path)
SCOPE={
 'core__golden coastal sandstone':[([4.92,-3.33,4.2],[12.11,6.40,9.6]),([4.4,-3.33,6.8],[4.92,2.4,9.6])],
 'core_liftaway_cave_ceiling':[([4.92,-3.33,4.2],[float(np.float32(5.65)),-.8278,8.2]),([4.4,-3.33,6.8],[4.92,-.8278,8.2])],
 'core_retreat_liftaway_roof':[([4.92,-3.33,5.8],[11.25,-.8458,9.6]),([4.4,-3.33,6.8],[4.92,-.8458,9.6])],
}
EXTRA=SCOPE
new_upper=([-15.2,-12.5,float(np.float32(6.8))],[-6.9,0.,14.])
bath_front=([-8.3999,-3.25,5.35],[-4.7547,-.8278,9.51])
bath_full_upper=([-8.3999,-6.45,float(np.float32(6.8))],[-4.7547,.474,9.51])
bath_extra=([-8.6,-6.45,float(np.float32(6.8))],[-6.9,.474,10.])
SCOPE={name:list(BASE_BOXES)+[new_upper] for name in NAMES}
SCOPE['core__golden coastal sandstone']+=[([-15.2,-8.73,6.2],[-12.7,0.,14.])]
SCOPE['core_bathwing_liftaway_roof']+=[bath_front,bath_full_upper,bath_extra]
SCOPE['core_liftaway_cave_ceiling']=[([-5.65,-2.85,5.8],[float(np.float32(5.65)),-.8278,8.2])]
for name,boxes in EXTRA.items():SCOPE[name]+=boxes
forelip=([-12.81,-.60,5.77],[-6.91,.00001,7.80]);tip=([-7.489,.00001,6.931],[-7.370,.0063,7.049])
for name in ['core__golden coastal sandstone','core_bathwing_liftaway_roof','core_estate_library_liftaway_roof']:SCOPE[name]+=[forelip]
SCOPE['core_bathwing_liftaway_roof']+=[tip]
SCOPE['core_estate_library_liftaway_roof']+=[([-12.81,.00001,5.77],[-6.91,.04,7.80])]
def key(f):
 corners=tuple((tuple(f['p'][i]),tuple(f['n'][i]),tuple(f['c'][i])) for i in range(3))
 return f['m'],min(corners[i:]+corners[:i] for i in range(3))
def minus_exact(a,b):
 remain=Counter(key(f) for f in b['triangles']);out=[];same=0
 for f in a['triangles']:
  k=key(f)
  if remain[k]:remain[k]-=1;same+=1
  else:out.append(f)
 return {'triangles':out},same
changed=[n for n in before['objects'] if before['objects'][n]!=after['objects'].get(n)]
r={'baseline':start_name,'baselineSha256':hashlib.sha256(before_path.read_bytes()).hexdigest(),'candidate':variant,'candidateSha256':hashlib.sha256(after_path.read_bytes()).hexdigest(),'scope':SCOPE,'changedObjects':changed,'unrelatedExact':all(before['objects'][n]==after['objects'].get(n) for n in before['objects'] if n not in ALLOWED),'objectRosterExact':set(before['objects'])==set(after['objects']),'materialsExact':before['materials']==after['materials'],'targets':{},'method':'Every actual outside part of every triangle in both directions. First subtract identical oriented field triangles by multiplicity; compare all remaining outside surface corners, edge midpoints and centroids to the complete opposite native surface using independently calibrated stable distance and affine-field weights. Source IDs do not exclude any face, including genuine sourceID0 reconstruction.'}
for name in sorted(NAMES):
 BOXES=SCOPE[name];a,b=before['targets'][name],after['targets'][name]
 aa,identical_f=minus_exact(outside(a),outside(b));bb,identical_r=minus_exact(outside(b),outside(a))
 f=compare(aa,b) if aa['triangles'] else {'failureCount':0};rev=compare(bb,a) if bb['triangles'] else {'failureCount':0}
 row={'outsideExactSourceTriangles':identical_f,'outsideExactCandidateTriangles':identical_r,'sourceToCandidate':f,'candidateToSource':rev,'nativeClosedEdges':[a['nonmanifold'],b['nonmanifold']],'rgbPresenceExact':(a['activeColor'] is None)==(b['activeColor'] is None)}
 row['passed']=not f['failureCount'] and not rev['failureCount'] and row['nativeClosedEdges']==[0,0] and row['rgbPresenceExact'];r['targets'][name]=row
 print('INCREMENT_OUTSIDE',name,row['passed'],f['failureCount'],rev['failureCount'],flush=True)
 (q/(variant+'-full-original-mineral-field-audit.json')).write_text(json.dumps(r,indent=2))
# Strong original lower-negativeY controls retain the historical untouched lower
# bands, excluding only the actual bath front and approved outer-left volumes.
r['genuineProtectedLowerNegativeY']={}
for name in sorted(NAMES):
 def lower(snap):
  result=[]
  floor=5.8 if name=='core_liftaway_cave_ceiling' else float(np.float32(6.8))
  for f in snap['triangles']:
   poly=[{k:f[k][i] for k in ['p','n','c']} for i in range(3)]
   poly=clip(clip(poly,1,0.,-1),2,floor,-1);parts=[poly]
   exceptions=([bath_front] if name=='core_bathwing_liftaway_roof' else [])+EXTRA.get(name,[])[:1]+([forelip] if name in ['core__golden coastal sandstone','core_bathwing_liftaway_roof','core_estate_library_liftaway_roof'] else [])+([tip] if name=='core_bathwing_liftaway_roof' else [])
   for lo,hi in exceptions:parts=[v for p in parts for v in subtract_box(p,lo,hi)]
   for p in parts:
    for i in range(1,len(p)-1):
     t=[p[0],p[i],p[i+1]]
     if np.linalg.norm(np.cross(np.asarray(t[1]['p'])-t[0]['p'],np.asarray(t[2]['p'])-t[0]['p']))>1e-20:result.append({**{k:[v[k] for v in t] for k in ['p','n','c']},'m':f['m']})
  return {'triangles':result}
 a,b=before['targets'][name],after['targets'][name];aa,same=minus_exact(lower(a),lower(b));bb,_=minus_exact(lower(b),lower(a));f=compare(aa,b) if aa['triangles'] else {'failureCount':0};rev=compare(bb,a) if bb['triangles'] else {'failureCount':0};r['genuineProtectedLowerNegativeY'][name]={'sourceToCandidate':f,'candidateToSource':rev,'exactTriangles':same,'passed':not f['failureCount'] and not rev['failureCount']};print('DIRECT_ORIGINAL_PROTECTED_LOWER',name,f['failureCount'],rev['failureCount'],flush=True)
r['passed']=all(row['passed'] for row in r['genuineProtectedLowerNegativeY'].values()) and r['unrelatedExact'] and r['objectRosterExact'] and r['materialsExact'] and all(row['passed'] for row in r['targets'].values())
(q/(variant+'-full-original-mineral-field-audit.json')).write_text(json.dumps(r,indent=2));assert r['passed'],'Increment outside/native optical custody failed under unchanged limits'
