﻿"""Corrected strict genuine-area controls, with zero ports explicitly separate."""
import bpy,numpy as np,json,hashlib,sys,importlib.util
from pathlib import Path
from collections import Counter
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];sys.path[:0]=[str(Q),str(ROOT/'bin')]
from exact_scope_clipping_v481 import outside_surface
from audit_coastal_f6_native_topology import qualify
from replay_coastal_f6_patch import column_hash,mesh_record,digest
spec=importlib.util.spec_from_file_location('closed_fields',Q/'native_triangle_fields-v2-closed-field.py');closed=importlib.util.module_from_spec(spec);spec.loader.exec_module(closed)
OLD=json.loads((Q/'v474-composed-r6-independent-fields.json').read_text());BASE=Path(OLD['baseline']);PREVIOUS=Path(OLD['candidate']);CAND=Path('C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/combined-side-fan-control-v1/candidate-attempt-1/candidate.blend');REPORT=Q/'v519-combined-side-fan-independent-area-fields.json';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(BASE)==OLD['baselineSha256'];assert sha(CAND)=='156b915b4754e6ce644e1a3c8fede8bc04c8ad1c7041c0d624b7c3d76d15260d';assert sha(Q/'native_triangle_fields-v2-closed-field.py')=='f52bbcb90b29b589541c3022c9242d91cb97ef223525c0288bdc9b160e9b1587';assert json.loads((Q/'v479-closed-field-oracle-calibration.json').read_text())['passed']
names=set(OLD['targets']);geo={'core__golden coastal sandstone','core_liftaway_cave_ceiling','core_estate_library_liftaway_roof','core_retreat_liftaway_roof','core_bathwing_liftaway_roof'}
scopes={n:[] for n in names}
TOOLS=json.loads((Q/'v518-realized-combined-side-fan-tools.json').read_text());assert TOOLS['passed'];assert TOOLS['candidateSha256']=='156b915b4754e6ce644e1a3c8fede8bc04c8ad1c7041c0d624b7c3d76d15260d'
for n,v in TOOLS['owners'].items():scopes[n]=v['exactNativeAxisCellDecomposition']

def geometry(m):
 arrays=[(m.vertices,'co',3,np.float32),(m.edges,'vertices',2,np.int32),(m.loops,'vertex_index',1,np.int32),(m.loops,'edge_index',1,np.int32),(m.polygons,'loop_start',1,np.int32),(m.polygons,'loop_total',1,np.int32),(m.polygons,'material_index',1,np.int32),(m.polygons,'use_smooth',1,np.bool_)];return [column_hash(*args) for args in arrays]
bpy.ops.wm.open_mainfile(filepath=str(PREVIOUS));previous_geometry={n:geometry(bpy.data.objects[n].data) for n in names}
helper=Q/'audit-v416-full-original-library-union.py';ns={};exec(compile(helper.read_text().split('from collections import Counter')[0],str(helper)+' [read-only snapshot definitions]','exec'),ns);ns['NAMES']=names;ns['_kernel'].weights=closed.field_weights;ns['_kernel'].triangle_distance=closed.triangle_distance;before=ns['snapshot'](BASE);after=ns['snapshot'](CAND);same_geometry={n:geometry(bpy.data.objects[n].data)==previous_geometry[n] for n in names}
florapack=json.loads((Q/'guarded-v454-flora-patch/manifest.json').read_text());flora=(set(florapack['targetOwners'])|set(florapack['declaredNewObjects']))-geo;flora_exact={n:before['objects'][n]==after['objects'].get(n) for n in flora}
def key(f):
 c=tuple((tuple(f['p'][i]),tuple(f['n'][i]),tuple(f['c'][i])) for i in range(3));return f['m'],min(c[i:]+c[:i] for i in range(3))
def minus(a,b):
 counts=Counter(key(f) for f in b['triangles']);out=[];same=0
 for f in a['triangles']:
  k=key(f)
  if counts[k]:counts[k]-=1;same+=1
  else:out.append(f)
 return {'triangles':out},same
def genuine(s):return {'triangles':[f for f in s['triangles'] if not closed.exact_zero_triangle(f['p'])]}
def compare(a,b):
 # The exact clipper serializes corner rows as JSON-compatible lists; the
 # unchanged comparison kernel's exact-position key requires hashable tuples.
 # Convert representation only; no numeric value/field/geometry is changed.
 def rows(surface):
  return {**surface,'triangles':[{**f,**{kind:[tuple(row) for row in f[kind]] for kind in ['p','n','c']}} for f in surface['triangles']]}
 return ns['compare'](rows(a),rows(b)) if a['triangles'] else {'failureCount':0}
r={'baselineSha256':sha(BASE),'candidateSha256':sha(CAND),'previousGeometryControlSha256':sha(PREVIOUS),'geometryLayoutsExactVs3d466DiagnosticOnly':same_geometry,'all52F6FloraWholeMeshesAndRolesExact':flora_exact,'surfaceToleranceM':3e-6,'splitNormalTolerance':1e-6,'linearColorTolerance':1e-7,'kernelSha256':sha(Q/'native_triangle_fields-v2-closed-field.py'),'exactScopeClipperSha256':sha(Q/'exact_scope_clipping_v481.py'),'actualPhysicalToolReceiptFrom':'v518-realized-combined-side-fan-tools.json','actualPhysicalToolReceiptSha256':sha(Q/'v518-realized-combined-side-fan-tools.json'),'method':'Exact cyclic P/N/RGB/material common triangles verified and subtracted BEFORE scope clipping, full genuine-area target retained. Exact binary-Fraction original barycentric clipping, no area epsilon; exact-rational original zero charts excluded from undefined2D field inference ONLY with their separate port gate still OPEN. Qualified Euclidean closest closed-triangle field weights; no affine extrapolation or clip-normalize. Every genuine remaining outside triangle in both directions receives all7 whole-surface probes. Self-controls mandatory.','targets':{},'protectedLower':{},'areaFieldsPassed':False,'zeroPortGate':'OPEN: six original rational-zero charts346/362/365/366/379/382 require separate directed continuous field/port/multiplicity qualification against the ACTUAL smaller tools. No old geometry receipt or corner-presence waiver.','passed':False}
for name in sorted(names):
 a,b=before['targets'][name],after['targets'][name];af,same=minus(a,b);bf,_=minus(b,a);a_ref,b_ref=genuine(a),genuine(b);ao=outside_surface(af,scopes[name]);bo=outside_surface(bf,scopes[name]);selfa=compare(ao,a_ref);selfb=compare(bo,b_ref);f=compare(ao,b_ref);rev=compare(bo,a_ref);mats=all(before['materials'][mat]==after['materials'].get(mat) for mat in {t['m'] for t in a['triangles']});row={'exactCompleteTriangleMultiplicity':same,'querySourcePieces':len(ao['triangles']),'queryCandidatePieces':len(bo['triangles']),'sourceExactZeroNovelChartCount':len(ao['exactZeroSourceIndices']),'candidateExactZeroNovelChartCount':len(bo['exactZeroSourceIndices']),'selfSource':selfa,'selfCandidate':selfb,'sourceToCandidate':f,'candidateToSource':rev,'usedMaterialDefinitionsExact':mats,'passed':not any(d['failureCount'] for d in [selfa,selfb,f,rev]) and mats};r['targets'][name]=row;REPORT.write_text(json.dumps(r,indent=2));print('CLOSED_EXACT_AREA_FIELDS',name,row['passed'],'self',selfa['failureCount'],selfb['failureCount'],'cross',f['failureCount'],rev['failureCount'],flush=True)
 if name in geo:
  floor=5.8 if name=='core_liftaway_cave_ceiling' else float(np.float32(6.8));al=outside_surface(af,scopes[name],[(1,0.,-1),(2,floor,-1)]);bl=outside_surface(bf,scopes[name],[(1,0.,-1),(2,floor,-1)]);lf=compare(al,b_ref);lr=compare(bl,a_ref);r['protectedLower'][name]={'sourceToCandidate':lf,'candidateToSource':lr,'passed':not lf['failureCount'] and not lr['failureCount']};REPORT.write_text(json.dumps(r,indent=2));print('CLOSED_EXACT_LOWER',name,lf['failureCount'],lr['failureCount'],flush=True)
bpy.ops.wm.open_mainfile(filepath=str(CAND));r['savedDirectedTopology']={n:qualify(bpy.data.objects[n].data) for n in geo|{n for n,v in scopes.items() if v}};r['areaFieldsPassed']=all(flora_exact.values()) and all(v['passed'] for v in r['targets'].values()) and all(v['passed'] for v in r['protectedLower'].values()) and all(v['passed'] for v in r['savedDirectedTopology'].values());r['sourceFilesUnchanged']=sha(BASE)==r['baselineSha256'] and sha(CAND)==r['candidateSha256'];REPORT.write_text(json.dumps(r,indent=2));print('CORRECTED_GENUINE_AREA_GATE',r['areaFieldsPassed'],'ZERO_PORT_GATE_OPEN',flush=True)
