"""Conservative exact continuous closed-segment field/port coverage, no area-zero inference."""
from fractions import Fraction as F
ff=lambda v:F.from_float(float(v))
vec=lambda a:tuple(ff(v) for v in a)
sub=lambda a,b:tuple(x-y for x,y in zip(a,b))
dot=lambda a,b:sum(x*y for x,y in zip(a,b))
add=lambda a,b:tuple(x+y for x,y in zip(a,b))
scale=lambda a,s:tuple(x*s for x in a)
def at(a,b,t):return add(a,scale(b,t))

def outside_intervals(edge,boxes):
 p,e=vec(edge['p'][0]),sub(vec(edge['p'][1]),vec(edge['p'][0]));ranges=[(F(0),F(1))]
 for lo,hi in boxes:
  low,high=F(0),F(1)
  for k in range(3):
   a,b=ff(lo[k]),ff(hi[k])
   if not e[k]:
    if not a<=p[k]<=b:low,high=F(1),F(0);break
   else:
    x,y=(a-p[k])/e[k],(b-p[k])/e[k];low=max(low,min(x,y));high=min(high,max(x,y))
  if low>high:continue
  out=[]
  for a,b in ranges:
   if high<=a or low>=b:out.append((a,b));continue
   if a<low:out.append((a,min(b,low)))
   if high<b:out.append((max(a,high),b))
  ranges=out
 return ranges

def norm_allowed(interval,a,b,tolerance):
 lo,hi=interval;limit=ff(tolerance)**2;q=lambda t:dot(at(a,b,t),at(a,b,t));lv,hv=q(lo),q(hi)
 if lv<=limit and hv<=limit:return lo,hi
 bb=dot(b,b)
 if not bb:return None
 minimum=max(lo,min(hi,-dot(a,b)/bb))
 if q(minimum)>limit:return None
 # Return only certified-inside rational bounds. A boundary-only irrational
 # contact may conservatively remain unproved; it can never create false cover.
 if lv>limit:
  bad,good=lo,minimum
  for _ in range(96):
   middle=(bad+good)/2
   if q(middle)<=limit:good=middle
   else:bad=middle
  lo=good
 if hv>limit:
  good,bad=minimum,hi
  for _ in range(96):
   middle=(good+bad)/2
   if q(middle)<=limit:good=middle
   else:bad=middle
  hi=good
 return (lo,hi) if lo<=hi else None

def color_allowed(interval,a,b):
 lo,hi=interval;tolerance=ff(1e-7)
 for x,y in zip(a,b):
  if not y:
   if abs(x)>tolerance:return None
  else:
   l,h=sorted(((-tolerance-x)/y,(tolerance-x)/y));lo=max(lo,l);hi=min(hi,h)
   if lo>hi:return None
 return lo,hi

def covered_intervals(source,target,interval):
 p,e=vec(source['p'][0]),sub(vec(source['p'][1]),vec(source['p'][0]));a,d=vec(target['p'][0]),sub(vec(target['p'][1]),vec(target['p'][0]));dd=dot(d,d)
 if not dd:return []
 u0,ud=dot(sub(p,a),d)/dd,dot(e,d)/dd;cuts={interval[0],interval[1]}
 if ud:
  for value in [F(0),F(1)]:
   t=(value-u0)/ud
   if interval[0]<t<interval[1]:cuts.add(t)
 cuts=sorted(cuts);result=[]
 for lo,hi in zip(cuts,cuts[1:]):
  midpoint=(lo+hi)/2;u=u0+ud*midpoint
  alpha,beta=(F(0),F(0)) if u<=0 else (F(1),F(0)) if u>=1 else (u0,ud)
  kept=(lo,hi)
  for kind,tolerance in [('p',3e-6),('n',1e-6),('c',None)]:
   source0,source1=vec(source[kind][0]),sub(vec(source[kind][1]),vec(source[kind][0]));target0,target1=vec(target[kind][0]),sub(vec(target[kind][1]),vec(target[kind][0]));error0=sub(source0,at(target0,target1,alpha));error1=sub(source1,scale(target1,beta));kept=color_allowed(kept,error0,error1) if kind=='c' else norm_allowed(kept,error0,error1,tolerance)
   if kept is None:break
  if kept is not None:result.append(kept)
 return result

def gaps(interval,ranges):
 lo,hi=interval;result=[];cursor=lo
 for a,b in sorted(ranges):
  if b<cursor or a>hi:continue
  if a>cursor:result.append((cursor,min(a,hi)))
  cursor=max(cursor,b)
  if cursor>=hi:break
 if cursor<hi:result.append((cursor,hi))
 return result

def endpoint_matches(source,t,target):
 expected={k:at(vec(source[k][0]),sub(vec(source[k][1]),vec(source[k][0])),t) for k in ['p','n','c']}
 for i in range(2):
  if dot(sub(expected['p'],vec(target['p'][i])),sub(expected['p'],vec(target['p'][i])))>ff(3e-6)**2:continue
  if dot(sub(expected['n'],vec(target['n'][i])),sub(expected['n'],vec(target['n'][i])))>ff(1e-6)**2:continue
  if any(abs(x-y)>ff(1e-7) for x,y in zip(expected['c'],vec(target['c'][i]))):continue
  return True
 return False

def qualification(packet,boxes):
 rows=[];edge_provider_sets={}
 for source in packet['sourceDirectedZeroLoops']:
  intervals=outside_intervals(source,boxes);field=[];fan=[];provider_edges=set();providers=[];neighbor_ids={i for v in source['originalIncidentLoops'] if v['loop']!=source['loop'] for i in v['incidentNativePolygonRenderIds']};source_delta=sub(vec(source['p'][1]),vec(source['p'][0]));port_ok={t:False for interval in intervals for t in interval}
  for edge in packet['targetNativeEdges']:
   for target in edge['incidences']:
    if target['material']!=source['material']:continue
    directed=dot(source_delta,sub(vec(target['p'][1]),vec(target['p'][0])))>0
    native_fan=directed and target['BreakfastSourceTriangle']==source['sourceZeroTriangle'] and len(edge['incidences'])==2 and any(v['loop']!=target['loop'] and v['BreakfastSourceTriangle'] in neighbor_ids for v in edge['incidences'])
    matched=[]
    for interval in intervals:matched.extend(covered_intervals(source,target,interval))
    field.extend(matched)
    if native_fan and matched:
     fan.extend(matched);provider_edges.add(edge['nativeEdge']);providers.append({'candidateNativeEdge':edge['nativeEdge'],'candidateLoop':target['loop'],'sourceID':target['BreakfastSourceTriangle'],'certifiedIntervals':[[str(a),str(b)] for a,b in matched]})
     for t in port_ok:
      if any(a<=t<=b for a,b in matched) and endpoint_matches(source,t,target):port_ok[t]=True
  fieldgaps=[g for interval in intervals for g in gaps(interval,field)];fangaps=[g for interval in intervals for g in gaps(interval,fan)];row={'sourceZeroTriangle':source['sourceZeroTriangle'],'sourceNativeEdge':source['nativeEdge'],'sourceLoop':source['loop'],'outsideIntervals':[[str(a),str(b)] for a,b in intervals],'continuousFieldGaps':[[str(a),str(b)] for a,b in fieldgaps],'directedNativeFanGaps':[[str(a),str(b)] for a,b in fangaps],'actualEndpointPorts':{str(t):v for t,v in port_ok.items()},'providers':providers,'continuousFieldPassed':not fieldgaps,'directedFanAndPortsPassed':not fangaps and all(port_ok.values())};rows.append(row)
  if intervals:
   edge_provider_sets[source['nativeEdge']]=edge_provider_sets.get(source['nativeEdge'],provider_edges)&provider_edges
 # An injective actual-native edge witness is required for distinct original
 # native edge identities. Original two-sided loops on ONE edge share a key.
 matched={}
 def allocate(source_id,seen):
  for target in edge_provider_sets[source_id]:
   if target in seen:continue
   seen.add(target)
   if target not in matched or allocate(matched[target],seen):matched[target]=source_id;return True
  return False
 multiplicity=all(allocate(k,set()) for k in edge_provider_sets)
 return {'rows':rows,'allContinuousDirectedLoopFieldsPassed':all(r['continuousFieldPassed'] for r in rows),'allActualDirectedFanAndEndpointPortsPassed':all(r['directedFanAndPortsPassed'] for r in rows),'distinctOriginalNativeEdgeMultiplicityPassed':multiplicity,'injectiveNativeEdgeWitness':{str(v):k for k,v in matched.items()},'passed':all(r['continuousFieldPassed'] and r['directedFanAndPortsPassed'] for r in rows) and multiplicity}
