"""Read-only actual native directed-edge/fan packet for exact continuous1D proof."""
import bpy,numpy as np,json,hashlib,sys
from pathlib import Path
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];sys.path.insert(0,str(ROOT/'bin'))
from replay_coastal_f6_patch import mesh_record,digest
BASE=Q/'combined-v463-library-flora-arrival/candidate-lit.blend';CAND=Path('C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/combined-side-fan-control-v1/candidate-attempt-1/candidate.blend');assert hashlib.sha256(BASE.read_bytes()).hexdigest()=='76acde19b2b57e46d217b075f8805977fcf14fb039e615d46f0bd7eee801f7c2';assert hashlib.sha256(CAND.read_bytes()).hexdigest()=='156b915b4754e6ce644e1a3c8fede8bc04c8ad1c7041c0d624b7c3d76d15260d';NAME='core__golden coastal sandstone';SIX={346,362,365,366,379,382}

def setup(path):
 bpy.ops.wm.open_mainfile(filepath=str(path));o=bpy.data.objects[NAME];m=o.data;m.calc_loop_triangles();points=[tuple(o.matrix_world@v.co) for v in m.vertices];normals=[tuple(v.vector) for v in m.corner_normals];a=m.color_attributes.active_color;colors=[tuple(v.color) for v in a.data] if a else None;by_edge={};poly_for_loop={};render_by_poly={}
 for t in m.loop_triangles:render_by_poly.setdefault(t.polygon_index,[]).append(t)
 for poly in m.polygons:
  for li in poly.loop_indices:by_edge.setdefault(m.loops[li].edge_index,[]).append(li);poly_for_loop[li]=poly
 def loop(li):
  poly=poly_for_loop[li];lj=poly.loop_start+(li-poly.loop_start+1)%poly.loop_total;vis=[m.loops[i].vertex_index for i in [li,lj]];ns=[normals[i] for i in [li,lj]];cs=[(colors[i] if a.domain=='CORNER' else colors[v]) if colors else (1.,1.,1.,1.) for i,v in zip([li,lj],vis)];out={'loop':li,'nextLoop':lj,'polygon':poly.index,'nativeEdge':m.loops[li].edge_index,'vertices':vis,'p':[points[v] for v in vis],'n':ns,'c':cs,'material':m.materials[poly.material_index].name,'incidentNativePolygonRenderIds':[t.index+1 for t in render_by_poly[poly.index] if li in t.loops and lj in t.loops]};a_source=m.attributes.get('Breakfast source triangle');out['BreakfastSourceTriangle']=int(a_source.data[poly.index].value) if a_source else None;return out
 return m,points,by_edge,loop,render_by_poly
m,points,by_edge,loop,render_by_poly=setup(BASE);source=[];bboxes=[]
for sid in sorted(SIX):
 tri=m.loop_triangles[sid-1];poly=m.polygons[tri.polygon_index];pp=[points[v] for v in tri.vertices];bboxes.append((np.min(pp,0),np.max(pp,0)))
 for li in poly.loop_indices:
  row=loop(li);row['sourceZeroTriangle']=sid;row['originalIncidentLoops']=[loop(i) for i in by_edge[row['nativeEdge']]];source.append(row)
source_hash=digest(mesh_record(m));m,points,by_edge,loop,render_by_poly=setup(CAND);target=[]
for ei,lis in by_edge.items():
 edge=m.edges[ei];ps=np.asarray([points[v] for v in edge.vertices]);lo=ps.min(0);hi=ps.max(0)
 if not any(np.all(hi>=a-3e-6) and np.all(lo<=b+3e-6) for a,b in bboxes):continue
 target.append({'nativeEdge':ei,'vertices':list(edge.vertices),'incidences':[loop(i) for i in lis]})
r={'baselineSha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),'candidateSha256':hashlib.sha256(CAND.read_bytes()).hexdigest(),'sourceNativeCoreFieldDigest':source_hash,'candidateNativeCoreFieldDigest':digest(mesh_record(m)),'actualToolReceipt':'v518-realized-combined-side-fan-tools.json','sourceDirectedZeroLoops':source,'targetNativeEdges':target,'status':'Read-only actual native loop.edge_index packet. Distinct parallel native edges remain distinct; no coordinate-based adjacency or nearest-area zero-field inference. Source-native source identity/fan matching and exact continuous closed-segment field coverage are separate subsequent controls.'};(Q/'v520-combined-side-fan-native-zero-port-packet.json').write_text(json.dumps(r,indent=2));print('NATIVE_ZERO_PACKET',len(source),len(target),flush=True)
