"""Stable native triangle distance/linear-field coordinates, including thin faces.

Float64 uses local plane/edge differences. Ill-conditioned input uses an exact
float-to-Decimal cross product and dominant-axis projection, independently of
the calibration oracle's Decimal Gram/KKT solve. No preservation bound changes.
"""
from decimal import Decimal, localcontext
import math
import numpy as np


def _input(point, triangle):
    p = np.asarray(point, dtype=np.float64)
    t = np.asarray(triangle, dtype=np.float64)
    u, v = t[1] - t[0], t[2] - t[0]
    n = np.cross(u, v)
    area = float(np.linalg.norm(n))
    condition = (float(u @ u) + float(v @ v)) / area if area else math.inf
    return p, t, u, v, n, condition


def _decimal(point, triangle, need_distance):
    with localcontext() as context:
        context.prec = 80
        dec = lambda x: Decimal.from_float(float(x))
        p = [dec(x) for x in point]
        t = [[dec(x) for x in row] for row in triangle]
        sub = lambda a, b: [x - y for x, y in zip(a, b)]
        dot = lambda a, b: sum(x * y for x, y in zip(a, b))
        u, v, ap = sub(t[1], t[0]), sub(t[2], t[0]), sub(p, t[0])
        n = [u[1] * v[2] - u[2] * v[1],
             u[2] * v[0] - u[0] * v[2],
             u[0] * v[1] - u[1] * v[0]]
        n2 = dot(n, n)
        weights = None
        if n2:
            height = dot(n, ap)
            projected = [ap[k] - n[k] * height / n2 for k in range(3)]
            axis = max(range(3), key=lambda k: abs(n[k]))
            j, k = [i for i in range(3) if i != axis]
            determinant = u[j] * v[k] - u[k] * v[j]
            wb = (projected[j] * v[k] - projected[k] * v[j]) / determinant
            wc = (u[j] * projected[k] - u[k] * projected[j]) / determinant
            weights = [1 - wb - wc, wb, wc]
            if need_distance and min(weights) >= 0:
                return float((height * height / n2).sqrt())
        if not need_distance:
            return np.asarray([float(x) for x in weights]) if weights is not None else None
        squared = []
        for i, j in [(0, 1), (1, 2), (2, 0)]:
            edge, delta = sub(t[j], t[i]), sub(p, t[i])
            length = dot(edge, edge)
            fraction = min(Decimal(1), max(Decimal(0), dot(delta, edge) / length)) if length else Decimal(0)
            residual = [delta[k] - fraction * edge[k] for k in range(3)]
            squared.append(dot(residual, residual))
        return float(min(squared).sqrt())


def barycentric(point, triangle):
    p, t, u, v, n, condition = _input(point, triangle)
    if condition > 1e4:
        return _decimal(p, t, False)
    ap = p - t[0]
    ap -= n * float(n @ ap) / float(n @ n)
    j, k = [i for i in range(3) if i != int(np.argmax(np.abs(n)))]
    determinant = u[j] * v[k] - u[k] * v[j]
    wb = (ap[j] * v[k] - ap[k] * v[j]) / determinant
    wc = (u[j] * ap[k] - u[k] * ap[j]) / determinant
    return np.asarray([1 - wb - wc, wb, wc])


def triangle_distance(point, triangle):
    p, t, u, v, n, condition = _input(point, triangle)
    if condition > 1e4:
        return _decimal(p, t, True)
    weights = barycentric(p, t)
    if weights is not None and min(weights) >= 0:
        return abs(float(n @ (p - t[0]))) / float(np.linalg.norm(n))
    distances = []
    for a, b in zip(t, np.roll(t, -1, axis=0)):
        edge, delta = b - a, p - a
        squared = float(edge @ edge)
        fraction = min(1., max(0., float(delta @ edge) / squared)) if squared else 0.
        distances.append(float(np.linalg.norm(delta - fraction * edge)))
    return min(distances)



def exact_zero_triangle(triangle):
    """Exact dyadic cross product of actual binary floating-point inputs."""
    values = [[float(x).as_integer_ratio() for x in row] for row in triangle]
    denominator = max(d for row in values for _, d in row)
    points = [[n * (denominator // d) for n, d in row] for row in values]
    u = [points[1][k] - points[0][k] for k in range(3)]
    v = [points[2][k] - points[0][k] for k in range(3)]
    return not any((u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0]))


def closest_weights(point, triangle):
    """Coordinates at the actual Euclidean closest CLOSED-triangle point.

    Interior coordinates retain the independently calibrated dominant-plane
    implementation. An exterior point projects to one of the three actual
    closed segments. Clip-and-normalize of plane weights is not this projection.
    For degenerate geometry the closest position exists but its field basis
    need not be unique: area-field callers must use field_weights below.
    """
    p = np.asarray(point, dtype=np.float64)
    t = np.asarray(triangle, dtype=np.float64)
    if p.shape != (3,) or t.shape != (3, 3) or not np.all(np.isfinite(t)) or not np.all(np.isfinite(p)):
        raise ValueError('Finite point and actual three triangle corners required')
    if not exact_zero_triangle(t):
        weights = barycentric(p, t)
        if weights is not None and min(weights) >= 0:
            return tuple(float(x) for x in weights)
    with localcontext() as context:
        context.prec = 100
        d = Decimal.from_float
        pp = [d(float(x)) for x in p]
        tt = [[d(float(x)) for x in row] for row in t]
        choices = []
        for i, j in ((0, 1), (1, 2), (2, 0)):
            edge = [tt[j][k] - tt[i][k] for k in range(3)]
            delta = [pp[k] - tt[i][k] for k in range(3)]
            squared = sum(x*x for x in edge)
            fraction = min(Decimal(1), max(Decimal(0), sum(a*b for a,b in zip(delta, edge))/squared)) if squared else Decimal(0)
            residual = [delta[k] - fraction*edge[k] for k in range(3)]
            weights = [Decimal(0)] * 3
            weights[i], weights[j] = 1-fraction, fraction
            choices.append((sum(x*x for x in residual), weights))
        _, weights = min(choices, key=lambda item: item[0])
        return tuple(float(x) for x in weights)


def field_weights(point, triangle):
    """Closest field coordinates on a genuine nondegenerate area chart.

    A rational-zero triangle with distinct paired corner fields is not a
    single-valued area field. Preserve its original corner/port chart directly;
    never infer its field from an arbitrary nearest vertex or fake clip sliver.
    """
    if exact_zero_triangle(triangle):
        raise ValueError('Exact zero-area field requires paired source-corner/port custody')
    return closest_weights(point, triangle)
