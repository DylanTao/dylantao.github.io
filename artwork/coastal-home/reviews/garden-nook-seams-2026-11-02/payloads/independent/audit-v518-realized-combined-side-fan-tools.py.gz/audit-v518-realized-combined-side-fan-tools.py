"""Independent closed-axis-cell qualification of actually delivered temporary tools."""
import bpy,numpy as np,json,hashlib,sys,math
from pathlib import Path
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];sys.path.insert(0,str(ROOT/'bin'))
from audit_coastal_f6_native_topology import qualify
RECEIPT=Path('C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/combined-side-fan-control-v1/candidate-attempt-1/REPLAY.json');assert hashlib.sha256(RECEIPT.read_bytes()).hexdigest()=='40a876a766531c728e8bdbfe6922b1d8470bf71dc75c044d61e30091ee48783e';R=json.loads(RECEIPT.read_text());proposal=json.loads((Q/'proposal-v489-finite-landing-side-tools.json').read_text());front=json.loads((Q/'proposal-v513-source-field-preserving-side-planes.json').read_text());bpy.ops.wm.read_factory_settings(use_empty=True)
def winding(t,p):
 a,b,c=(t[:,i]-p for i in range(3));la=np.linalg.norm(a,axis=1);lb=np.linalg.norm(b,axis=1);lc=np.linalg.norm(c,axis=1);num=np.einsum('ij,ij->i',a,np.cross(b,c));den=la*lb*lc+np.einsum('ij,ij->i',a,b)*lc+np.einsum('ij,ij->i',b,c)*la+np.einsum('ij,ij->i',c,a)*lb;return float(np.arctan2(num,den).sum()/(2*math.pi))
result={'candidateSha256':R['candidateSha256'],'actualProducerReceipt':str(RECEIPT),'actualProducerReceiptSha256':hashlib.sha256(RECEIPT.read_bytes()).hexdigest(),'method':'Actual delivered Float32 tool P/index arrays reconstructed read-only with directed closed positive-volume validation. Every union boundary triangle must be axis-planar; exact coordinate-cell centers classified by oriented winding and actual signed volume independently matched. Actual full cell union compared to the separately approved physical proposal, not an AABB.','owners':{},'passed':False}
for row in R['temporaryCutTools']:
 name=row['owner'];u=row['actualUnion'];p=np.asarray(u['nativeVertices']);ids=np.asarray(u['nativeTriangles']);assert np.array_equal(p,p.astype(np.float32).astype(np.float64));t=p[ids];m=bpy.data.meshes.new('read-only actual tool '+name);m.from_pydata(p.tolist(),[],ids.tolist());top=qualify(m);assert top['passed'],top;assert all(any(np.all(v[:,k]==v[0,k]) for k in range(3)) for v in t),'Non-axis actual boundary forbidden'
 axes=[np.unique(p[:,k]) for k in range(3)];shape=tuple(len(a)-1 for a in axes);grid=np.zeros(shape,bool)
 for cell in np.ndindex(shape):
  center=np.asarray([(axes[k][cell[k]]+axes[k][cell[k]+1])/2 for k in range(3)]);w=winding(t,center);assert min(abs(w),abs(w-1))<1e-7,(name,cell,w);grid[cell]=abs(w-1)<1e-7
 pending=grid.copy();boxes=[]
 while pending.any():
  lo=np.argwhere(pending)[0];hi=lo+1
  for k in range(3):
   while hi[k]<shape[k]:
    n=hi.copy();n[k]+=1
    if not np.all(pending[tuple(slice(lo[j],n[j]) for j in range(3))]):break
    hi=n
  pending[tuple(slice(lo[k],hi[k]) for k in range(3))]=False;boxes.append(([float(axes[k][lo[k]]) for k in range(3)],[float(axes[k][hi[k]]) for k in range(3)]))
 signed=float(np.einsum('ij,ij->i',t[:,0],np.cross(t[:,1],t[:,2])).sum()/6);boxvol=sum(float(np.prod(np.asarray(b)-a)) for a,b in boxes);assert abs(signed-boxvol)<1e-10*max(1.,abs(signed));expected=front['physicalUnionByOwner'][name]['proposedActualClosedCells'];allaxes=[sorted(set(axes[k])|{v[k] for box in expected for v in box}) for k in range(3)];mismatch=[]
 for cell in np.ndindex(tuple(len(a)-1 for a in allaxes)):
  center=np.asarray([(allaxes[k][cell[k]]+allaxes[k][cell[k]+1])/2 for k in range(3)]);inside=any(np.all(center>lo) and np.all(center<hi) for lo,hi in expected);actual=abs(winding(t,center)-1)<1e-7
  if inside!=actual:mismatch.append(center.tolist())
 assert not mismatch,(name,mismatch);result['owners'][name]={'actualNativeToolVertices':p.tolist(),'actualNativeToolTriangles':ids.tolist(),'exactNativeAxisCellDecomposition':boxes,'allActualBoundaryFacesAxisPlanar':True,'actualGridCells':int(np.prod(shape)),'insideCells':int(grid.sum()),'actualSignedToolVolume':signed,'exactDecomposedVolume':boxvol,'directedTopology':top,'actualUnionExactlyMatchesApprovedProposal':True};print('ACTUAL_TOOL_QUALIFIED',name,len(boxes),signed,flush=True)
result['passed']=True;(Q/'v518-realized-combined-side-fan-tools.json').write_text(json.dumps(result,indent=2))
