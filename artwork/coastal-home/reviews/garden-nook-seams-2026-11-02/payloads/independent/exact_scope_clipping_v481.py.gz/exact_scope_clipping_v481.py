﻿"""Exact source-barycentric closed-box clipping for read-only native field audits."""
from fractions import Fraction as F
import numpy as np

def fractions(row):return tuple(F.from_float(float(v)) for v in row)
def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def exact_nonzero(points):
 u=tuple(points[1][k]-points[0][k] for k in range(3));v=tuple(points[2][k]-points[0][k] for k in range(3));return any(cross(u,v))
def coordinate(weights,points,axis):return sum(weights[i]*points[i][axis] for i in range(3))
def clip(poly,points,axis,value,sign):
 out=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  da=(coordinate(a,points,axis)-value)*sign;db=(coordinate(b,points,axis)-value)*sign
  if da>=0:out.append(a)
  if (da<0)!=(db<0):
   t=da/(da-db);out.append(tuple(a[i]*(1-t)+b[i]*t for i in range(3)))
 # Consecutive duplicate parameter ports have identical P/N/RGB; nonconsecutive
 # or geometrically coincident DISTINCT barycentric ports are never welded.
 result=[]
 for row in out:
  if not result or row!=result[-1]:result.append(row)
 if len(result)>1 and result[0]==result[-1]:result.pop()
 return result

def outside_box(poly,points,lo,hi):
 result=[]
 for axis,value,sign in [(i,lo[i],1) for i in range(3)]+[(i,hi[i],-1) for i in range(3)]:
  if not poly:break
  part=clip(poly,points,axis,value,-sign)
  if len(part)>=3 and not all(coordinate(row,points,axis)==value for row in part):result.append(part)
  poly=clip(poly,points,axis,value,sign)
 return result

def outside_surface(snapshot,boxes,keep_planes=()):
 out=[];zero_sources=[];zero_clipped=0;box_f=[(fractions(lo),fractions(hi)) for lo,hi in boxes]
 for index,face in enumerate(snapshot['triangles']):
  points=tuple(fractions(p) for p in face['p'])
  if not exact_nonzero(points):zero_sources.append(index+1);continue
  lo=[min(p[k] for p in points) for k in range(3)];hi=[max(p[k] for p in points) for k in range(3)];relevant=[(a,b) for a,b in box_f if all(hi[k]>=a[k] and lo[k]<=b[k] for k in range(3))]
  polys=[[(F(1),F(0),F(0)),(F(0),F(1),F(0)),(F(0),F(0),F(1))]]
  for a,b in relevant:polys=[part for poly in polys for part in outside_box(poly,points,a,b)]
  for axis,value,sign in keep_planes:polys=[clip(poly,points,axis,F.from_float(float(value)),sign) for poly in polys if poly]
  for poly in polys:
   for i in range(1,len(poly)-1):
    weights=[poly[0],poly[i],poly[i+1]];ps=[tuple(coordinate(w,points,k) for k in range(3)) for w in weights]
    if not exact_nonzero(ps):zero_clipped+=1;continue
    fields={kind:[[float(sum(w[j]*F.from_float(float(face[kind][j][k])) for j in range(3))) for k in range(len(face[kind][0]))] for w in weights] for kind in ['n','c']}
    out.append({'p':[[float(v) for v in p] for p in ps],**fields,'m':face['m'],'originalRenderTriangle':index+1})
 return {'triangles':out,'exactZeroSourceIndices':zero_sources,'exactZeroClippedPiecesNotManufactured':zero_clipped}
