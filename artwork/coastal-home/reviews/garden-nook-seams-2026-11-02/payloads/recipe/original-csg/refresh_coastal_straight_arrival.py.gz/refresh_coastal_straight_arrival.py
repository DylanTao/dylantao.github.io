"""Build the surveyed straight arrival from an explicitly pinned native input.

The source remains read-only. Independent native-field, circulation, export,
light-cache and rendered gates govern admission of the output.
"""
import bpy, bmesh, hashlib, json, math, sys
from pathlib import Path
from mathutils import Vector

root = Path(__file__).resolve().parents[1]
args={a[2:].split('=',1)[0]:a.split('=',1)[1] for a in sys.argv if a.startswith('--') and '=' in a}
for key in ['source','expected-source-sha256','output','report']:
    if key not in args:raise RuntimeError('Explicit --'+key+'= is required')
parts_dir=root/'bin/coastal_straight_arrival_parts'
sys.path.insert(0, str(root/'bin'))
from coastal_office import Parts, cylinder
import coastal_arrival_hall as old
import coastal_estate_architecture as library

report_path=Path(args['report']).resolve();qa=report_path.parent;qa.mkdir(parents=True,exist_ok=True)
source=Path(args['source']).resolve();output=Path(args['output']).resolve()
if source==output:raise RuntimeError('Construction output must be separate from its pinned input')
assert hashlib.sha256(source.read_bytes()).hexdigest() == args['expected-source-sha256']
assert bpy.app.version==(4,5,9), 'Requires exact Blender4.5.9'
bpy.ops.wm.open_mainfile(filepath=str(source))
scene = bpy.context.scene
assert not scene.get('straightArrivalPrototype')
exec(compile((parts_dir/'components.py').read_text(encoding='utf8'),'exact component retirement','exec'))
old._remove_islands=remove_islands_exact
exec(compile((parts_dir/'native_custody.py').read_text(encoding='utf8'),'native triangle custody','exec'))
import importlib.util
_spec=importlib.util.spec_from_file_location('arrival_exact_fields',parts_dir/'triangle_fields.py')
exact_fields=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(exact_fields)
original_fields={}

geology = old._geology(scene)
geology += [o for o in scene.objects if o.type=='MESH' and o.get('caveRoof') and o not in geology]
geology += [bpy.data.objects['core_arrival_hall__golden coastal sandstone']]
original_ground_tree=old._tree([bpy.data.objects['core__golden coastal sandstone']])
m = library.materials()
m['paving']=bpy.data.materials['travertine paving stone']
assert all(m[k] for k in ['stone','rock','oak','bronze'])
p = Parts('core_straight_arrival_trial')
stone, oak, bronze = [p.bm(m[k]) for k in ['stone','oak','bronze']]
rise, going, landing, width = 2.6/15, .28, 1.4, 2.2
counts = [15,18,19]
axis_x, axis_z = math.sin(math.radians(52)), math.cos(math.radians(52))

def point(s,t,h):
    return Vector((axis_x*s+axis_z*t, -(17.3+axis_z*s-axis_x*t), h))

def prism(bm, profile, t0, t1):
    rings = [[bm.verts.new(point(s,t,h)) for s,h in profile] for t in [t0,t1]]
    faces = [bm.faces.new(list(reversed(rings[0]))),bm.faces.new(rings[1])]
    for i in range(len(profile)):
        j=(i+1)%len(profile)
        faces.append(bm.faces.new((rings[0][i],rings[0][j],rings[1][j],rings[1][i])))
    bmesh.ops.recalc_face_normals(bm,faces=faces)
    volume = sum(f.verts[0].co.dot(f.verts[i].co.cross(f.verts[i+1].co))
                 for f in faces for i in range(1,len(f.verts)-1)) / 6
    if volume < 0:
        bmesh.ops.reverse_faces(bm,faces=faces)

def slab(bm,s0,s1,t0,t1,h0,h1):
    prism(bm,[(s0,h0),(s1,h0),(s1,h1),(s0,h1)],t0,t1)

caps=[]; flights=[]; s=0.; h=0.
slab(stone,-1.4,0,-1.5,1.5,-.25,0)
for fi,count in enumerate(counts):
    first_s,first_h=s,h
    profile=[(s,h-.35),(s,h-.028)]
    for k in range(count):
        top=h+rise
        profile.extend([(s,top-.028),(s+going,top-.028)])
        slab(oak,s-.012,s+going,-width/2,width/2,top-.028,top)
        # The rill follows gravity beside the treads; its final flowing surface is a later task.
        # Raised kerbs and the shared side slab support the shallow rill.
        slab(stone,s,s+going,-1.82,-1.70,top-.065,top+.025)
        slab(stone,s,s+going,-1.25,-1.10,top-.065,top+.025)
        caps.append({'s':s+going/2,'height':top,'point':list(point(s+going/2,0,top))})
        s+=going;h=top
    profile.extend([(s,h-.35),(first_s,first_h-.35)])
    # Remove the repeated closing point before forming the closed stair prism.
    if profile[-1]==profile[0]:profile.pop()
    prism(stone,profile,-width/2,width/2)
    prism(stone,[(a,z-.037) for a,z in profile],-1.82,-1.05)
    flights.append({'startS':first_s,'endS':s,'bottom':first_h,'top':h,'risers':count})
    if fi<len(counts)-1:
        slab(stone,s,s+landing,-width/2,width/2,h-.35,h-.028)
        slab(oak,s,s+landing,-width/2,width/2,h-.028,h)
        slab(stone,s,s+landing,-1.82,-1.05,h-.387,h-.065)
        slab(stone,s,s+landing,-1.82,-1.70,h-.065,h+.025)
        slab(stone,s,s+landing,-1.25,-1.10,h-.065,h+.025)
        # A transverse bearing beam seats into both untouched rock banks.
        slab(stone,s+.12,s+landing-.12,-2.18,2.18,h-.39,h-.18)
        s+=landing
slab(stone,s,s+.58,-1.25,1.7,h-.3,h)
slab(stone,s+.58,s+2.4,-1.7,1.7,h-.3,h)
slab(stone,s,s+.58,-1.82,-1.05,h-.387,h-.065)
slab(stone,s,s+.58,-1.82,-1.70,h-.065,h+.025)
slab(stone,s,s+.58,-1.25,-1.10,h-.065,h+.025)
slab(stone,s+.53,s+.61,-1.82,-1.10,h-.3,h+.055)
slab(stone,s+.12,s+.46,-1.72,-1.67,h-.02,h+.05)
# The recirculating feed is upstream of the side-arrival crossing.
# The crossing therefore remains a continuous dry stone surface.
slab(stone,-.62,.01,-1.82,-1.05,0,.04)
for a,b in [(-1.82,-1.70),(-1.25,-1.10)]:slab(stone,-.62,.01,a,b,.04,.09)
slab(stone,-.65,-.60,-1.82,-1.10,0,.09)
top_s,top_h=s,h
for flight in flights:
    a,b=flight['startS'],flight['endS'];ha,hb=flight['bottom'],flight['top']
    for t in [-1.17,1.17]:
        cylinder(bronze,point(a,t,ha+1.10),point(b,t,hb+1.10),.022,10)
        for k in range(max(2,math.ceil((b-a)/1.2))+1):
            q=k/max(2,math.ceil((b-a)/1.2));along=a+(b-a)*q;floor=ha+(hb-ha)*q
            cylinder(bronze,point(along,t,floor),point(along,t,floor+1.10),.012,8)

# A closed right-side stone stringer seats every railing post. Its base
# penetrates the actual cut floor20mm; its cap embeds the metal feet8mm.
for fi,flight in enumerate(flights):
    a,b=flight['startS'],flight['endS'];ha,hb=flight['bottom'],flight['top']
    prism(stone,[(a,ha-.42),(b,hb-.42),(b,hb+.008),(a,ha+.008)],1.10,1.30)
    if fi<len(flights)-1:slab(stone,b,b+landing,1.10,1.30,hb-.42,hb+.008)

# Continuous landing rails, leaving the first right-hand gallery crossing open.
for index,flight in enumerate(flights[:-1]):
    a=flight['endS'];height=flight['top']+1.10
    for across in ([-1.17] if index==0 else [-1.17,1.17]):
        cylinder(bronze,point(a,across,height),point(a+landing,across,height),.022,10)

# Cut a real, closed inclined shaft; every source volume change is guarded by the existing tool.
cut=bmesh.new()
# The existing foyer already supplies the bottom half metre of headroom.
# Keep the excavation landward of it; an unnecessary seaward tail touched a remote roof.
cut_start=.5
# The shaft follows each actual flight and its horizontal landing. A global
# slope cut through the third flight's tread surfaces in the rejected v3.
line=[(cut_start,flights[0]['bottom']+(cut_start-flights[0]['startS'])*rise/going)]
for flight in flights:
    if flight['startS']>cut_start:line.append((flight['startS'],flight['bottom']))
    line.append((flight['endS'],flight['top']))
line.append((top_s+2.42,top_h))
profile=[(along,height-.40) for along,height in line]
profile += [(along,height+2.65) for along,height in reversed(line)]
prism(cut,profile,-2.05,2.05)
data=bpy.data.meshes.new('private straight-arrival shaft cutter');cut.to_mesh(data);cut.free()
cutter=bpy.data.objects.new(data.name,data);bpy.context.collection.objects.link(cutter)
control=bmesh.new();control.from_mesh(data);signed=control.calc_volume(signed=True);control.free()
assert signed > 0, ('Cutter must have positive winding',signed)
print('Cutter signed volume',signed,flush=True)
if '--boolean-probe' in sys.argv:
    original=bpy.data.objects['core__golden coastal sandstone'];rows=[]
    options=[('EXACT',False,False),('EXACT',True,True),('MANIFOLD',False,False),('FLOAT',False,False)]
    for solver,self_intersection,hole_tolerant in options:
        obj=original.copy();obj.data=original.data.copy();bpy.context.collection.objects.link(obj)
        modifier=obj.modifiers.new('private independent solver control','BOOLEAN')
        allowed=[v.identifier for v in modifier.bl_rna.properties['solver'].enum_items]
        if solver not in allowed:
            bpy.data.objects.remove(obj,do_unlink=True);continue
        modifier.operation='DIFFERENCE';modifier.solver=solver;modifier.object=cutter
        modifier.use_self=self_intersection;modifier.use_hole_tolerant=hole_tolerant
        bpy.context.view_layer.objects.active=obj
        bpy.ops.object.modifier_apply(modifier=modifier.name)
        bm=bmesh.new();bm.from_mesh(obj.data)
        rows.append({'solver':solver,'self':self_intersection,'holeTolerant':hole_tolerant,
                     'rawSignedVolume':bm.calc_volume(signed=True),'faces':len(bm.faces),
                     'nonManifoldEdges':sum(len(e.link_faces)!=2 for e in bm.edges)})
        bm.free();bpy.data.objects.remove(obj,do_unlink=True)
    (qa/'boolean-independent-controls.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
    print('Boolean controls only:',rows,'; no native file saved',flush=True);sys.exit(0)
if '--survey-only' in sys.argv:
    import coastal_shell as shell
    obj=bpy.data.objects['core__golden coastal sandstone'];bm=bmesh.new();bm.from_mesh(obj.data)
    islands=shell._islands(bm);ids={v:i for i,group in enumerate(islands) for v in group};rows=[]
    for i,group in enumerate(islands):
        faces=[f for f in bm.faces if ids[f.verts[0]]==i]
        coords=[obj.matrix_world@v.co for v in group]
        volume=sum(f.verts[0].co.dot(f.verts[k].co.cross(f.verts[k+1].co)) for f in faces for k in range(1,len(f.verts)-1))/6
        rows.append({'id':i,'vertices':len(group),'faces':len(faces),'signedVolume':volume,
                     'min':[min(v[k] for v in coords) for k in range(3)],'max':[max(v[k] for v in coords) for k in range(3)],
                     'nonManifoldEdges':sum(len(e.link_faces)!=2 for e in {e for f in faces for e in f.edges})})
    bm.free();(qa/'native-island-survey.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
    print('Survey only:',len(rows),'native components; no cut or save');sys.exit(0)
report={'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'status':'UNQUALIFIED construction trial',
        'basis':{'startWorld':[0,17.3],'directionWorld':[axis_x,axis_z]},'clearWidth':width,'rise':rise,'going':going,
        'flights':flights,'topNative':list(point(top_s,0,top_h)),'topHeight':top_h,
        'pending':['old-hall retirement and enclosure','upper-floor gallery connection','pavilion and graded approach',
                   'water flow and local planting','native overlap/support/closed audit','AO/export/cache/actual Walk/render gates']}
def guarded_manifold_cut(tool,targets):
    bpy.context.view_layer.update()
    for name,kind,domain in [('Arrival source triangle','INT','FACE')]:
        if not tool.data.attributes.get(name):tool.data.attributes.new(name,kind,domain)
    corners=[tool.matrix_world@Vector(v) for v in tool.bound_box]
    lo=[min(v[k] for v in corners) for k in range(3)];hi=[max(v[k] for v in corners) for k in range(3)]
    limit=old._volume(tool)*1.02+.05;results=[]
    for obj in targets:
        bounds=[obj.matrix_world@Vector(v) for v in obj.bound_box]
        a=[min(v[k] for v in bounds) for k in range(3)];b=[max(v[k] for v in bounds) for k in range(3)]
        if not all(a[k]<=hi[k] and b[k]>=lo[k] for k in range(3)):continue
        control=bmesh.new();control.from_mesh(obj.data)
        bad=sum(not e.is_manifold for e in control.edges);control.free()
        if bad:raise RuntimeError(f'Closed-input Manifold control fails on {obj.name}: {bad}')
        if obj.name=='core_retreat_liftaway_roof':
            from mathutils.bvhtree import BVHTree
            def actual_tree(owner):
                owner.data.calc_loop_triangles()
                return BVHTree.FromPolygons([owner.matrix_world@v.co for v in owner.data.vertices],
                    [tuple(t.vertices) for t in owner.data.loop_triangles],all_triangles=True)
            def inside(tree,point):
                direction=Vector((.78241,.56321,.26519)).normalized();start=point.copy();hits=0
                for _ in range(4096):
                    hit,_,_,_=tree.ray_cast(start,direction,1000)
                    if hit is None:return hits%2==1
                    hits+=1;start=hit+direction*.00001
                raise RuntimeError('Ray parity failed to terminate')
            ot,tt=actual_tree(obj),actual_tree(tool)
            contacts=ot.overlap(tt)
            if not contacts and not any(inside(ot,tool.matrix_world@v.co) for v in tool.data.vertices) and not inside(tt,obj.matrix_world@obj.data.vertices[0].co):
                # AABB overlap alone reaches this remote roof. Its one connected
                # closed island and the closed tool are surface-disjoint, and
                # neither contains the other. Keep all original fields exact.
                results.append({'object':obj.name,'skippedProvenDisjoint':True,'surfacePairs':0,'toolVerticesOutside':len(tool.data.vertices)})
                continue
        if obj.name not in original_fields:
            print('CUSTODY_INPUT',obj.name,flush=True)
            original_fields[obj.name]=source_fields(obj)
            triangulate_native_render_faces(obj.data,raw_normals)
        before=old._volume(obj);saved=obj.data.copy()
        modifier=obj.modifiers.new('private closed-input straight arrival','BOOLEAN')
        modifier.operation='DIFFERENCE';modifier.solver='MANIFOLD';modifier.object=tool
        bpy.context.view_layer.objects.active=obj;bpy.ops.object.modifier_apply(modifier=modifier.name)
        _s=importlib.util.spec_from_file_location('arrival_boundary',parts_dir/'boundary.py');_u=importlib.util.module_from_spec(_s);_s.loader.exec_module(_u)
        restore_original_outside=_u.restore_original_outside
        try:
            outside_custody=restore_original_outside(obj,saved,Vector(lo),Vector(hi),tool=tool)
        except RuntimeError:
            bm=bmesh.new();bm.from_mesh(obj.data);edges=[]
            ids=bm.faces.layers.int.get('Arrival source triangle')
            for e in bm.edges:
                if not e.is_manifold:
                    edges.append({'points':[list(obj.matrix_world@v.co) for v in e.verts],'length':e.calc_length(),
                                  'faces':[{'sourceTriangle':f[ids] if ids else None,'points':[list(obj.matrix_world@v.co) for v in f.verts]} for f in e.link_faces]})
            bm.free()
            (qa/'boundary-failure.json').write_text(json.dumps({'object':obj.name,'cutBounds':[lo,hi],'edges':edges},indent=2)+'\n')
            bpy.ops.wm.save_as_mainfile(filepath=str(qa/'DIAGNOSTIC-open-boundary.blend'),compress=True)
            raise
        control=bmesh.new();control.from_mesh(obj.data);bad=sum(not e.is_manifold for e in control.edges);control.free()
        lost=before-old._volume(obj)
        if bad or lost < -.05 or lost > limit:
            rejected=obj.data;obj.data=saved;bpy.data.meshes.remove(rejected)
            raise RuntimeError(f'Manifold result rejected: {obj.name}, open={bad}, removed={lost}, limit={limit}')
        if abs(lost) < 1e-8:
            # A disjoint Boolean may retriangulate nonplanar inherited n-gons.
            # Restore its exact original rather than accepting a needless rewrite.
            no_op=obj.data;obj.data=saved;bpy.data.meshes.remove(no_op)
            results.append({'object':obj.name,'removedVolume':lost,'nonManifoldEdges':bad,'restoredExactNoop':True})
        else:
            import numpy as np
            _rs=importlib.util.spec_from_file_location('arrival_refit',parts_dir/'refit.py');_r=importlib.util.module_from_spec(_rs);_rs.loader.exec_module(_r)
            refit=_r.refit_split_points(obj,original_fields[obj.name],exact_fields)
            values=np.asarray([tuple(v.vector) for v in obj.data.corner_normals],dtype=np.float64)
            own=obj.data.attributes.get('Arrival source triangle')
            if own is None:raise RuntimeError('CSG dropped original triangle custody')
            color=obj.data.color_attributes.active_color
            if color is None:
                color=obj.data.color_attributes.new('Arrival neutral source color','FLOAT_COLOR','CORNER')
                for dst in color.data:dst.color=(1.,1.,1.,1.)
                obj.data.color_attributes.active_color=color
            if color.domain!='CORNER':raise RuntimeError('Unmapped original corner color')
            restored=0;maximum_distance=0.
            for face in obj.data.polygons:
                sid=own.data[face.index].value
                if sid<=0:
                    for li in face.loop_indices:values[li]=tuple(face.normal)
                    continue
                source=original_fields[obj.name]['triangles'][sid]
                points=[tuple(v) for v in source['p']]
                for li in face.loop_indices:
                    at=tuple(obj.matrix_world@obj.data.vertices[obj.data.loops[li].vertex_index].co)
                    if at in points:
                        k=points.index(at);weights=np.zeros(3);weights[k]=1.
                    else:
                        distance=exact_fields.triangle_distance(at,source['p']);maximum_distance=max(maximum_distance,distance)
                        if distance>3e-6:raise RuntimeError('Original source plane left its support: '+str((obj.name,sid,at,distance)))
                        weights=np.asarray(exact_fields.barycentric(at,source['p']))
                        if weights.shape!=(3,) or not np.all(np.isfinite(weights)):raise RuntimeError('Invalid source affine weights')
                    values[li]=weights@source['n']
                    color.data[li].color=weights@source['c']
                    restored+=1
            raw_normals(obj.data,values)
            bpy.data.meshes.remove(saved)
            results.append({'object':obj.name,'removedVolume':lost,'nonManifoldEdges':bad,'restoredExactNoop':False,'sourceCornersRestored':restored,'outsideCustody':outside_custody,'splitPointRefits':refit})
    bpy.data.objects.remove(tool,do_unlink=True)
    return results
excavation_tools=[cutter]
def apply_arrival_excavation():
    report['excavationTools']=[];report['excavationUnions']=[]
    for tool in excavation_tools:
        report['excavationTools'].append({'name':tool.name,'vertices':[list(tool.matrix_world@v.co) for v in tool.data.vertices],
                                         'faces':[list(f.vertices) for f in tool.data.polygons],'volume':old._volume(tool)})
    primary=excavation_tools[0]
    for other in excavation_tools[1:]:
        a,b=old._volume(primary),old._volume(other)
        modifier=primary.modifiers.new('single connected arrival excavation','BOOLEAN');modifier.operation='UNION';modifier.solver='MANIFOLD';modifier.object=other
        bpy.context.view_layer.objects.active=primary;bpy.ops.object.modifier_apply(modifier=modifier.name)
        control=bmesh.new();control.from_mesh(primary.data);bad=sum(not e.is_manifold for e in control.edges)
        pending=set(control.verts);components=0
        while pending:
            components+=1;stack=[pending.pop()]
            while stack:
                v=stack.pop()
                for edge in v.link_edges:
                    u=edge.other_vert(v)
                    if u in pending:pending.remove(u);stack.append(u)
        control.free();volume=old._volume(primary)
        if components!=1 or a+b-volume<=1e-5:raise RuntimeError('Excavation union lacks a positive connected overlap '+str((components,a,b,volume)))
        if bad or volume<max(a,b)-1e-5 or volume>a+b+1e-5:raise RuntimeError('Invalid excavation union '+str((bad,a,b,volume)))
        report['excavationUnions'].append({'added':other.name,'inputVolumes':[a,b],'outputVolume':volume,'nonmanifoldEdges':bad,'connectedComponents':components,'positiveOverlapVolume':a+b-volume})
        bpy.data.objects.remove(other,do_unlink=True)
    targets=old._geology(scene)
    targets += [o for o in scene.objects if o.type=='MESH' and o.get('caveRoof') and o not in targets]
    hall=bpy.data.objects['core_arrival_hall__golden coastal sandstone']
    if hall not in targets:targets.append(hall)
    report['cuts']=guarded_manifold_cut(primary,targets)
    report['galleryStoneCuts']=guarded_manifold_cut(stone_gallery_tool,[stone_owner])
    report['excavationPolicy']='Single connected shaft/gallery/approach difference in geology; separate gallery-only masonry opening preserves main pivot surround.'

exec(compile((parts_dir/'gallery_water.py').read_text(encoding='utf8'),'private gallery and water trial','exec'))
exec(compile((parts_dir/'garden.py').read_text(encoding='utf8'),'new contour approach','exec'))
objects=p.finish()
for obj in objects:
    if obj.type=='MESH' and 'brass' not in obj.name and 'bronze' not in obj.name:
        for face in obj.data.polygons:face.use_smooth=False
    if obj.name.endswith('estate warm opal diffuser'):obj['installationGlow']='straight-arrival-coves'
    if any(mat and mat.name in ('arrival flowing spring water','arrival spring rill spill') for mat in obj.data.materials):
        obj['walk']='through';obj['noContactOcclusion']=True;obj['noVolumeDepth']=True;obj['closedSolid']=True
    obj['renderStyle']='realistic';obj['architectureComponent']='straight-arrival-trial';obj['unqualifiedPrototype']=True;obj['installationGroup']='straight-arrival'
from coastal_straight_arrival_lining import build as build_lining
report['lining']=build_lining(scene,report,old._geology(scene))
for obj in scene.objects:
    if obj.name.startswith('core_straight_arrival_trial__arrival dark weathered bronze'):obj['rainRoof']=True
scene['straightArrivalPrototype']=1
bpy.ops.wm.save_as_mainfile(filepath=str(output))
report_path.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print('PRIVATE trial saved',qa,'top',top_h,'native',list(point(top_s,0,top_h)),flush=True)
