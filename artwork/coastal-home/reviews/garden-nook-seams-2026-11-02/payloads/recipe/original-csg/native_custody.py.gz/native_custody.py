import bpy,bmesh,numpy as np
def triangulate_native_render_faces(mesh, set_normals):
    """Bind original render triangles to their original polygon-owned edges.

    Distinct original polygon interiors may have coincident render diagonals.
    Native Mesh supports distinct edge records with identical endpoints. Its
    loop.edge_index owns those edges explicitly, so no invented midpoint or
    rounded corner is needed. The native/BMesh roundtrip must stay closed.
    """
    mesh.calc_loop_triangles()
    vertices = [tuple(vertex.co) for vertex in mesh.vertices]
    vertex_weights = [[(i, 1.0)] for i in range(len(vertices))]
    edges = [tuple(edge.vertices) for edge in mesh.edges]
    edge_weights = [[(i, 1.0)] for i in range(len(edges))]
    normals = np.asarray([tuple(entry.vector) for entry in mesh.corner_normals], dtype=np.float64)
    polygons = {face.index: {'vertices': list(face.vertices), 'loops': list(face.loop_indices), 'material': face.material_index, 'smooth': face.use_smooth} for face in mesh.polygons}
    boundaries = {}
    for face in mesh.polygons:
        boundaries[face.index] = {tuple(sorted((mesh.loops[index].vertex_index, mesh.loops[face.loop_start + (k + 1) % face.loop_total].vertex_index))): mesh.loops[index].edge_index for k, index in enumerate(face.loop_indices)}
    attrs = []
    widths = {'FLOAT': ('value', 1, np.float32), 'INT': ('value', 1, np.int32), 'BOOLEAN': ('value', 1, np.bool_), 'FLOAT_VECTOR': ('vector', 3, np.float32), 'FLOAT_COLOR': ('color', 4, np.float32), 'BYTE_COLOR': ('color', 4, np.float32), 'FLOAT2': ('vector', 2, np.float32)}
    for attr in mesh.attributes:
        if attr.name.startswith('.') or attr.name in ('position', 'material_index', 'custom_normal'):
            continue
        if attr.data_type not in widths:
            raise RuntimeError('Unmapped native attribute: ' + attr.name + ' ' + attr.data_type)
        prop, width, dtype = widths[attr.data_type]
        values = np.empty(len(attr.data) * width, dtype=dtype)
        attr.data.foreach_get(prop, values)
        attrs.append((attr.name, attr.domain, attr.data_type, prop, width, values.reshape((-1, width)).copy()))
    active_color = mesh.color_attributes.active_color.name if mesh.color_attributes.active_color else None
    source_triangle = mesh.attributes.get('Arrival source triangle')
    source_triangle_ids = [entry.value for entry in source_triangle.data] if source_triangle else None
    faces, corner_edges, corner_weights, face_owners = ([], [], [], [])
    triangle_owners = []
    owned_edges = {}
    for triangle in mesh.loop_triangles:
        ids = list(triangle.vertices)
        if len(set(ids)) != 3:
            raise RuntimeError('Repeated source triangle vertex in ' + mesh.name)
        faces.append(ids)
        corner_weights.extend([[(index, 1.0)] for index in triangle.loops])
        face_owners.append(triangle.polygon_index)
        triangle_owners.append(source_triangle_ids[triangle.polygon_index] if source_triangle_ids else triangle.index + 1)
        for a, b in zip(ids, ids[1:] + ids[:1]):
            pair = tuple(sorted((a, b)))
            edge = boundaries[triangle.polygon_index].get(pair)
            if edge is None:
                key = (triangle.polygon_index, pair)
                if key not in owned_edges:
                    owned_edges[key] = len(edges)
                    edges.append(pair)
                    edge_weights.append([])
                edge = owned_edges[key]
            corner_edges.append(edge)
    mesh.clear_geometry()
    mesh.vertices.add(len(vertices))
    mesh.edges.add(len(edges))
    mesh.loops.add(len(corner_weights))
    mesh.polygons.add(len(faces))
    mesh.vertices.foreach_set('co', np.asarray(vertices, dtype=np.float32).reshape(-1))
    mesh.edges.foreach_set('vertices', np.asarray(edges, dtype=np.int32).reshape(-1))
    mesh.loops.foreach_set('vertex_index', np.asarray(faces, dtype=np.int32).reshape(-1))
    mesh.loops.foreach_set('edge_index', np.asarray(corner_edges, dtype=np.int32))
    mesh.polygons.foreach_set('loop_start', np.arange(len(faces), dtype=np.int32) * 3)
    mesh.polygons.foreach_set('loop_total', np.full(len(faces), 3, dtype=np.int32))
    mesh.polygons.foreach_set('material_index', [polygons[owner]['material'] for owner in face_owners])
    mesh.polygons.foreach_set('use_smooth', [polygons[owner]['smooth'] for owner in face_owners])
    mesh.update(calc_edges=False)
    for name, domain, data_type, prop, width, values in attrs:
        attr = mesh.attributes.get(name) or mesh.attributes.new(name, data_type, domain)
        if domain == 'POINT':
            weights = vertex_weights
        elif domain == 'CORNER':
            weights = corner_weights
        elif domain == 'FACE':
            weights = [[(owner, 1.0)] for owner in face_owners]
        elif domain == 'EDGE':
            weights = edge_weights
        else:
            raise RuntimeError('Unmapped native attribute domain: ' + domain)
        mapped = np.asarray([sum((values[i] * w for i, w in row), np.zeros(width)) for row in weights])
        if data_type == 'BOOLEAN':
            mapped = mapped >= 0.5
        elif data_type == 'INT':
            mapped = np.rint(mapped).astype(np.int32)
        attr.data.foreach_set(prop, mapped.reshape(-1))
    if active_color:
        mesh.color_attributes.active_color = mesh.color_attributes[active_color]
    if source_triangle_ids is None:
        attribute = mesh.attributes.new('Arrival source triangle', 'INT', 'FACE')
        attribute.data.foreach_set('value', np.asarray(triangle_owners, dtype=np.int32))
    mapped_normals = np.asarray([normals[row[0][0]] for row in corner_weights])
    set_normals(mesh, mapped_normals)
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bad = sum((not edge.is_manifold for edge in bm.edges))
    bm.free()
    if bad:
        raise RuntimeError('Native render-edge ownership opened ' + mesh.name + ': ' + str(bad))
    return [{'ownedNativeDiagonals': len(owned_edges), 'duplicateEndpointPairs': len(edges) - len(set((tuple(sorted(edge)) for edge in edges))), 'addedVertices': 0, 'cornerFieldsCopiedExactly': True, 'nonmanifoldEdges': bad}]

def source_fields(obj):
    mesh = obj.data
    mesh.calc_loop_triangles()
    points = [tuple(obj.matrix_world @ vertex.co) for vertex in mesh.vertices]
    normals = [tuple(entry.vector) for entry in mesh.corner_normals]
    color = mesh.color_attributes.active_color
    colors = [tuple(entry.color) for entry in color.data] if color else None
    result = {'triangles': {}}
    for triangle in mesh.loop_triangles:
        row = {'p': np.asarray([points[i] for i in triangle.vertices], dtype=np.float64), 'n': np.asarray([normals[i] for i in triangle.loops], dtype=np.float64), 'c': np.asarray([colors[i] if colors else (1.,1.,1.,1.) for i in triangle.loops], dtype=np.float64), 'material': triangle.material_index}
        result.setdefault(triangle.polygon_index + 1, []).append(row)
        result['triangles'][triangle.index + 1] = row
    return result
def raw_normals(mesh,values):
    import numpy as np
    a=mesh.attributes.get('custom_normal')
    if a:mesh.attributes.remove(a)
    a=mesh.attributes.new('custom_normal','FLOAT_VECTOR','CORNER')
    a.data.foreach_set('vector',np.asarray(values,dtype=np.float32).reshape(-1))
    mesh.update()
