"""ONE private source-edge-bound two-zero-chart fan repair; no volume change."""
import bpy, bmesh, numpy as np, json, hashlib
from pathlib import Path
from fractions import Fraction as F

Q=Path(__file__).resolve().parent
BEFORE=Path(r'C:/dev/dylantao.github.io/.jekyll-cache/visual-qa/final-house-integration-20261102/olive-v1/candidate.blend')
INPUT=Q.parent/'exact-tool-membership-control-v1/candidate-attempt-1/candidate.blend'
assert hashlib.sha256(BEFORE.read_bytes()).hexdigest()=='2219191865a713604630ce37fb1219bb754f6c519921f0769117e8818c2c608c'
assert hashlib.sha256(INPUT.read_bytes()).hexdigest()=='cf46c6bbf842e7deaca0afc647cd62b17bd68b159531c509acdf1a48127e8db4'
OWNER='core__golden coastal sandstone'
CLIP=(-5.900000095367432,-3.419999122619629,-.21499985456466675)

def numeric_attributes(mesh):
    result={}
    for attr in mesh.attributes:
        if attr.name in ('position','material_index','.edge_verts','.corner_vert','.corner_edge'):
            continue
        props={}
        for prop in attr.data[0].bl_rna.properties if len(attr.data) else []:
            if prop.identifier=='rna_type' or prop.type not in ('INT','FLOAT','BOOLEAN'):
                continue
            if attr.data_type in ('FLOAT_COLOR','BYTE_COLOR') and prop.identifier!=('color'if attr.data_type=='FLOAT_COLOR'else'color_srgb'):
                continue
            width=prop.array_length if getattr(prop,'is_array',False)else 1
            dtype=np.float32 if prop.type=='FLOAT'else np.int32 if prop.type=='INT'else np.bool_
            values=np.empty(len(attr.data)*width,dtype=dtype)
            attr.data.foreach_get(prop.identifier,values)
            props[prop.identifier]=values.reshape((-1,width))
        if not props:raise RuntimeError('Unmapped native attribute '+attr.name+' '+attr.data_type)
        result[attr.name]={'domain':attr.domain,'type':attr.data_type,'props':props}
    return result

def weighted(values, weights):
    out=[]
    for k in range(values.shape[1]):
        if values.dtype.kind in ('i','u','b'):
            selected={values[i,k].item()for i,w in weights if w}
            if len(selected)!=1:raise RuntimeError('Categorical source field differs across a new port')
            out.append(next(iter(selected)))
        else:
            out.append(float(sum(F(float(values[i,k]))*w for i,w in weights)))
    return np.asarray(out,dtype=values.dtype)

bpy.ops.wm.open_mainfile(filepath=str(BEFORE));obj=bpy.data.objects[OWNER];mesh=obj.data;mesh.calc_loop_triangles()
original_matrix=np.asarray(obj.matrix_world);original_attrs=numeric_attributes(mesh)
original_N=np.asarray([tuple(v.vector)for v in mesh.corner_normals],dtype=np.float32)
original_P=np.asarray([tuple(v.co)for v in mesh.vertices],dtype=np.float32)
source={}
for sid in (362,365):
    t=mesh.loop_triangles[sid-1];face=mesh.polygons[t.polygon_index]
    assert list(t.vertices)==list(face.vertices) and len(t.vertices)==3
    source[sid]={'face':face.index,'vertices':list(t.vertices),'loops':list(t.loops),
                 'edges':[mesh.loops[i].edge_index for i in t.loops],
                 'material':face.material_index,'smooth':face.use_smooth}
assert source[362]['vertices']==[32518,32639,32513]
assert source[365]['vertices']==[32518,32513,32639]
assert source[362]['edges']==[63879,63783,165192]
assert source[365]['edges']==[165193,63783,63879]
world_P=[tuple(obj.matrix_world@v.co)for v in mesh.vertices]
A,B,C=[world_P[i]for i in source[362]['vertices']]
assert all(p[1:]==CLIP[1:]for p in (A,B,C)) and A[0]<CLIP[0]<B[0]<C[0]
ab=(F(CLIP[0])-F(A[0]))/(F(B[0])-F(A[0]));ac=(F(CLIP[0])-F(A[0]))/(F(C[0])-F(A[0]))
assert ab==F(716368,862931) and ac==F(716368,1725861)
zero_corner_weights={362:[[(source[362]['loops'][0],1-ab),(source[362]['loops'][1],ab)],[(source[362]['loops'][1],F(1))],[(source[362]['loops'][2],F(1))],[(source[362]['loops'][0],1-ac),(source[362]['loops'][2],ac)]],
                     365:[[(source[365]['loops'][0],1-ac),(source[365]['loops'][1],ac)],[(source[365]['loops'][1],F(1))],[(source[365]['loops'][2],F(1))],[(source[365]['loops'][0],1-ab),(source[365]['loops'][2],ab)]]}

bpy.ops.wm.open_mainfile(filepath=str(INPUT));obj=bpy.data.objects[OWNER];mesh=obj.data
assert mesh.users==1 and mesh.shape_keys is None and np.array_equal(original_matrix,np.asarray(obj.matrix_world))
old_attrs=numeric_attributes(mesh);old_N=np.asarray([tuple(v.vector)for v in mesh.corner_normals],dtype=np.float32)
points=[tuple(v.co)for v in mesh.vertices];world=[tuple(obj.matrix_world@v.co)for v in mesh.vertices]
ports=[i for i,p in enumerate(world)if p==CLIP];assert len(ports)==1
p1=ports[0];cv=[i for i,p in enumerate(world)if p==C];assert len(cv)==1
c=cv[0];assert not any(p==B for p in world)
ids=mesh.attributes['Breakfast source triangle']
assert not any(v.value in (362,365)for v in ids.data)
face363=[f for f in mesh.polygons if ids.data[f.index].value==363 and p1 in f.vertices]
face364=[f for f in mesh.polygons if ids.data[f.index].value==364 and p1 in f.vertices]
caps=[f for f in mesh.polygons if ids.data[f.index].value==0 and p1 in f.vertices]
assert len(face363)==len(face364)==len(caps)==1
f363,f364,cap=face363[0],face364[0],caps[0]
assert c in f363.vertices and c in f364.vertices
faces=[list(f.vertices)for f in mesh.polygons]
face_edges=[[mesh.loops[li].edge_index for li in f.loop_indices]for f in mesh.polygons]
old_loops=[list(f.loop_indices)for f in mesh.polygons]
edges=[tuple(e.vertices)for e in mesh.edges]
old_counts={'POINT':len(points),'EDGE':len(edges),'FACE':len(faces),'CORNER':len(mesh.loops)}
longs=[ei for f in (f363,f364)for ei in face_edges[f.index]if set(edges[ei])=={p1,c}]
assert len(longs)==2 and longs[0]==longs[1];long1=longs[0]
cap_i=faces[cap.index].index(p1);prev=faces[cap.index][cap_i-1];following=faces[cap.index][(cap_i+1)%len(faces[cap.index])]
assert prev in f364.vertices and following in f363.vertices
cap_up=face_edges[cap.index][(cap_i-1)%len(faces[cap.index])]
assert set(edges[cap_up])=={prev,p1}
cap_down=face_edges[cap.index][cap_i]
assert set(edges[cap_down])=={p1,following}
p2=len(points);ps=p2+1;b=p2+2
points += [points[p1],points[p1],tuple(original_P[32639])]
edges[cap_up]=tuple(p2 if i==p1 else i for i in edges[cap_up])
long2=len(edges);edges.append((p2,c))
short=len(edges);edges.append((ps,b))
bc=len(edges);edges.append((b,c))
cut2=len(edges);edges.append((p2,ps))
cut1=len(edges);edges.append((ps,p1))
faces[f364.index]=[p2 if i==p1 else i for i in faces[f364.index]]
face_edges[f364.index]=[long2 if i==long1 else i for i in face_edges[f364.index]]
face_corners=[list(row)for row in old_loops]
faces[cap.index]=faces[cap.index][:cap_i]+[p2,ps,p1]+faces[cap.index][cap_i+1:]
face_corners[cap.index]=old_loops[cap.index][:cap_i]+[old_loops[cap.index][cap_i]]*3+old_loops[cap.index][cap_i+1:]
face_edges[cap.index]=face_edges[cap.index][:cap_i]+[cut2,cut1,cap_down]+face_edges[cap.index][cap_i+1:]
new_face_ids={362:len(faces),365:len(faces)+1}
faces += [[ps,b,c,p1],[p2,c,b,ps]]
face_edges += [[short,bc,long1,cut1],[long2,bc,short,cut2]]
face_corners += [[('source',362,i)for i in range(4)],[('source',365,i)for i in range(4)]]
assert len(faces)==len(face_edges)==len(face_corners)
for vs,es in zip(faces,face_edges):
 assert len(vs)==len(es)
 for i,ei in enumerate(es):assert set(edges[ei])=={vs[i],vs[(i+1)%len(vs)]},(vs,es,i,edges[ei])

output=mesh.copy();output.clear_geometry()
output.vertices.add(len(points));output.edges.add(len(edges));output.loops.add(sum(map(len,faces)));output.polygons.add(len(faces))
output.vertices.foreach_set('co',np.asarray(points,dtype=np.float32).reshape(-1))
output.edges.foreach_set('vertices',np.asarray(edges,dtype=np.int32).reshape(-1))
output.loops.foreach_set('vertex_index',np.asarray([i for face in faces for i in face],dtype=np.int32))
output.loops.foreach_set('edge_index',np.asarray([i for face in face_edges for i in face],dtype=np.int32))
output.polygons.foreach_set('loop_start',np.cumsum([0]+[len(vs)for vs in faces[:-1]],dtype=np.int32))
output.polygons.foreach_set('loop_total',np.asarray(list(map(len,faces)),dtype=np.int32))
output.polygons.foreach_set('material_index',[f.material_index for f in mesh.polygons]+[source[362]['material'],source[365]['material']])
output.polygons.foreach_set('use_smooth',[f.use_smooth for f in mesh.polygons]+[source[362]['smooth'],source[365]['smooth']])
output.update(calc_edges=False)
old_loop_map=[i for row in face_corners for i in row]
source_edge_map=[165193,63879,63783,None,None]
point_weights=[[(32518,1-ac),(32513,ac)],[(32518,1-ab),(32639,ab)],[(32639,F(1))]]
checks={}
for name,old in old_attrs.items():
    attr=output.attributes.get(name)or output.attributes.new(name,old['type'],old['domain'])
    assert(attr.data_type,attr.domain)==(old['type'],old['domain'])
    for prop,values in old['props'].items():
        if old['domain']=='CORNER':
            rows=[]
            for item in old_loop_map:
                if isinstance(item,int):rows.append(values[item])
                else:
                    _,sid,corner=item
                    if name=='custom_normal':original=original_N
                    else:
                        source_attr=original_attrs[name]
                        assert source_attr['domain']=='CORNER'and source_attr['type']==old['type']
                        original=source_attr['props'][prop]
                    rows.append(weighted(original,zero_corner_weights[sid][corner]))
            result=np.asarray(rows,dtype=values.dtype)
        elif old['domain']=='POINT':
            original=original_attrs[name]['props'][prop]
            # Two born ports keep the existing born-port provenance sentinel0;
            # restored B receives its exact original native-point metadata.
            result=np.concatenate([values,np.asarray([values[p1],values[p1],original[32639]])])
        elif old['domain']=='EDGE':
            original=original_attrs[name]['props'][prop]
            result=np.concatenate([values,np.asarray([original[i]if i is not None else np.zeros(values.shape[1],dtype=values.dtype)for i in source_edge_map])])
        elif old['domain']=='FACE':
            if name=='Breakfast source triangle':new=np.asarray([[362],[365]],dtype=values.dtype)
            else:
                original=original_attrs[name]['props'][prop];new=original[[source[362]['face'],source[365]['face']]]
            result=np.concatenate([values,new])
        else:raise RuntimeError('Unmapped native domain '+old['domain'])
        attr.data.foreach_set(prop,result.reshape(-1))
        checks[name+':'+prop]=int(values.size)
output.update(calc_edges=False)
obj.data=output
old_f364_index=f364.index;old_cap_index=cap.index
name=mesh.name;bpy.data.meshes.remove(mesh);output.name=name
bm=bmesh.new();bm.from_mesh(output)
bad=[e.index for e in bm.edges if not e.is_manifold or not e.is_contiguous]
bm.free()
if bad:raise RuntimeError('Exact restored native fan is not directedclosed: '+str(bad))
assert len(output.vertices)==old_counts['POINT']+3 and len(output.edges)==old_counts['EDGE']+5
output.calc_loop_triangles()
roles={'Plong1':p1,'Plong2':p2,'Pshort':ps,'B':b,'C':c}
proof={'scope':'PRIVATE exact directed source-fan insertion only; same physical tool and no positive-area source/cap geometry change. Independent full area/continuous1D/injectivefan/body gates still required.',
       'inputSha256':hashlib.sha256(INPUT.read_bytes()).hexdigest(),'originalSha256':hashlib.sha256(BEFORE.read_bytes()).hexdigest(),
       'source':source,'port':CLIP,'fractions':{'AB':str(ab),'AC':str(ac)},'roles':roles,'faces':new_face_ids,
       'changedExistingSourceFace':old_f364_index,'changedExistingCap':old_cap_index,'changedExistingBornCapEdge':cap_up,
       'originalLongEdgeIds':[165192,165193],'newParallelLongEdgeIds':[long1,long2],
       'newCounts':{'vertices':3,'edges':5,'polygons':2,'loops':10},'existingNumericFieldsCopied':checks,
       'insertedZeroCharts':[{'source':sid,'polygon':i,'vertices':list(output.polygons[i].vertices),'edges':[output.loops[li].edge_index for li in output.polygons[i].loop_indices],
                             'nativeP':[tuple(obj.matrix_world@output.vertices[v].co)for v in output.polygons[i].vertices],
                             'N':[tuple(output.corner_normals[li].vector)for li in output.polygons[i].loop_indices]}for sid,i in new_face_ids.items()],
       'directedBadEdges':bad}
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(Q/'candidate-v2.blend'),compress=True)
proof['candidateSha256']=hashlib.sha256((Q/'candidate-v2.blend').read_bytes()).hexdigest()
(Q/'FAN-INSERTION-V2.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'candidateSha256':proof['candidateSha256'],'newFaces':new_face_ids,'roles':roles,'badEdges':bad}))
