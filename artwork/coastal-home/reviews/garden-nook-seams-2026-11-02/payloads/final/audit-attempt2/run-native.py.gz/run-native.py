from pathlib import Path
q=Path(__file__).resolve().parent
for name in ('topology.py','bearings.py','native-census.py'):
    p=q/name;exec(compile(p.read_text(),str(p),'exec'),{'__file__':str(p),'__name__':'__audit__'})
