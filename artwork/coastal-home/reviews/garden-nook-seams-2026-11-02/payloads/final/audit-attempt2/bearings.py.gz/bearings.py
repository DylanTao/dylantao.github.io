from pathlib import Path
import hashlib
assert hashlib.sha256(Path('C:\\dev\\site-takeover-worktrees\\breakfast-nook-20261101\\.jekyll-cache\\visual-qa\\breakfast-nook-20261101\\combined-side-fan-control-v1\\candidate-attempt-1\\candidate.blend').read_bytes()).hexdigest() == '156b915b4754e6ce644e1a3c8fede8bc04c8ad1c7041c0d624b7c3d76d15260d'
import bpy, json, math
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
q = Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str('C:\\dev\\site-takeover-worktrees\\breakfast-nook-20261101\\.jekyll-cache\\visual-qa\\breakfast-nook-20261101\\combined-side-fan-control-v1\\candidate-attempt-1\\candidate.blend'))
scene = bpy.context.scene
names = ['core__golden coastal sandstone', 'coast_shared_golden coastal sandstone']
slabs = [o.name for o in scene.objects if 'bedchamber_slab' in o.name]
trees = {}
for name in names + slabs:
    o = scene.objects[name]
    m = o.data
    m.calc_loop_triangles()
    trees[name] = BVHTree.FromPolygons([o.matrix_world @ v.co for v in m.vertices], [tuple(t.vertices) for t in m.loop_triangles], all_triangles=True)

def cast(point, direction, owners):
    at = Vector((point[0], -point[2], point[1]))
    dr = Vector((direction[0], -direction[2], direction[1]))
    hits = []
    for name in owners:
        p, n, i, d = trees[name].ray_cast(at, dr, 12)
        if p is not None:
            hits.append({'owner': name, 'point': [p.x, p.z, -p.y], 'normal': [n.x, n.z, -n.y], 'face': i, 'distance': d})
    return min(hits, key=lambda r: r['distance']) if hits else None
pads = []
for z in (3.6, 6.4):
    for i in range(11):
        for j in range(11):
            x = -8.11 + 0.32 * (i + 0.01) / 10.02
            zz = z - 0.16 + 0.32 * (j + 0.01) / 10.02
            h = cast([x, -1.239, zz], [0, -1, 0], names)
            pads.append({'point': [x, -1.24, zz], 'hit': h, 'gap': h['distance'] - 0.001 if h else None})
beam = []
for i in range(5):
    for j in range(33):
        x = -8.05 + 0.2 * (i + 0.01) / 4.02
        z = 3.43 + 3.14 * (j + 0.01) / 32.02
        h = cast([x, 1.339, z], [0, 1, 0], slabs)
        beam.append({'point': [x, 1.34, z], 'hit': h, 'gap': h['distance'] - 0.001 if h else None})
floor = []
for i in range(13):
    for j in range(17):
        x = -7.85 + 2.4 * (i + 0.01) / 12.02
        z = 3.4 + 3.2 * (j + 0.01) / 16.02
        h = cast([x, -1.179, z], [0, -1, 0], names)
        floor.append({'point': [x, -1.18, z], 'hit': h, 'gap': h['distance'] - 0.001 if h else None})
result = {'scope': 'Actual native ray/contact samples on source-bound guarded replayV2; geometric bearing only, no engineering capacity claim. All misses retained.', 'sourceSha256': __import__('hashlib').sha256(Path('C:\\dev\\site-takeover-worktrees\\breakfast-nook-20261101\\.jekyll-cache\\visual-qa\\breakfast-nook-20261101\\combined-side-fan-control-v1\\candidate-attempt-1\\candidate.blend').read_bytes()).hexdigest(), 'slabOwners': slabs, 'pads': pads, 'beamTop': beam, 'floorUnderside': floor, 'summary': {key: {'samples': len(rows), 'within3um': sum((r['gap'] is not None and abs(r['gap']) <= 3e-06 for r in rows)), 'maxGap': max((r['gap'] for r in rows if r['gap'] is not None), default=None), 'missing': sum((r['hit'] is None for r in rows))} for key, rows in [('pads', pads), ('beamTop', beam), ('floorUnderside', floor)]}}
(q / 'NATIVE-REPLAY-V2-BEARING.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result['summary']))
