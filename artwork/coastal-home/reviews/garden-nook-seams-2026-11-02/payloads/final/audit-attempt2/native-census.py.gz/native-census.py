import bpy, json, gzip, hashlib
from pathlib import Path
q = Path(__file__).resolve().parent
AFTER = Path('C:\\dev\\site-takeover-worktrees\\breakfast-nook-20261101\\.jekyll-cache\\visual-qa\\breakfast-nook-20261101\\combined-side-fan-control-v1\\candidate-attempt-1\\candidate.blend')
assert hashlib.sha256(AFTER.read_bytes()).hexdigest() == '156b915b4754e6ce644e1a3c8fede8bc04c8ad1c7041c0d624b7c3d76d15260d'
bpy.ops.wm.open_mainfile(filepath=str(AFTER))
region = ((-8.5, -1.4, 1), (-1.8, 3.2, 8.3))
triangles = []
owners = []
hidden = []
for obj in bpy.context.scene.objects:
    if obj.type != 'MESH':
        continue
    if obj.hide_render:
        hidden.append(obj.name)
        continue
    m = obj.data
    m.calc_loop_triangles()
    p = [obj.matrix_world @ v.co for v in m.vertices]
    bounds = [(min((v[k] for v in p)), max((v[k] for v in p))) for k in range(3)] if p else []
    if not bounds:
        continue
    wb = [bounds[0], bounds[2], (-bounds[1][1], -bounds[1][0])]
    if any((wb[k][1] < region[0][k] or wb[k][0] > region[1][k] for k in range(3))):
        continue
    count = 0
    for t in m.loop_triangles:
        vertices = [[p[i].x, p[i].z, -p[i].y] for i in t.vertices]
        if any((max((v[k] for v in vertices)) < region[0][k] or min((v[k] for v in vertices)) > region[1][k] for k in range(3))):
            continue
        material = m.materials[t.material_index].name if m.materials and m.materials[t.material_index] else ''
        triangles.append({'owner': obj.name, 'triangle': t.index, 'polygon': t.polygon_index, 'material': material, 'points': vertices})
        count += 1
    owners.append({'owner': obj.name, 'includedTriangles': count})
(q / 'NATIVE-REGION-TRIANGLES.json.gz').write_bytes(gzip.compress(json.dumps({'sourceSha256': hashlib.sha256(AFTER.read_bytes()).hexdigest(), 'region': region, 'owners': owners, 'hiddenRenderOwnersExcluded': hidden, 'triangles': triangles}, separators=(',', ':')).encode()))
print('REGION TRIANGLES', len(triangles))
