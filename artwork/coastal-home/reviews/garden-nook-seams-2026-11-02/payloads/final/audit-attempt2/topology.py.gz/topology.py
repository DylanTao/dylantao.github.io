from pathlib import Path
import hashlib
assert hashlib.sha256(Path('C:\\dev\\site-takeover-worktrees\\breakfast-nook-20261101\\.jekyll-cache\\visual-qa\\breakfast-nook-20261101\\combined-side-fan-control-v1\\candidate-attempt-1\\candidate.blend').read_bytes()).hexdigest() == '156b915b4754e6ce644e1a3c8fede8bc04c8ad1c7041c0d624b7c3d76d15260d'
import bpy
import bmesh
import hashlib
import json
from pathlib import Path
q = Path(__file__).resolve().parent
source = Path('C:\\dev\\site-takeover-worktrees\\breakfast-nook-20261101\\.jekyll-cache\\visual-qa\\breakfast-nook-20261101\\combined-side-fan-control-v1\\candidate-attempt-1\\candidate.blend')
bpy.ops.wm.open_mainfile(filepath=str(source))
names = ['core__golden coastal sandstone', 'coast_shared_golden coastal sandstone', 'core_reno_slab_ground', 'core_reno_floorboards_lower', 'core_finish_bedchamber_rock_fin__La Jolla bluff sandstone']
names += [o.name for o in bpy.context.scene.objects if o.type == 'MESH' and o.name.startswith(('core_breakfast_nook__', 'core_breakfast_window__')) and ('olive leaf' not in o.name)]
names += ['kitchen_nook_olive_stem__honey ash', 'kitchen_nook_olive_pot__terracotta']
rows = []
for name in names:
    obj = bpy.data.objects[name]
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    row = {'object': name, 'vertices': len(bm.verts), 'faces': len(bm.faces), 'boundaryEdges': sum((e.is_boundary for e in bm.edges)), 'nonManifoldEdges': sum((not e.is_manifold for e in bm.edges)), 'inconsistentWindingEdges': sum((e.is_manifold and (not e.is_contiguous) for e in bm.edges)), 'zeroAreaFaces': sum((f.calc_area() == 0 for f in bm.faces))}
    bm.free()
    rows.append(row)
    assert row['nonManifoldEdges'] == row['inconsistentWindingEdges'] == 0, row
(q / 'R6-DIRECTED-TOPOLOGY.json').write_text(json.dumps({'scope': 'Private R6 source, all5 cut owners plus new solid structure/window/pot pieces. Open curved leaves excluded explicitly. Original degenerate sheets retained rather than pruned. No renderer/final F6/native admission.', 'sourceSha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'rows': rows}, indent=2) + '\n', encoding='utf-8')
print('PASS', len(rows), 'named source owners')
