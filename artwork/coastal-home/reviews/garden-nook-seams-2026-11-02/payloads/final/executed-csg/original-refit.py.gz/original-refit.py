"""Certify float32 split points against every incident original triangle."""
import itertools,math,numpy as np
from mathutils import Vector
def refit_split_points(obj,fields,kernel):
    mesh=obj.data;ids=mesh.attributes['Arrival source triangle'].data
    incident={};exact={}
    for sid,row in fields['triangles'].items():
        for p in row['p']:exact.setdefault(tuple(p),set()).add(sid)
    for face in mesh.polygons:
        sid=ids[face.index].value
        if sid>0:
            for vi in face.vertices:incident.setdefault(vi,set()).add(sid)
    def closest(p,t):
        w=kernel.barycentric(p,t)
        if w is not None and min(w)>=0:return np.asarray(w)@t
        candidates=[]
        for a,b in zip(t,np.roll(t,-1,axis=0)):
            d=b-a;q=float(d@d);f=max(0,min(1,float((p-a)@d)/q)) if q else 0
            candidates.append(a+f*d)
        return min(candidates,key=lambda at:float(np.linalg.norm(at-p)))
    moved=[]
    for vi,sources in incident.items():
        p=np.asarray(obj.matrix_world@mesh.vertices[vi].co,dtype=np.float64)
        if sources<=exact.get(tuple(p),set()):continue
        ts=[fields['triangles'][sid]['p'] for sid in sources]
        error=lambda point:max(kernel.triangle_distance(point,t) for t in ts)
        before=error(p)
        if before<=1.5e-6:continue
        if before>1e-4:raise RuntimeError('Genuine source surface change, not rounding: '+str((obj.name,vi,before)))
        fitted=p.copy()
        for _ in range(12):fitted=np.mean([closest(fitted,t) for t in ts],axis=0)
        neighbors=[]
        for v in fitted:
            f=np.float32(v);neighbors.append([float(np.nextafter(f,np.float32(-math.inf))),float(f),float(np.nextafter(f,np.float32(math.inf)))])
        candidates=[(error(np.asarray(at)),float(np.linalg.norm(np.asarray(at)-p)),at) for at in itertools.product(*neighbors)]
        residual,delta,at=min(candidates)
        if residual>3e-6:raise RuntimeError('No float32 point satisfies original3um surfaces: '+str((obj.name,vi,before,residual)))
        if delta:
            mesh.vertices[vi].co=obj.matrix_world.inverted()@Vector(at)
            moved.append({'vertex':vi,'sourceTriangles':sorted(sources),'beforeDistance':before,'afterDistance':residual,'displacement':delta})
    mesh.update()
    return moved
