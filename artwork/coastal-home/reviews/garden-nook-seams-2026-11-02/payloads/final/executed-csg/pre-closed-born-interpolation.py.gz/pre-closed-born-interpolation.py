def guarded_manifold_cut(tool,targets):
    bpy.context.view_layer.update()
    for name,kind,domain in [('Breakfast source triangle','INT','FACE')]:
        if not tool.data.attributes.get(name):tool.data.attributes.new(name,kind,domain)
    corners=[tool.matrix_world@Vector(v) for v in tool.bound_box]
    lo=[min(v[k] for v in corners) for k in range(3)];hi=[max(v[k] for v in corners) for k in range(3)]
    limit=old._volume(tool)*1.02+.05;results=[]
    for obj in targets:
        bounds=[obj.matrix_world@Vector(v) for v in obj.bound_box]
        a=[min(v[k] for v in bounds) for k in range(3)];b=[max(v[k] for v in bounds) for k in range(3)]
        if not all(a[k]<=hi[k] and b[k]>=lo[k] for k in range(3)):continue
        control=bmesh.new();control.from_mesh(obj.data)
        bad=sum(not e.is_manifold for e in control.edges);control.free()
        if bad:raise RuntimeError(f'Closed-input Manifold control fails on {obj.name}: {bad}')
        if obj.name=='core_retreat_liftaway_roof':
            from mathutils.bvhtree import BVHTree
            def actual_tree(owner):
                owner.data.calc_loop_triangles()
                return BVHTree.FromPolygons([owner.matrix_world@v.co for v in owner.data.vertices],
                    [tuple(t.vertices) for t in owner.data.loop_triangles],all_triangles=True)
            def inside(tree,point):
                direction=Vector((.78241,.56321,.26519)).normalized();start=point.copy();hits=0
                for _ in range(4096):
                    hit,_,_,_=tree.ray_cast(start,direction,1000)
                    if hit is None:return hits%2==1
                    hits+=1;start=hit+direction*.00001
                raise RuntimeError('Ray parity failed to terminate')
            ot,tt=actual_tree(obj),actual_tree(tool)
            contacts=ot.overlap(tt)
            if not contacts and not any(inside(ot,tool.matrix_world@v.co) for v in tool.data.vertices) and not inside(tt,obj.matrix_world@obj.data.vertices[0].co):
                # AABB overlap alone reaches this remote roof. Its one connected
                # closed island and the closed tool are surface-disjoint, and
                # neither contains the other. Keep all original fields exact.
                results.append({'object':obj.name,'skippedProvenDisjoint':True,'surfacePairs':0,'toolVerticesOutside':len(tool.data.vertices)})
                continue
        if obj.name not in original_fields:
            print('CUSTODY_INPUT',obj.name,flush=True)
            original_fields[obj.name]=source_fields(obj)
            triangulate_native_render_faces(obj.data,raw_normals)
        before=old._volume(obj);saved=obj.data.copy()
        modifier=obj.modifiers.new('private closed-input straight arrival','BOOLEAN')
        modifier.operation='DIFFERENCE';modifier.solver='MANIFOLD';modifier.object=tool
        bpy.context.view_layer.objects.active=obj;bpy.ops.object.modifier_apply(modifier=modifier.name)
        _s=importlib.util.spec_from_file_location('breakfast_boundary',parts_dir/'boundary.py');_u=importlib.util.module_from_spec(_s);_s.loader.exec_module(_u)
        restore_original_outside=_u.restore_original_outside
        try:
            outside_custody=restore_original_outside(obj,saved,Vector(lo),Vector(hi),tool=tool)
        except RuntimeError:
            bm=bmesh.new();bm.from_mesh(obj.data);edges=[]
            ids=bm.faces.layers.int.get('Breakfast source triangle')
            for e in bm.edges:
                if not e.is_manifold:
                    edges.append({'points':[list(obj.matrix_world@v.co) for v in e.verts],'length':e.calc_length(),
                                  'faces':[{'sourceTriangle':f[ids] if ids else None,'points':[list(obj.matrix_world@v.co) for v in f.verts]} for f in e.link_faces]})
            bm.free()
            (qa/'boundary-failure.json').write_text(json.dumps({'object':obj.name,'cutBounds':[lo,hi],'edges':edges},indent=2)+'\n')
            bpy.ops.wm.save_as_mainfile(filepath=str(qa/'DIAGNOSTIC-open-boundary.blend'),compress=True)
            raise
        control=bmesh.new();control.from_mesh(obj.data);bad=sum(not e.is_manifold for e in control.edges);control.free()
        lost=before-old._volume(obj)
        if bad or lost < -.05 or lost > limit:
            rejected=obj.data;obj.data=saved;bpy.data.meshes.remove(rejected)
            raise RuntimeError(f'Manifold result rejected: {obj.name}, open={bad}, removed={lost}, limit={limit}')
        if abs(lost) < 1e-8:
            # A disjoint Boolean may retriangulate nonplanar inherited n-gons.
            # Restore its exact original rather than accepting a needless rewrite.
            no_op=obj.data;obj.data=saved;bpy.data.meshes.remove(no_op)
            results.append({'object':obj.name,'removedVolume':lost,'nonManifoldEdges':bad,'restoredExactNoop':True})
        else:
            import numpy as np
            _rs=importlib.util.spec_from_file_location('breakfast_refit',parts_dir/'refit.py');_r=importlib.util.module_from_spec(_rs);_rs.loader.exec_module(_r)
            refit=_r.refit_split_points(obj,original_fields[obj.name],exact_fields)
            values=np.asarray([tuple(v.vector) for v in obj.data.corner_normals],dtype=np.float64)
            own=obj.data.attributes.get('Breakfast source triangle')
            if own is None:raise RuntimeError('CSG dropped original triangle custody')
            color=obj.data.color_attributes.active_color
            if color is None:
                color=obj.data.color_attributes.new('Breakfast neutral source color','FLOAT_COLOR','CORNER')
                for dst in color.data:dst.color=(1.,1.,1.,1.)
                obj.data.color_attributes.active_color=color
            if color.domain!='CORNER':raise RuntimeError('Unmapped original corner color')
            restored=0;maximum_distance=0.
            for face in obj.data.polygons:
                sid=own.data[face.index].value
                if sid<=0:
                    for li in face.loop_indices:values[li]=tuple(face.normal)
                    continue
                source=original_fields[obj.name]['triangles'][sid]
                points=[tuple(v) for v in source['p']]
                original_indices=list(face.loop_indices)
                actual_points=[tuple(obj.matrix_world@obj.data.vertices[obj.data.loops[li].vertex_index].co)for li in original_indices]
                cycle=next((k for k in range(3)if len(actual_points)==3 and actual_points==points[-k:]+points[:-k]),None)
                for corner,li in enumerate(original_indices):
                    at=tuple(obj.matrix_world@obj.data.vertices[obj.data.loops[li].vertex_index].co)
                    if cycle is not None:
                        k=(corner-cycle)%3;weights=np.zeros(3);weights[k]=1.
                    elif at in points:
                        k=points.index(at);weights=np.zeros(3);weights[k]=1.
                    else:
                        distance=exact_fields.triangle_distance(at,source['p']);maximum_distance=max(maximum_distance,distance)
                        if distance>3e-6:raise RuntimeError('Original source plane left its support: '+str((obj.name,sid,at,distance)))
                        weights=np.asarray(exact_fields.barycentric(at,source['p']))
                        if weights.shape!=(3,) or not np.all(np.isfinite(weights)):raise RuntimeError('Invalid source affine weights')
                    values[li]=weights@source['n']
                    color.data[li].color=weights@source['c']
                    restored+=1
            raw_normals(obj.data,values)
            bpy.data.meshes.remove(saved)
            results.append({'object':obj.name,'removedVolume':lost,'nonManifoldEdges':bad,'restoredExactNoop':False,'sourceCornersRestored':restored,'outsideCustody':outside_custody,'splitPointRefits':refit})
    bpy.data.objects.remove(tool,do_unlink=True)
    return results
