"""Physical cutter-local reconstruction; retain every uninvolved native triangle."""
import bpy,bmesh,json
from mathutils import Vector
from mathutils.bvhtree import BVHTree

def restore_original_outside(target,original_mesh,lo,hi,tool=None,**unused):
    assert tool is not None
    original_mesh.calc_loop_triangles();tool.data.calc_loop_triangles()
    points=[target.matrix_world@v.co for v in original_mesh.vertices]
    triangles=[tuple(t.vertices) for t in original_mesh.loop_triangles]
    toolpoints=[tool.matrix_world@v.co for v in tool.data.vertices]
    tooltriangles=[tuple(t.vertices) for t in tool.data.loop_triangles]
    source=original_mesh.attributes['Arrival source triangle']
    tree=BVHTree.FromPolygons(points,triangles,all_triangles=True)
    cuttree=BVHTree.FromPolygons(toolpoints,tooltriangles,all_triangles=True)
    pairs=tree.overlap(cuttree)
    touched={source.data[original_mesh.loop_triangles[i].polygon_index].value for i,j in pairs}
    def inside(point):
        if not all(lo[k]-1e-6<=point[k]<=hi[k]+1e-6 for k in range(3)):return False
        nearest=cuttree.find_nearest(point)
        if nearest[0] is not None and nearest[3]<=1e-6:return True
        d=Vector((.78241,.56321,.26519)).normalized();start=point.copy();hits=0
        for _ in range(4096):
            p,_,_,_=cuttree.ray_cast(start,d,1000)
            if p is None:return hits%2==1
            hits+=1;start=p+d*.00001
        raise RuntimeError('Closed cutter parity did not terminate')
    inside_vertices={i for i,p in enumerate(points) if inside(p)}
    for t in original_mesh.loop_triangles:
        if any(i in inside_vertices for i in t.vertices):touched.add(source.data[t.polygon_index].value)
    old=bmesh.new();old.from_mesh(original_mesh)
    new=bmesh.new();new.from_mesh(target.data)
    bmesh.ops.transform(old,matrix=target.matrix_world,verts=list(old.verts))
    bmesh.ops.transform(new,matrix=target.matrix_world,verts=list(new.verts))
    own=old.faces.layers.int.get('Arrival source triangle');newown=new.faces.layers.int.get('Arrival source triangle')
    assert own and newown
    retained=old.verts.layers.int.new('Arrival retained outside')
    originalid=old.verts.layers.int.new('Arrival original chart')
    fullids={}
    for i,v in enumerate(old.verts):
        v[retained]=1;v[originalid]=i+1;fullids[i+1]={f[own] for f in v.link_faces if f[own]>0}
    bmesh.ops.delete(old,geom=[f for f in old.faces if f[own] in touched],context='FACES')
    bmesh.ops.delete(new,geom=[f for f in new.faces if f[newown]>0 and f[newown] not in touched],context='FACES')
    old_count=len(old.faces);new_count=len(new.faces)
    temp=bpy.data.meshes.new('actual cutter interior only');new.to_mesh(temp);new.free();old.from_mesh(temp);bpy.data.meshes.remove(temp)
    def ids(v):
        if v[retained]:return fullids[v[originalid]]
        return {f[own] for f in v.link_faces if f[own]>0}
    def weld():
        keep=[v for v in old.verts if v[retained] and any(e.is_boundary for e in v.link_edges)]
        insert=[v for v in old.verts if not v[retained] and any(e.is_boundary for e in v.link_edges)]
        mapping={}
        # Exact boundary charts are selected by the complete original incident IDs.
        for v in insert:
            close=[a for a in keep if (a.co-v.co).length<=3e-6]
            if not close:continue
            shared=ids(v);ranked=sorted(close,key=lambda a:(-len(ids(a)&shared),(a.co-v.co).length,a.index))
            if len(ranked)>1 and len(ids(ranked[0])&shared)==len(ids(ranked[1])&shared):
                raise RuntimeError('Ambiguous cutter-local chart '+json.dumps({'point':list(v.co),'new':sorted(shared),'old':[sorted(ids(a)) for a in ranked]}))
            mapping[v]=ranked[0]
        if mapping:bmesh.ops.weld_verts(old,targetmap=mapping)
        return len(mapping)
    welded=weld();boundary=[e for e in old.edges if e.is_boundary];verts=list({v for e in boundary for v in e.verts});splits=0
    for edge in list(boundary):
        if not edge.is_valid:continue
        a,b=edge.verts;d=b.co-a.co;length2=d.length_squared
        if length2<1e-12:continue
        on=[]
        for v in verts:
            if v in (a,b):continue
            t=(v.co-a.co).dot(d)/length2
            if 1e-5<t<1-1e-5 and (v.co-(a.co+d*t)).length<=3e-6:on.append((t,v.co.copy()))
        previous=a
        for t,point in sorted(on,key=lambda r:r[0]):
            if not edge.is_valid:break
            rel=(point-previous.co).length/(b.co-previous.co).length
            newedge,v=bmesh.utils.edge_split(edge,previous,rel);v.co=point;splits+=1
            edge=next((e for e in v.link_edges if b in e.verts),newedge);previous=v
    welded+=weld()
    trash=[v for v in old.verts if not v.link_faces]
    if trash:bmesh.ops.delete(old,geom=trash,context='VERTS')
    bad=[e for e in old.edges if not e.is_manifold]
    report={'method':'Only source triangles intersecting the actual closed cutter or containing cutter-interior vertices are reconstructed; every other native triangle is exact. No global bounding-box CSG admission.',
      'sourceTrianglesTouched':len(touched),'sourceTriangleIDs':sorted(touched),'bvhSurfacePairs':len(pairs),'insideVertices':len(inside_vertices),'retainedFaces':old_count,'solvedFaces':new_count,'boundaryWelds':welded,'boundarySplits':splits,'nonmanifoldEdges':len(bad)}
    print('CUTTER_LOCAL_CUSTODY',json.dumps({k:v for k,v in report.items() if k!='sourceTriangleIDs'}),flush=True)
    bmesh.ops.transform(old,matrix=target.matrix_world.inverted(),verts=list(old.verts))
    old.verts.layers.int.remove(retained);old.verts.layers.int.remove(originalid);old.to_mesh(target.data);old.free();target.data.update()
    if bad:raise RuntimeError('Cutter-local reconstruction has '+str(len(bad))+' unjoined edges')
    return report
