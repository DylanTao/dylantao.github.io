import bpy, hashlib, json, gzip, numpy as np, ast, array
from pathlib import Path
from mathutils import Matrix, Vector
from mathutils.bvhtree import BVHTree
q = Path(__file__).resolve().parent
BEFORE = Path('C:\\dev\\dylantao.github.io\\.jekyll-cache\\visual-qa\\final-house-integration-20261102\\olive-v1\\candidate.blend')
AFTER = Path('C:\\dev\\site-takeover-worktrees\\breakfast-nook-20261101\\.jekyll-cache\\visual-qa\\breakfast-nook-20261101\\combined-side-fan-control-v1\\candidate-attempt-1\\candidate.blend')
CONTROL = Path('C:\\dev\\site-takeover-worktrees\\breakfast-nook-20261101\\.jekyll-cache\\visual-qa\\breakfast-nook-20261101\\composed-rigid-r9\\candidate.blend')
REPLAY = Path('C:\\dev\\site-takeover-worktrees\\breakfast-nook-20261101\\.jekyll-cache\\visual-qa\\breakfast-nook-20261101\\combined-side-fan-control-v1\\candidate-attempt-1\\REPLAY.json')
actions = json.loads(REPLAY.read_text())['furniture']
olive = [a for a in actions if a['action'] in ('whole-olive', 'split-whole-olive')]
records = {}
normal_rows = []

def numeric(attr):
    result = {}
    if not len(attr.data):
        return result
    for prop in attr.data[0].bl_rna.properties:
        if prop.identifier == 'rna_type' or prop.type not in ('INT', 'FLOAT', 'BOOLEAN'):
            continue
        width = prop.array_length if getattr(prop, 'is_array', False) else 1
        values = np.empty(len(attr.data) * width, dtype=np.float32 if prop.type == 'FLOAT' else np.int32 if prop.type == 'INT' else np.bool_)
        attr.data.foreach_get(prop.identifier, values)
        result[prop.identifier] = values.reshape((-1, width))
    return result
fingerprint = Path('C:\\dev\\site-takeover-worktrees\\breakfast-nook-20261101\\artwork\\coastal-home\\reviews\\bedroom-ambience-2026-11-01\\replay_lighting.py')
tree = ast.parse(fingerprint.read_text())
for node in tree.body:
    if isinstance(node, ast.FunctionDef) and node.name in ('stream', 'geometry', 'native_state', 'materials'):
        exec(compile(ast.Module(body=[node], type_ignores=[]), 'retained exact native fingerprint', 'exec'))
bpy.ops.wm.open_mainfile(filepath=str(CONTROL))
control_state = native_state()
control_materials = materials()
bpy.ops.wm.open_mainfile(filepath=str(BEFORE))
for name in sorted({a['object'] for a in olive}):
    obj = bpy.data.objects[name]
    m = obj.data
    selected = [a for a in olive if a['object'] == name]
    delivery = {a['deliveryObject'] for a in selected}
    assert len(delivery) == 1
    delivery = next(iter(delivery))
    split = delivery != name
    faces = sorted({i for a in selected for i in a['faces']})
    vertices = sorted({v for i in faces for v in m.polygons[i].vertices})
    loops = [li for i in faces for li in m.polygons[i].loop_indices]
    edges = sorted({m.loops[li].edge_index for li in loops})
    vm = {i: k for k, i in enumerate(vertices)} if split else {i: i for i in vertices}
    indices = {'POINT': vertices, 'CORNER': loops, 'FACE': faces, 'EDGE': edges}
    if not split:
        assert faces == list(range(len(m.polygons)))
    records[name] = {'delivery': delivery, 'split': split, 'faces': faces, 'newFaces': list(range(len(faces))) if split else faces, 'oldPoints': vertices, 'newPoints': list(range(len(vertices))) if split else vertices, 'localP': np.array([tuple(m.vertices[i].co) for i in vertices]), 'oldWorld': np.array([tuple(obj.matrix_world @ m.vertices[i].co) for i in vertices]), 'edges': [tuple((vm[i] for i in m.edges[e].vertices)) for e in edges], 'winding': [tuple((vm[i] for i in m.polygons[f].vertices)) for f in faces], 'normal': np.array([tuple(m.corner_normals[i].vector) for i in loops]), 'attrs': {a.name: {'type': a.data_type, 'domain': a.domain, 'fields': {k: v[indices[a.domain]].copy() for k, v in numeric(a).items()}} for a in m.attributes if not a.name.startswith('.') and a.name != 'position'}, 'matrix': np.array(obj.matrix_world), 'expectedMatrix': np.array(Matrix.Translation(Vector((-2.44, -2.49, -0.6))) @ obj.matrix_world), 'materials': [a.name for a in m.materials]}
bpy.ops.wm.open_mainfile(filepath=str(AFTER))
rows = []
after_state = native_state()
after_materials = materials()
changed_owners = set(records)
new_nodes = {r['delivery'] for r in records.values() if r['split']}
assert len(new_nodes) == 2
assert set(after_state) == set(control_state) | new_nodes
changed_cut_owners = {'core__golden coastal sandstone','coast_shared_golden coastal sandstone','core_reno_slab_ground','core_reno_floorboards_lower','core_finish_bedchamber_rock_fin__La Jolla bluff sandstone','core_breakfast_nook__warm cut stone'}
unaffected = [n for n in control_state if n not in changed_owners and n not in changed_cut_owners]
assert all((after_state[n] == control_state[n] for n in unaffected)), [n for n in unaffected if after_state[n] != control_state[n]]
assert after_materials == control_materials
for name, r in records.items():
    obj = bpy.data.objects[r['delivery']]
    m = obj.data
    assert np.array_equal(np.array(obj.matrix_world), r['expectedMatrix']), (name, 'matrix')
    assert [a.name for a in m.materials] == r['materials']
    assert [tuple(m.polygons[f].vertices) for f in r['newFaces']] == r['winding']
    local = np.array([tuple(m.vertices[i].co) for i in r['newPoints']])
    assert np.array_equal(local, r['localP']), (name, 'localP')
    actual = np.array([tuple(obj.matrix_world @ m.vertices[i].co) for i in r['newPoints']])
    error = float(np.max(np.abs(actual - r['oldWorld'] - np.array([-2.44, -2.49, -0.6]))))
    assert error <= 3e-06, (name, error)
    loops = [li for i in r['newFaces'] for li in m.polygons[i].loop_indices]
    pairs = {tuple(sorted(e.vertices)): e.index for e in m.edges}
    edges = [pairs[tuple(sorted(e))] for e in r['edges']]
    indices = {'POINT': r['newPoints'], 'CORNER': loops, 'FACE': r['newFaces'], 'EDGE': edges}
    checks = 0
    for key, a in r['attrs'].items():
        attr = m.attributes[key]
        assert (attr.data_type, attr.domain) == (a['type'], a['domain'])
        for field, original in a['fields'].items():
            current = numeric(attr)[field][indices[a['domain']]]
            assert np.array_equal(original, current), (name, key, field)
            checks += original.size
    normal = np.array([tuple(m.corner_normals[i].vector) for i in loops])
    assert np.array_equal(normal, r['normal']), (name, 'resolvedN')
    assert np.array_equal(np.array(obj.matrix_world)[:3, :3], r['matrix'][:3, :3])
    normal_rows.append({'sourceOwner': name, 'deliveredOwner': r['delivery'], 'original': r['normal'].tolist(), 'candidate': normal.tolist()})
    rows.append({'sourceOwner': name, 'deliveredOwner': r['delivery'], 'splitOwnedIslands': r['split'], 'faces': len(r['faces']), 'vertices': len(r['newPoints']), 'localPExact': True, 'maximumRigidWorldTranslationResidualM': error, 'windingExact': True, 'resolvedLocalAndWorldNormalsExact': True, 'otherNumericComponentsExact': int(checks), 'expectedMatrixAndMaterialSlotsExact': True})
receipt = {'scope': 'Private V513+exact-membership+twofan156b native custody versus original olive input and frozen R9. All whole olive local P/N/attributes/winding exact; all other original/nonplant objects except exactly five cut owners and NEW keyed stone are exact against R9. Those six intentionally changed owners remain subject to independent unchanged whole-area/zero-field gates; no AO/export/render/admission claim.', 'beforeSha256': hashlib.sha256(BEFORE.read_bytes()).hexdigest(), 'afterSha256': hashlib.sha256(AFTER.read_bytes()).hexdigest(), 'failedControlSha256': hashlib.sha256(CONTROL.read_bytes()).hexdigest(), 'actionIslands': len(olive), 'newNodes': sorted(new_nodes), 'existingNonplantControlMeshesExact': len(unaffected), 'rows': rows}
(q / 'WHOLE-OLIVE-RIGID-EXACT.json').write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
(q / 'WHOLE-OLIVE-RESOLVED-NORMALS.json.gz').write_bytes(gzip.compress(json.dumps(normal_rows).encode()))
print('OLIVE EXACT', len(rows), 'owners', len(olive), 'islands', 'nonplant exact', len(unaffected), 'maxWorldP', max((r['maximumRigidWorldTranslationResidualM'] for r in rows)))
obj = bpy.data.objects['core_breakfast_nook__warm cut stone']
m = obj.data
m.calc_loop_triangles()
tree = BVHTree.FromPolygons([obj.matrix_world @ v.co for v in m.vertices], [tuple(t.vertices) for t in m.loop_triangles], all_triangles=True)
foot_rows = []
for x, z in [(-7.848003327787021, 3.6017478152309614), (-7.848003327787021, 6.398252184769039)]:
    at = Vector((x, -z, -1.0))
    hits = []
    for i in range(8):
        p, n, face, d = tree.ray_cast(at, Vector((0, 0, -1)), 0.3)
        if p is None:
            break
        hits.append({'nativeTriangle': face, 'world': [p.x, p.z, -p.y], 'normal': [n.x, n.z, -n.y]})
        at = p + Vector((0, 0, -1e-06))
    levels = [h['world'][1] for h in hits]
    expected = [-1.02, -1.14, -1.18, -1.24]
    assert len(levels) == 4 and all((abs(a - b) < 1e-06 for a, b in zip(levels, expected))), levels
    overlap = levels[1] - levels[2]
    assert overlap > 0.03999
    foot_rows.append({'xz': [x, z], 'hits': hits, 'actualFloorFootingOverlapM': overlap})
(q / 'FLOOR-FOOTING-LOAD-PATH.json').write_bytes((json.dumps({'scope': 'Actual composed closed native floor and footing vertical surface intervals at both retained direct-rock6cm misses. Floor[-1.18,-1.02] and footing[-1.24,-1.14] overlap4cm;242footpad direct-rock samples are separate. Geometric load path only, no engineering certification.', 'sourceSha256': receipt['afterSha256'], 'rows': foot_rows}, indent=2) + '\n').encode())
print('FOOTING OVERLAP', [r['actualFloorFootingOverlapM'] for r in foot_rows])
region = ((-8.5, -1.4, 1), (-2.3, 3, 8.1))
triangles = []
owners = []
hidden = []
for obj in bpy.context.scene.objects:
    if obj.type != 'MESH':
        continue
    if obj.hide_render:
        hidden.append(obj.name)
        continue
    m = obj.data
    m.calc_loop_triangles()
    p = [obj.matrix_world @ v.co for v in m.vertices]
    bounds = [(min((v[k] for v in p)), max((v[k] for v in p))) for k in range(3)] if p else []
    if not bounds:
        continue
    wb = [bounds[0], bounds[2], (-bounds[1][1], -bounds[1][0])]
    if any((wb[k][1] < region[0][k] or wb[k][0] > region[1][k] for k in range(3))):
        continue
    count = 0
    for t in m.loop_triangles:
        vertices = [[p[i].x, p[i].z, -p[i].y] for i in t.vertices]
        if any((max((v[k] for v in vertices)) < region[0][k] or min((v[k] for v in vertices)) > region[1][k] for k in range(3))):
            continue
        material = m.materials[t.material_index].name if m.materials and m.materials[t.material_index] else ''
        triangles.append({'owner': obj.name, 'triangle': t.index, 'polygon': t.polygon_index, 'material': material, 'points': vertices})
        count += 1
    owners.append({'owner': obj.name, 'includedTriangles': count})
(q / 'NATIVE-REGION-TRIANGLES.json.gz').write_bytes(gzip.compress(json.dumps({'sourceSha256': receipt['afterSha256'], 'region': region, 'owners': owners, 'hiddenRenderOwnersExcluded': hidden, 'triangles': triangles}, separators=(',', ':')).encode()))
print('REGION TRIANGLES', len(triangles))
