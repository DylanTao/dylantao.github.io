import gzip
import hashlib
import json
from pathlib import Path

root=Path.cwd()
q=Path(__file__).resolve().parent
packet=root/'artwork/coastal-home/reviews/exporter-integration-2026-11-02'
index=packet/'MANIFEST.json'
data=json.loads(index.read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
for row in data['files']:
    assert sha((packet/row['path']).read_bytes())==row['sha256']
def deposit(relative,body,compressed=True):
    target=packet/(relative+('.gz'if compressed else''))
    target.parent.mkdir(parents=True,exist_ok=True)
    assert not target.exists()
    stored=gzip.compress(body,mtime=0)if compressed else body
    target.write_bytes(stored)
    row={'path':target.relative_to(packet).as_posix(),'bytes':len(stored),'sha256':sha(stored)}
    if compressed:row.update(encoding='gzip',bodyBytes=len(body),bodySha256=sha(body))
    data['files'].append(row)
for name in ['build-exporter.json','build-exporter.log']:
    deposit('final-gates/'+name,(q/'camera-checkpoint'/name).read_bytes())
assert json.loads((q/'camera-checkpoint/build-exporter.json').read_bytes())['exitCode']==0
for name in ['NAVIGATION-PROCESS.json','native-navigation.log']:
    deposit('final-gates/'+name,(q/'exporter-checkpoint'/name).read_bytes())
assert json.loads((q/'exporter-checkpoint/NAVIGATION-PROCESS.json').read_bytes())['exitCode']==0
for p in (q/'exporter-checkpoint/native-navigation').glob('*/*'):
    if p.suffix in {'.png','.json'}:
        deposit('navigation/'+p.parent.name+'/'+p.name,p.read_bytes(),p.suffix!='.png')
for name in ['assets/js/home-scene/walk-controls.mjs','test/coastal-breakfast-walk-entry.test.mjs','test/test_resting_review_custody.py']:
    deposit('selected-source/'+name,(root/name).read_bytes())
for name in ['run-exporter-navigation.py','prepare-exporter-build.py','finalize-exporter-checkpoint.py']:
    deposit('producers/'+name,(q/name).read_bytes())
index.write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
print(json.dumps({'payloads':len(data['files']),'storedBytes':sum(r['bytes']for r in data['files'])}))
