import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import urllib.request

root=Path.cwd()
q=Path(__file__).resolve().parent/'exporter-checkpoint'
work=Path('C:/dev/cqa1102')
assert not (q/'server.json').exists()
shutil.copyfile(q.parent/'private-serve-template.py',q/'serve.py')
log=(q/'server.log').open('wb')
child=subprocess.Popen([sys.executable,str(q/'serve.py')],cwd=root,stdout=log,stderr=subprocess.STDOUT,creationflags=0x08000000)
for _ in range(100):
    if (q/'server.json').exists():break
    assert child.poll()is None
    time.sleep(.1)
server=json.loads((q/'server.json').read_bytes())
assert server['pid']==child.pid
with urllib.request.urlopen(server['url'],timeout=10)as response:
    assert response.headers['X-Sirui-Preview']==server['header']
env=dict(os.environ,VISUAL_BASE_URL=server['url'],NO_WEBSERVER='1')
command=[shutil.which('node'),str(work/'node_modules/playwright/cli.js'),'test','--config','test/visual/public.config.js','desk-scene.spec.js','--grep','public room navigation works in the embed and starts a safe walk from the chosen room','--project','desktop-1440','--project','mobile-390','--workers','1','--output',str(q/'native-navigation')]
start=time.monotonic()
with(q/'native-navigation.log').open('wb')as output:
    result=subprocess.run(command,cwd=work,env=env,stdout=output,stderr=subprocess.STDOUT)
(q/'NAVIGATION-PROCESS.json').write_text(json.dumps({'server':server,'command':command,'exitCode':result.returncode,'seconds':time.monotonic()-start,'scope':'Existing ordinary public Rooms/Walk case on fresh complete production product; native WindowsD3D11 at desktop1440 and touch390. No physical-phone or timing claim.'},indent=2)+'\n',encoding='utf8')
print(json.dumps({'exitCode':result.returncode,'seconds':time.monotonic()-start,'url':server['url']}))
raise SystemExit(result.returncode)
