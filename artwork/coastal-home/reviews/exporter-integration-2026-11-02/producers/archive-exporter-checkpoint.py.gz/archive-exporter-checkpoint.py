import gzip
import hashlib
import json
from pathlib import Path
import subprocess

root=Path.cwd()
q=Path(__file__).resolve().parent
packet=root/'artwork/coastal-home/reviews/exporter-integration-2026-11-02'
packet.mkdir(exist_ok=True)
assert sorted(p.name for p in packet.iterdir())==['README.md']
sha=lambda b:hashlib.sha256(b).hexdigest()
records=[]
def deposit(relative,body):
    target=packet/(relative+'.gz')
    target.parent.mkdir(parents=True,exist_ok=True)
    assert not target.exists()
    target.write_bytes(gzip.compress(body,mtime=0))
    stored=target.read_bytes()
    records.append({'path':target.relative_to(packet).as_posix(),'bytes':len(stored),'sha256':sha(stored),'encoding':'gzip','bodyBytes':len(body),'bodySha256':sha(body)})
for name in ['SOURCE.json','node.json','node.log','python.json','python.log']:
    deposit('gates/'+name,(q/'exporter-checkpoint'/name).read_bytes())
for name in ['NATIVE-FIXTURE.json','ORIGINAL-FIELDS.json','REOPENED-FIELDS.json','fixture.glb']:
    deposit('native-fixture/'+name,(q/'root-geology-helper-v1'/name).read_bytes())
for p in (q/'root-geology-helper-v1/custody').rglob('*'):
    if p.is_file():
        deposit('native-fixture/custody/'+p.relative_to(q/'root-geology-helper-v1/custody').as_posix(),p.read_bytes())
fixture=(q/'root-geology-helper-v1/fixture.glb').read_bytes()
prior=json.loads(gzip.decompress((root/'artwork/coastal-home/reviews/geology-export-custody-2026-11-02/EVIDENCE.json.gz').read_bytes()))
match=next(row for row in prior['files']if row['path']=='export-custody-fixture-v627/fixture.glb')
assert sha(fixture)==match['sha256']and len(fixture)==match['bytes']
deposit('FIXTURE-BYTE-IDENTITY.json',(json.dumps({'scope':'The actual root nativefixture output is byte-identical to the portable worker fixture whose production-WASM8face proof is retained. This does not infer other model validity. Root fixture separately repeats open/reversed rejection, exact nativefields, ordinaryvalidation and SDK/source immutability.','rootFixtureSha256':sha(fixture),'portableEvidencePath':match['path'],'bytes':len(fixture),'exact':True},indent=2)+'\n').encode())
for name in ['CAMERA-DELIVERY.json','CAMERA-DELIVERY-INTERIM.json']:
    deposit(name,(q/name).read_bytes())
failed=subprocess.check_output(['gh','run','view','41479086682','--repo','DylanTao/dylantao.github.io','--attempt','1','--log-failed'],cwd=root)
assert b'Internal Server Error'in failed and b'2dfd0d0169303d956e33d9b9a6e1a503a7b57dbd'in failed
deposit('camera-deploy-original-failure.log',failed)
for name in ['validate-exporter-checkpoint.py','check-camera-delivery.py','archive-exporter-checkpoint.py']:
    deposit('producers/'+name,(q/name).read_bytes())
(packet/'MANIFEST.json').write_text(json.dumps({'schema':'coastal-exporter-integration-v1','scope':'Actual isolated source gates, root nativefixture and exact portable fixture identity, prior cameraCI42success/live9response binding, plus original GitHub remote500deployment failure. README is editorial; all raw program/generated payload bytes remain sealed.','files':records},indent=2)+'\n',encoding='utf8')
print(json.dumps({'payloads':len(records),'storedBytes':sum(r['bytes']for r in records)}))
