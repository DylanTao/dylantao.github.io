import argparse
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

root=Path.cwd()
q=Path(__file__).resolve().parent/'exporter-checkpoint'
work=Path('C:/dev/cqa1102')
parser=argparse.ArgumentParser()
parser.add_argument('mode',choices=['prepare','node','python'])
args=parser.parse_args()
files=['bin/coastal_geology_export_custody.py','bin/test_coastal_geology_export_custody.py','assets/js/home-scene/walk-controls.mjs','test/coastal-breakfast-walk-entry.test.mjs','test/test_resting_review_custody.py']
for packet in ['geology-export-custody-2026-11-02','camera-focus-2026-11-02']:
    files += [p.relative_to(root).as_posix() for p in (root/'artwork/coastal-home/reviews'/packet).rglob('*')if p.is_file()]
sha=lambda p:hashlib.sha256(p.read_bytes().replace(b'\r\n',b'\n')if p.suffix in {'.mjs','.py','.json','.md'}else p.read_bytes()).hexdigest()
if args.mode=='prepare':
    assert not q.exists()
    q.mkdir()
    for name in files:
        target=work/name
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(root/name,target)
    (q/'SOURCE.json').write_text(json.dumps({'parent':'2dfd0d0169303d956e33d9b9a6e1a503a7b57dbd','scope':'Exact exporter helper, fixture, Walk API and custody paths in isolated validated camera checkout. Uncommitted native/auditor work is excluded. Every copied path is checked by normalized Git source hash; sealed binary evidence remains exact.','files':[{'path':name,'gitSha256':sha(root/name)}for name in files]},indent=2)+'\n',encoding='utf8')
    print('Prepared isolated exporter/Walk checkpoint paths')
    raise SystemExit(0)
snapshot=json.loads((q/'SOURCE.json').read_bytes())
for row in snapshot['files']:
    assert sha(root/row['path'])==row['gitSha256']==sha(work/row['path'])
if args.mode=='node':
    command=[shutil.which('node'),'--test',*[p.relative_to(work).as_posix()for p in sorted((work/'test').glob('*.test.mjs'))]]
else:
    command=[sys.executable,'-X','utf8','-m','unittest','discover','-s','test','-p','test_*.py']
start=time.monotonic()
with(q/(args.mode+'.log')).open('wb')as log:
    result=subprocess.run(command,cwd=work,env=dict(os.environ,NODE_PATH=str(root/'node_modules')),stdout=log,stderr=subprocess.STDOUT)
unchanged=all(sha(root/r['path'])==r['gitSha256']==sha(work/r['path'])for r in snapshot['files'])
receipt={'at':datetime.now(timezone.utc).isoformat(),'mode':args.mode,'command':command,'worktree':str(work),'exitCode':result.returncode,'seconds':time.monotonic()-start,'allSelectedSourcesUnchanged':unchanged}
(q/(args.mode+'.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps(receipt,indent=2))
assert result.returncode==0 and unchanged
