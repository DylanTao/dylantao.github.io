from pathlib import Path
import shutil

root=Path.cwd()
q=Path(__file__).resolve().parent
work=Path('C:/dev/cqa1102')
for name in ['docs/october-2026-handoff.md','test/test_resting_review_custody.py']:
    shutil.copyfile(root/name,work/name)
packet='artwork/coastal-home/reviews/exporter-integration-2026-11-02'
assert not (work/packet).exists()
shutil.copytree(root/packet,work/packet)
destination=q/'exporter-checkpoint/site/al-folio/assets/img'
assert not destination.exists()
shutil.copytree(q/'camera-checkpoint/final-site/al-folio/assets/img',destination)
print('Fresh complete exporter/Walk checkpoint build prepared; unchanged derived images seeded')
