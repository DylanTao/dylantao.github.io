from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import urllib.request

root=Path.cwd()
q=Path(__file__).resolve().parent
source='2dfd0d0169303d956e33d9b9a6e1a503a7b57dbd'
pages='2c846cc119103bd5afc0b696fc273e3922e1c8ba'
message=subprocess.check_output(['git','log','-1','--format=%s',pages],cwd=root,text=True)
assert source in message
paths=['index.html','assets/js/home-scene/controller.mjs','assets/js/home-scene/arrival-rill.mjs','assets/js/home-scene/static-light-field.mjs','assets/js/home-scene/light-installations.mjs','assets/js/home-scene/warm-practicals.mjs','assets/js/home-scene/rain-roof-field.mjs','assets/models/home/manifest.json','assets/models/home/static-light-field.json']
sha=lambda b:hashlib.sha256(b).hexdigest()
def check(path):
    expected=subprocess.check_output(['git','show',pages+':'+path],cwd=root)
    url='https://dylantao.github.io/'+(''if path=='index.html'else path)+'?camera='+source[:9]
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Sirui-site-delivery-check/1.0','Cache-Control':'no-cache'}),timeout=45)as response:
        body=response.read()
        row={'path':path,'url':url,'status':response.status,'bytes':len(body),'sha256':sha(body),'pinnedSha256':sha(expected),'exact':body==expected}
    assert row['status']==200 and row['exact'],row
    return row
with ThreadPoolExecutor(max_workers=4)as pool:
    rows=list(pool.map(check,paths))
runs=json.loads(subprocess.check_output(['gh','run','list','--repo','DylanTao/dylantao.github.io','--commit',source,'--limit','20','--json','databaseId,workflowName,status,conclusion'],cwd=root,text=True))
visual=json.loads(subprocess.check_output(['gh','run','view','41479086680','--repo','DylanTao/dylantao.github.io','--json','status,conclusion,jobs'],cwd=root,text=True))
receipt={'at':datetime.now(timezone.utc).isoformat(),'source':source,'pages':pages,'responses':rows,'workflows':runs,'visual':{'status':visual['status'],'conclusion':visual['conclusion'],'jobs':[{k:j[k]for k in ['name','status','conclusion','databaseId']}for j in visual['jobs']]},'limits':'Live exact-byte readback. Deploymentattempt1failed with a GitHub remote InternalServerError after successful build; same-source attempt2 succeeded. FinalCI status remains as recorded, never inferred from HTTP200.'}
(q/'CAMERA-DELIVERY.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
counts={}
for j in visual['jobs']:
    k=j['conclusion']or j['status'];counts[k]=counts.get(k,0)+1
print(json.dumps({'exactResponses':len(rows),'source':source,'pages':pages,'visual':counts,'workflows':runs},indent=2))
