from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
root=Path.cwd();q=Path(__file__).parent;out=q/'bedroom-curtains-checkpoint-v4'
rel='assets/models/home/manifest.json';a=(root/rel).read_bytes();b=(out/'site/al-folio'/rel).read_bytes();assert json.loads(a)==json.loads(b)
(out/'FAILED-CHECKER-V1.json').write_text(json.dumps({'at':datetime.now(timezone.utc).isoformat(),'scope':'The v1 checker incorrectly demanded raw byte equality between the formatted source manifest and publisher-processed JSON. Source331881bytes and built233489bytes differ only by publisher JSON formatting; complete parsed content is exact. The actual full built manifest must still be byte-exact to testedV3, and the signed cache retains strict raw-byte equality. No product or built bytes changed to repair this checker.','sourceBytes':len(a),'builtBytes':len(b),'sourceSha256':hashlib.sha256(a).hexdigest(),'builtSha256':hashlib.sha256(b).hexdigest(),'semanticExact':True},indent=2)+'\n',encoding='utf8')
s=(q/'check-bedroom-final-bindings-v1.cjs').read_text(encoding='utf8')
old="assert.ok(fs.readFileSync(path.join(built,rel)).equals(fs.readFileSync(path.join(root,rel))));"
assert s.count(old)==1
s=s.replace(old,"if(rel.endsWith('/manifest.json')) assert.deepEqual(JSON.parse(fs.readFileSync(path.join(built,rel))),JSON.parse(fs.readFileSync(path.join(root,rel)))); else assert.ok(fs.readFileSync(path.join(built,rel)).equals(fs.readFileSync(path.join(root,rel))));")
p=q/'check-bedroom-final-bindings-v2.cjs';assert not p.exists();p.write_text(s,encoding='utf8',newline='\n')
