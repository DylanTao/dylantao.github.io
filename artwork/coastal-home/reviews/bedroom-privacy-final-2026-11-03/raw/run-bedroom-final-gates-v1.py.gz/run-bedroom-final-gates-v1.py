from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,sysconfig,time
root=Path.cwd();q=Path(__file__).parent;wt=Path('C:/dev/dqa1103');out=q/'bedroom-final-gates-v1';assert not out.exists();out.mkdir()
env=dict(os.environ,BUNDLE_PATH='C:/tools/site-gems-ruby33',OPENBLAS_NUM_THREADS='1');env['PATH']='C:/tools/site-bin;C:/tools/Ruby33/bin;'+sysconfig.get_path('scripts')+';'+env['PATH'];rows=[]
for name,args in [('prettier',['C:/Program Files/nodejs/npx.cmd','prettier','.','--check']),('targeted-native-physical',['node','--test','test/coastal-bedroom-curtains.test.mjs','test/coastal-architecture-finish.test.mjs']),('builder-syntax',[sys.executable,'-X','utf8','-m','py_compile','bin/coastal_architecture_finish.py']),('style',['node','test/style_contract.js'])]:
 start=time.monotonic()
 with(out/(name+'.log')).open('wb')as log:r=subprocess.run(args,cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 rows.append(dict(name=name,command=args,exitCode=r.returncode,seconds=time.monotonic()-start));(out/'GATES.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),scope='Complete final-source formatting plus targeted final camera/native physical proof, after prior complete420Python/1075Node pass. Only camera literals, comment, documentation/packet and stronger physical test changed since the complete unit run.',rows=rows),indent=2)+'\n',encoding='utf8');print(json.dumps(rows[-1]),flush=True);assert r.returncode==0,name
