import fs from 'node:fs/promises';
import {createTriangleBVH,normalize} from '../../../assets/js/home-scene/light-trace-core.mjs';
const dir='.jekyll-cache/visual-qa/house-final-2026-10-28/sofa-current';
const input=JSON.parse(await fs.readFile(`${dir}/actual-start-poses.json`,'utf8'));
const sub=(a,b)=>a.map((x,i)=>x-b[i]),dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0),add=(a,b,t)=>a.map((x,i)=>x+b[i]*t);
function distanceSq(p,coords,k){
 const a=coords.slice(k,k+3),b=coords.slice(k+3,k+6),c=coords.slice(k+6,k+9),ab=sub(b,a),ac=sub(c,a),ap=sub(p,a);
 const ab2=dot(ab,ab),ac2=dot(ac,ac),abac=dot(ab,ac);
 if(ab2*ac2-abac*abac<1e-20){
  const seg=(u,v)=>{const d=sub(v,u),s=dot(d,d),t=s?Math.max(0,Math.min(1,dot(sub(p,u),d)/s)):0,q=sub(p,add(u,d,t));return dot(q,q);};
  return Math.min(seg(a,b),seg(a,c),seg(b,c));
 }
 const d1=dot(ab,ap),d2=dot(ac,ap);if(d1<=0&&d2<=0)return dot(ap,ap);
 const bp=sub(p,b),d3=dot(ab,bp),d4=dot(ac,bp);if(d3>=0&&d4<=d3)return dot(bp,bp);
 const vc=d1*d4-d3*d2;if(vc<=0&&d1>=0&&d3<=0){const d=sub(p,add(a,ab,d1/(d1-d3)));return dot(d,d);}
 const cp=sub(p,c),d5=dot(ab,cp),d6=dot(ac,cp);if(d6>=0&&d5<=d6)return dot(cp,cp);
 const vb=d5*d2-d1*d6;if(vb<=0&&d2>=0&&d6<=0){const d=sub(p,add(a,ac,d2/(d2-d6)));return dot(d,d);}
 const va=d3*d6-d5*d4;if(va<=0&&d4-d3>=0&&d5-d6>=0){const d=sub(p,add(b,sub(c,b),(d4-d3)/((d4-d3)+(d5-d6))));return dot(d,d);}
 const inv=1/(va+vb+vc),v=vb*inv,w=vc*inv,d=sub(p,add(add(a,ab,v),ac,w));return dot(d,d);
}
const dirs=[[.876,.347,.336],[-.271,.899,.345]].map(normalize);
const rows=[];
for(const row of input.rows){
 const positions=new Float32Array(row.sofa.flatMap(s=>s.positions)),tree=await createTriangleBVH(positions,new Float32Array(positions.length/3));
 const boxes=[];
 for(let k=0;k<positions.length;k+=9)boxes.push([
  Math.min(positions[k],positions[k+3],positions[k+6]),Math.min(positions[k+1],positions[k+4],positions[k+7]),Math.min(positions[k+2],positions[k+5],positions[k+8]),
  Math.max(positions[k],positions[k+3],positions[k+6]),Math.max(positions[k+1],positions[k+4],positions[k+7]),Math.max(positions[k+2],positions[k+5],positions[k+8])]);
 const winding=(p,d)=>{let near=1e-6,sum=0,n=0;while(n++<100){const hit=tree.ray(p,d,100,near);if(!hit)break;sum+=hit.backface?1:-1;near=hit.distance+1e-5;}return sum;};
 const tests=[];
 for(const offset of [0,-.25]){
  let ambiguous=0,inside=0,maxDepth=0,witness=null; const perMesh={};
  for(const point of row.points){
   const p=[point.point[0]+offset,point.point[1],point.point[2]],a=winding(p,dirs[0]),b=winding(p,dirs[1]);
   if((a>0)!==(b>0)){ambiguous++;continue;}if(a<=0)continue;
   let dist=Infinity;for(let j=0;j<boxes.length;j++){
    const box=boxes[j];let lower=0;for(let a=0;a<3;a++){const d=Math.max(box[a]-p[a],0,p[a]-box[a+3]);lower+=d*d;}
    if(lower<dist)dist=Math.min(dist,distanceSq(p,positions,j*9));
   }
   const depth=Math.sqrt(dist);inside++;perMesh[point.mesh]=(perMesh[point.mesh]||0)+1;
   if(depth>maxDepth){maxDepth=depth;witness={mesh:point.mesh,vertex:point.vertex,side:point.side,point:p,windings:[a,b],depth};}
  }
  tests.push({worldXOffsetM:offset,inside,ambiguous,maxDepthM:maxDepth,witness,perMesh});
 }
 const report={avatar:row.avatar,clip:row.clip,actor:row.actor,seconds:row.seconds,points:row.points.length,sofaTriangles:positions.length/9,tests};rows.push(report);console.log(JSON.stringify(report));
}
await fs.writeFile(`${dir}/actual-start-audit.json`,JSON.stringify({scope:input.scope,method:'Dominant ShinL/R weight >= .5; actual mesh.getVertexPosition includes morph and skin. Two non-axial winding rays, nearest exact current sofa triangle for inside points. Offset -0.25m is a diagnostic of retired actor x only, not the full historical scene.',runtimeErrors:input.runtimeErrors,rows},null,2)+'\n');
