import fs from 'node:fs/promises';
import {loadNativeAvatar,loadNativeModel,THREE} from '../../../test/helpers/coastal-native-avatar.mjs';
const dir='.jekyll-cache/visual-qa/house-final-2026-10-28/sofa-current';
const captured=JSON.parse(await fs.readFile(`${dir}/actual-start-poses.json`,'utf8'));
const config=JSON.parse(await fs.readFile('assets/models/home/manifest.json','utf8'));
const candidate=process.argv.includes('--candidate');
const room=config.rooms.find(r=>r.id==='lounge'),floor=await loadNativeModel(room.file,candidate?new URL('./sofa-current/native-candidate/models/',import.meta.url):undefined);
floor.scene.updateMatrixWorld(true);
floor.scene.traverse(o=>{if(o.isMesh)for(const m of [].concat(o.material))m.side=THREE.DoubleSide;});
const ray=new THREE.Raycaster(),down=new THREE.Vector3(0,-1,0),rows=[];
for(const style of captured.styles){
 const actual=captured.rows.find(r=>r.avatar===style&&r.clip==='lounge'),m=await loadNativeAvatar(style),actor=m.scene;
 actor.position.fromArray(actual.actor);actor.rotation.y=Math.PI;
 const mixer=new THREE.AnimationMixer(actor);mixer.clipAction(m.animations.find(a=>a.name==='lounge')).play();mixer.update(0);actor.updateMatrixWorld(true);
 let maxRuntimeDifference=0;for(const q of actual.points){const mesh=actor.getObjectByName(q.mesh);if(!mesh)throw Error('missing '+q.mesh);mesh.skeleton.update();const v=mesh.getVertexPosition(q.vertex,new THREE.Vector3()).applyMatrix4(mesh.matrixWorld);maxRuntimeDifference=Math.max(maxRuntimeDifference,v.distanceTo(new THREE.Vector3(...q.point)));}
 const feet={L:[],R:[]};actor.traverse(o=>{
  if(!o.isSkinnedMesh)return; o.skeleton.update();const ids=o.geometry.attributes.skinIndex,weights=o.geometry.attributes.skinWeight;
  for(let i=0;i<ids.count;i++){let side='';for(let k=0;k<4;k++){const n=o.skeleton.bones[ids.getComponent(i,k)]?.name;if(/^Foot[LR]$/.test(n)&&weights.getComponent(i,k)>.5)side=n.at(-1);}
   if(side)feet[side].push({mesh:o.name,vertex:i,point:o.getVertexPosition(i,new THREE.Vector3()).applyMatrix4(o.matrixWorld)});
  }
 });
 const results={};for(const side of ['L','R']){
  const foot=feet[side],min=Math.min(...foot.map(q=>q.point.y)),patch=foot.filter(q=>q.point.y<=min+.002);
  const samples=patch.map(q=>{ray.set(q.point.clone().addScaledVector(down,-.02),down);const hit=ray.intersectObject(floor.scene,true).find(h=>h.distance>.0001);return {mesh:q.mesh,vertex:q.vertex,point:q.point.toArray(),ground:hit?{mesh:hit.object.name,point:hit.point.toArray(),gapM:q.point.y-hit.point.y}:null};});
  results[side]={allFootVertices:foot.length,solePatchVertices:patch.length,minY:min,groundGapRangeM:[Math.min(...samples.map(q=>q.ground?.gapM??Infinity)),Math.max(...samples.map(q=>q.ground?.gapM??-Infinity))],samples};
 }
 rows.push({style,maxRuntimeShinVertexDifferenceM:maxRuntimeDifference,bones:Object.fromEntries(['Hips','ThighL','ShinL','FootL','ThighR','ShinR','FootR'].map(n=>[n,actor.getObjectByName(n).getWorldPosition(new THREE.Vector3()).toArray()])),feet:results});
}
await fs.writeFile(`${dir}/actual-floor-controls${candidate?'-candidate':''}.json`,JSON.stringify({scope:'Lowest 2mm actual deformed foot patch against actual decoded lounge-room triangles; source pose0 validated against all captured current runtime shin vertices. Other floor families are not included; absent ground is reported. Room GLB already uses world coordinates; its metadata offset is not applied.',candidate,room:room.file,roomOffsetMetadataOnly:room.offset,rows},null,2)+'\n');
console.log(JSON.stringify(rows.map(r=>({style:r.style,runtimeDelta:r.maxRuntimeShinVertexDifferenceM,feet:Object.fromEntries(Object.entries(r.feet).map(([k,v])=>[k,{minY:v.minY,gap:v.groundGapRangeM,samples:v.samples.slice(0,1)}]))})),null,2));
