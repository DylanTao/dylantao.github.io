import bpy,sys,json,hashlib,runpy,shutil
from pathlib import Path
root=Path.cwd();out=root/'.jekyll-cache/visual-qa/house-final-2026-10-28/sofa-current/native-candidate'
source=out/'candidate.blend';before=out/'before-bake.blend'
if not before.exists():shutil.copyfile(source,before)
bpy.ops.wm.open_mainfile(filepath=str(source));owner='lounge__ochre knit textile';obj=bpy.context.scene.objects[owner];mesh=obj.data
selected={v.index for v in mesh.vertices if -.181<(obj.matrix_world@v.co).x<.381 and -8.381<(obj.matrix_world@v.co).y<-7.819}
assert len(selected)==280
outside=[i for i,l in enumerate(mesh.loops) if l.vertex_index not in selected]
old=mesh.color_attributes.active_color;assert old.domain=='CORNER' and old.data_type=='FLOAT_COLOR'
colors={i:list(old.data[i].color) for i in outside}
sys.argv=['bake_coastal_light.py','--','--source='+str(source),'--prefixes=lounge__ochre knit textile,lounge__oatmeal wool textile,lounge__linen','--report='+str(out/'baked-light.json'),'--cpu']
runpy.run_path(str(root/'bin/bake_coastal_light.py'),run_name='__main__')
obj=bpy.context.scene.objects[owner];field=obj.data.color_attributes.active_color
for i,value in colors.items():field.data[i].color=value
assert all(list(field.data[i].color)==value for i,value in colors.items())
bpy.context.preferences.filepaths.save_version=0;bpy.ops.wm.save_as_mainfile(filepath=str(source),compress=True)
receipt={'method':'Official24sample CPU AO+diffuse producer; only the moved pouf and its actual wool/linen floor receivers bake. Restore exact untouched second-pouf corners afterward.','beforeSha256':hashlib.sha256(before.read_bytes()).hexdigest(),'afterSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'restoredSecondPoufCorners':len(outside),'approvedColorOwners':[owner,'lounge__oatmeal wool textile','lounge__linen']}
(out/'bake-custody.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(receipt),flush=True)
