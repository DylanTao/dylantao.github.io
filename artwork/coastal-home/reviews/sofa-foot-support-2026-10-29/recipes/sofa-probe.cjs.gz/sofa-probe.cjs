﻿const {chromium}=require('playwright');
const fs=require('node:fs/promises');
const path=require('node:path');
const {preparePage}=require(path.resolve('test/visual/helpers'));
(async()=>{
 const out='.jekyll-cache/visual-qa/house-final-2026-10-28/sofa-current';await fs.mkdir(out,{recursive:true});
 const b=await chromium.launch({args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
 try{
 const p=await b.newPage({viewport:{width:2560,height:1440},deviceScaleFactor:1});await preparePage(p,'light');
 await p.emulateMedia({reducedMotion:'reduce'});await p.clock.setFixedTime(new Date('2026-10-20T22:00:00-07:00'));
 await p.goto('http://127.0.0.1:4146/al-folio/?scene-lab=1&quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});
 await p.locator('[data-home-desk-mode="3d"]').click();await p.waitForFunction(()=>document.querySelector('[data-home-desk-scene]')?.dataset.sceneState==='ready',null,{timeout:180000});
 await p.locator('[data-world-fullscreen]').click();const lab=p.locator('[data-world-lab]');if(!await lab.evaluate(e=>e.open))await lab.locator('summary').first().click();
 await p.locator('[data-world-activity]').selectOption('lounge');await p.locator('[data-world-avatar]').selectOption('ghibli');
 await p.waitForFunction(()=>document.querySelector('[data-home-desk-scene]')?.getSceneEvidence()?.avatarId==='ghibli',null,{timeout:120000});
 const inventory=await p.evaluate(()=>{
 const e=document.querySelector('[data-home-desk-scene]'),sc=e.labScene.scene,v=[];const visible=o=>{for(let n=o;n;n=n.parent)if(!n.visible)return false;return true;};
 sc.updateMatrixWorld(true);sc.traverse(o=>{if(o.userData.furnitureAnchor||o.isSkinnedMesh&&visible(o))v.push({name:o.name,anchor:o.userData.furnitureAnchor,skinned:!!o.isSkinnedMesh,bones:o.skeleton?.bones.map(b=>b.name),vertices:o.geometry?.attributes.position.count});});
 return {state:e.getSceneEvidence(),nodes:v};});
 await fs.writeFile(out+'/inventory.json',JSON.stringify(inventory,null,2));
 if(await lab.evaluate(e=>e.open))await lab.locator('summary').first().click();
 const stills=[];
 for(const side of [{id:'full-front',yaw:0},{id:'three-quarter',yaw:.55}]){
  await p.evaluate(({yaw})=>{const e=document.querySelector('[data-home-desk-scene]'),s=e.getSceneEvidence();e.setLabCamera({target:[s.actorPosition[0],.22,s.actorPosition[2]+.02],yaw:s.actorFacing+yaw,pitch:.12,radius:2.7,free:true});},side);
  await p.waitForTimeout(500);await p.locator('[data-home-desk-scene] canvas').screenshot({path:out+'/ghibli-current-'+side.id+'.png'});
  stills.push({name:side.id,evidence:await p.evaluate(()=>document.querySelector('[data-home-desk-scene]').getSceneEvidence())});
 }
 await fs.writeFile(out+'/stills.json',JSON.stringify(stills,null,2));
 console.log(JSON.stringify({avatar:inventory.state.avatarId,room:inventory.state.currentRoom,activity:inventory.state.activity,animation:inventory.state.animation,position:inventory.state.actorPosition,facing:inventory.state.actorFacing,visibleSkinned:inventory.nodes.filter(x=>x.skinned).map(x=>({name:x.name,vertices:x.vertices,bones:x.bones.filter(n=>/Shin|Foot/.test(n))}))}));
 }finally{await b.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
