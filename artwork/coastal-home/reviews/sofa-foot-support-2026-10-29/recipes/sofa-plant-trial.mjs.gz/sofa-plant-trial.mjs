import fs from 'node:fs/promises';
import {loadNativeAvatar,loadNativeModel,THREE} from '../../../test/helpers/coastal-native-avatar.mjs';
import {createPlantedFeet} from '../../../assets/js/home-scene/planted-feet.mjs';
const dir='.jekyll-cache/visual-qa/house-final-2026-10-28/sofa-current';
const config=JSON.parse(await fs.readFile('assets/models/home/manifest.json','utf8')),contacts=JSON.parse(await fs.readFile('assets/models/home/character-contacts.json','utf8'));
const r=config.rooms.find(r=>r.id==='lounge'),room=await loadNativeModel(r.file);
room.scene.updateMatrixWorld(true);room.scene.traverse(o=>{if(o.isMesh)for(const m of [].concat(o.material))m.side=THREE.DoubleSide;});
const ray=new THREE.Raycaster(),down=new THREE.Vector3(0,-1,0);
function floor(x,z){ray.set(new THREE.Vector3(x,1,z),down);return ray.intersectObject(room.scene,true).filter(h=>h.point.y<0&&h.point.y>-.5).map(h=>({name:h.object.name,y:h.point.y}))[0];}
const grid=[];for(const z of [7.7,7.8,7.9,8,8.1,8.2])grid.push({z,points:[-.15,-.05,.05,.15,.25,.35].map(x=>({x,...floor(x,z)}))});
const rows=[];
for(const style of ['ghibli','lizard','south-park','simpsons','rick-and-morty']){
 const model=await loadNativeAvatar(style),actor=model.scene,mix=new THREE.AnimationMixer(actor),action=mix.clipAction(model.animations.find(c=>c.name==='lounge'));
 actor.position.fromArray(r.actor);actor.rotation.y=r.facing;
 const rig=createPlantedFeet(actor,contacts.avatars[style].lounge.legs);
 const footPoints=()=>{actor.updateMatrixWorld(true);const p={L:[],R:[]};actor.traverse(o=>{if(!o.isSkinnedMesh)return;o.skeleton.update();const ids=o.geometry.attributes.skinIndex,w=o.geometry.attributes.skinWeight;for(let i=0;i<ids.count;i++)for(let k=0;k<4;k++){const n=o.skeleton.bones[ids.getComponent(i,k)]?.name;if(/^Foot[LR]$/.test(n)&&w.getComponent(i,k)>.5)p[n.at(-1)].push(o.getVertexPosition(i,new THREE.Vector3()).applyMatrix4(o.matrixWorld));}});return p;};
 for(const z of [8.1,8,7.9]){
  mix.stopAllAction();action.reset().play();mix.update(0);actor.updateMatrixWorld(true);
  const target={L:{position:[.25,floor(.25,z).y,z]},R:{position:[-.05,floor(-.05,z).y,z]}};
  const solve=rig.apply(target),points=footPoints(),feet={};
  for(const side of ['L','R']){const ys=points[side].map(p=>p.y),min=Math.min(...ys),patch=points[side].filter(p=>p.y<=min+.002);feet[side]={minY:min,soleCount:patch.length,gaps:patch.map(p=>({point:p.toArray(),ground:floor(p.x,p.z)}))};}
  rows.push({style,z,target,solve,feet});
 }
}
await fs.writeFile(`${dir}/plant-trial.json`,JSON.stringify({scope:'Offline bounded actual avatar two-bone solve; no product change. Full current room floor triangles, retained native/decoded sole references; no source clips or leg lengths changed.',grid,rows},null,2)+'\n');
console.log(JSON.stringify({grid,rows:rows.map(r=>({style:r.style,z:r.z,solve:r.solve.map(s=>({side:s.side,drift:s.drift,reachViolation:s.reachViolation,reachSlack:s.reachSlack})),feet:Object.fromEntries(Object.entries(r.feet).map(([k,v])=>[k,{min:v.minY,count:v.soleCount,gapRange:[Math.min(...v.gaps.map(p=>p.point[1]-p.ground.y)),Math.max(...v.gaps.map(p=>p.point[1]-p.ground.y))]}]))}))},null,2));
