const {chromium}=require('playwright'),fs=require('node:fs/promises'),path=require('node:path');
const {preparePage,collectRuntimeErrors}=require(path.resolve('test/visual/helpers'));
(async()=>{
 const out='.jekyll-cache/visual-qa/house-final-2026-10-28/sofa-current/candidate-runtime';await fs.mkdir(out,{recursive:true});
 const b=await chromium.launch({args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
 try{
  const p=await b.newPage({viewport:{width:2560,height:1440},deviceScaleFactor:1});await preparePage(p,'light');const errors=collectRuntimeErrors(p);
  await p.emulateMedia({reducedMotion:'reduce'});await p.clock.setFixedTime(new Date('2026-10-20T22:00:00-07:00'));
  await p.goto('http://127.0.0.1:4149/al-folio/?scene-lab=1&quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});
  await p.locator('[data-home-desk-mode="3d"]').click();await p.waitForFunction(()=>document.querySelector('[data-home-desk-scene]')?.dataset.sceneState==='ready',null,{timeout:180000});
  await p.locator('[data-world-fullscreen]').click();const lab=p.locator('[data-world-lab]');if(!await lab.evaluate(e=>e.open))await lab.locator('summary').first().click();
  await p.locator('[data-world-activity]').selectOption('lounge');
  const styles=await p.locator('[data-world-avatar] option').evaluateAll(es=>es.map(e=>e.value)),rows=[];
  for(const style of styles){
   if(!await lab.evaluate(e=>e.open))await lab.locator('summary').first().click();
   await p.locator('[data-world-avatar]').selectOption(style);await p.waitForFunction(s=>document.querySelector('[data-home-desk-scene]')?.getSceneEvidence()?.avatarId===s,style,{timeout:120000});
   if(await lab.evaluate(e=>e.open))await lab.locator('summary').first().click();
   for(const shot of [{id:'whole',height:.22,radius:2.7,pitch:.12},{id:'feet',height:-.20,radius:.85,pitch:.24}]){
    await p.evaluate(({height,radius,pitch})=>{const e=document.querySelector('[data-home-desk-scene]'),s=e.getSceneEvidence();e.setLabCamera({target:[s.actorPosition[0],height,s.actorPosition[2]-.42],yaw:s.actorFacing,pitch,radius,free:true});},shot);
    await p.waitForTimeout(300);await p.locator('[data-home-desk-scene] canvas').screenshot({path:`${out}/${style}-${shot.id}.png`});
   }
   const state=await p.evaluate(()=>document.querySelector('[data-home-desk-scene]').getSceneEvidence());if(!state.simulation.lightField.cacheHit)throw Error('Candidate must restore its official cache');
   rows.push({style,state});console.log(JSON.stringify({style,cacheHit:state.simulation.lightField.cacheHit,actor:state.actorPosition,animation:state.animation}));
  }
  if(errors.length)throw Error(JSON.stringify(errors));await fs.writeFile(out+'/receipt.json',JSON.stringify({scope:'Complete candidate production assets and official cache; ordinary lounge/avatar controls, reduced-motion start pose. Explicit authored inspection cameras; not navigation or continuous-motion acceptance.',errors,rows},null,2));
 }finally{await b.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
