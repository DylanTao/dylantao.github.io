import sys,json
from pathlib import Path
import bpy
root=Path.cwd();sys.path.insert(0,str(root/'bin'))
from coastal_architecture_finish import components,bounds
import bmesh
bpy.ops.wm.open_mainfile(filepath=str(root/'artwork/coastal-home/coastal-home.blend'))
rows=[]
for obj in bpy.context.scene.objects:
 if obj.type!='MESH' or 'lounge' not in obj.name or not any('ochre knit' in m.name for m in obj.data.materials):continue
 bm=bmesh.new();bm.from_mesh(obj.data)
 for island in components(bm):
  lo,hi=bounds([obj.matrix_world@v.co for v in island]);rows.append({'object':obj.name,'vertices':len(island),'lo':list(lo),'hi':list(hi),'materials':[m.name for m in obj.data.materials]})
 bm.free()
out=root/'.jekyll-cache/visual-qa/house-final-2026-10-28/sofa-current/native-poufs.json';out.write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows),flush=True)
