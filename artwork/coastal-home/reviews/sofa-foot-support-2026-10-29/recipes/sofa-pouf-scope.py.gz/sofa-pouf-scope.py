import bpy,sys,json,hashlib
import numpy as np
from pathlib import Path
root=Path.cwd();out=root/'.jekyll-cache/visual-qa/house-final-2026-10-28/sofa-current'
owner='lounge__ochre knit textile'
def extract(file):
 bpy.ops.wm.open_mainfile(filepath=str(file));result={}
 for obj in bpy.context.scene.objects:
  row={'type':obj.type,'matrix':np.array(obj.matrix_world)}
  if obj.type=='MESH':
   m=obj.data;row.update({'positions':np.array([v.co[:] for v in m.vertices]).reshape(-1,3),'normals':np.array([n.vector[:] for n in m.corner_normals]).reshape(-1,3),'faces':[tuple(p.vertices) for p in m.polygons],'materials':[v.name for v in m.materials],'faceMaterials':[p.material_index for p in m.polygons]})
   row['colors']={a.name:np.array([v.color[:] for v in a.data]) for a in m.color_attributes};row['loopVertices']=np.array([l.vertex_index for l in m.loops])
  result[obj.name]=row
 return result
source=root/'artwork/coastal-home/coastal-home.blend';candidate=out/'native-candidate/candidate.blend'
a,b=extract(source),extract(candidate);fail=[];changes=[];color_changes=[]
if set(a)!=set(b):fail.append('object roster changed')
for name,x in a.items():
 y=b[name]
 if x['type']!=y['type'] or not np.array_equal(x['matrix'],y['matrix']):fail.append(name+': object transform/type')
 if x['type']!='MESH':continue
 for key in ('faces','materials','faceMaterials'):
  if x[key]!=y[key]:fail.append(name+': '+key)
 changed_colors=set(x['colors'])!=set(y['colors']) or any(not np.array_equal(v,y['colors'][k]) for k,v in x['colors'].items())
 allowed_bake='--baked' in sys.argv and name in (owner,'lounge__oatmeal wool textile','lounge__linen')
 if changed_colors and not allowed_bake:fail.append(name+': AO/color')
 if changed_colors:color_changes.append(name)
 d=np.linalg.norm(x['positions']-y['positions'],axis=1);nd=np.linalg.norm(x['normals']-y['normals'],axis=1)
 if name!=owner and (d.max(initial=0)>0 or nd.max(initial=0)>0):fail.append(name+': unrelated geometry/normal')
 if d.max(initial=0)>0:changes.append({'mesh':name,'movedVertices':int(np.count_nonzero(d)),'maxDisplacementM':float(d.max()),'normalChangedCorners':int(np.count_nonzero(nd))})
 if name==owner and allowed_bake:
  protected=d[x['loopVertices']]==0
  if set(x['colors'])!=set(y['colors']) or any(not np.array_equal(v[protected],y['colors'][k][protected]) for k,v in x['colors'].items()):fail.append(name+': untouched second-pouf AO changed')
if len(changes)!=1 or changes[0]['mesh']!=owner or changes[0]['movedVertices']!=280:fail.append('expected only the complete280vertex foot pouf')
report={'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'candidateSha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'objects':len(a),'meshObjects':sum(x['type']=='MESH' for x in a.values()),'changes':changes,'colorChanges':color_changes,'approvedBakedColorOwners':([owner,'lounge__oatmeal wool textile','lounge__linen'] if '--baked' in sys.argv else []),'failures':fail,'scope':'All object matrices, native mesh positions/topology/material slots/face assignments and actual corner normals before/save/reload. Only one complete280vertex pouf may move. Colors remain exact except explicitly approved bake owners; the untouched second pouf stays exact even within its shared material owner.'}
(out/'native-candidate/scope.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
if fail:raise RuntimeError(fail)
