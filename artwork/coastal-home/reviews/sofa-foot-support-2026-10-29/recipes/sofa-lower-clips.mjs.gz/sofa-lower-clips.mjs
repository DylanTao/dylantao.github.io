import fs from 'node:fs/promises';
import {loadNativeAvatar,THREE} from '../../../test/helpers/coastal-native-avatar.mjs';
const styles=['lizard','south-park','simpsons','ghibli','rick-and-morty'],rows=[];
for(const style of styles){
 const m=await loadNativeAvatar(style);
 for(const clip of m.animations.filter(a=>['lounge','drink'].includes(a.name))){
  const tracks=clip.tracks.filter(t=>/^(Root|Hips|Thigh[LR]|Shin[LR]|Foot[LR])\./.test(t.name)).map(t=>{
   const stride=t.getValueSize();let max=0;for(let i=stride;i<t.values.length;i++)max=Math.max(max,Math.abs(t.values[i]-t.values[i%stride]));
   return {name:t.name,interpolation:t.getInterpolation(),keys:t.times.length,maxAbsoluteKeyChange:max};
  });
  const mx=new THREE.AnimationMixer(m.scene),a=mx.clipAction(clip);a.play();
  const sample=[];for(let t=0;t<=clip.duration;t+=clip.duration/8){a.time=t;mx.update(0);m.scene.updateMatrixWorld(true);
   sample.push({seconds:t,bones:['Root','Hips','ThighL','ThighR','ShinL','ShinR','FootL','FootR'].map(n=>{const b=m.scene.getObjectByName(n);return{name:n,world:b.matrixWorld.toArray()};})});
  }
  mx.stopAllAction();rows.push({style,clip:clip.name,duration:clip.duration,tracks,sample});
 }
}
await fs.writeFile('.jekyll-cache/visual-qa/house-final-2026-10-28/sofa-current/lower-clip-controls.json',JSON.stringify({scope:'All authored Root/Hips/Thigh/Shin/Foot tracks of two actual decoded clips; key range control plus nine sampled FK phases. This excludes the later runtime dining solve.',rows},null,2)+'\n');
console.log(JSON.stringify(rows.map(r=>({style:r.style,clip:r.clip,duration:r.duration,movingTracks:r.tracks.filter(t=>t.maxAbsoluteKeyChange>1e-10)})),null,2));
