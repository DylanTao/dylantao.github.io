const { chromium } = require('playwright');
const fs = require('node:fs/promises');
const path = require('node:path');
const {preparePage, collectRuntimeErrors} = require(path.resolve('test/visual/helpers'));
const out=path.resolve('.jekyll-cache/visual-qa/house-final-2026-10-28/sofa-current');
(async()=>{
 await fs.mkdir(out,{recursive:true});
 const b=await chromium.launch({args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
 try{
  const p=await b.newPage({viewport:{width:1440,height:1000},deviceScaleFactor:1});
  await preparePage(p,'light'); const errors=collectRuntimeErrors(p);
  await p.emulateMedia({reducedMotion:'reduce'});await p.clock.setFixedTime(new Date('2026-10-20T22:00:00-07:00'));
  await p.goto('http://127.0.0.1:4146/al-folio/?scene-lab=1&quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});
  await p.locator('[data-home-desk-mode="3d"]').click();
  await p.waitForFunction(()=>document.querySelector('[data-home-desk-scene]')?.dataset.sceneState==='ready',null,{timeout:180000});
  await p.locator('[data-world-fullscreen]').click(); const lab=p.locator('[data-world-lab]');
  if(!await lab.evaluate(e=>e.open))await lab.locator('summary').first().click();
  await p.locator('[data-world-activity]').selectOption('lounge');
  const styles=await p.locator('[data-world-avatar] option').evaluateAll(es=>es.map(e=>e.value));
  const result={scope:'Actual current production scene, reduced-motion start pose only; posed visible Skin and clothes, actual visible living-sofa LOD. Not continuous contact proof.',styles,rows:[]};
  for(const style of styles){
   await p.locator('[data-world-avatar]').selectOption(style);
   await p.waitForFunction(s=>document.querySelector('[data-home-desk-scene]')?.getSceneEvidence()?.avatarId===s,style,{timeout:120000});
   for(const minute of [1320,1322]){
    await p.locator('[data-world-time]').evaluate((e,t)=>{e.value=t;e.dispatchEvent(new Event('input',{bubbles:true}));},minute);
    await p.waitForTimeout(200);
    const row=await p.evaluate(async()=>{
     const THREE=await import('/al-folio/assets/js/three.module.min.js');
     const el=document.querySelector('[data-home-desk-scene]'),scene=el.labScene.scene;
     const visible=o=>{for(let n=o;n;n=n.parent)if(!n.visible)return false;return true;};
     scene.updateMatrixWorld(true);const sofa=[];let root;
     scene.traverse(o=>{if(o.userData.furnitureAnchor==='living-sofa')root=o;});
     root.traverse(o=>{if(!o.isMesh||!visible(o))return; const a=o.geometry.attributes.position,ix=o.geometry.index,v=new THREE.Vector3(),ps=[];
      for(let k=0;k<(ix?.count||a.count);k++){v.fromBufferAttribute(a,ix?ix.getX(k):k).applyMatrix4(o.matrixWorld);ps.push(...v.toArray());}
      sofa.push({name:o.name,material:Array.isArray(o.material)?o.material.map(m=>m.name):o.material.name,positions:ps});
     });
     const points=[];
     scene.traverse(o=>{
      if(!o.isSkinnedMesh||!visible(o))return;const bones=o.skeleton.bones;
      if(!bones.some(b=>/^Shin[LR]$/.test(b.name)))return;
      o.skeleton.update(); const ids=o.geometry.attributes.skinIndex,weights=o.geometry.attributes.skinWeight,v=new THREE.Vector3();
      for(let i=0;i<ids.count;i++){
       let sum=0,side='';for(let k=0;k<4;k++){const name=bones[ids.getComponent(i,k)]?.name;if(/^Shin[LR]$/.test(name)){sum+=weights.getComponent(i,k);side=name;}}
       if(sum<.5)continue; o.getVertexPosition(i,v).applyMatrix4(o.matrixWorld);points.push({mesh:o.name,vertex:i,side,point:v.toArray()});
      }
     });
     const s=el.getSceneEvidence();return {avatar:s.avatarId,clip:s.animation,actor:s.actorPosition,seconds:s.animationSeconds,sofa,points};
    });
    result.rows.push(row);console.log(JSON.stringify({avatar:row.avatar,clip:row.clip,actor:row.actor,points:row.points.length,sofa:row.sofa.map(s=>({name:s.name,triangles:s.positions.length/9}))}));
   }
  }
  result.runtimeErrors=errors;await fs.writeFile(path.join(out,'actual-start-poses.json'),JSON.stringify(result));
 }finally{await b.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
