require 'jekyll'
require 'C:/dev/cqa1102/_plugins/site_module_assets.rb'
File.binwrite(ARGV[1], SiruiSite::ModuleAssets.compile(File.read(ARGV[0], encoding: 'UTF-8')))
