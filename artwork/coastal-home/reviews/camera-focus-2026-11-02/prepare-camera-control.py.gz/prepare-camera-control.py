import hashlib
import json
import os
from pathlib import Path
import subprocess

q = Path(__file__).resolve().parent / 'camera-checkpoint'
work = Path('C:/dev/cqa1102')
source = (work / 'assets/js/home-scene/controller.mjs').read_text(encoding='utf8')
needle = '      camera.position.y += outsideLift;'
assert source.count(needle) == 1
before = source.replace(needle, needle + '\n      aim.y += outsideLift * 0.85;')
(q / 'controlled-before-controller.mjs').write_text(before, encoding='utf8', newline='\n')
ruby = q / 'compile-control.rb'
ruby.write_text("require 'jekyll'\nrequire 'C:/dev/cqa1102/_plugins/site_module_assets.rb'\nFile.binwrite(ARGV[1], SiruiSite::ModuleAssets.compile(File.read(ARGV[0], encoding: 'UTF-8')))\n", encoding='utf8')
env = dict(os.environ, BUNDLE_PATH='C:/tools/site-gems-ruby33')
command = ['C:/tools/Ruby33/bin/ruby.exe', 'C:/tools/Ruby33/bin/bundle', 'exec', 'ruby', str(ruby), str(q / 'controlled-before-controller.mjs'), str(q / 'controlled-before-controller-compiled.mjs')]
with (q / 'compile-control.log').open('wb') as log:
    result = subprocess.run(command, cwd=work, env=env, stdout=log, stderr=subprocess.STDOUT)
assert result.returncode == 0
sha = lambda b: hashlib.sha256(b).hexdigest()
(q / 'CONTROL-SOURCE.json').write_text(json.dumps({'scope':'One-line controlled reintroduction of the prior aim lift into the exact tested checkpoint source. Same native/model/transport; response override is confined to this one controller in the before rendering, not a publication build.', 'beforeSourceSha256':sha(before.encode()),'afterSourceSha256':sha(source.encode()),'beforeCompiledSha256':sha((q / 'controlled-before-controller-compiled.mjs').read_bytes()),'command':command,'exitCode':result.returncode},indent=2)+'\n',encoding='utf8')
print('Controlled before module compiled with the owning production compiler')
