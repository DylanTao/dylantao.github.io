import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import urllib.request

q = Path(__file__).resolve().parent / 'camera-checkpoint'
work = Path('C:/dev/cqa1102')
server = json.loads((q / 'server.json').read_bytes())
with urllib.request.urlopen(server['url'], timeout=10) as response:
    assert response.headers['X-Sirui-Preview'] == server['header']
env = dict(os.environ, VISUAL_BASE_URL=server['url'], NO_WEBSERVER='1', VISUAL_WORKERS='1')
command = [shutil.which('node'), str(work / 'node_modules/playwright/cli.js'), 'test', '--config', 'test/visual/public.config.js', 'desk-scene.spec.js', '--grep', 'full exterior orbit and guided interior camera boundaries', '--project', 'desktop-1440', '--workers', '1', '--output', str(q / 'native-orbit-v2')]
start = time.monotonic()
with (q / 'native-orbit-v2.log').open('wb') as log:
    result = subprocess.run(command, cwd=work, env=env, stdout=log, stderr=subprocess.STDOUT)
(q / 'NATIVE-ORBIT-PROCESS.json').write_text(json.dumps({'command':command,'server':server,'exitCode':result.returncode,'seconds':time.monotonic()-start,'scope':'Actual extended existing public orbit case on complete fresh production build with original native1e10. Initial over-anchored grep matched no tests; retained as native-orbit.log.'},indent=2)+'\n',encoding='utf8')
print(json.dumps({'exitCode':result.returncode,'seconds':time.monotonic()-start}))
raise SystemExit(result.returncode)
