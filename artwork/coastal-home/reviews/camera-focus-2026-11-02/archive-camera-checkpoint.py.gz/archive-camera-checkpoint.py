import gzip
import hashlib
import json
from pathlib import Path
import shutil

root = Path.cwd()
q = Path(__file__).resolve().parent
evidence = q / 'camera-checkpoint'
out = root / 'artwork/coastal-home/reviews/camera-focus-2026-11-02'
assert not out.exists() or sorted(p.name for p in out.iterdir()) == ['README.md']
out.mkdir(exist_ok=True)
sha = lambda b: hashlib.sha256(b).hexdigest()
source = json.loads((evidence/'SOURCE.json').read_bytes())
for row in source['files']:
    assert sha((root/row['path']).read_bytes()) == row['rawSha256']
    assert sha((Path('C:/dev/cqa1102')/row['path']).read_bytes()) == row['rawSha256']
    target=out/'sources'/(row['path']+'.gz')
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress((root/row['path']).read_bytes(),mtime=0))
for name in ['SOURCE.json','CONTROL-SOURCE.json','NATIVE-ORBIT-PROCESS.json','node-v3.json','python-v4.json','build-v3.json','format-v3.json','controlled-before-controller.mjs','controlled-before-controller-compiled.mjs','compile-control.rb']:
    shutil.copyfile(evidence/name,out/name)
for name in ['node.log','node-v3.log','python.log','python-v3.log','python-v4.log','build.log','build-v2.log','build-v3.log','format-v3.log','native-orbit.log','native-orbit-v2.log','npm-ci.log','compile-control.log']:
    body=(evidence/name).read_bytes()
    target=out/'logs'/(name+'.gz');target.parent.mkdir(exist_ok=True)
    target.write_bytes(gzip.compress(body,mtime=0))
for version in ['framing-v1','framing-v2','framing-v3']:
    for path in (evidence/version).glob('*'):
        if path.suffix not in {'.png','.json'}:
            continue
        target=out/version/path.name;target.parent.mkdir(exist_ok=True)
        shutil.copyfile(path,target)
for path in (evidence/'native-orbit-v2').glob('*/*.png'):
    target=out/'native-orbit'/path.name;target.parent.mkdir(exist_ok=True)
    shutil.copyfile(path,target)
for filename in ['capture-framing-v1.cjs','capture-framing-v2.cjs']:
    shutil.copyfile(evidence/filename,out/filename)
for filename in ['capture-camera-checkpoint.cjs','prepare-camera-control.py','run-camera-orbit.py','check-arrival-format.cjs']:
    shutil.copyfile(q/filename,out/filename)
for filename in ['CAMERA-CACHE-COMPARISON.json','ARRIVAL-FORMAT.json']:
    shutil.copyfile(q/filename,out/filename)
capture=json.loads((evidence/'framing-v3/CAPTURE.json').read_bytes())
assert not capture['errors'] and not capture['failed']
assert all(r.get('exact') and r.get('owned') and r['status']==200 for r in capture['responses'])
assert len(capture['rows'])==7
qualification={'parent':source['parent'],'currentValidationWorktree':'C:/dev/cqa1102','relocation':'Validation worktree was moved twice with git worktree to a shorter explicit path because Windows file-open limits affected archived evidence. SOURCE and each original process receipt retain their real invocation paths. Every selected raw source body still matches both root and current validation checkout.', 'geometry':'Canonical native1e10 and all GLBs unchanged. Full product, no omitted images; unchanged derived image cache reused.', 'sourceBodiesExact':len(source['files']),'node':{'tests':1009,'passed':1002,'skipped':7,'failed':0},'python':{'tests':393,'failed':0},'productionBuildExitCode':json.loads((evidence/'build-v3.json').read_bytes())['exitCode'],'nativeOrbitExitCode':json.loads((evidence/'NATIVE-ORBIT-PROCESS.json').read_bytes())['exitCode'],'framingCases':len(capture['rows']),'exactObservedSceneResponses':len(capture['responses']),'knownControls':'First framing fixture requested manual Pause under reduced-motion, which correctly disables that button. Second fixture incorrectly waited for no pending animation frame before Pause; ordinary live animation kept queuing frames. Third waits for actual stable camera positions, then uses enabled public Pause after complete near-field ecology. Both failures retained. Earlier Node imports, Windows path failures and build invocation failures are also retained.', 'limits':'Focus correction does not remove real terrain occlusion on the landward side. Four viewport widths, native2K and PC WebKit are functional/render evidence, not hardware timing or physical-iPhone proof. Inclined light regions, native soffit/canopy overrides and arrival rill are strict optional support for later qualified metadata; canonical1e10 does not enable them. Final new native house, coffee routine, whole-house appearance and performance remain open.'}
(out/'QUALIFICATION.json').write_text(json.dumps(qualification,indent=2)+'\n',encoding='utf8')
print(json.dumps({'folder':str(out),'files':sum(1 for p in out.rglob('*') if p.is_file()),'sceneResponses':len(capture['responses']),'pngs':sum(1 for p in out.rglob('*.png'))}))
