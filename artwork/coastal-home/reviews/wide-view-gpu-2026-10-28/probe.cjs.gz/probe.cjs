const fs = require("node:fs/promises");
const path = require("node:path");
const crypto = require("node:crypto");
const { chromium } = require("playwright");
const Q = path.join(process.cwd(), ".jekyll-cache/visual-qa/wide-view-diagnostic-2026-10-28");
const ONLY_FOUR_K = process.env.WIDE_FOUR_K === "1";
const URL = "http://127.0.0.1:4130/al-folio/?scene-lab=1&quality=high&resolution=fixed";
const sha = (v) => crypto.createHash("sha256").update(v).digest("hex");
const save = (name, value) => fs.writeFile(path.join(Q, name), JSON.stringify(value, null, 2) + "\n");

// Installed only after the complete outside view has settled. It does not
// replace programs, textures, geometry, uniforms, visibility or scheduling.
function installProbe() {
  const host = document.querySelector("[data-home-desk-scene]"), scene = host.labScene.scene;
  const initialBefore = scene.onBeforeRender;
  scene.onBeforeRender = function (renderer, ...args) {
    initialBefore.call(this, renderer, ...args);
    scene.onBeforeRender = initialBefore;
    const gl = renderer.getContext(), ext = gl.getExtension("EXT_disjoint_timer_query_webgl2");
    if (!ext) { window.wideProbe = { error: "GPU timer unavailable" }; return; }
    const oceans = [];
    scene.traverse((o) => {
      if (o.isMesh && [o.material].flat().some((m) => String(m?.customProgramCacheKey?.()).startsWith("pacific-optics-v6"))) oceans.push(o);
    });
    if (oceans.length !== 1) { window.wideProbe = { error: "Expected one real Pacific draw; found " + oceans.length }; return; }
    const ocean = oceans[0], pending = [], samples = [], events = [], roles = {}, stack = [];
    const targetIds = new WeakMap(); let nextTarget = 0, phase = null, skippedExternal = 0, skippedPending = 0, disjoint = 0;
    const originalRender = renderer.render, originalShadow = renderer.shadowMap.render, originalBlit = gl.blitFramebuffer;
    const oceanBefore = ocean.onBeforeRender, oceanAfter = ocean.onAfterRender; let oceanQuery = null;
    function target() {
      const t = renderer.getRenderTarget();
      if (!t) return { id: 0, size: [gl.drawingBufferWidth, gl.drawingBufferHeight], samples: 0, name: "screen" };
      if (!targetIds.has(t)) targetIds.set(t, ++nextTarget);
      return { id: targetIds.get(t), size: [t.width, t.height], samples: t.samples, name: t.texture?.name || "" };
    }
    function role(object) {
      const t = target(), m = object.material;
      const u = Object.keys(m?.uniforms || {});
      let kind = object === scene ? "main-scene" : object.isScene ? "other-scene" : m?.name || m?.type || object.type;
      if (u.includes("hazeMarch")) kind = "haze-volume";
      else if (u.includes("hazeVolumeEnabled")) kind = "haze-composite";
      else if (u.includes("toneMappingExposure") && u.includes("tDiffuse")) kind = "output";
      const key = `${kind}|target${t.id}|${t.size.join("x")}|samples${t.samples}`;
      if (!roles[key]) roles[key] = { kind, target: t, objectType: object.type, objectName: object.name, material: m?.name || m?.type, uniforms: u, override: scene.overrideMaterial?.type || null };
      return key;
    }
    function poll() {
      if (gl.getParameter(ext.GPU_DISJOINT_EXT)) {
        disjoint++; for (const p of pending.splice(0)) gl.deleteQuery(p.q); return;
      }
      for (let i = pending.length - 1; i >= 0; i--) {
        const p = pending[i];
        if (!gl.getQueryParameter(p.q, gl.QUERY_RESULT_AVAILABLE)) continue;
        const ms = gl.getQueryParameter(p.q, gl.QUERY_RESULT) / 1e6;
        if (Number.isFinite(ms) && ms >= 0) samples.push({ phase: p.phase, mode: p.mode, role: p.role, ms, draws: p.draws, triangles: p.triangles, cpuMs: p.cpuMs });
        gl.deleteQuery(p.q); pending.splice(i, 1);
      }
    }
    function begin(label, mode) {
      if (!phase || phase.mode !== mode) return null;
      if (gl.getQuery(ext.TIME_ELAPSED_EXT, gl.CURRENT_QUERY)) { skippedExternal++; return null; }
      if (pending.length >= 256) { skippedPending++; return null; }
      const q = gl.createQuery(); if (!q) return null;
      const token = { q, phase: phase.name, mode, role: label, at: performance.now(), calls: renderer.info.render.calls, tris: renderer.info.render.triangles };
      gl.beginQuery(ext.TIME_ELAPSED_EXT, q); return token;
    }
    function end(p) {
      if (!p) return;
      gl.endQuery(ext.TIME_ELAPSED_EXT);
      p.cpuMs = performance.now() - p.at; p.draws = renderer.info.render.calls - p.calls; p.triangles = renderer.info.render.triangles - p.tris;
      pending.push(p);
    }
    renderer.render = function (object, camera) {
      if (stack.length === 0) poll();
      const label = role(object), token = begin(label, "render"); stack.push(label);
      try { return originalRender.call(this, object, camera); } finally { stack.pop(); end(token); }
    };
    renderer.shadowMap.render = function (...args) {
      const label = "shadow|from:" + (stack[stack.length - 1] || "outside-render");
      if (!roles[label]) roles[label] = { kind: "shadow-map", parent: stack[stack.length - 1], target: target() };
      const token = begin(label, "shadow");
      try { return originalShadow.apply(this, args); } finally { end(token); }
    };
    gl.blitFramebuffer = function (...args) {
      const label = `blit|${Math.abs(args[6]-args[4])}x${Math.abs(args[7]-args[5])}|mask${args[8]}`;
      if (!roles[label]) roles[label] = { kind: "framebuffer-blit", bounds: args.slice(0,8), mask: args[8], filter: args[9] };
      const token = begin(label, "blit");
      try { return originalBlit.apply(this, args); } finally { end(token); }
    };
    ocean.onBeforeRender = function (...args) {
      oceanBefore.apply(this, args);
      const label = "ocean|" + JSON.stringify(target());
      if (!roles[label]) roles[label] = { kind: "ocean", target: target(), parent: stack[stack.length - 1], vertices: ocean.geometry.attributes.position.count, triangles: ocean.geometry.index.count / 3 };
      oceanQuery = begin(label, "ocean");
    };
    ocean.onAfterRender = function (...args) { end(oceanQuery); oceanQuery = null; oceanAfter.apply(this, args); };
    window.wideProbe = {
      setPhase(name, mode) { phase = name ? { name, mode } : null; events.push({ name, mode, at: performance.now(), sceneFrames: host.getSceneEvidence().frames }); },
      read() { poll(); return { samples: [...samples], events: [...events], roles, skippedExternal, skippedPending, disjoint, pending: pending.length, completeScene: host.getSceneEvidence(), ocean: { id: ocean.id, name: ocean.name, parent: ocean.parent.name, material: ocean.material.name, programKey: ocean.material.customProgramCacheKey() } }; },
      restore() {
        phase = null; renderer.render = originalRender; renderer.shadowMap.render = originalShadow; gl.blitFramebuffer = originalBlit; ocean.onBeforeRender = oceanBefore; ocean.onAfterRender = oceanAfter;
        for (const p of pending.splice(0)) gl.deleteQuery(p.q);
      },
    };
  };
  host.labScene.requestFrame();
}

async function main() {
  await fs.mkdir(Q, { recursive: true });
  const browser = await chromium.launch({ headless: true, args: ["--use-angle=d3d11", "--ignore-gpu-blocklist"] });
  const receipt = { url: URL, createdAt: new Date().toISOString(), method: "Complete served source; public South Park selector and fixed authored Date. Native RAF. Runtime-only GPU timer callbacks in disjoint non-nested modes; existing composer queries cause exclusions. No program/geometry/uniform/visibility/quality substitutions. Uninstrumented wall-frame controls precede and follow each resolution's renderer hooks.", responses: [], errors: [], console: [], controls: [], runs: [] };
  let page;
  try {
    page = await browser.newPage({ viewport: ONLY_FOUR_K ? { width: 3840, height: 2160 } : { width: 2560, height: 1440 }, deviceScaleFactor: 1, timezoneId: "America/Los_Angeles", reducedMotion: "no-preference" });
    const bodies = new Set(), pendingBodies = [];
    page.on("pageerror", e => receipt.errors.push(e.message));
    page.on("console", e => { if (["error", "warning"].includes(e.type())) receipt.console.push({ type: e.type(), text: e.text() }); });
    page.on("response", response => {
      if (response.status() >= 400) receipt.errors.push(`HTTP ${response.status()} ${response.url()}`);
      if (!response.url().startsWith("http://127.0.0.1:4130/al-folio/")) return;
      const key = response.url(); if (bodies.has(key)) return; bodies.add(key);
      pendingBodies.push((async()=>{const body = await response.body(); receipt.responses.push({ url: key, status: response.status(), bytes: body.length, sha256: sha(body) });})().catch(e=>receipt.errors.push("Body readback " + key + ": " + e.message)));
    });
    await page.route(/https:\/\/(?:plausible\.io|www\.google-analytics\.com|www\.googletagmanager\.com)\//, r=>r.fulfill({status:200,body:""}));
    await page.addInitScript(() => {
      const D = Date, t = D.parse("2026-10-28T13:20:00-07:00");
      window.Date = new Proxy(D, { apply: () => new D(t).toString(), construct: (target, args) => Reflect.construct(target, args.length ? args : [t]), get: (target, key) => key === "now" ? () => t : Reflect.get(target, key) });
      let state = 7; Math.random = () => (state = (state * 1664525 + 1013904223) >>> 0) / 4294967296;
    });
    await page.goto(URL, { waitUntil: "domcontentloaded" });
    await page.locator('[data-home-desk-mode="3d"]').click();
    const host = page.locator("[data-home-desk-scene]");
    await host.scrollIntoViewIfNeeded();
    await page.waitForFunction(()=>document.querySelector('[data-home-desk-scene]')?.dataset.sceneState === "ready", null, {timeout:180000});
    await page.locator('[data-world-avatar]').evaluate(e=>{e.value="south-park";e.dispatchEvent(new Event("change",{bubbles:true}));});
    await page.waitForFunction(()=>document.querySelector('[data-home-desk-scene]').getSceneEvidence().avatarId === "south-park");
    await page.locator('[data-world-fullscreen]').click();
    await page.waitForFunction(()=>!!document.querySelector('[data-home-desk-scene]').getSceneEvidence().fullscreen);
    await page.locator('[data-world-view]').click();
    await page.waitForFunction(()=>{const e=document.querySelector('[data-home-desk-scene]'),s=e.getSceneEvidence();return s.currentRoom === "outside" && s.simulation.lightField.ready && e.labScene.scene.getObjectByName('coastal-hinterland')?.visible && e.labScene.scene.getObjectByName('clifftop-flora')?.visible},null,{timeout:180000});
    const control = async (name) => {
      const begin = await host.evaluate(e=>({at:performance.now(),frames:e.getSceneEvidence().frames}));
      await page.waitForTimeout(3500);
      const end = await host.evaluate(e=>({at:performance.now(),state:e.getSceneEvidence()}));
      const row = { name, wallMs: end.at - begin.at, frames: end.state.frames - begin.frames, fps: (end.state.frames - begin.frames) * 1000 / (end.at - begin.at), state: end.state };
      receipt.controls.push(row); await save("receipt.json", receipt); console.log(JSON.stringify({control:name,fps:row.fps,canvas:[end.state.canvasWidth,end.state.canvasHeight],draws:end.state.drawCalls}));
    };
    for (const [label,width,height] of (ONLY_FOUR_K ? [["4k",3840,2160]] : [["2k",2560,1440]])) {
      await page.setViewportSize({width,height}); await page.waitForTimeout(3500);
      const state = await host.evaluate(e=>e.getSceneEvidence());
      if (state.canvasWidth !== width || state.canvasHeight !== height || state.quality.tier !== "high") throw Error("Native high buffer mismatch " + JSON.stringify([state.canvasWidth,state.canvasHeight,state.quality.tier]));
      await control(label+"-before");
      const canvas = host.locator("canvas:not(.home-world-sketch)").first();
      await canvas.screenshot({path:path.join(Q,label+"-complete.png")});
      await page.evaluate(installProbe);
      await page.waitForFunction(()=>!!window.wideProbe,null,{timeout:10000});
      const error = await page.evaluate(()=>window.wideProbe.error); if(error)throw Error(error);
      for (const [index,mode] of ["render","ocean","shadow","blit","blit","shadow","ocean","render"].entries()) {
        await page.evaluate(({label,index,mode})=>window.wideProbe.setPhase(`${label}-${index}-${mode}`,mode),{label,index,mode});
        await page.waitForTimeout(5500);
        await page.evaluate(()=>window.wideProbe.setPhase(null,null));
      }
      await page.waitForTimeout(500);
      const result = await page.evaluate(()=>window.wideProbe.read());
      receipt.runs.push({label,...result});
      await page.evaluate(()=>{window.wideProbe.restore();delete window.wideProbe;});
      await save("receipt.json",receipt);
      await control(label+"-after");
    }
    receipt.backend = await host.locator("canvas:not(.home-world-sketch)").first().evaluate(c=>{const g=c.getContext('webgl2'),d=g.getExtension('WEBGL_debug_renderer_info');return {renderer:g.getParameter(d?d.UNMASKED_RENDERER_WEBGL:g.RENDERER),vendor:g.getParameter(d?d.UNMASKED_VENDOR_WEBGL:g.VENDOR),userAgent:navigator.userAgent}});
    await Promise.all(pendingBodies);
  } finally { await save("receipt.json",receipt); await browser.close(); }
}
main().catch(async e=>{await fs.writeFile(path.join(Q,"failure.txt"),e.stack);console.error(e);process.exitCode=1;});
