"""Private emitted-field planar count control; authoring source is never saved."""
import bpy,numpy as np,json,sys,types,hashlib
from pathlib import Path
from collections import Counter
ARGS={a[2:].split('=',1)[0]:a.split('=',1)[1] for a in sys.argv if a.startswith('--') and '=' in a}
ROOT=Path(ARGS['repo']).resolve();Q=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'bin'));sys.path.insert(0,str(Q))
assert bpy.app.version==(4,5,9)
assert hashlib.sha256((ROOT/'bin/coastal_export_geometry.py').read_bytes()).hexdigest()==json.loads((Q/'manifest.json').read_text())['owningModuleSha256']
from coastal_export_geometry import compact_constant_planar,EXACT_NORMAL_ATTRIBUTE
import audit_coastal_export_geometry as audit
k=types.ModuleType('calibrated');exec(compile((Q/'native_triangle_fields-v1.py').read_text(),'calibrated-source-kernel','exec'),k.__dict__);audit.weights=k.field_weights;audit.triangle_distance=k.triangle_distance
source=Path(ARGS['source']).resolve();assert hashlib.sha256(source.read_bytes()).hexdigest()==ARGS['expected-source-sha256'];before_hash=hashlib.sha256(source.read_bytes()).hexdigest();bpy.ops.wm.open_mainfile(filepath=str(source));names=['core__golden coastal sandstone','core_bathwing_liftaway_roof','core_estate_library_liftaway_roof','core_retreat_liftaway_roof','core_liftaway_cave_ceiling'];rows={}
def snapshot(m):
 m.calc_loop_triangles();p=[tuple(v.co) for v in m.vertices];a=m.color_attributes.active_color;exact=m.attributes.get(EXACT_NORMAL_ATTRIBUTE);n=[tuple(v.vector) for v in (exact.data if exact else m.corner_normals)];fs=[]
 for t in m.loop_triangles:fs.append({'p':[p[v] for v in t.vertices],'n':[n[li] for li in t.loops],'c':[tuple(a.data[v].color) if a else (1.,1.,1.,1.) for v in t.vertices],'m':m.materials[t.material_index].name})
 return {'triangles':fs}
def key(f):
 c=tuple((f['p'][i],f['n'][i],f['c'][i]) for i in range(3));return f['m'],min(c[i:]+c[:i] for i in range(3))
for name in names:
 m=bpy.data.objects[name].data;m.calc_loop_triangles();pp=np.asarray([v.co for v in m.vertices]);tt=pp[np.asarray([t.vertices for t in m.loop_triangles])];area2=np.linalg.norm(np.cross(tt[:,1]-tt[:,0],tt[:,2]-tt[:,0]),axis=1);native_zero=int(np.count_nonzero(area2==0.));a=m.color_attributes.active_color;had_rgb=a is not None
 if a:
  sums=np.zeros(len(m.vertices));counts=np.zeros(len(m.vertices))
  for loop,color in zip(m.loops,a.data):sums[loop.vertex_index]+=sum(color.color[:3])/3;counts[loop.vertex_index]+=1
  for old in list(m.color_attributes):m.color_attributes.remove(old)
  a=m.color_attributes.new(name='Baked bounce',type='BYTE_COLOR',domain='POINT')
  for i,c in enumerate(a.data):v=round(float(sums[i]/max(1.,counts[i]))*32)/32;c.color=(v,v,v,1.)
 else:
  a=m.color_attributes.new(name='Baked bounce',type='BYTE_COLOR',domain='POINT')
  for c in a.data:c.color=(1.,1.,1.,1.)
 m.color_attributes.active_color=a;before=snapshot(m);result=compact_constant_planar(m)
 if not had_rgb:m.color_attributes.remove(m.color_attributes.active_color)
 after=snapshot(m);ca=Counter(map(key,before['triangles']));cb=Counter(map(key,after['triangles']));different_before={'triangles':[]};different_after={'triangles':[]}
 for old,new,out in [(before,cb,different_before),(after,ca,different_after)]:
  seen=Counter()
  for f in old['triangles']:
   kk=key(f);seen[kk]+=1
   if seen[kk]>new[kk]:out['triangles'].append(f)
 if different_before['triangles'] and different_after['triangles']:
  f=audit.compare(different_before,after);r=audit.compare(different_after,before);passed=not f['failureCount'] and not r['failureCount']
 else:f={'failureCount':0};r={'failureCount':0};passed=not different_before['triangles'] and not different_after['triangles']
 rows[name]={'sourceNativeStrictZeroAreaTriangles':native_zero,'compaction':result,'beforeEmittedTriangles':len(before['triangles']),'afterEmittedTriangles':len(after['triangles']),'triangleSavings':len(before['triangles'])-len(after['triangles']),'unchangedOrientedTriangleFields':sum((ca&cb).values()),'changedSourceSurface':f,'changedCandidateSurface':r,'passed':passed,'originalRgbAbsenceRestored':had_rgb or m.color_attributes.active_color is None};print('LOSSLESS_ROOF_EXPORT',name,rows[name]['triangleSavings'],native_zero,passed,flush=True)
report={'sourceSha256':before_hash,'nativeSourceUnchanged':hashlib.sha256(source.read_bytes()).hexdigest()==before_hash,'owners':rows,'additionalSavingsBeyondExistingCoreExport':sum(r['triangleSavings'] for n,r in rows.items() if n!='core__golden coastal sandstone'),'policy':'Private export-emitted POINT color preparation exactly matches existing exporter. Only complete constant-color/normal/material coplanar stars are removed; all curves, gradients and boundaries remain. Exact oriented field identity is retained for unaffected triangles; changed whole surfaces use independently calibrated3um/N1e-6/RGB1e-7 checks. No native source is saved, no default quantization/LOD is changed, and no master/exporter is modified. Fresh-bake counts and actual decoded/rendered/producer gates remain required.'};Path(ARGS['report']).write_text(json.dumps(report,indent=2));print('ADDITIONAL_LOSSLESS_ROOF_SAVINGS',report['additionalSavingsBeyondExistingCoreExport'],flush=True)
