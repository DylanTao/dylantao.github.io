"""Stable native triangle distance/linear-field coordinates, including thin faces.

Float64 uses local plane/edge differences. Ill-conditioned input uses an exact
float-to-Decimal cross product and dominant-axis projection, independently of
the calibration oracle's Decimal Gram/KKT solve. No preservation bound changes.
"""
from decimal import Decimal, localcontext
import math
import numpy as np


def _input(point, triangle):
    p = np.asarray(point, dtype=np.float64)
    t = np.asarray(triangle, dtype=np.float64)
    u, v = t[1] - t[0], t[2] - t[0]
    n = np.cross(u, v)
    area = float(np.linalg.norm(n))
    condition = (float(u @ u) + float(v @ v)) / area if area else math.inf
    return p, t, u, v, n, condition


def _decimal(point, triangle, need_distance):
    with localcontext() as context:
        context.prec = 80
        dec = lambda x: Decimal.from_float(float(x))
        p = [dec(x) for x in point]
        t = [[dec(x) for x in row] for row in triangle]
        sub = lambda a, b: [x - y for x, y in zip(a, b)]
        dot = lambda a, b: sum(x * y for x, y in zip(a, b))
        u, v, ap = sub(t[1], t[0]), sub(t[2], t[0]), sub(p, t[0])
        n = [u[1] * v[2] - u[2] * v[1],
             u[2] * v[0] - u[0] * v[2],
             u[0] * v[1] - u[1] * v[0]]
        n2 = dot(n, n)
        weights = None
        if n2:
            height = dot(n, ap)
            projected = [ap[k] - n[k] * height / n2 for k in range(3)]
            axis = max(range(3), key=lambda k: abs(n[k]))
            j, k = [i for i in range(3) if i != axis]
            determinant = u[j] * v[k] - u[k] * v[j]
            wb = (projected[j] * v[k] - projected[k] * v[j]) / determinant
            wc = (u[j] * projected[k] - u[k] * projected[j]) / determinant
            weights = [1 - wb - wc, wb, wc]
            if need_distance and min(weights) >= 0:
                return float((height * height / n2).sqrt())
        if not need_distance:
            return np.asarray([float(x) for x in weights]) if weights is not None else None
        squared = []
        for i, j in [(0, 1), (1, 2), (2, 0)]:
            edge, delta = sub(t[j], t[i]), sub(p, t[i])
            length = dot(edge, edge)
            fraction = min(Decimal(1), max(Decimal(0), dot(delta, edge) / length)) if length else Decimal(0)
            residual = [delta[k] - fraction * edge[k] for k in range(3)]
            squared.append(dot(residual, residual))
        return float(min(squared).sqrt())


def barycentric(point, triangle):
    p, t, u, v, n, condition = _input(point, triangle)
    if condition > 1e4:
        return _decimal(p, t, False)
    ap = p - t[0]
    ap -= n * float(n @ ap) / float(n @ n)
    j, k = [i for i in range(3) if i != int(np.argmax(np.abs(n)))]
    determinant = u[j] * v[k] - u[k] * v[j]
    wb = (ap[j] * v[k] - ap[k] * v[j]) / determinant
    wc = (u[j] * ap[k] - u[k] * ap[j]) / determinant
    return np.asarray([1 - wb - wc, wb, wc])


def triangle_distance(point, triangle):
    p, t, u, v, n, condition = _input(point, triangle)
    if condition > 1e4:
        return _decimal(p, t, True)
    weights = barycentric(p, t)
    if weights is not None and min(weights) >= 0:
        return abs(float(n @ (p - t[0]))) / float(np.linalg.norm(n))
    distances = []
    for a, b in zip(t, np.roll(t, -1, axis=0)):
        edge, delta = b - a, p - a
        squared = float(edge @ edge)
        fraction = min(1., max(0., float(delta @ edge) / squared)) if squared else 0.
        distances.append(float(np.linalg.norm(delta - fraction * edge)))
    return min(distances)


def field_weights(point, triangle):
    weights = barycentric(point, triangle)
    if weights is None:
        nearest = min(range(3), key=lambda i: math.dist(point, triangle[i]))
        return tuple(float(i == nearest) for i in range(3))
    weights = np.clip(weights, 0., 1.)
    weights /= sum(weights)
    return tuple(weights)
