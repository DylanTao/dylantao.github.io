// Read-only exact-area census in actual decoded GLB primitive position/index streams.
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import crypto from 'node:crypto';
const args=Object.fromEntries(process.argv.slice(2).map(a=>{const at=a.indexOf('=');return[a.slice(2,at),a.slice(at+1)]}));const require=createRequire(import.meta.url),root=args.repo,q=path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/,'$1'));
const d=await require(path.join(root,'assets/js/vendor/three-r164/libs/draco/draco_wasm_wrapper.js'))({wasmBinary:fs.readFileSync(path.join(root,'assets/js/vendor/three-r164/libs/draco/draco_decoder.wasm'))});
const files=[['baseline',args.old],['candidate',args.new]];
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function readGlb(bytes){
 if(bytes.readUInt32LE(0)!==0x46546c67||bytes.readUInt32LE(4)!==2)throw Error('Not GLB2');
 let json,binary;for(let p=12;p<bytes.length;){const n=bytes.readUInt32LE(p),kind=bytes.readUInt32LE(p+4),data=bytes.subarray(p+8,p+8+n);if(kind===0x4e4f534a)json=JSON.parse(data.toString('utf8'));if(kind===0x004e4942)binary=data;p+=8+n;}return{json,binary};
}
function decodeDraco(g,p){
 const ext=p.extensions.KHR_draco_mesh_compression,bv=g.json.bufferViews[ext.bufferView],bytes=g.binary.subarray(bv.byteOffset||0,(bv.byteOffset||0)+bv.byteLength),dec=new d.Decoder(),mesh=new d.Mesh();
 try{
  const status=dec.DecodeArrayToMesh(new Int8Array(bytes),bytes.length,mesh);if(!status.ok())throw Error(status.error_msg());
  const a=dec.GetAttributeByUniqueId(mesh,ext.attributes.POSITION),count=mesh.num_points()*a.num_components(),pointer=d._malloc(count*4);let positions;
  try{dec.GetAttributeDataArrayForAllPoints(mesh,a,d.DT_FLOAT32,count*4,pointer);positions=new Float32Array(d.HEAPF32.buffer,pointer,count).slice();}finally{d._free(pointer);}
  const n=mesh.num_faces()*3,pi=d._malloc(n*4);let indices;try{dec.GetTrianglesUInt32Array(mesh,n*4,pi);indices=new Uint32Array(d.HEAPF32.buffer,pi,n).slice();}finally{d._free(pi);}
  const attributes={POSITION:positions};for(const [semantic,id] of Object.entries(ext.attributes)){if(semantic==='POSITION')continue;const a=dec.GetAttributeByUniqueId(mesh,id),n=mesh.num_points()*a.num_components(),pointer=d._malloc(n*4);try{dec.GetAttributeDataArrayForAllPoints(mesh,a,d.DT_FLOAT32,n*4,pointer);attributes[semantic]=new Float32Array(d.HEAPF32.buffer,pointer,n).slice();}finally{d._free(pointer);}}return{positions,indices,attributes};
 }finally{d.destroy(mesh);d.destroy(dec);}
}
function accessor(g,i){
 const a=g.json.accessors[i],v=g.json.bufferViews[a.bufferView],ctors={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array},width={SCALAR:1,VEC2:2,VEC3:3,VEC4:4}[a.type],C=ctors[a.componentType],n=a.count*width,out=new C(n),start=(v.byteOffset||0)+(a.byteOffset||0),stride=v.byteStride||width*C.BYTES_PER_ELEMENT;
 if(a.sparse)throw Error('Sparse accessor unsupported');for(let j=0;j<a.count;j++)for(let k=0;k<width;k++){const at=start+j*stride+k*C.BYTES_PER_ELEMENT,b=g.binary;out[j*width+k]=a.componentType===5126?b.readFloatLE(at):a.componentType===5125?b.readUInt32LE(at):a.componentType===5123?b.readUInt16LE(at):a.componentType===5121?b.readUInt8(at):a.componentType===5122?b.readInt16LE(at):b.readInt8(at);}return out;
}
const hole=[-12.609999656677246,-.25999999046325684,10.146266460418701];
function distanceToTriangle(point,flat,ids){
 const p=ids.map(i=>[flat[3*i],flat[3*i+1],flat[3*i+2]]),a=p[0],u=p[1].map((v,k)=>v-a[k]),v=p[2].map((v,k)=>v-a[k]),n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]],nl=Math.hypot(...n);
 let best=Infinity;
 if(nl){const axis=n.reduce((best,x,i)=>Math.abs(x)>Math.abs(n[best])?i:best,0),q=[0,1,2].filter(i=>i!==axis),dx=point[q[0]]-a[q[0]],dy=point[q[1]]-a[q[1]],det=u[q[0]]*v[q[1]]-u[q[1]]*v[q[0]],b=(dx*v[q[1]]-dy*v[q[0]])/det,c=(u[q[0]]*dy-u[q[1]]*dx)/det;if(b>=0&&c>=0&&b+c<=1)best=Math.abs(n.reduce((s,x,k)=>s+x*(point[k]-a[k]),0))/nl;}
 for(let i=0;i<3;i++){const a=p[i],b=p[(i+1)%3],d=b.map((v,k)=>v-a[k]),w=point.map((v,k)=>v-a[k]),den=d.reduce((s,v)=>s+v*v,0),t=den?Math.max(0,Math.min(1,d.reduce((s,v,k)=>s+v*w[k],0)/den)):0;best=Math.min(best,Math.hypot(...point.map((v,k)=>v-a[k]-t*d[k])));}
 return best;
}
const report={method:'Actual GLB2 primitive bytes and pinned Draco WASM decode; cross product computed from exact decoded Float32 position values in Float64 arithmetic. A triangle counts only if all three cross-product components equal exactly zero, with no epsilon, short-edge or near-zero filtering. Native source/exporter/assets are untouched.',files:{}};
for(const [label,file] of files){
 if(!fs.existsSync(file)){report.files[label]={file,unavailable:true};continue;}
 const bytes=fs.readFileSync(file),g=readGlb(bytes),rows=[],decoded=new Map();
 for(const [ni,node] of (g.json.nodes||[]).entries()){
  if(node.mesh==null)continue;
  for(const [pi,primitive] of g.json.meshes[node.mesh].primitives.entries()){
   if((primitive.mode??4)!==4)throw Error('Nontriangle mode '+label+' '+ni+' '+pi);
   const key=node.mesh+':'+pi;let row=decoded.get(key);
   if(!row){const stream=primitive.extensions?.KHR_draco_mesh_compression?decodeDraco(g,primitive):{positions:accessor(g,primitive.attributes.POSITION),indices:primitive.indices==null?null:accessor(g,primitive.indices)},p=stream.positions,attrs=stream.attributes||Object.fromEntries(Object.entries(primitive.attributes).map(([name,i])=>[name,accessor(g,i)])),attributeBits=Object.fromEntries(Object.entries(attrs).map(([name,a])=>[name,new Uint32Array(Float32Array.from(a).buffer)])),sameTuple=(i,j)=>Object.values(attributeBits).every(a=>{const width=a.length/(p.length/3);for(let c=0;c<width;c++)if(a[i*width+c]!==a[j*width+c])return false;return true;}),ix=stream.indices||Uint32Array.from({length:p.length/3},(_,i)=>i);let exact=0,repeated=0,identicalTuplePair=0,otherZero=0,holeDistance=Infinity;const witnesses=[];
    for(let t=0;t<ix.length;t+=3){const i=ix[t],j=ix[t+1],k=ix[t+2],a=i*3,b=j*3,c=k*3,ux=p[b]-p[a],uy=p[b+1]-p[a+1],uz=p[b+2]-p[a+2],vx=p[c]-p[a],vy=p[c+1]-p[a+1],vz=p[c+2]-p[a+2],cross=[uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx];if(node.name==='core__golden coastal sandstone')holeDistance=Math.min(holeDistance,distanceToTriangle(hole,p,[i,j,k]));if(cross.every(v=>v===0)){exact++;if(i===j||j===k||k===i)repeated++;else if(sameTuple(i,j)||sameTuple(j,k)||sameTuple(k,i))identicalTuplePair++;else otherZero++;if(witnesses.length<3)witnesses.push({triangle:t/3,indices:[i,j,k],positions:[[...p.subarray(a,a+3)],[...p.subarray(b,b+3)],[...p.subarray(c,c+3)]]});}}
    row={holeWitnessDistanceM:Number.isFinite(holeDistance)?holeDistance:null,primitive:pi,materialIndex:primitive.material??null,material:g.json.materials?.[primitive.material]?.name??null,rawTriangles:ix.length/3,exactZeroAreaTriangles:exact,identicalIndexDegenerates:repeated,distinctIndicesWithIdenticalFullInputTuplePair:identicalTuplePair,otherDistinctIndexZeroAreaTriangles:otherZero,activeVertexInputSemantics:Object.keys(attrs),nonzeroAreaTriangles:ix.length/3-exact,indexAccessorCountMatches:primitive.indices==null||g.json.accessors[primitive.indices].count===ix.length,positionStreamSha256:sha(Buffer.from(p.buffer,p.byteOffset,p.byteLength)),indexStreamSha256:sha(Buffer.from(ix.buffer,ix.byteOffset,ix.byteLength)),witnesses};decoded.set(key,row);
   }
   rows.push({nodeIndex:ni,owner:node.name??'node-'+ni,...row});
  }
 }
 const total=rows.reduce((s,r)=>s+r.rawTriangles,0),zero=rows.reduce((s,r)=>s+r.exactZeroAreaTriangles,0);report.files[label]={file,sha256:sha(bytes),bytes:bytes.length,rawNodeTriangles:total,exactZeroAreaTriangles:zero,nonzeroAreaTriangles:total-zero,primitiveRows:rows,holeWitnessGLTFWorld:hole,holeDistanceToActualDecodedCoreM:Math.min(...rows.filter(r=>r.owner==='core__golden coastal sandstone').map(r=>r.holeWitnessDistanceM))};console.log('ZERO_CLASSES',label,total,zero,rows.reduce((s,r)=>s+r.identicalIndexDegenerates,0),rows.reduce((s,r)=>s+r.distinctIndicesWithIdenticalFullInputTuplePair,0),rows.reduce((s,r)=>s+r.otherDistinctIndexZeroAreaTriangles,0));
}
fs.writeFileSync(args.report,JSON.stringify(report,null,2));
