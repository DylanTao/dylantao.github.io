# Qualified planar export coverage repair

Commit `e0b8c1dd0` changes only `bin/coastal_export_geometry.py`, its nine regression tests, and the actual annulus fixture. Preserve original face corridors through holes/pinches, compact only certified planar disks, and reconstruct explicit native corner-edge ownership. The old110mm false cap and the41-edge `from_pydata` failure are retained controls. Every final prepared owner is closed; bidirectional geometry/N/RGB limits remain3um/1e-6/1e-7. Core savings19238 versus the old19836; the corrected actual home-shell costs598 more triangles.

The fresh final-code delivered GLB has258810 raw node triangles,948364bytes, and112.212mm clearance at the old hole witness (old export0). This is decoded geometry evidence, not a3um Draco precision claim. Inspect the four full4K renders with their camera/error reports. The earlier183 shape remains appearance-rejected; no final mountain, combined collector/cache, byte-budget or publication acceptance is implied.

Reproduce the read-only native proof from any checkout containing the exact owning module from that commit (Blender4.5.9):

```powershell
& 'D:/tools/blender-4.5.9-windows-x64/blender.exe' --background --factory-startup --python-exit-code 1 -t 4 --python '<packet>/run_native_audit.py' -- --repo=<repo> --source=<native.blend> --expected-source-sha256=<actual-pinned-native-sha256> --report=<private-qa>/native-audit.json
node '<packet>/run_decoded_audit.mjs' --repo=<repo> --old=<old-home-shell.glb> --new=<corrected-home-shell.glb> --report=<private-qa>/decoded-audit.json
python -m unittest discover -s test -p test_coastal_export_geometry.py
```

The native proof reproduces the existing emitted POINT color preparation, tests all five owners independently, and never saves the native source. It bundles the independently calibrated closest-point kernel and original field auditor. The decoded proof uses that checkout's pinned Draco WASM directly, retains exact area/index/full-input-tuple census, and tests the actual hole witness. Read-only input hashes and all evidence-file hashes are bound in `manifest.json`. The native/GLB binaries remain external pinned inputs; the packet does not duplicate a master or install assets.
