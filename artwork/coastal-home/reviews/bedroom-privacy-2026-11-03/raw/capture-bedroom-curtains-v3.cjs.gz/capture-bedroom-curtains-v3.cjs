const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {chromium,expect}=require('@playwright/test');
const q=__dirname,out=path.join(q,'bedroom-curtains-appearance-v3');if(fs.existsSync(out))throw Error('Fresh output required');fs.mkdirSync(out);
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),rows=[],errors=[],failed=[];
const state=s=>s.evaluate(e=>e.getSceneEvidence());
async function settle(s){let prior;for(let i=0;i<100;i++){const e=await state(s);if(prior&&!e.traveling&&Math.hypot(...e.camera.map((v,n)=>v-prior[n]))<1e-5)return e;prior=e.camera;await s.page().waitForTimeout(100);}throw Error('Camera not settled');}
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
 try{
  for(const kind of ['candidate']){
   const preview=path.join(q,kind==='baseline'?'remote-refresh-checkpoint-v2':'bedroom-curtains-checkpoint-v3'),built=path.join(preview,'site/al-folio'),server=JSON.parse(fs.readFileSync(path.join(preview,'server.json')));
   const modules=JSON.parse(fs.readFileSync(path.join(built,'assets/js/module-build.json'))).modules;
   for(const[rel,row]of Object.entries(modules))expect(hash(fs.readFileSync(path.join(built,rel)))).toBe(row.outputSha256);
   const context=await browser.newContext({viewport:{width:2560,height:1440},deviceScaleFactor:1,timezoneId:'America/Los_Angeles',reducedMotion:'reduce',colorScheme:'light'}),p=await context.newPage();p.setDefaultTimeout(45000);
   p.on('pageerror',e=>errors.push({kind,error:e.message}));p.on('console',m=>{if(m.type()==='error')errors.push({kind,error:m.text()});});p.on('requestfailed',r=>failed.push({kind,url:r.url(),failure:r.failure()}));
   await p.clock.setFixedTime(new Date('2026-11-03T10:00:00-08:00'));
   await p.route(/https:\/\/(?:analytics\.google\.com|www\.google-analytics\.com|www\.googletagmanager\.com|plausible\.io)\//,r=>r.fulfill({status:204,body:''}));
   await p.goto(server.url+'?scene-lab=1&quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});
   await p.locator('[data-home-desk-mode="3d"]').click();const scene=p.locator('[data-home-desk-scene]'),canvas=scene.locator('canvas:not(.home-world-sketch)');await scene.scrollIntoViewIfNeeded();await expect(scene).toHaveAttribute('data-scene-state','ready',{timeout:180000});
   await p.locator('[data-world-places]>summary').click();await p.locator('[data-world-destination="sleep"]').click();await settle(scene);await p.locator('[data-world-fullscreen]').click();
   for(const[period,minute]of [['sleep-morning',600],['sleep-night',210],['awake-afternoon',900]]){
    await p.locator('[data-world-time]').evaluate((e,v)=>{e.value=String(v);e.dispatchEvent(new Event('input',{bubbles:true}));},minute);
    await p.locator('[data-world-places]>summary').click();await p.locator('[data-world-destination="sleep"]').click();await settle(scene);
    for(const view of ['inside','window']){
     if(view==='window')await scene.evaluate(e=>e.setLabCamera({target:[-6.84,3.0,3.43],yaw:Math.PI,pitch:.07,radius:7,free:true}));
     const e=await settle(scene);if(kind==='candidate'){expect(e.simulation.bedroomCurtains.target).toBe(period.startsWith('sleep')?0:1);expect(e.simulation.lightField.cacheHit).toBe(true);}
     const image=await canvas.screenshot({path:path.join(out,kind+'-'+period+'-'+view+'.png')});expect(image.length).toBeGreaterThan(50000);
     const backend=await canvas.evaluate(c=>{const g=c.getContext('webgl2'),x=g.getExtension('WEBGL_debug_renderer_info');return{renderer:g.getParameter(x?.UNMASKED_RENDERER_WEBGL||g.RENDERER),buffer:[g.drawingBufferWidth,g.drawingBufferHeight]};});
     rows.push({kind,period,minute,view,scope:view==='window'?'Disclosed fixed seaward authoring camera':'Actual public Sleep destination camera',pngSha256:hash(image),backend,evidence:e});fs.writeFileSync(path.join(out,'PROGRESS.json'),JSON.stringify(rows,null,2));
    }
   }
   await context.close();
  }
  fs.writeFileSync(path.join(out,'REPORT.json'),JSON.stringify({at:new Date().toISOString(),scope:'Complete compiled baseline/candidate previews with all model bodies retained. Current official candidate cache installed as separately recorded. Authoring clock events and a disclosed exterior camera isolate drapes; these do not claim physical-phone performance or final new geology.',browser:browser.version(),rows,errors,failed},null,2)+'\n');expect(errors).toEqual([]);
 }finally{await browser.close();}
})().catch(e=>{fs.writeFileSync(path.join(out,'FAILURE.json'),JSON.stringify({error:String(e),stack:e.stack,rows,errors,failed},null,2)+'\n');console.error(e);process.exitCode=1;});
