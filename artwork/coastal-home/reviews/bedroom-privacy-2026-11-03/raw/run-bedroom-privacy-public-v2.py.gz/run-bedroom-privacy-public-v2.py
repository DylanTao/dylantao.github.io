from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,os,time
q=Path(__file__).parent;out=q/'bedroom-curtains-checkpoint-v3';wt=Path('C:/dev/dqa1103')
env=dict(os.environ,NO_WEBSERVER='1',VISUAL_BASE_URL=json.loads((out/'server.json').read_bytes())['url'].rstrip('/'),CI='1')
command=['C:/Program Files/nodejs/npx.cmd','playwright','test','--config','test/visual/public.config.js','--project','desktop-1440','--project','laptop-1280','--project','tablet-768','--project','mobile-390','--workers','1','--output',str(out/'browser-results'),'test/visual/desk-scene.spec.js','--grep','sleeping privacy drapes']
start=time.monotonic()
with(out/'PRIVACY-BROWSER.log').open('wb')as log:r=subprocess.run(command,cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
(out/'PRIVACY-BROWSER.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),command=command,env={k:env[k]for k in ['NO_WEBSERVER','VISUAL_BASE_URL','CI']},exitCode=r.returncode,seconds=time.monotonic()-start,scope='Actual public privacy case at four standard widths: asleep embedded/fullscreen bedroom with inside camera, closed drapes, public Walk spawn and normal Noon theme waking/opening. No authoring activity selector or geometry substitution. No performance claim.'),indent=2)+'\n',encoding='utf8');print(json.dumps(dict(exitCode=r.returncode,seconds=time.monotonic()-start)));raise SystemExit(r.returncode)
