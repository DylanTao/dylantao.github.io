from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib,os,time,shutil
root=Path.cwd();q=Path(__file__).parent;out=q/'bedroom-curtains-bake-v1';assert not out.exists();out.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
protected=['artwork/coastal-home/coastal-home.blend','assets/models/home/home-shell.glb','assets/models/home/room-kitchen.glb','assets/models/home/room-sleep.glb']
before={p:sha(root/p)for p in protected}
for rel in ['assets/models/home/manifest.json','assets/models/home/static-light-field.json']:
 dest=out/'before'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,dest)
inputs=['assets/js/home-scene/bedroom-curtains.mjs','assets/js/home-scene/controller.mjs','bin/coastal_static_light_inputs.cjs','test/coastal-bedroom-curtains.test.mjs']
record={'at':datetime.now(timezone.utc).isoformat(),'sourceHead':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'sourceFiles':[{'path':p,'sha256':sha(root/p)}for p in inputs],'protectedBefore':before,'scope':'Official owning producer with exact current root inputs. The complete frozen62690preview supplies generated HTML/pictures; the official producer itself serves every current scene source/model and strips the prior cache descriptor. No private native/garden/entrance/coffee activation. Expected transport bits unchanged because dynamic drapes are outside static model collection.'}
(out/'SOURCE.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
env=dict(os.environ,COASTAL_CACHE_URL='http://127.0.0.1:62690/al-folio/',COASTAL_BAKE_TIMEOUT_MS='300000');start=time.monotonic()
with(out/'bake.log').open('wb')as log:r=subprocess.run(['node','bin/bake_coastal_static_light.cjs'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
record.update(exitCode=r.returncode,seconds=time.monotonic()-start,protectedAfter={p:sha(root/p)for p in protected})
assert record['protectedBefore']==record['protectedAfter']
if r.returncode==0:
 cache=json.loads((root/'assets/models/home/static-light-field.json').read_bytes());old=json.loads((out/'before/assets/models/home/static-light-field.json').read_bytes())
 record.update(cacheBytes=(root/'assets/models/home/static-light-field.json').stat().st_size,cacheSha256=sha(root/'assets/models/home/static-light-field.json'),manifestSha256=sha(root/'assets/models/home/manifest.json'),transportExact=cache['transport']==old['transport'],momentsExact=cache['moments']==old['moments'])
(out/'PROCESS.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');print(json.dumps(record));assert r.returncode==0
