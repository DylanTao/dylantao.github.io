import hashlib
import json
import re
from pathlib import Path

q = Path(__file__).resolve().parent
old = Path('C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/composed-native-rigid-r9-audit-v1/body-census-v2')
source = q / 'owning-ao-v1/candidate.blend'
manifest = Path('C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/combined-side-fan-control-v1/candidate-attempt-1/manifest.json')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(source) == 'f89c2c2eb438a78ed7c9bb84779248fe9846fe902acd18ae1140ef16765bf295'
assert sha(manifest) == '1761204ff8d3bfc289296d252dadc64dab3bea44687065d5a803a950223f324f'
out = q / 'fresh-garden-v8-body'
assert not out.exists()
out.mkdir()
receipt = {'source': str(source), 'sourceSha256': sha(source), 'manifest': str(manifest), 'manifestSha256': sha(manifest), 'templates': {}, 'scope': 'Fresh extraction of actual post-garden, post-owning-AO source. Unchanged full-box SAT, support and head rays; no decoded export or gait admission.'}
extract = (old / 'widened-native-body-census.py').read_text()
extract, count = re.subn(r'^AFTER=Path\(.+\)$', 'AFTER=Path(' + repr(source.as_posix()) + ')', extract, flags=re.M)
assert count == 1
extract = extract.replace('8607c3f2179e968c7c1bd14a60d630a0168b399b13167d826a69f0d66fadb9b1', sha(source))
(out / 'extract.py').write_text(extract, encoding='utf8', newline='\n')
for name in ('native-body.mjs', 'native-portal.mjs'):
    text = (old / name).read_text()
    text = text.replace('C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/composed-rigid-r9/manifest.json', manifest.as_posix())
    text = text.replace('actual corrected8607c3f2 native triangles', 'actual post-garden/post-owning-AO f89c2c2e native triangles')
    text = text.replace('actual corrected8607c3f2 native triangles', 'actual post-garden/post-owning-AO f89c2c2e native triangles')
    (out / name).write_text(text, encoding='utf8', newline='\n')
    receipt['templates'][name] = {'originalSha256': sha(old / name), 'executedSha256': sha(out / name), 'onlyChanges': 'Pinned manifest and explicit source-scope label; physical SAT/ray math unchanged.'}
garden = (q / 'qualify-garden-v5.py').read_text()
garden = garden.replace("source = q / 'garden-v5/candidate.blend'", 'source = Path(' + repr(source.as_posix()) + ')')
garden = garden.replace('9c48aea4b5626335e4fc39519e0a2249a45627fc13fe7bd7dd306739b13ce160', sha(source))
garden = garden.replace("'GARDEN-V5-NATIVE.json'", "'GARDEN-NATIVE.json'")
garden = garden.replace('New additive geometry on exact R9 parent; all503 existing native meshes/materials separately exact in GARDEN.json. Final reconstructed source, decoded export, cache and appearance gates remain.', 'All actual garden geometry and fifteen floor contacts extracted from fresh post-garden/post-owning-AO f89c2c2e source. Decoded export, cache and appearance gates remain.')
(out / 'garden-native.py').write_text(garden, encoding='utf8', newline='\n')
check = (q / 'check-garden-v5-body.mjs').read_text()
check = re.sub(r"const bodyPath='[^']+';", "const bodyPath=path.join(q,'COMPOSED-NATIVE-BODY.json');", check)
check = check.replace("'GARDEN-V5-NATIVE.json'", "'GARDEN-NATIVE.json'")
check = check.replace("'GARDEN-V5-BODY.json'", "'GARDEN-BODY.json'")
check = check.replace('8607c3f2179e968c7c1bd14a60d630a0168b399b13167d826a69f0d66fadb9b1', sha(source))
check = check.replace('Pinned full105-box R9 census required', 'Fresh full105-box actual f89 source census required')
check = check.replace('pinned full-width', 'fresh full-width').replace('R9 parent fields are exact in native replay.', 'Source and body census are the same actual f89 native source.')
(out / 'garden-body.mjs').write_text(check, encoding='utf8', newline='\n')
(out / 'INPUTS.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
print(json.dumps({'out': str(out), 'sourceSha256': sha(source)}))
