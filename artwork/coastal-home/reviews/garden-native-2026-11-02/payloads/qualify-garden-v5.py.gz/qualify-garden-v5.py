import bpy
import bmesh
import hashlib
import json
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree

q = Path(__file__).resolve().parent
source = q / 'garden-v5/candidate.blend'
assert hashlib.sha256(source.read_bytes()).hexdigest() == '9c48aea4b5626335e4fc39519e0a2249a45627fc13fe7bd7dd306739b13ce160'
bpy.ops.wm.open_mainfile(filepath=str(source))
result = {'sourceSha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'objects': [], 'triangles': [], 'failures': []}
for obj in bpy.context.scene.objects:
    if not obj.name.startswith('core_breakfast_garden'):
        continue
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    unseen = set(bm.faces)
    components = []
    while unseen:
        start = unseen.pop()
        part, stack = {start}, [start]
        while stack:
            for edge in stack.pop().edges:
                for face in edge.link_faces:
                    if face in unseen:
                        unseen.remove(face)
                        part.add(face)
                        stack.append(face)
        temp, mapping = bmesh.new(), {}
        for face in part:
            for vert in face.verts:
                if vert not in mapping:
                    mapping[vert] = temp.verts.new(vert.co)
            temp.faces.new([mapping[v] for v in face.verts])
        closed = all(e.is_manifold and e.is_contiguous for e in temp.edges)
        volume = temp.calc_volume(signed=True) if closed else None
        components.append({'faces': len(part), 'closedDirected': closed, 'signedVolumeM3': volume})
        temp.free()
    leaf = 'fern leaf' in obj.name
    if not leaf and any(not c['closedDirected'] or c['signedVolumeM3'] <= 1e-12 for c in components):
        result['failures'].append(obj.name + ': solid orientation/closure')
    if leaf and (len(components) != 14 or any(f.calc_area() <= 1e-12 for f in bm.faces)):
        result['failures'].append(obj.name + ': leaf count/area')
    points = [obj.matrix_world @ v.co for v in obj.data.vertices]
    world = [[float(p.x), float(p.z), float(-p.y)] for p in points]
    obj.data.calc_loop_triangles()
    for tri in obj.data.loop_triangles:
        result['triangles'].append({'owner': obj.name, 'triangle': tri.index, 'points': [world[i] for i in tri.vertices]})
    result['objects'].append({'name': obj.name, 'components': components, 'lo': [min(p[k] for p in world) for k in range(3)], 'hi': [max(p[k] for p in world) for k in range(3)]})
    bm.free()
floor = bpy.data.objects['core_breakfast_nook__warm cut stone']
floor.data.calc_loop_triangles()
tree = BVHTree.FromPolygons([floor.matrix_world @ v.co for v in floor.data.vertices], [tuple(t.vertices) for t in floor.data.loop_triangles], all_triangles=True)
contacts = []
for x in (-6.50, -6.27, -6.0, -5.80, -5.58):
    for z in (6.26, 6.37, 6.48):
        point, normal, index, distance = tree.ray_cast(Vector((x, -z, -.99)), Vector((0, 0, -1)), .2)
        if point is None or abs(float(point.z) - (-1.02)) > .000003:
            result['failures'].append('Missing exact floor support')
        contacts.append({'x': x, 'landward': z, 'floorUp': float(point.z) if point else None, 'baseOverlapM': float(point.z) + 1.028 if point else None})
result['floorContacts'] = contacts
result['scope'] = 'New additive geometry on exact R9 parent; all503 existing native meshes/materials separately exact in GARDEN.json. Final reconstructed source, decoded export, cache and appearance gates remain.'
(q / 'GARDEN-V5-NATIVE.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf8')
assert not result['failures'], result['failures']
assert len(result['triangles']) == 1092
print(json.dumps({'triangles': len(result['triangles']), 'floorContacts': len(contacts), 'failures': result['failures']}))
