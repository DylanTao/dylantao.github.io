import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';

const q = path.dirname(import.meta.filename);
const T = await import(pathToFileURL(path.join(process.cwd(), 'assets/js/three.module.min.js')));
const bodyBytes = fs.readFileSync(path.join(q, 'COMPOSED-NATIVE-BODY.json'));
const body = JSON.parse(bodyBytes);
const rawBytes = fs.readFileSync(path.join(q, 'NATIVE-REGION-TRIANGLES.json.gz'));
const raw = JSON.parse(zlib.gunzipSync(rawBytes));
const groups = new Map();
for (const row of raw.triangles) {
  if (/leaf|grass|flora|needles/.test(row.owner)) continue;
  const key = row.owner + '::' + row.material;
  if (!groups.has(key)) groups.set(key, { owner: row.owner, material: row.material, p: [] });
  groups.get(key).p.push(...row.points.flat());
}
const meshes = [];
for (const group of groups.values()) {
  const geometry = new T.BufferGeometry();
  geometry.setAttribute('position', new T.BufferAttribute(new Float64Array(group.p), 3));
  const mesh = new T.Mesh(geometry, new T.MeshBasicMaterial({ side: T.DoubleSide }));
  mesh.name = group.owner;
  mesh.updateMatrixWorld();
  meshes.push(mesh);
}
const ray = new T.Raycaster();
const required = body.rows.filter(r => r.id.startsWith('exit-') || r.id.startsWith('whole'));
if (required.length !== 105 || required.some(r => r.blockers.length || !r.support)) throw Error('Unchanged full standing-box SAT/support must pass');
const rows = required.map(row => {
  const hx = (row.box[1][0] - row.box[0][0]) / 2;
  const hz = (row.box[1][2] - row.box[0][2]) / 2;
  const outsideOriginal = row.head.filter(h => Math.abs(h.offset[0]) > hx || Math.abs(h.offset[1]) > hz);
  const samples = [[0, 0], [-Math.min(.24, hx), 0], [Math.min(.24, hx), 0], [0, -Math.min(.24, hz)], [0, Math.min(.24, hz)]];
  const head = samples.map(offset => {
    const x = row.planned[0] + offset[0], z = row.planned[2] + offset[1];
    if (x < row.box[0][0] - 1e-12 || x > row.box[1][0] + 1e-12 || z < row.box[0][2] - 1e-12 || z > row.box[1][2] + 1e-12) throw Error('Sample leaves actual standing rectangle');
    ray.set(new T.Vector3(x, row.actualFoot + .221, z), new T.Vector3(0, 1, 0));
    const hit = ray.intersectObjects(meshes, false)[0];
    return { offset, clearance: hit ? hit.distance + .221 : null, owner: hit?.object.name ?? null };
  });
  return { id: row.id, box: row.box, head, originalOutsideFootprintRays: outsideOriginal };
});
const minimum = Math.min(...rows.flatMap(r => r.head.map(h => h.clearance).filter(v => v !== null)));
if (minimum < 2.1) throw Error('Headroom below unchanged2.1m requirement in actual standing box');
const failedOutside = rows.flatMap(r => r.originalOutsideFootprintRays.filter(h => h.clearance !== null && h.clearance < 2.1).map(h => ({ id: r.id, ...h })));
const result = {
  sourceSha256: raw.sourceSha256,
  triangleCensusSha256: crypto.createHash('sha256').update(rawBytes).digest('hex'),
  bodyCensusSha256: crypto.createHash('sha256').update(bodyBytes).digest('hex'),
  producerSha256: crypto.createHash('sha256').update(fs.readFileSync(import.meta.filename)).digest('hex'),
  standingBoxes: rows.length, unchangedContinuousSATBlockers: 0, missingSupport: 0,
  minimumHeadWithinStandingFootprintM: minimum,
  originalOutsideFootprintFailures: failedOutside,
  scope: 'Supplement to retained failed unmodified R9 head-ray collector: the narrow aisle/head rectangle was .05m deep while its longitudinal diagnostic rays extended .24m in either direction. Keep the same actual standing boxes, continuous finite triangle SAT and2.1m head requirement. Only ray sampling coordinates are clamped into that exact box. Planting-bed space outside the aisle is not claimed as walkable.',
  rows
};
fs.writeFileSync(path.join(q, 'STANDING-HEAD-QUALIFICATION.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ boxes: rows.length, minimumHeadM: minimum, retainedOriginalOutsideFailures: failedOutside }));
