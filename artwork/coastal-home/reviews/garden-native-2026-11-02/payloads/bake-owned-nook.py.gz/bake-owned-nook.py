"""Private owning bake with exact restoration of all inherited corner colors."""
import array
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import sys
import bpy

root = Path.cwd()
q = Path(__file__).resolve().parent
source = q / 'garden-on-v8/candidate.blend'
source_sha = '3f7932dae803fbe9d71693288d8c9f6688438f31b56eda7b35bd6ff0349245cf'
manifest = Path('C:/dev/site-takeover-worktrees/breakfast-nook-20261101/.jekyll-cache/visual-qa/breakfast-nook-20261101/combined-side-fan-control-v1/candidate-attempt-1/manifest.json')
assert hashlib.sha256(source.read_bytes()).hexdigest() == source_sha
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == '1761204ff8d3bfc289296d252dadc64dab3bea44687065d5a803a950223f324f'
assert bpy.app.version == (4, 5, 9)
out = q / 'owning-ao-v1'
assert not out.exists()
out.mkdir()
ns = runpy.run_path(str(root / 'artwork/coastal-home/reviews/bedroom-ambience-2026-11-01/replay_lighting.py'))
cuts = {'coast_shared_golden coastal sandstone','core__golden coastal sandstone','core_reno_slab_ground','core_reno_floorboards_lower','core_finish_bedchamber_rock_fin__La Jolla bluff sandstone'}
plants = {'kitchen__olive leaf','kitchen_nook_olive__honey ash','kitchen_nook_olive_stem__honey ash','kitchen_nook_olive_pot__terracotta'}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def shape(obj):
    mesh = obj.data
    h = hashlib.sha256()
    h.update(repr(tuple(v for row in obj.matrix_world for v in row)).encode())
    for collection, field, width, kind in [
        (mesh.vertices,'co',3,'f'),(mesh.vertices,'normal',3,'f'),
        (mesh.edges,'vertices',2,'i'),(mesh.loops,'vertex_index',1,'i'),
        (mesh.polygons,'loop_start',1,'i'),(mesh.polygons,'loop_total',1,'i'),
        (mesh.polygons,'material_index',1,'i'),(mesh.polygons,'use_smooth',1,'b'),
        (mesh.corner_normals,'vector',3,'f')]:
        h.update(ns['stream'](collection,field,width,kind))
    for attr in sorted(mesh.attributes,key=lambda a:a.name):
        if attr.data_type in {'FLOAT_COLOR','BYTE_COLOR'}:
            continue
        if attr.data_type in {'FLOAT_VECTOR','FLOAT2'}:
            field,width,kind = 'vector',2 if attr.data_type=='FLOAT2' else 3,'f'
        elif attr.data_type in {'INT16_2D','INT32_2D','INT32_4D'}:
            field,width,kind = 'value',4 if attr.data_type=='INT32_4D' else 2,'i'
        elif attr.data_type in {'FLOAT','INT','BOOLEAN','INT8'}:
            field,width,kind = 'value',1,'f' if attr.data_type=='FLOAT' else 'i'
        else:
            raise RuntimeError('Unhandled attribute '+attr.name+'/'+attr.data_type)
        h.update(repr((attr.name,attr.domain,attr.data_type)).encode())
        h.update(ns['stream'](attr.data,field,width,kind))
    h.update(repr([m.name if m else None for m in mesh.materials]).encode())
    return h.hexdigest()

def colors(attr):
    values=array.array('f',[0.0])*(len(attr.data)*4)
    attr.data.foreach_get('color',values)
    return values

bpy.ops.wm.open_mainfile(filepath=str(source))
before = ns['native_state']()
materials = ns['materials']()
full = set(plants)
cap_loops = {}
for obj in bpy.context.scene.objects:
    if obj.type != 'MESH':
        continue
    if obj.name.startswith('core_breakfast') and not any(m and m.name=='facade low-iron glass' for m in obj.data.materials):
        full.add(obj.name)
    if obj.name in cuts:
        sid=obj.data.attributes['Breakfast source triangle']
        assert sid.domain=='FACE' and sid.data_type=='INT'
        loops={loop for face in obj.data.polygons if sid.data[face.index].value==0 for loop in range(face.loop_start,face.loop_start+face.loop_total)}
        if loops:
            cap_loops[obj.name]=sorted(loops)
owned = full | set(cap_loops)
assert len(full)==18 and len(cap_loops)==4 and len(owned)==22
assert owned.issubset(before)
shapes = {name:shape(bpy.data.objects[name]) for name in owned}
work=out/'bake-work.blend'
shutil.copyfile(source,work)
sys.argv=['bake_coastal_light.py','--','--cpu',f'--source={work}',f'--manifest={manifest}',
          '--prefixes='+','.join(sorted(owned)),f'--report={out / "BAKE.json"}']
runpy.run_path(str(root/'bin/bake_coastal_light.py'),run_name='__main__')
stats=json.loads((out/'BAKE.json').read_bytes())
assert {row['mesh'] for row in stats['surfaces']}==owned
baked={}
for name in owned:
    obj=bpy.data.objects[name]
    assert shape(obj)==shapes[name],name
    attr=obj.data.color_attributes.active_color
    assert attr and attr.domain=='CORNER' and attr.data_type=='FLOAT_COLOR'
    baked[name]=colors(attr)
# Reopen the untouched input so temporary world, visibility, render and bake
# settings cannot leak from the baker into the final source.
bpy.ops.wm.open_mainfile(filepath=str(source))
changes=[]
for name in sorted(owned):
    obj=bpy.data.objects[name]
    attr=obj.data.color_attributes.active_color
    if attr is None and len(obj.data.color_attributes)==1:
        attr=obj.data.color_attributes[0]
    if attr is None:
        assert name in full
        attr=obj.data.color_attributes.new(name='Baked contact and bounce',type='FLOAT_COLOR',domain='CORNER')
    assert attr.domain=='CORNER' and attr.data_type=='FLOAT_COLOR'
    original=colors(attr)
    assert len(original)==len(baked[name])
    if name in cap_loops:
        values=array.array('f',original)
        for loop in cap_loops[name]:
            values[loop*4:loop*4+4]=baked[name][loop*4:loop*4+4]
    else:
        values=baked[name]
    attr.data.foreach_set('color',values)
    obj.data.color_attributes.active_color=attr
    if name in full:
        obj['bakedLighting']='Cycles AO + diffuse indirect, 24 samples, neutral modulation'
    actual=colors(attr)
    allowed=set(cap_loops[name]) if name in cap_loops else set(range(len(attr.data)))
    changed=[i for i in range(len(attr.data)) if original[i*4:i*4+4] != actual[i*4:i*4+4]]
    assert set(changed).issubset(allowed)
    assert shape(obj)==shapes[name]
    changes.append({'name':name,'scope':'New cap CORNER colors only' if name in cap_loops else 'Complete new/moved owning mesh color',
                    'corners':len(attr.data),'allowedCorners':len(allowed),'changedCorners':len(changed),
                    'inheritedColorsExact':name in cap_loops,'shapeSha256':shapes[name]})
after=ns['native_state']()
assert set(before)==set(after)
unowned=[name for name in before if name not in owned and before[name]!=after[name]]
assert not unowned,unowned
assert ns['materials']()==materials
target=out/'candidate.blend'
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(target),compress=True)
bpy.ops.wm.open_mainfile(filepath=str(target))
assert ns['native_state']()==after
assert ns['materials']()==materials
assert sha(source)==source_sha
receipt={'scope':'Official24sample neutral AO/indirect pass on18new/moved whole meshes and only genuine new cap CORNER colors of4old cut owners. All original/inherited cornercolors, all positions/normals/UV/other numeric fields, materials and unowned native meshes exact. No native topology, raw source-port or cache admission is implied; independent post-bake outside fields and final exports remain required.',
         'inputSha256':source_sha,'outputSha256':sha(target),'bakerSha256':sha(root/'bin/bake_coastal_light.py'),
         'producerSha256':sha(Path(__file__)),'unownedNativeMeshesExact':len(before)-len(owned),'unownedChanges':unowned,
         'changes':changes,'capLoopMasks':cap_loops,'bake':stats}
(out/'OWNED-AO.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps({'source':str(target),'sha256':sha(target),'wholeMeshes':len(full),'capOwners':len(cap_loops),'unownedExact':len(before)-len(owned)}))
