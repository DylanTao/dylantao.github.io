import bpy
import hashlib
import json
from pathlib import Path
import sys

root = Path.cwd()
q = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'bin'))
import coastal_preview as preview

source = q / 'garden-v5/candidate.blend'
source_sha = '9c48aea4b5626335e4fc39519e0a2249a45627fc13fe7bd7dd306739b13ce160'
assert hashlib.sha256(source.read_bytes()).hexdigest() == source_sha
bpy.ops.wm.open_mainfile(filepath=str(source))
scene = bpy.context.scene
camera = preview.setup(scene, resolution=(1200, 800), samples=16, cutaway=False)
preview.add_fill(scene, 'garden design preview soft practical proxy', (-6.0, -5.9, 1.02), energy=35, size=1.2, target=(-6.2, -6.2, -.6))
views = {
    'garden-standing': ((-5.67, -5.52, .59), (-6.57, -6.24, -.38), 57),
    'garden-seated': ((-6.85, -5.72, .10), (-5.95, -6.36, -.44), 58),
}
out = q / 'garden-design-v5'
written = preview.render(scene, camera, views, out)
assert hashlib.sha256(source.read_bytes()).hexdigest() == source_sha
receipt = {'sourceSha256': source_sha, 'scope': 'Eevee design-only previews with explicit35W area-light proxy. These do not establish browser lighting, final seam closure, decoded geometry or final source admission.', 'resolution': [1200, 800], 'samples': 16, 'viewsNativeCoordinates': views, 'images': [{'path': Path(p).name, 'sha256': hashlib.sha256(Path(p).read_bytes()).hexdigest()} for p in written]}
(out / 'DESIGN.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
print(json.dumps({'views': len(written), 'sourceUnchanged': True}))
