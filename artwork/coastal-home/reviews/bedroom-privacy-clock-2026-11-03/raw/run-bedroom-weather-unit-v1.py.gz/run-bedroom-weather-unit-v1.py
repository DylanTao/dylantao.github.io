from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,time,hashlib
root=Path.cwd();q=Path(__file__).resolve().parent;out=q/'bedroom-weather-unit-v1'
assert not out.exists();out.mkdir()
command=['node','--test',*[str(p.relative_to(root))for p in sorted((root/'test').glob('*.test.mjs'))]]
start=time.monotonic()
with(out/'NODE.log').open('wb')as log:r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=900)
record={'at':datetime.now(timezone.utc).isoformat(),'command':command,'exitCode':r.returncode,'seconds':time.monotonic()-start,'sourceClockTestSHA256':hashlib.sha256((root/'test/visual/desk-scene.spec.js').read_bytes()).hexdigest(),'scope':'Complete JavaScript suite rerun after fixing the newly registered privacy browser clock. All product/compiled/cache/model/CSS bodies remain unchanged. The original failed integration and local weather regression remain retained separately.'}
(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'exitCode':r.returncode,'seconds':record['seconds']}));raise SystemExit(r.returncode)
