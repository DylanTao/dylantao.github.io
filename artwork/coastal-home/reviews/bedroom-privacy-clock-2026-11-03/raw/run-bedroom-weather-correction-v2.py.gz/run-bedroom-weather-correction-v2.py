from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, time, urllib.request

root=Path.cwd();q=Path(__file__).resolve().parent;out=q/'bedroom-weather-correction-v2'
assert not out.exists();out.mkdir()
server=json.loads((q/'bedroom-curtains-checkpoint-v3/server.json').read_bytes())
with urllib.request.urlopen(server['url'],timeout=10) as response:
    assert response.status==200 and response.headers['X-Sirui-Preview']==server['header']
env=dict(os.environ,NO_WEBSERVER='1',VISUAL_BASE_URL=server['url'].rstrip('/'),CI='1')
command=['C:/Program Files/nodejs/npx.cmd','playwright','test','--config','test/visual/public.config.js','--project','desktop-1440','--project','laptop-1280','--project','tablet-768','--project','mobile-390','--workers','1','--output',str(out/'browser-results'),'test/visual/desk-scene.spec.js','--grep','sleeping privacy drapes']
start=time.monotonic()
with(out/'BROWSER.log').open('wb')as log:
    result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record={'at':datetime.now(timezone.utc).isoformat(),'command':command,'cwd':str(root),'env':{k:env[k]for k in ['NO_WEBSERVER','VISUAL_BASE_URL','CI']},'server':server,'exitCode':result.returncode,'seconds':time.monotonic()-start,'sourceTestSHA256':sha(root/'test/visual/desk-scene.spec.js'),'sourceGroupSHA256':sha(root/'test/visual/scene-groups.json'),'sourceModuleBindings':str(q/'bedroom-curtains-checkpoint-v4/FINAL-BINDINGS.json'),'originalIntegrationFailureSHA256':sha(q/'BEDROOM-INTEGRATION-FAILURE.log'),'localOriginalFailureSHA256':sha(q/'BEDROOM-WEATHER-LOCAL-FAILURE.log'),'correctedWeatherAndClothTestsSHA256':sha(q/'BEDROOM-WEATHER-CORRECTED.log'),'scope':'Fix only the registered browser test clock, from the current rolling NWS window to the existing historical October23date. Product/runtime/cache/model/CSS bodies are unchanged and exact to the tested V3/V4 preview. The actual four-width public privacy/inside-camera/Walk/Noon path is rerun at this historical date. The original CI and local test failures are preserved; no fixture, weather guard, threshold or expected assertion is relaxed.'}
(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'exitCode':result.returncode,'seconds':record['seconds']}))
raise SystemExit(result.returncode)
