import * as THREE from "../three.module.min.js";
import { smooth } from "./wildlife-acting.mjs";
import { fitFootSole, groundFootQuaternion } from "./wildlife-ground-contact.mjs";

export const RABBIT_PAWS = ["FrontPawL", "FrontPawR", "HindPawL", "HindPawR"];

// Keep the exact rigid skin envelope, including toe edges that can become the
// lowest point as a paw rolls. This is sampled once from the delivered model.
export function rabbitSoles(model, bones) {
  model.updateMatrixWorld(true);
  const result = Object.fromEntries(RABBIT_PAWS.map((name) => [name, new Map()]));
  const inverse = Object.fromEntries(RABBIT_PAWS.map((name) => [name, bones[name].object.matrixWorld.clone().invert()]));
  const point = new THREE.Vector3();
  model.traverse((mesh) => {
    if (!mesh.isSkinnedMesh) return;
    const skin = mesh.geometry.attributes.skinIndex,
      weights = mesh.geometry.attributes.skinWeight;
    for (let i = 0; i < skin.count; i++)
      for (const name of RABBIT_PAWS) {
        let owned = 0;
        for (let j = 0; j < 4; j++) if (mesh.skeleton.bones[skin.getComponent(i, j)] === bones[name].object) owned += weights.getComponent(i, j);
        if (owned < 0.999) continue;
        mesh.getVertexPosition(i, point).applyMatrix4(mesh.matrixWorld).applyMatrix4(inverse[name]);
        const key = point.toArray().map((v) => Math.round(v * 1e5)).join(",");
        result[name].set(key, point.clone());
      }
  });
  return Object.fromEntries(Object.entries(result).map(([name, points]) => [name, [...points.values()]]));
}

// Ground support fades during the first/last part of the authored flight.
// The root path, phase, lift and central airborne pose stay unchanged. A hard
// airborne boolean here would pop the 2 cm fit off at the instant of takeoff.
export function rabbitSupportWeight(pose) {
  if (pose.state !== "hop" && pose.state !== "bolt") return 1;
  const takeoff = pose.state === "bolt" ? 0.1 : 0.18,
    landing = pose.state === "bolt" ? 0.85 : 0.76;
  const f = Math.max(0, Math.min(1, (pose.phase - takeoff) / (landing - takeoff)));
  return 1 - smooth(f / 0.18) + smooth((f - 0.82) / 0.18);
}

export function createRabbitContactFit({ group, bones, soles, ground }) {
  const changed = ["BodyPose", ...RABBIT_PAWS, "ForelegL", "ForelegR", "HindlegL", "HindlegR"];
  const rest = new Map(changed.map((name) => [name, { position: bones[name].object.position.clone(), quaternion: bones[name].object.quaternion.clone(), scale: bones[name].object.scale.clone() }]));
  const unit = new THREE.Quaternion(),
    up = new THREE.Vector3(0, 1, 0);
  function reset() {
    for (const name of changed) {
      const bone = bones[name].object,
        original = rest.get(name);
      bone.position.copy(original.position);
      bone.quaternion.copy(original.quaternion);
      bone.scale.copy(original.scale);
    }
  }
  function update(pose) {
    const weight = rabbitSupportWeight(pose);
    if (weight < 1e-8 || !ground.evidence().ready) return [];
    group.updateWorldMatrix(true, true);
    const rootQ = group.getWorldQuaternion(new THREE.Quaternion()),
      inverseRootQ = rootQ.clone().invert(),
      yaw = Math.atan2(new THREE.Vector3(0, 0, 1).applyQuaternion(rootQ).x, new THREE.Vector3(0, 0, 1).applyQuaternion(rootQ).z);
    const contacts = [];
    for (const name of RABBIT_PAWS) {
      const paw = bones[name].object,
        fore = name.startsWith("Front"),
        raised = fore ? Math.max(0, Math.min(1, pose.pawRaise)) : 0,
        amount = weight * (1 - smooth(raised)),
        legName = name.replace("FrontPaw", "Foreleg").replace("HindPaw", "Hindleg"),
        leg = bones[legName].object;
      const raw = paw.getWorldPosition(new THREE.Vector3()),
        rawQ = paw.getWorldQuaternion(new THREE.Quaternion()),
        hip = leg.getWorldPosition(new THREE.Vector3()),
        legQ = leg.getWorldQuaternion(new THREE.Quaternion());
      const intentionalLift = fore ? pose.foreLift + raised * (0.15 + pose.groomStroke * 0.012) : pose.hindLift;
      const lift = new THREE.Vector3(0, intentionalLift, 0).applyQuaternion(rootQ).add(new THREE.Vector3(0, pose.lift, 0)),
        reference = raw.clone().sub(lift),
        surface = ground.sample(reference.x, reference.z, reference.y + 0.5);
      if (!surface || amount < 1e-8) {
        contacts.push({ foot: name, contact: false, weight: amount, supported: 0, reason: surface ? "intentional raised paw" : "missing support" });
        continue;
      }
      const orientation = groundFootQuaternion(yaw, surface.normal).multiply(inverseRootQ).multiply(rawQ);
      const fitted = fitFootSole(ground, soles[name], reference, orientation);
      if (fitted.supported !== soles[name].length || Math.abs(fitted.correction) > 0.12) {
        contacts.push({ foot: name, contact: false, weight: amount, supported: fitted.supported, samples: soles[name].length, reason: "incomplete or distant support" });
        continue;
      }
      const target = raw.clone().lerp(fitted.position.add(lift), amount),
        blendedOrientation = rawQ.clone().slerp(orientation, amount),
        clear = fitFootSole(ground, soles[name], target, blendedOrientation, true);
      contacts.push({ foot: name, legName, raw, rawQ, hip, legQ, amount, surface, orientation,
        target: clear.position, correction: fitted.correction, clearanceLift: clear.correction,
        contact: !pose.airborne && raised < 1e-4 && intentionalLift < 1e-5,
        supported: fitted.supported, samples: soles[name].length, supportVisible: fitted.visible, supportMesh: surface.mesh,
        intentionalLift, weight: amount });
    }
    const valid = contacts.filter((c) => c.target);
    if (!valid.length) return contacts;
    // A small body accommodation avoids extending every leg by the original
    // path's clearance. Actual support normals supply cross-slope alignment;
    // the authored hips/chest/head acting remains relative to this body.
    const normal = new THREE.Vector3();
    let total = 0, correction = 0;
    for (const c of valid) { normal.addScaledVector(c.surface.normal, c.amount); total += c.amount; correction += c.correction * c.amount; }
    normal.normalize();
    const delta = new THREE.Quaternion().setFromUnitVectors(up.clone().applyQuaternion(rootQ), normal);
    if (unit.angleTo(delta) > 0.35) delta.slerp(unit, 1 - 0.35 / unit.angleTo(delta));
    const body = bones.BodyPose.object,
      bodyQ = body.getWorldQuaternion(new THREE.Quaternion()),
      parentQ = body.parent.getWorldQuaternion(new THREE.Quaternion());
    body.quaternion.copy(parentQ.invert().multiply(unit.clone().slerp(delta, weight).multiply(bodyQ)));
    const accommodation = Math.max(-0.015, Math.min(0.015, correction / total)) * weight;
    const bodyPosition = body.getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(0, accommodation, 0));
    body.position.copy(body.parent.worldToLocal(bodyPosition));
    group.updateWorldMatrix(true, true);
    for (const c of valid) {
      const paw = bones[c.foot].object,
        leg = bones[c.legName].object,
        hip = leg.getWorldPosition(new THREE.Vector3()),
        oldDirection = c.raw.clone().sub(c.hip),
        newDirection = c.target.clone().sub(hip),
        ratio = newDirection.length() / Math.max(1e-5, oldDirection.length());
      const legTargetQ = new THREE.Quaternion().setFromUnitVectors(oldDirection.normalize(), newDirection.normalize()).multiply(c.legQ);
      leg.quaternion.copy(leg.parent.getWorldQuaternion(new THREE.Quaternion()).invert().multiply(legTargetQ));
      leg.scale.copy(rest.get(c.legName).scale).multiplyScalar(Math.max(0.8, Math.min(1.18, ratio)));
      paw.position.copy(paw.parent.worldToLocal(c.target.clone()));
      paw.quaternion.copy(paw.parent.getWorldQuaternion(new THREE.Quaternion()).invert().multiply(c.rawQ.clone().slerp(c.orientation, c.amount)));
      c.position = c.target.toArray(); c.orientation = paw.getWorldQuaternion(new THREE.Quaternion()).toArray(); c.legStretch = ratio;
      c.bodyAccommodation = accommodation;
      for (const key of ["raw", "rawQ", "hip", "legQ", "target", "surface", "amount"]) delete c[key];
    }
    group.updateWorldMatrix(true, true);
    return contacts;
  }
  return { reset, update };
}
