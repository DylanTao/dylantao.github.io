const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {chromium,expect}=require('C:/dev/dylantao.github.io/node_modules/@playwright/test');
const {preparePage,collectRuntimeErrors,screenshotMetrics}=require('../../../test/visual/helpers.js');
const q=__dirname,out=path.join(q,'walkthrough'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');fs.mkdirSync(out,{recursive:true});
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
 try{
  const context=await browser.newContext({viewport:{width:2560,height:1440},deviceScaleFactor:1,reducedMotion:'no-preference',timezoneId:'America/Los_Angeles'}),page=await context.newPage(),errors=collectRuntimeErrors(page);
  page.setDefaultTimeout(90000);await preparePage(page,'light');await page.clock.setFixedTime(new Date('2026-10-31T13:20:00-07:00'));
  await page.goto('http://127.0.0.1:4158/al-folio/?scene-lab=1&quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});
  await page.locator('[data-home-desk-mode="3d"]').click();
  const host=page.locator('[data-home-desk-scene]'),canvas=host.locator('canvas'),ui=page.locator('[data-home-world-controls]');
  await host.scrollIntoViewIfNeeded();await expect(host).toHaveAttribute('data-scene-state','ready',{timeout:240000});
  await ui.locator('[data-world-fullscreen]').click();await canvas.focus();
  await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().ecology.wildlife.modelsReady)).toBe(true);
  const order=await host.evaluate(e=>e.getSceneEvidence().neighbours.map(n=>n.id)),rows=[];
  async function select(id){
   let current=await host.evaluate(e=>e.getSceneEvidence().inspection?.id),from=order.indexOf(current),to=order.indexOf(id);
   const steps=(to-from+order.length)%order.length;
   for(let i=0;i<steps;i++)await canvas.press('n');
   await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().inspection?.id)).toBe(id);await page.waitForTimeout(350);
  }
  async function capture(label,index,measure=false){
   const before=await host.evaluate(async(e,measure)=>{
    const THREE=await import(new URL('assets/js/three.module.min.js',document.baseURI));
    const {createGroundPatch,isCoastalGround}=await import(new URL('assets/js/home-scene/wildlife-ground-contact.mjs',document.baseURI));
    const ev=e.getSceneEvidence(),id=ev.inspection?.id,world=e.labScene.scene,bones=[],seen=new Set();world.updateMatrixWorld(true);
    const meshes=[];
    world.traverse(o=>{if(!o.isSkinnedMesh||o.userData.action?.id!==id)return;meshes.push(o);o.skeleton.update();
     for(const b of o.skeleton.bones){if(seen.has(b.uuid))continue;seen.add(b.uuid);bones.push({name:b.name,position:b.position.toArray(),quaternion:b.quaternion.toArray(),scale:b.scale.toArray()})}
    });
    let support=null;
    if(measure&&/^(rabbit|raccoon|seaLion|seal)-/.test(id)){
     window.__animalReadOnlyPatches??={};
     if(!window.__animalReadOnlyPatches[id]){
      const manifest=await(await fetch(new URL('assets/models/home/manifest.json',document.baseURI))).json();
      const key=id==='rabbit-0'?'rabbitWest':id==='rabbit-1'?'rabbitEast':id.split('-')[0];
      const patch=createGroundPatch(manifest.terrain.habitats[key].path,1.1),visible=[];
      world.traverseVisible(o=>{if(isCoastalGround(o))visible.push(o)});patch.capture(visible);window.__animalReadOnlyPatches[id]=patch;
     }
     const patch=window.__animalReadOnlyPatches[id],feet=Object.fromEntries(['FrontPawL','FrontPawR','HindPawL','HindPawR'].map(n=>[n,[]]));
     let minimum=null,supported=0,missing=0,total=0;
     for(const mesh of meshes){const skin=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight;
      for(let i=0;i<skin.count;i++){
       total++;const p=mesh.getVertexPosition(i,new THREE.Vector3()).applyMatrix4(mesh.matrixWorld),hit=patch.sample(p.x,p.z,p.y+.5);
       if(!hit){missing++;continue}supported++;
       const point={vertex:i,mesh:mesh.name,material:mesh.material.name,point:p.toArray(),gap:p.y-hit.height,support:{height:hit.height,mesh:hit.mesh,triangle:hit.triangle,visible:hit.visible}};
       if(!minimum||point.gap<minimum.gap)minimum=point;
       for(const name of Object.keys(feet)){let owned=0;for(let k=0;k<4;k++)if(mesh.skeleton.bones[skin.getComponent(i,k)].name===name)owned+=weights.getComponent(i,k);if(owned>=.999)feet[name].push(point)}
      }
     }
     support={total,supported,missing,minimum,feet:Object.fromEntries(Object.entries(feet).map(([n,p])=>[n,{vertices:p.length,minimum:p.sort((a,b)=>a.gap-b.gap)[0]||null}])),ground:patch.evidence()};
    }
    return{performanceNow:performance.now(),evidence:ev,bones,support};
   },measure);
   const file=`${label}-${index}.png`,image=await canvas.screenshot({path:path.join(out,file)}),after=await host.evaluate(e=>({performanceNow:performance.now(),frames:e.getSceneEvidence().frames,activeSeconds:e.getSceneEvidence().animationSeconds}));
   rows.push({label,index,file,pngSha256:sha(image),metrics:screenshotMetrics(image),...before,screenshotEnd:after,errors:[...errors],scope:'Actual uninterrupted active-scene frames and public N inspection; authoring flag exposes read-only geometry. Screenshot is bracketed by recorded frame/active-time reads, not claimed as an instantaneous pose timestamp.'});
   fs.writeFileSync(path.join(out,'frames.json'),JSON.stringify(rows,null,2));
   console.log(JSON.stringify({label,index,id:before.evidence.inspection?.id,frame:before.evidence.frames,active:before.evidence.animationSeconds,supportMin:before.support?.minimum?.gap,errors:errors.length}));
  }
  for(const id of ['rabbit-0','rabbit-1','seaLion-0','seal-0','raccoon-0','gull-0','balcony-gull-0','sandpiper-0','swimmer-0','pelican-0','cormorant-0']){
   await select(id);
   for(let i=0;i<3;i++){await capture('noon-'+id,i,i===0);await page.waitForTimeout(240)}
  }
  await canvas.press('Enter');await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().inspection)).toBe(null);
  for(const [label,pose]of [['underdeck-beach',{target:[0,-2,4],yaw:Math.PI,pitch:-.18,radius:18}],['foreland',{target:[0,1,3],yaw:Math.PI,pitch:.25,radius:30}]]){
   const n=await host.evaluate(e=>e.getSceneEvidence().frames);await host.evaluate((e,p)=>e.setLabCamera(p),pose);await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().frames)).toBeGreaterThan(n);
   await capture(label,0,false);
  }
  await page.locator('[data-world-exit]:visible').click();
  await page.locator('[data-theme-toggle]:visible').first().click();await page.locator('[data-theme-mode-option="evening"]:visible').first().click();
  await ui.locator('[data-world-fullscreen]').click();await canvas.focus();await select('raccoon-0');
  for(let i=0;i<8;i++){await capture('evening-raccoon-0',i,i===0||i===7);await page.waitForTimeout(1350)}
  expect(errors).toEqual([]);await context.close();
 }finally{await browser.close()}
})().catch(e=>{fs.writeFileSync(path.join(out,'failure.txt'),String(e.stack||e));console.error(e);process.exitCode=1});
