const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {chromium,expect}=require('C:/dev/dylantao.github.io/node_modules/@playwright/test');
const {preparePage,collectRuntimeErrors,screenshotMetrics}=require('../../../test/visual/helpers.js');
const q=__dirname,sha=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
 try{
  const context=await browser.newContext({viewport:{width:2560,height:1440},deviceScaleFactor:1,reducedMotion:'no-preference',timezoneId:'America/Los_Angeles'}),page=await context.newPage(),errors=collectRuntimeErrors(page);
  page.setDefaultTimeout(90000);await preparePage(page,'light');await page.clock.setFixedTime(new Date('2026-10-31T13:20:00-07:00'));
  await page.goto('http://127.0.0.1:4158/al-folio/?scene-lab=1&quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});
  await page.locator('[data-home-desk-mode="3d"]').click();
  const host=page.locator('[data-home-desk-scene]'),canvas=host.locator('canvas'),ui=page.locator('[data-home-world-controls]');
  await host.scrollIntoViewIfNeeded();await expect(host).toHaveAttribute('data-scene-state','ready',{timeout:240000});
  await ui.locator('[data-world-fullscreen]').click();await canvas.focus();await canvas.press('n');
  await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().inspection?.id)).toBe('rabbit-0');
  await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().ecology.wildlife.modelsReady)).toBe(true);
  await page.waitForTimeout(500);
  const rows=[];
  for(let index=0;index<6;index++){
   const row=await host.evaluate(async(e,index)=>{
    const THREE=await import(new URL('assets/js/three.module.min.js',document.baseURI));
    const {createGroundPatch,isCoastalGround}=await import(new URL('assets/js/home-scene/wildlife-ground-contact.mjs',document.baseURI));
    const world=e.labScene.scene,ev=e.getSceneEvidence(),id=ev.inspection.id;
    world.updateMatrixWorld(true);
    const record={id,index,performanceNow:performance.now(),frame:ev.frames,activeSeconds:ev.animationSeconds,
     rabbit:ev.ecology.wildlife.rabbitHabitats[Number(id.split('-')[1])],camera:ev.cameraPosition,orbit:ev.cameraOrbit,inspection:ev.inspection};
    if(!window.__readOnlyRabbitGround){
     const manifest=await(await fetch(new URL('assets/models/home/manifest.json',document.baseURI))).json();
     const ground=createGroundPatch(manifest.terrain.habitats.rabbitWest.path,.8),visible=[];
     world.traverseVisible(o=>{if(isCoastalGround(o))visible.push(o)});ground.capture(visible);
     window.__readOnlyRabbitGround=ground;
    }
    const ground=window.__readOnlyRabbitGround,paws={FrontPawL:[],FrontPawR:[],HindPawL:[],HindPawR:[]};
    world.traverse(o=>{
     if(!o.isSkinnedMesh||o.userData.action?.id!==id)return;
     o.skeleton.update();const skin=o.geometry.attributes.skinIndex,weights=o.geometry.attributes.skinWeight;
     for(let i=0;i<skin.count;i++)for(const name of Object.keys(paws)){
      let weight=0;for(let k=0;k<4;k++)if(o.skeleton.bones[skin.getComponent(i,k)].name===name)weight+=weights.getComponent(i,k);
      if(weight<.999)continue;
      const p=o.getVertexPosition(i,new THREE.Vector3()).applyMatrix4(o.matrixWorld),hit=ground.sample(p.x,p.z,p.y+.5);
      paws[name].push({vertex:i,mesh:o.name,point:p.toArray(),hit:hit?{height:hit.height,mesh:hit.mesh,triangle:hit.triangle,visible:hit.visible}:null,gap:hit?p.y-hit.height:null});
     }
    });
    record.feet=Object.fromEntries(Object.entries(paws).map(([n,points])=>{const valid=points.filter(p=>p.gap!==null).sort((a,b)=>a.gap-b.gap);return[n,{vertices:points.length,missing:points.length-valid.length,minimum:valid[0]?.gap,witness:valid[0]}]}));
    record.ground=ground.evidence();return record;
   },index);
   const file=`rabbit-probe-${index}.png`,png=await canvas.screenshot({path:path.join(q,file)});
   rows.push({...row,file,pngSha256:sha(png),metrics:screenshotMetrics(png),errors:[...errors]});
   fs.writeFileSync(path.join(q,'rabbit-contact-probe.json'),JSON.stringify(rows,null,2));
   console.log(JSON.stringify({index,active:row.activeSeconds,state:row.rabbit.state,contact:row.rabbit.contact,airborne:row.rabbit.airborne,lift:row.rabbit.lift,feet:Object.fromEntries(Object.entries(row.feet).map(([n,p])=>[n,[p.minimum,p.missing]])),errors:errors.length}));
   await page.waitForTimeout(180);
  }
  await context.close();
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
