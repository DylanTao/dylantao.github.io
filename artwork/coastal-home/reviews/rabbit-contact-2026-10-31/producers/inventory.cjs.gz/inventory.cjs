const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {chromium,expect}=require('C:/dev/dylantao.github.io/node_modules/@playwright/test');
const {preparePage,collectRuntimeErrors,screenshotMetrics}=require('../../../test/visual/helpers.js');
const q=__dirname;
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
 try{
  const context=await browser.newContext({viewport:{width:2560,height:1440},deviceScaleFactor:1,reducedMotion:'no-preference',timezoneId:'America/Los_Angeles'});
  const page=await context.newPage(),errors=collectRuntimeErrors(page);page.setDefaultTimeout(90000);
  await preparePage(page,'light');await page.clock.setFixedTime(new Date('2026-10-31T13:20:00-07:00'));
  await page.goto('http://127.0.0.1:4158/al-folio/?quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});
  await page.locator('[data-home-desk-mode="3d"]').click();
  const host=page.locator('[data-home-desk-scene]');await host.scrollIntoViewIfNeeded();
  await expect(host).toHaveAttribute('data-scene-state','ready',{timeout:240000});
  const data=await page.evaluate(()=>({evidence:document.querySelector('[data-home-desk-scene]').getSceneEvidence(),controls:[...document.querySelectorAll('button,select,summary,a')].filter(e=>[...e.attributes].some(a=>a.name.startsWith('data-world')||a.name.startsWith('data-room'))).map(e=>({tag:e.tagName,text:e.textContent.trim().slice(0,100),attrs:Object.fromEntries([...e.attributes].filter(a=>a.name.startsWith('data-')).map(a=>[a.name,a.value])),visible:!!e.getClientRects().length}))}));
  fs.writeFileSync(path.join(q,'inventory.json'),JSON.stringify({...data,errors},null,2));
  await host.locator('canvas').screenshot({path:path.join(q,'initial-public-2k.png')});
  console.log(JSON.stringify({current:data.evidence.currentRoom,neighbours:data.evidence.neighbours?.map(n=>n.id),visible:data.controls.filter(c=>c.visible),errors}));
  await context.close();
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
