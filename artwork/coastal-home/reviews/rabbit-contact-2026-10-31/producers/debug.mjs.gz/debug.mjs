import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { THREE, loadNativeModel } from "file:///C:/dev/site-takeover-worktrees/identity-footer/test/helpers/coastal-native-avatar.mjs";
import { nativeGeometry } from "file:///C:/dev/site-takeover-worktrees/identity-footer/test/helpers/coastal-native-geometry.mjs";
const {createWildlife}=await import(process.argv.includes("--baseline")?new URL("./baseline-wildlife.mjs",import.meta.url).href:"file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife.mjs");
import { createGroundPatch } from "file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife-ground-contact.mjs";
import { rabbitActing, rabbitSchedule } from "file:///C:/dev/site-takeover-worktrees/identity-footer/assets/js/home-scene/wildlife-motion.mjs";

const models = new URL("file:///C:/dev/site-takeover-worktrees/identity-footer/.jekyll-cache/visual-qa/animal-readonly-20261031/inputs/assets/models/home/");
const config = JSON.parse(fs.readFileSync(new URL("manifest.json", models)));
const perches = JSON.parse(fs.readFileSync(new URL("wildlife-perch-support.json", models)));
const species = ["BrushRabbit", "CaliforniaSeaLion", "HarborSeal", "Raccoon", "WesternGull", "Sandpiper", "BrownPelican", "BrandtsCormorant"];
const masters = await Promise.all(species.map((name) => loadNativeModel(name + ".glb", models)));
async function world(manifest, grounds) {
  const scene = new THREE.Group(), environment = new THREE.Group(); scene.add(environment, ...grounds);
  const wildlife = createWildlife(environment, manifest, {
    createModelLoader: () => ({ loader: { loadAsync: async (url) => masters[species.indexOf(url.split("/").at(-1).replace(".glb", ""))] }, decoder: { dispose() {} } }),
    loadPerchSupport: async () => perches,
  });
  for (let i = 0; i < 100 && !wildlife.evidence().modelsReady; i++) await new Promise(setImmediate);
  assert.equal(wildlife.evidence().modelsReady, true);
  wildlife.captureGround(grounds); scene.updateMatrixWorld(true);
  const paws = [0, 1].map((index) => {
    const list=[];
    scene.traverse((mesh) => {
      if (!mesh.isSkinnedMesh || mesh.userData.action?.id !== `rabbit-${index}`) return;
      const skin=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight;
      for(let i=0;i<skin.count;i++) {
        const names=new Map();
        for(let k=0;k<4;k++){const name=mesh.skeleton.bones[skin.getComponent(i,k)].name;names.set(name,(names.get(name)||0)+weights.getComponent(i,k));}
        for(const [name,weight]of names)if(/^(Front|Hind)Paw[LR]$/.test(name)&&weight>=.999)list.push({mesh,index:i,name});
      }
    });
    assert.ok(list.length>1000);return list;
  });
  const patches=["rabbitWest","rabbitEast"].map((key)=>{const p=createGroundPatch(manifest.terrain.habitats[key].path,1);p.capture(grounds);assert.ok(p.evidence().ready);return p});
  function measure(index) {
    scene.updateMatrixWorld(true);
    for(const mesh of new Set(paws[index].map(p=>p.mesh)))mesh.skeleton.update();
    const feet=Object.fromEntries(["FrontPawL","FrontPawR","HindPawL","HindPawR"].map(n=>[n,{minimum:Infinity,missing:0,points:[]} ]));
    for(const p of paws[index]){
      const v=p.mesh.getVertexPosition(p.index,new THREE.Vector3()).applyMatrix4(p.mesh.matrixWorld),hit=patches[index].sample(v.x,v.z,v.y+.5),foot=feet[p.name];
      foot.points.push(v.toArray());if(!hit)foot.missing++;else foot.minimum=Math.min(foot.minimum,v.y-hit.height);
    }
    return feet;
  }
  return {scene,wildlife,paws,measure};
}
function samples() {
  const times=new Set([0,1,2,4,8,12,16,24,32,40,48,56,64,72]);
  for(const seed of [1,2])for(const at of [0,40,80]){
    const schedule=rabbitSchedule(at,seed);
    for(const s of schedule.segments)for(const t of [s.start+1e-5,(s.start+s.end)/2,s.end-1e-5])if(t>=0)times.add(t);
    for(const h of schedule.hops)for(const u of [0,.05,.1,.18,.2,.35,.5,.7,.76,.85,.95,1]){
      const t=h.start+(h.end-h.start)*u;if(t>=0)times.add(t);
    }
  }
  return [...times].sort((a,b)=>a-b);
}

const grounds=await Promise.all([nativeGeometry("home-shell.glb",models),nativeGeometry("coast.glb",models)]);
const runtime=await world(structuredClone(config),grounds),rows=[];
for(const time of [0,4,12,88.96390346092171]){
 runtime.wildlife.update(time,"day",{force:true});
 for(let i=0;i<2;i++)rows.push({time,index:i,pose:rabbitActing(time,i+1),feet:Object.fromEntries(Object.entries(runtime.measure(i)).map(([n,f])=>[n,{minimum:f.minimum,missing:f.missing}])),actual:runtime.wildlife.evidence().rabbitHabitats[i]});
}
const label=process.argv.includes("--baseline")?"baseline":"candidate";
fs.writeFileSync(new URL(`./debug-${label}.json`,import.meta.url),JSON.stringify(rows,null,2));
console.log(JSON.stringify(rows.map(r=>({time:r.time,index:r.index,state:r.pose.state,air:r.pose.airborne,phase:r.pose.phase,feet:r.feet,contacts:r.actual.contacts}))));
