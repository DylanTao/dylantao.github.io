const fs=require('node:fs'),path=require('node:path');
const {chromium,expect}=require('C:/dev/dylantao.github.io/node_modules/@playwright/test');
const {preparePage,collectRuntimeErrors}=require('../../../test/visual/helpers.js');const q=__dirname;
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
 try{
  const context=await browser.newContext({viewport:{width:1440,height:1000},deviceScaleFactor:1,reducedMotion:'reduce'}),page=await context.newPage(),errors=collectRuntimeErrors(page);
  await preparePage(page,'light');await page.clock.setFixedTime(new Date('2026-10-31T13:20:00-07:00'));
  await page.goto('http://127.0.0.1:4162/al-folio/?scene-lab=1&quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});
  await page.locator('[data-home-desk-mode="3d"]').click();const host=page.locator('[data-home-desk-scene]'),canvas=host.locator('canvas'),ui=page.locator('[data-home-world-controls]');
  await host.scrollIntoViewIfNeeded();await expect(host).toHaveAttribute('data-scene-state','ready',{timeout:240000});await ui.locator('[data-world-fullscreen]').click();
  const details=ui.locator('details').first();if(!await details.evaluate(e=>e.open))await details.locator('summary').first().click();
  await ui.locator('[data-world-destination="overview"]').first().click();await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().currentRoom)).toBe('overview');if(await details.evaluate(e=>e.open))await details.locator('summary').first().click();
  const rows=[];
  for(let index=0;index<2;index++){
   const p=await host.evaluate((e,i)=>e.getSceneEvidence().neighbours.find(n=>n.id==='rabbit-'+i).worldCenter,index);
   const previous=await host.evaluate(e=>e.getSceneEvidence().frames);await host.evaluate((e,p)=>e.setLabCamera({target:p,yaw:2.7,pitch:.3,radius:1.6}),p);await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().frames)).toBeGreaterThan(previous);
   const row=await host.evaluate(async(e,index)=>{
    const T=await import(new URL('assets/js/three.module.min.js',document.baseURI)),{createGroundPatch,isCoastalGround}=await import(new URL('assets/js/home-scene/wildlife-ground-contact.mjs',document.baseURI));
    const world=e.labScene.scene,ev=e.getSceneEvidence(),manifest=await(await fetch(new URL('assets/models/home/manifest.json',document.baseURI))).json();world.updateMatrixWorld(true);
    const patch=createGroundPatch(manifest.terrain.habitats[index?'rabbitEast':'rabbitWest'].path,1),visible=[];world.traverseVisible(o=>{if(isCoastalGround(o))visible.push(o)});patch.capture(visible);
    const feet=Object.fromEntries(['FrontPawL','FrontPawR','HindPawL','HindPawR'].map(n=>[n,{vertices:0,missing:0,minimum:Infinity}]));
    world.traverse(mesh=>{
     if(!mesh.isSkinnedMesh||mesh.userData.action?.id!=='rabbit-'+index)return;mesh.skeleton.update();const s=mesh.geometry.attributes.skinIndex,w=mesh.geometry.attributes.skinWeight;
     for(let i=0;i<s.count;i++)for(const name of Object.keys(feet)){
      let own=0;for(let k=0;k<4;k++)if(mesh.skeleton.bones[s.getComponent(i,k)].name===name)own+=w.getComponent(i,k);if(own<.999)continue;
      const f=feet[name],p=mesh.getVertexPosition(i,new T.Vector3()).applyMatrix4(mesh.matrixWorld),hit=patch.sample(p.x,p.z,p.y+.5);f.vertices++;
      if(!hit)f.missing++;else f.minimum=Math.min(f.minimum,p.y-hit.height);
     }
    });
    const supports=ev.ecology.wildlife.rabbitHabitats[index].contacts.map(c=>{const mesh=world.getObjectByName(c.supportMesh);let shown=!!mesh;for(let o=mesh;o;o=o.parent)shown&&=o.visible;return{foot:c.foot,owner:c.supportMesh,recordedVisible:c.supportVisible,actuallyVisible:shown}});
    return{index,evidence:ev,feet,supports,visiblePatch:patch.evidence(),scope:'Actual overview cutaway and a disclosed close authoring camera; independent visible delivered ground and rigid toe vertices, no geometry/material/lighting writes.'};
   },index);
   row.file=`cutaway-rabbit-${index}.png`;await canvas.screenshot({path:path.join(q,row.file)});rows.push({...row,errors:[...errors]});fs.writeFileSync(path.join(q,'cutaway-rabbits.json'),JSON.stringify(rows,null,2));console.log(JSON.stringify({index,feet:row.feet,supports:row.supports,errors:errors.length}));
  }
  expect(errors).toEqual([]);await context.close();
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
