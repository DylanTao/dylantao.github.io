from pathlib import Path
import re
q=Path(__file__).parent;root=q.parents[2]
s=(q/'debug.mjs').read_text(encoding='utf-8').split('const grounds=await Promise.all')[0]
tail=r'''
const grounds=await Promise.all([nativeGeometry("home-shell.glb",models),nativeGeometry("coast.glb",models)]);
const runtime=await world(structuredClone(config),grounds),rows=[],others=[],pawCache=runtime.paws;
const patches=["rabbitWest","rabbitEast"].map(key=>{const p=createGroundPatch(config.terrain.habitats[key].path,1);p.capture(grounds);return p});
const allMeshes=[0,1].map(index=>{const out=[];runtime.scene.traverse(o=>{if(o.isSkinnedMesh&&o.userData.action?.id===`rabbit-${index}`)out.push(o)});return out});
const digest=b=>crypto.createHash("sha256").update(JSON.stringify(b)).digest("hex");
for(const time of samples()){
 runtime.wildlife.update(time,"day",{force:true});runtime.scene.updateMatrixWorld(true);
 for(let index=0;index<2;index++){
  const pose=rabbitActing(time,index+1),feet=runtime.measure(index),points=[];let minimum=null,missing=0,total=0;
  for(const mesh of allMeshes[index]){
   mesh.skeleton.update();const skin=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight;
   for(let i=0;i<skin.count;i++){
    const p=mesh.getVertexPosition(i,new THREE.Vector3()).applyMatrix4(mesh.matrixWorld);points.push(...p.toArray());total++;
    const hit=patches[index].sample(p.x,p.z,p.y+.5);if(!hit){missing++;continue}
    const gap=p.y-hit.height;
    if(!minimum||gap<minimum.gap)minimum={gap,vertex:i,mesh:mesh.name,material:mesh.material.name,point:p.toArray(),support:{height:hit.height,mesh:hit.mesh,triangle:hit.triangle},weights:Array.from({length:4},(_,k)=>({bone:mesh.skeleton.bones[skin.getComponent(i,k)].name,weight:weights.getComponent(i,k)}))};
   }
  }
  const group=allMeshes[index][0].parent;
  rows.push({time,index,state:pose.state,phase:pose.phase,airborne:pose.airborne,lift:pose.lift,
    rootPosition:runtime.wildlife.evidence().rabbitHabitats[index].position,
    feet:Object.fromEntries(Object.entries(feet).map(([n,f])=>[n,{minimum:f.minimum,missing:f.missing}])),
    allSkin:{minimum,total,missing,worldVerticesSha256:digest(points)},contacts:runtime.wildlife.evidence().rabbitHabitats[index].contacts||[]});
 }
 const byId={};runtime.scene.traverse(o=>{
  if(!o.isSkinnedMesh||!o.userData.action?.id||o.userData.action.id.startsWith("rabbit-"))return;
  const id=o.userData.action.id;if(byId[id])return;
  byId[id]=[o.parent.position.toArray(),o.parent.quaternion.toArray(),o.parent.scale.toArray(),o.skeleton.bones.map(b=>[b.name,...b.position.toArray(),...b.quaternion.toArray(),...b.scale.toArray()])];
 });others.push({time,sha256:digest(byId)});
}
const label=process.argv.includes("--baseline")?"baseline":"candidate";
fs.writeFileSync(new URL(`./native-${label}.json`,import.meta.url),JSON.stringify({rows,otherSpecies:others},null,2));
console.log(JSON.stringify({label,rows:rows.length,times:others.length,minimumBodyGap:Math.min(...rows.map(r=>r.allSkin.minimum.gap)),minimumToeGap:Math.min(...rows.flatMap(r=>Object.values(r.feet).map(f=>f.minimum))),worst:rows.sort((a,b)=>a.allSkin.minimum.gap-b.allSkin.minimum.gap).slice(0,3).map(r=>({time:r.time,index:r.index,state:r.state,air:r.airborne,witness:r.allSkin.minimum}))}));
'''
s='import crypto from "node:crypto";\n'+s+tail
(q/'native-proof.mjs').write_text(s,encoding='utf-8',newline='\n')
