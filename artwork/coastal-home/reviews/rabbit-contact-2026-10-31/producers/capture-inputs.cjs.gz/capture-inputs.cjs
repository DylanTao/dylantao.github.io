const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const base='http://127.0.0.1:4158/al-folio/',q=__dirname,rows=[];
(async()=>{
 async function save(relative){
  if(relative.includes('..'))throw Error('Unexpected input path');
  const url=new URL(relative,base),response=await fetch(url);if(!response.ok)throw Error(url.href+' '+response.status);
  const body=Buffer.from(await response.arrayBuffer()),file=path.join(q,'inputs',relative);fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,body);
  rows.push({path:relative,bytes:body.length,sha256:crypto.createHash('sha256').update(body).digest('hex')});return body;
 }
 const manifest=JSON.parse(await save('assets/models/home/manifest.json'));
 const models=['home-shell.glb','coast.glb','BrushRabbit.glb','CaliforniaSeaLion.glb','HarborSeal.glb','Raccoon.glb','WesternGull.glb','Sandpiper.glb','BrownPelican.glb','BrandtsCormorant.glb','wildlife-perch-support.json','static-light-field.json'];
 if(manifest.hinterland?.file)models.push(manifest.hinterland.file);
 for(const name of [...new Set(models)])await save('assets/models/home/'+name);
 for(const name of ['controller.mjs','wildlife.mjs','wildlife-motion.mjs','wildlife-neighbor-motion.mjs','wildlife-seabird-motion.mjs','wildlife-ground-contact.mjs','wildlife-perch-contact.mjs','shore.mjs','realism.mjs','materials.mjs','model-loader.mjs'])await save('assets/js/home-scene/'+name);
 await save('assets/js/three.module.min.js');
 fs.writeFileSync(path.join(q,'INPUT_BINDINGS.json'),JSON.stringify({preview:base,scope:'Frozen coordinator public503 preview. Served model and module bytes, no product writes. Master attribution75af is coordinator-provided; actual delivered inputs are hashed here.',files:rows},null,2));
 console.log(JSON.stringify({files:rows.length,bytes:rows.reduce((n,r)=>n+r.bytes,0)}));
})().catch(e=>{console.error(e);process.exitCode=1});
