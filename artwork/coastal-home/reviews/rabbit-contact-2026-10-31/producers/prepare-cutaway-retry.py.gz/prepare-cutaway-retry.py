from pathlib import Path
q=Path(__file__).parent
s=(q/'cutaway-probe.cjs').read_text(encoding='utf-8')
assert s.count('data-world-room="overview"')==1
s=s.replace('data-world-room="overview"','data-world-destination="overview"')
(q/'cutaway-probe-corrected.cjs').write_text(s,encoding='utf-8',newline='\n')
