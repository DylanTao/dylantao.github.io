import fs from 'node:fs';
import {nativeGeometry}from '../../../test/helpers/coastal-native-geometry.mjs';
import {createGroundPatch}from '../../../assets/js/home-scene/wildlife-ground-contact.mjs';
const models=new URL('./inputs/assets/models/home/',import.meta.url),manifest=JSON.parse(fs.readFileSync(new URL('manifest.json',models))),grounds=await Promise.all([nativeGeometry('home-shell.glb',models),nativeGeometry('coast.glb',models)]),rows=[];
const meshes=new Map();for(const root of grounds)root.traverse(o=>{if(o.isMesh)meshes.set(o.name,o)});
for(const name of ['rabbitWest','rabbitEast']){
 const path=manifest.terrain.habitats[name].path,patch=createGroundPatch(path,1);patch.capture(grounds);
 const samples=path.map((p,index)=>{
  const hit=patch.sample(p[0],p[2],p[1]+.2),mesh=meshes.get(hit?.mesh),chain=[];
  for(let o=mesh;o;o=o.parent)chain.push({name:o.name,metadata:o.userData});
  return{index,point:p,hit:hit?{mesh:hit.mesh,triangle:hit.triangle,height:hit.height,pathClearance:p[1]-hit.height,normal:hit.normal.toArray()}:null,ownerChain:chain};
 });
 const byOwner={};for(const r of samples){const key=r.hit?.mesh||'missing';(byOwner[key]??=[]).push(r.index)}
 rows.push({name,samples,byOwner});
}
const cutaway=JSON.parse(fs.readFileSync(new URL('./cutaway-rabbits.json',import.meta.url))),current=cutaway[1].evidence.ecology.wildlife.rabbitHabitats[1],station=((current.progress%1)+1)%1*manifest.terrain.habitats.rabbitEast.path.length;
const report={scope:'Exact delivered decoded home-shell/coast native triangles from the frozen503 input packet; route centres, not a replacement for full dynamic paw footprints. Original GLTF node names and metadata are retained in ownerChain. Browser actual owner was core_retreat_liftaway_roof_1.',routes:rows,
 currentEast:{progress:current.progress,station,fromIndex:Math.floor(station),toIndex:(Math.floor(station)+1)%48,position:current.position,actualBrowserSupports:cutaway[1].supports,visibleToeGaps:cutaway[1].feet}};
fs.writeFileSync(new URL('./rabbit-route-owners.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify({routes:rows.map(r=>({name:r.name,byOwner:r.byOwner})),currentEast:report.currentEast}));
