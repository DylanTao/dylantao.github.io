import gzip
import hashlib
import json
import subprocess
from pathlib import Path

q = Path(__file__).parent
root = q.parents[2]
out = root / 'artwork/coastal-home/reviews/rabbit-contact-2026-10-31'
binding = json.loads((out / 'SOURCE_BINDINGS.json').read_text())
binding['candidateServedBindings'] = []
for name in ['assets/js/home-scene/wildlife.mjs', 'assets/js/home-scene/wildlife-rabbit-contact.mjs', 'test/wildlife-rabbit-contact.test.mjs']:
    blob = subprocess.check_output(['git', 'show', binding['sourceCommit'] + ':' + name], cwd=root)
    (out / ('source/' + name + '.gz')).write_bytes(gzip.compress(blob, compresslevel=9, mtime=0))
    if name.startswith('assets/'):
        actual = (root / name).read_bytes()
        assert actual.replace(b'\r\n', b'\n') == blob
        binding['candidateServedBindings'].append({'path': name, 'bytes': len(actual), 'sha256': hashlib.sha256(actual).hexdigest(), 'differenceFromGitBlob': 'Only Windows CRLF checkout line endings; no code difference.'})
(out / 'SOURCE_BINDINGS.json').write_text(json.dumps(binding, indent=2) + '\n', encoding='utf-8', newline='\n')
(out / 'producers/finalize-rabbit.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), compresslevel=9, mtime=0))
manifest = {'schema': 1, 'scope': 'Measured rabbit contact repair; eastern roof/cutaway habitat remains open. Source and private evidence only.', 'files': []}
for path in sorted(out.rglob('*')):
    if path.is_file() and path.name != 'MANIFEST.json':
        b = path.read_bytes()
        manifest['files'].append({'path': path.relative_to(out).as_posix(), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
(out / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'payloads': len(manifest['files']), 'bytes': sum(r['bytes'] for r in manifest['files']), 'sourceBindings': len(binding['sourceBindings']), 'servedBindings': len(binding['candidateServedBindings'])}))
