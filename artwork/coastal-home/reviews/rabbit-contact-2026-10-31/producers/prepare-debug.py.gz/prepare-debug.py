from pathlib import Path
import re
q=Path(__file__).parent;root=q.parents[2]
def imports(s,folder):
    return re.sub(r'from\s*(["\'])(\.[^"\']+)\1',lambda m:'from "'+(folder/m[2]).resolve().as_uri()+'"',s)
old=(q/'inputs/assets/js/home-scene/wildlife.mjs').read_text(encoding='utf-8')
(q/'baseline-wildlife.mjs').write_text(imports(old,root/'assets/js/home-scene'),encoding='utf-8',newline='\n')
s=(root/'test/wildlife-rabbit-contact.test.mjs').read_text(encoding='utf-8').split('test("delivered rabbit contact soles')[0]
s=imports(s,root/'test')
s=s.replace('import { createWildlife } from "'+(root/'assets/js/home-scene/wildlife.mjs').as_uri()+'";', 'const {createWildlife}=await import(process.argv.includes("--baseline")?new URL("./baseline-wildlife.mjs",import.meta.url).href:"'+(root/'assets/js/home-scene/wildlife.mjs').as_uri()+'");')
s=s.replace('new URL("../assets/models/home/", import.meta.url)', 'new URL("'+(q/'inputs/assets/models/home/').as_uri()+'/")')
tail='''
const grounds=await Promise.all([nativeGeometry("home-shell.glb",models),nativeGeometry("coast.glb",models)]);
const runtime=await world(structuredClone(config),grounds),rows=[];
for(const time of [0,4,12,88.96390346092171]){
 runtime.wildlife.update(time,"day",{force:true});
 for(let i=0;i<2;i++)rows.push({time,index:i,pose:rabbitActing(time,i+1),feet:Object.fromEntries(Object.entries(runtime.measure(i)).map(([n,f])=>[n,{minimum:f.minimum,missing:f.missing}])),actual:runtime.wildlife.evidence().rabbitHabitats[i]});
}
const label=process.argv.includes("--baseline")?"baseline":"candidate";
fs.writeFileSync(new URL(`./debug-${label}.json`,import.meta.url),JSON.stringify(rows,null,2));
console.log(JSON.stringify(rows.map(r=>({time:r.time,index:r.index,state:r.pose.state,air:r.pose.airborne,phase:r.pose.phase,feet:r.feet,contacts:r.actual.contacts}))));
'''
(q/'debug.mjs').write_text(s+tail,encoding='utf-8',newline='\n')
