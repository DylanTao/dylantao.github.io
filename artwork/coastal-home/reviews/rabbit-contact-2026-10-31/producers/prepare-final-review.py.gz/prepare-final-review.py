from pathlib import Path
q=Path(__file__).parent
s=(q/'live-review.cjs').read_text(encoding='utf-8').replace('live-review-v3','live-review-final').replace("?40:120","?40:90")
(q/'live-review-final.cjs').write_text(s,encoding='utf-8',newline='\n')
