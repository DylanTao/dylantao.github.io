from pathlib import Path
q=Path(__file__).parent
s=(q/'contact-probe.cjs').read_text(encoding='utf-8').replace('4158','4162').replace('rabbit-probe-','rabbit-after-v3-probe-').replace('rabbit-contact-probe.json','rabbit-after-v3-contact-probe.json')
(q/'contact-after-v3.cjs').write_text(s,encoding='utf-8',newline='\n')
