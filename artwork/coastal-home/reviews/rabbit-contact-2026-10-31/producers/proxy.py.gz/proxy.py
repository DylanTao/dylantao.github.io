from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.request import urlopen,Request
from urllib.error import HTTPError
q=Path(__file__).parent;root=q.parents[2]
OWNED={f'/al-folio/assets/js/home-scene/{name}':root/'assets/js/home-scene'/name for name in ['wildlife.mjs','wildlife-rabbit-contact.mjs']}
class Handler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def log_message(self,*args):pass
    def do_GET(self):
        name=self.path.split('?',1)[0]
        if name in OWNED:
            body=OWNED[name].read_bytes();status=200;headers={'Content-Type':'text/javascript; charset=utf-8'}
        else:
            try:
                with urlopen(Request('http://127.0.0.1:4158'+self.path,headers={'Cache-Control':'no-cache'}),timeout=90)as response:
                    body=response.read();status=response.status;headers=dict(response.headers)
            except HTTPError as error:
                body=error.read();status=error.code;headers={'Content-Type':'text/plain'}
        self.send_response(status)
        for key,value in headers.items():
            if key.lower() in ['content-type','content-encoding','content-range','access-control-allow-origin']:self.send_header(key,value)
        self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(body)
class Server(ThreadingHTTPServer):
    request_queue_size=128
    daemon_threads=True
Server(('127.0.0.1',4162),Handler).serve_forever()
