import fs from 'node:fs';
import {loadNativeModel}from '../../../test/helpers/coastal-native-avatar.mjs';
import {footSole}from '../../../assets/js/home-scene/wildlife-ground-contact.mjs';
const gltf=await loadNativeModel('BrushRabbit.glb',new URL('./inputs/assets/models/home/',import.meta.url)),rows=[];
gltf.scene.updateMatrixWorld(true);
gltf.scene.traverse(o=>{if(o.isBone)rows.push({name:o.name,parent:o.parent?.name,position:o.position.toArray(),quaternion:o.quaternion.toArray()})});
const soles={};for(const name of ['FrontPawL','FrontPawR','HindPawL','HindPawR']){
 const s=footSole(gltf.scene,gltf.scene.getObjectByName(name));soles[name]={count:s.length,min:[0,1,2].map(i=>Math.min(...s.map(p=>p.getComponent(i)))),max:[0,1,2].map(i=>Math.max(...s.map(p=>p.getComponent(i))))};
}
fs.writeFileSync(new URL('./rig.json',import.meta.url),JSON.stringify({bones:rows,soles},null,2));
console.log(JSON.stringify({bones:rows.filter(r=>/Paw|leg|Leg|Pose|Hips|Chest|Root/.test(r.name)),soles}));
