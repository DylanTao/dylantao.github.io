import fs from 'node:fs';
import {loadNativeModel}from '../../../test/helpers/coastal-native-avatar.mjs';
const frames=JSON.parse(fs.readFileSync(new URL('./walkthrough/frames.json',import.meta.url))),rows=[];
for(const [label,model]of [['noon-seaLion-0','CaliforniaSeaLion.glb'],['noon-seal-0','HarborSeal.glb'],['noon-raccoon-0','Raccoon.glb']]){
 const frame=frames.find(r=>r.label===label&&r.support),w=frame.support.minimum;
 const gltf=await loadNativeModel(model,new URL('./inputs/assets/models/home/',import.meta.url));
 const mesh=gltf.scene.getObjectByName(w.mesh);if(!mesh)throw Error('No exact source mesh '+w.mesh);
 const skin=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight,p=mesh.geometry.attributes.position;
 rows.push({label,file:frame.file,frame:frame.evidence.frames,activeSeconds:frame.evidence.animationSeconds,
  state:label==='noon-raccoon-0'?frame.evidence.ecology.wildlife.raccoon.state:frame.evidence.ecology.wildlife.contacts.find(c=>c.habitat===(model==='HarborSeal.glb'?'seal':'seaLion')).state,
  actualSurfaceWitness:w,source:{model,mesh:mesh.name,index:w.vertex,vertexCount:p.count,restPosition:[p.getX(w.vertex),p.getY(w.vertex),p.getZ(w.vertex)],weights:Array.from({length:4},(_,k)=>({bone:mesh.skeleton.bones[skin.getComponent(w.vertex,k)].name,weight:weights.getComponent(w.vertex,k)}))},
  qualification:'A deformed native skin vertex and visible physical support witness. Bone ownership distinguishes a foot/flipper or body/tail part; an exterior visibility/contact plan is still required before treating hidden anatomy as a rendered defect.'});
}
fs.writeFileSync(new URL('./other-species-witnesses.json',import.meta.url),JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));
