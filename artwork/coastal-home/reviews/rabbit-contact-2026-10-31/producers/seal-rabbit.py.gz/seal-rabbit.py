import gzip
import hashlib
import json
import subprocess
from pathlib import Path

q = Path(__file__).parent
root = q.parents[2]
out = root / 'artwork/coastal-home/reviews/rabbit-contact-2026-10-31'
assert not out.exists(), 'Do not overwrite a sealed review'
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip()
assert source.startswith('31412345b')
baseline = json.loads((q / 'native-baseline.json').read_text())
candidate = json.loads((q / 'native-candidate.json').read_text())
assert len(baseline['rows']) == len(candidate['rows']) == 742
assert baseline['otherSpecies'] == candidate['otherSpecies']
central = []
for b, c in zip(baseline['rows'], candidate['rows']):
    assert (b['time'], b['index'], b['rootPosition'], b['lift']) == (c['time'], c['index'], c['rootPosition'], c['lift'])
    if c['state'] in ('hop', 'bolt'):
        start, end = (.1, .85) if c['state'] == 'bolt' else (.18, .76)
        f = (c['phase'] - start) / (end - start)
        if .18 <= f <= .82:
            assert b['allSkin']['worldVerticesSha256'] == c['allSkin']['worldVerticesSha256']
            central.append({'time': c['time'], 'index': c['index'], 'sha256': c['allSkin']['worldVerticesSha256']})
assert len(central) == 62
assert min(r['allSkin']['minimum']['gap'] for r in candidate['rows']) >= -1e-10
assert all(r['allSkin']['missing'] == 0 for r in candidate['rows'])
desktop = json.loads((q / 'live-review-final/chromium-frames.json').read_text())
phone = json.loads((q / 'live-review-final/webkit-frames.json').read_text())
assert len(desktop) == 180 and len(phone) == 80
assert all(not r['errors'] for r in desktop + phone)
out.mkdir(parents=True)

def put(src, target, compress=True):
    data = Path(src).read_bytes()
    path = out / (target + ('.gz' if compress else ''))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(gzip.compress(data, compresslevel=9, mtime=0) if compress else data)

for path in sorted((q / 'inputs').rglob('*')):
    if path.is_file():
        put(path, 'controls/served-4158/' + path.relative_to(q / 'inputs').as_posix())
put(q / 'INPUT_BINDINGS.json', 'INPUT_BINDINGS.json', False)
data_names = ['native-baseline.json', 'native-candidate.json', 'actual-gpu-skin.json', 'rabbit-contact-probe.json', 'cutaway-rabbits.json', 'rabbit-route-owners.json', 'other-species-witnesses.json', 'rig.json', 'inventory.json']
for name in data_names:
    put(q / name, 'data/' + name)
for name in ['chromium-frames.json', 'webkit-frames.json']:
    put(q / 'live-review-final' / name, 'data/final-' + name)
put(q / 'live-review-v3/chromium-frames.json', 'attempts/v3-chromium-frames.json')
put(q / 'walkthrough/frames.json', 'data/initial-walkthrough-frames.json')
for version in ['v2', 'v3']:
    for name in ['wildlife-rabbit-contact.mjs', 'native-candidate.json']:
        put(q / ('attempt-' + version) / name, 'attempts/' + version + '/' + name)
for path in sorted(q.glob('*.log')):
    put(path, 'logs/' + path.name)
for path in sorted(q.iterdir()):
    if path.suffix in ['.cjs', '.mjs', '.py']:
        put(path, 'producers/' + path.name)
for path in sorted((q / 'final-registered').rglob('*.json')):
    put(path, 'registered/' + path.relative_to(q / 'final-registered').as_posix())
images = ['rabbit-probe-0.png', 'cutaway-rabbit-0.png', 'cutaway-rabbit-1.png', 'walkthrough/underdeck-beach-0.png', 'walkthrough/noon-seaLion-0-0.png', 'walkthrough/noon-seal-0-0.png', 'walkthrough/noon-raccoon-0-0.png']
for variant in ['baseline', 'candidate']:
    images += ['live-review-final/chromium-' + variant + '-' + str(i) + '.png' for i in [0, 24, 48, 72]]
    images += ['live-review-final/webkit-' + variant + '-' + str(i) + '.png' for i in [0, 20]]
for name in images:
    put(q / name, 'views/' + name, False)

owned = ['assets/js/home-scene/wildlife.mjs', 'assets/js/home-scene/wildlife-rabbit-contact.mjs', 'test/wildlife-rabbit-contact.test.mjs']
dependencies = ['assets/js/home-scene/wildlife-acting.mjs', 'assets/js/home-scene/wildlife-ground-contact.mjs', 'assets/js/home-scene/wildlife-motion.mjs', 'assets/js/home-scene/wildlife-neighbor-motion.mjs', 'assets/js/home-scene/wildlife-perch-contact.mjs', 'assets/js/home-scene/model-loader.mjs', 'assets/js/three.module.min.js']
bindings = []
for name in owned + dependencies:
    data = subprocess.check_output(['git', 'show', source + ':' + name], cwd=root)
    bindings.append({'path': name, 'bytes': len(data), 'gitBlobSha256': hashlib.sha256(data).hexdigest()})
    if name in owned:
        put(root / name, 'source/' + name)
binding = {'sourceCommit': source, 'sourceBindings': bindings, 'compiledScope': 'Read-through proxy 4162 substitutes exactly wildlife.mjs and wildlife-rabbit-contact.mjs onto the complete frozen coordinator public503 product at 4158. No native model, manifest or cache is changed. The 26 retained served inputs bind actual baseline bytes; canonical native attribution 75af is coordinator-provided.', 'publication': 'None. Coordinator must integrate, regenerate final F6 habitats/support, repeat visible-ground checks, run the official combined cache, full gates, CI and live verification.'}
(out / 'SOURCE_BINDINGS.json').write_text(json.dumps(binding, indent=2) + '\n', encoding='utf-8', newline='\n')
analysis = {'pairedRows': len(candidate['rows']), 'sampleTimes': len(candidate['otherSpecies']), 'minimumCandidateSkinGapM': min(r['allSkin']['minimum']['gap'] for r in candidate['rows']), 'minimumBaselineToeGapM': min(f['minimum'] for r in baseline['rows'] for f in r['feet'].values()), 'centralFlightExactWorldVertexHashes': central, 'otherSpeciesDigestRowsExact': len(candidate['otherSpecies']), 'chromiumNativeRAFRecords': len(desktop), 'webkitNativeRAFRecords': len(phone), 'includedOriginalImages': images, 'openGate': 'Every rabbitEast route index 0-47 is supported by a liftaway roof; visible cutaway toe gaps 2.254-2.260 m are NOT fixed in this checkpoint.'}
(out / 'ANALYSIS.json').write_text(json.dumps(analysis, indent=2) + '\n', encoding='utf-8', newline='\n')
readme = '''# Rabbit contact fit and the remaining cutaway habitat defect

Source `31412345b` fits each rabbit's actual paw sole to the delivered terrain,
then accommodates its small body and connected legs. The authored root route,
timing, hop height and middle of each airborne phase remain unchanged. A separate
roof-visibility defect remains open; this checkpoint does not finish all wildlife
hovering.

## Contact evidence

The baseline public rabbit in a grazing pose had front-paw gaps of 25.0/26.4 mm
and rear-paw gaps of 15.6/21.3 mm. Other sampled authored poses pushed a toe as
far as 29.6 mm into the delivered surface. The new helper measures the four actual
sole envelopes against retained triangles. It uses a 0.6 mm toe contact margin,
fades support smoothly across takeoff and landing, and preserves intentional
grooming lifts. Incomplete footprints and implausible corrections report an
unfitted contact instead of inventing ground or moving the authored route.

A body envelope from 1,234 actual skin vertices prevents compressed hips/chest
from entering the ground. This is a reduced CPU query set, not a geometry or
render-detail reduction. The leg attachment follows the measured hip-to-foot
axis; every next pose restores its authored transforms. The body margin is
1.6 mm and its correction is bounded. No mesh, material or species-wide vertical
offset was changed.

An independent native check evaluates every delivered skin vertex, not only that
envelope: 742 paired poses at 371 times across both rigs, schedules, contact
states and hop boundaries. The worst final toe/skin gap is numerical roundoff
(-5.33e-15 m); no sampled skin point lacks support. Planted toe gaps are within
0.600002 mm. Root position and authored lift are exact for every paired row;
all 62 middle-flight whole-skin world-vertex hashes are exact. Root/skeleton
digests of the other 26 neighbours are exact at all 371 times.

Focused tests use the actual delivered rabbit and explicit crossed grades,
edge/missing support, microsecond takeoff/landing continuity, and compressed
hip/chest poses. They check toe/skin distance, not just helper fields. They do
not prove every possible future terrain or animation state.

## Actual drawing and motion

A passive observer reads the actual uploaded bone texture from the rabbit beauty
draw. Every GPU bone matrix matches its live bone-world/inverse-bind product
with maximum error zero, including the four affine leg attachments. Framebuffer
bindings, active texture and original callbacks restore exactly; GL/runtime
errors are zero. This is an actual draw readback, not a CPU-only matrix claim.

The final native Chromium comparison records 90 uninterrupted RAF samples per
variant at 2560 x 1440, with normal public N inspection and captured graze/sit/hop
states. Modern WebKit 27.2 records 40 per variant at 390 x 1000. Only Date is fixed;
RAF/performance and the acting clock remain live. PNGs are bracketed by frame and
active-time reads, so the side-by-side variants are representative movement
evidence rather than exact simultaneous pixel comparisons. All captures are
nonblank and have zero runtime errors. WebKit is phone emulation, not a physical
iPhone or phone performance result.

The bounded local rabbit-update telemetry has a median of about 1.40 ms (p95
1.67 ms), versus 0.083 ms (p95 0.263 ms) for baseline after warmup. The larger first
envelope took about 3.61 ms median and was reduced. These are one machine's JS
slice diagnostics, not a whole-site frame-rate claim or a universal budget.

Twenty-three focused animal tests pass. Both existing registered browser cases
pass at all four standard widths: delivered contact/bounded motion, and keyboard
inspection/orbit/return (eight cases, 2.7 minutes). No new browser case or registry
entry is added here; the new CPU test is separate. The coordinator must register
and run visible-ground/cutaway habitat coverage after the F6 terrain integration.
Style contract, targeted Prettier and diff checks pass.

## Retained attempts and remaining work

The first smooth contact fit still let an early-flight rear toe enter by 4.56 mm;
the actual-toe lift guard repairs that transition. The next toe-only attempt
buried compressed hips by about 16 mm. Both are rejected; retained V2/V3 source,
native measurements, logs and the first expensive live comparison explain the
final envelope and cost tradeoff.

**The eastern rabbit still floats in overview cutaway.** All `rabbitEast` path
indices 0-47 hit native `core_retreat_liftaway_roof` primitive 0 (actual browser
mesh `core_retreat_liftaway_roof_1`). That owner is hidden by the cutaway policy;
independent visible-ground ray tests measure 2.254-2.260 m below its toes. The
recorded helper visibility flag is stale and is not proof of visible support.
At the witness station, route progress is 0.7981481414, between indices 38/39.
All western route indices hit fixed golden coastal sandstone. The coordinator
must regenerate the eastern route onto retained ground or explicitly couple
roof-supported wildlife to roof visibility. This helper does neither and must
not teleport the animal down when the roof disappears.

The separate read-only audit retains three outer-skin penetration candidates:
sea-lion Hips (-102.6 mm), seal FrontFlipperTipL (-33.0 mm), and sleeping raccoon
TailTip (-178.3 mm). They need pose-specific visible/contact interpretation;
the raccoon's already-correct planted paws must not be raised by a global shift.
The accompanying shoreline/underdeck images also expose old cliff/slab geometry
sent to the terrain owner. No other-animal or terrain repair is claimed here.

## Provenance and replay limits

`SOURCE_BINDINGS.json` binds committed source blobs. `INPUT_BINDINGS.json` hashes
the 26 actual frozen served inputs. Controls include their unchanged bytes;
data include native paired measurements, actual GPU readback, live frame evidence,
route ownership and the original audit. Original representative PNG bytes are
retained. Gzip payloads use deterministic compression and can be inspected with
ordinary Python gzip/JSON tools. `MANIFEST.json` hashes every payload except itself.

Proxy 4162 replaces only the two rabbit modules over the complete frozen public503
preview at 4158. It does not change native models, manifest, light inputs or cache.
Its old restored cache is a control, not a signed acceptance cache for the new
source. The coordinator owns the final combined native pipeline, habitat/support
regeneration, official cache bake, public navigation checks, full suite, CI and
live-site verification. Nothing in this worker checkpoint was pushed.
'''
(out / 'README.md').write_text(readme, encoding='utf-8', newline='\n')
manifest = {'schema': 1, 'scope': 'Measured rabbit contact repair; eastern roof/cutaway habitat remains open. Source and private evidence only.', 'files': []}
for path in sorted(out.rglob('*')):
    if path.is_file():
        b = path.read_bytes()
        manifest['files'].append({'path': path.relative_to(out).as_posix(), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
(out / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'source': source, 'payloads': len(manifest['files']), 'bytes': sum(r['bytes'] for r in manifest['files']), 'includedImages': len(images), 'centralFlightExact': len(central)}))
