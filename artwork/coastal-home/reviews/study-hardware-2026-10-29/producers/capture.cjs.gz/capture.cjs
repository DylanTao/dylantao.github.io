const fs = require('node:fs'), path = require('node:path');
const engine=process.env.STUDY_ENGINE||'chromium';
const api=require(engine==='webkit'?'C:/dev/dylantao.github.io/.jekyll-cache/visual-qa/takeover-archives/walk-audit-20261028-cache/visual-qa/walk-audit-20261028/pw165/node_modules/@playwright/test':'C:/dev/dylantao.github.io/node_modules/@playwright/test');
const {chromium,webkit,expect}=api;
const {preparePage, collectRuntimeErrors, screenshotMetrics} = require('../../../test/visual/helpers.js');
const q = __dirname;
const variant = process.argv[2] || 'baseline';
const width=Number(process.argv[3]||1440), height=width===3840?2160:width===2560?1440:width===1280?800:width===768?1024:1000;
const base = process.env.STUDY_URL || 'http://127.0.0.1:4150/al-folio/';
(async()=>{
  const browser = engine==='webkit'?await webkit.launch({headless:true}):await chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
  const rows = [];
  try {
    const context = await browser.newContext({viewport:{width,height}, deviceScaleFactor:1, hasTouch:engine==='webkit',isMobile:engine==='webkit',reducedMotion:'reduce', timezoneId:'America/Los_Angeles'});
    const page = await context.newPage(), errors = collectRuntimeErrors(page);
    page.setDefaultTimeout(90000);
    await preparePage(page,'light');
    await page.clock.setFixedTime(new Date('2026-10-23T16:00:00-07:00'));
    await page.goto(base+'?scene-lab=1&quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});
    if(engine==='webkit')await page.locator('[data-home-desk-mode="3d"]').tap();
    else await page.locator('[data-home-desk-mode="3d"]').click();
    const host = page.locator('[data-home-desk-scene]'), ui = page.locator('[data-home-world-controls]');
    await host.scrollIntoViewIfNeeded();
    await expect(host).toHaveAttribute('data-scene-state','ready',{timeout:180000});
    const manifest = JSON.parse(fs.readFileSync(path.resolve(q,'../../../assets/models/home/manifest.json'),'utf8'));
    await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().roomCount),{timeout:90000}).toBe(manifest.rooms.length);
    const details = ui.locator('details').first();
    if(!await details.evaluate(e=>e.open)) await details.locator('summary').first().click();
    await ui.locator('[data-world-avatar]').selectOption('ghibli');
    await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().avatarId),{timeout:90000}).toBe('ghibli');
    await expect(ui).not.toHaveAttribute('aria-busy','true',{timeout:90000});
    await ui.locator('[data-world-room="study"]').first().click();
    await host.scrollIntoViewIfNeeded();
    await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().currentRoom),{timeout:90000}).toBe('study');
    if(width>=2560) {
      await ui.locator('[data-world-fullscreen]').click();
      await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().fullscreen),{timeout:15000}).not.toBe(null);
    }
    if(await details.evaluate(e=>e.open)) await details.locator('summary').first().click();
    const frame=await host.evaluate(e=>{const f=e.getSceneEvidence().frames;e.labScene.requestFrame();return f});
    await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().frames),{timeout:90000}).toBeGreaterThan(frame);
    await page.waitForTimeout(900);
    const image = await host.locator('canvas').screenshot({path:path.join(q,variant+'-study-'+width+'.png')});
    const backend=await host.locator('canvas').evaluate(c=>{const gl=c.getContext('webgl2')||c.getContext('webgl'),debug=gl.getExtension('WEBGL_debug_renderer_info');return{renderer:gl.getParameter(debug?.UNMASKED_RENDERER_WEBGL||gl.RENDERER),version:gl.getParameter(gl.VERSION),buffer:[gl.drawingBufferWidth,gl.drawingBufferHeight]}});
    rows.push({variant,engine,browserVersion:browser.version(),backend,url:page.url(),errors,evidence:await host.evaluate(e=>e.getSceneEvidence()),metrics:screenshotMetrics(image)});
    if(width>=2560) {
      const frame=await host.evaluate(e=>{const f=e.getSceneEvidence().frames;e.setLabCamera({target:[-10.7,.26,6.04],yaw:2.95,pitch:.12,radius:1.0});return f});
      await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().frames),{timeout:90000}).toBeGreaterThan(frame);
      await page.waitForTimeout(1400);
      const image=await host.locator('canvas').screenshot({path:path.join(q,variant+'-hardware-'+width+'.png')});
      rows.push({variant,engine,browserVersion:browser.version(),backend,url:page.url(),errors,evidence:await host.evaluate(e=>e.getSceneEvidence()),metrics:screenshotMetrics(image)});
    }
    fs.writeFileSync(path.join(q,variant+'-capture-'+width+'.json'),JSON.stringify(rows,null,2));
    console.log(JSON.stringify(rows.map(r=>({variant:r.variant,room:r.evidence.currentRoom,rooms:r.evidence.roomCount,camera:r.evidence.camera,errors:r.errors,metrics:r.metrics}))));
    await context.close();
  } finally { await browser.close() }
})().catch(e=>{console.error(e);process.exitCode=1});
