import hashlib
import json
from pathlib import Path
import sys
import bpy
import numpy as np

q=Path(__file__).parent
sys.path.insert(0,str(q.parents[2]/'bin'))
import refresh_coastal_study_hardware as recipe
groups=recipe.select(bpy.context.scene)
out={}
for group,objects in groups.items():
    h=hashlib.sha256()
    for name,indices in sorted(objects.items()):
        points=recipe.world_points(bpy.context.scene.objects[name],sorted(indices))
        h.update(name.encode())
        h.update(points.astype('<f4').tobytes())
    out[group]=h.hexdigest()
(q/'hardware-fingerprints.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out),flush=True)
