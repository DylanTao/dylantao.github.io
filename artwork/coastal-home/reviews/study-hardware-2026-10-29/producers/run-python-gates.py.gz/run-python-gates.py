import json
from pathlib import Path
import subprocess
import sys

q=Path(__file__).parent
result=subprocess.run([sys.executable,'-m','unittest','discover','-s','test','-p','test_*.py'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(q/'python-gates-clean.log').write_bytes(result.stdout)
receipt={'command':[sys.executable,'-m','unittest','discover','-s','test','-p','test_*.py'],'returncode':result.returncode,'log':'python-gates-clean.log'}
(q/'python-gates.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
raise SystemExit(result.returncode)
