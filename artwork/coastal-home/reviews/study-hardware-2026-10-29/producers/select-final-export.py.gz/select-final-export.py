import hashlib
import json
import shutil
from pathlib import Path

q=Path(__file__).parent
archive=q/'level7'
archive.mkdir(exist_ok=True)
for pattern in ['candidate-*.png','candidate-capture-*.json','webkit-candidate-*.png','webkit-candidate-capture-*.json','decoded-*.json','decoded-*.log']:
    for p in q.glob(pattern):shutil.copy2(p,archive/p.name)
candidate=q/'candidate-level10/models/room-study.glb'
(q/'site/al-folio/assets/models/home/room-study.glb').write_bytes(candidate.read_bytes())
changed=[]
for row in json.loads((q/'compiled-baseline.json').read_text())['files']:
    file=q/'site/al-folio'/row['path']
    digest=hashlib.sha256(file.read_bytes()).hexdigest()
    if digest!=row['sha256']:changed.append({'path':row['path'],'before':row['sha256'],'after':digest})
assert [x['path']for x in changed]==['assets/models/home/room-study.glb']
(q/'final-preview-substitution.json').write_text(json.dumps({'completeCompiledFiles':1360,'scope':'Exactly one delivered room; matched Dracoeffort10, unchanged quantization; pre-final vertexAO/static-light bake','changed':changed},indent=2)+'\n')
print(json.dumps(changed))
