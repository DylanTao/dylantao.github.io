const path=require('node:path');
const base=require('../../../test/visual/public.config.js');
module.exports={...base,testDir:path.resolve(__dirname,'../../../test/visual'),testMatch:'estate-redesign.spec.js',grep:/visitor circulation: the study joins outdoor living and the living facade returns to the same floor$/,workers:1,outputDir:path.join(__dirname,'navigation'),reporter:[['line'],['json',{outputFile:path.join(__dirname,'navigation-results.json')}]],use:{...base.use,trace:'off'},projects:[{name:'desktop-1440',use:{viewport:{width:1440,height:1000}}}]};
