import json
from pathlib import Path

q=Path(__file__).parent
doc=json.loads((q/'inventory.json').read_text())
regions={
 'primary':([-11.86,-5.35,.879],[-11.62,-4.35,1.55]),
 'secondary':([-11.84,-6.18,.879],[-11.20,-5.70,1.41]),
 'laptop':([-11.66,-4.28,.879],[-11.15,-3.78,1.12]),
 'tower':([-10.94,-7.03,-.001],[-10.46,-6.77,.51]),
}
out={k:[]for k in regions}
for obj in doc['objects']:
 if not any(w in obj['name']for w in ['screen','device','laptop','pc ','rtx']):continue
 for i,c in enumerate(obj.get('components',[])):
  owner=[]
  for name,(lo,hi)in regions.items():
   if all(c['lo'][k]>=lo[k] and c['hi'][k]<=hi[k]for k in range(3)):
    owner.append(name)
  if len(owner)>1:raise RuntimeError((obj['name'],i,owner))
  if owner:out[owner[0]].append({'object':obj['name'],'component':i,'vertices':c['count'],'lo':c['lo'],'hi':c['hi']})
for name,rows in out.items():
 print(name,'vertices',sum(r['vertices']for r in rows),'islands',len(rows))
 for obj in sorted(set(r['object']for r in rows)):
  print(' ',obj,sum(r['vertices']for r in rows if r['object']==obj),[r['component']for r in rows if r['object']==obj])
(q/'selection-plan.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
