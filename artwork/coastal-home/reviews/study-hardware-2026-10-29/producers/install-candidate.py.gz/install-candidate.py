import hashlib
import json
from pathlib import Path

q=Path(__file__).parent
folder=q/'site/al-folio/assets/models/home'
target=folder/'room-study.glb'
baseline=q/'baseline-room-study.glb'
if baseline.exists():raise RuntimeError('Do not overwrite baseline custody')
baseline.write_bytes(target.read_bytes())
target.write_bytes((q/'candidate-final/models/room-study.glb').read_bytes())
before=json.loads((q/'compiled-baseline.json').read_text())
changes=[]
for row in before['files']:
    p=q/'site/al-folio'/row['path']
    digest=hashlib.sha256(p.read_bytes()).hexdigest()
    if digest!=row['sha256']:changes.append({'path':row['path'],'before':row['sha256'],'after':digest})
assert [r['path']for r in changes]==['assets/models/home/room-study.glb'],changes
(q/'preview-substitution.json').write_text(json.dumps({'scope':'Complete frozen compiled site; exactly one changed room GLB; pre-final contact/static-light bake','changes':changes},indent=2)+'\n')
print(json.dumps(changes))
