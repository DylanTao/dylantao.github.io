"""Compare the two actual browser/Draco decodes, with native island custody."""
import hashlib
import json
import math
from pathlib import Path
import sys

import bpy
import numpy as np
from mathutils import Vector
from mathutils.kdtree import KDTree

q=Path(__file__).parent
sys.path.insert(0,str(q.parents[2]/'bin'))
import refresh_coastal_study_hardware as r
bpy.ops.wm.open_mainfile(filepath=str(q/'baseline.blend'))
scene=bpy.context.scene
groups=r.select(scene)
membership={}
for group,objects in groups.items():
    for name,indices in objects.items():
        for i in indices:membership[(name,i)]=group
data=json.loads((q/'decoded-exports.json').read_text())
base={m['name']:m for m in data[0]['meshes']}
cand={m['name']:m for m in data[1]['meshes']}
receipt=json.loads((q/'candidate-final/receipt.json').read_text())
rows=[];pieces=[];diagonals=[]
assert base.keys()==cand.keys()
for name,b in base.items():
    a=cand[name]
    assert b['material']==a['material']
    assert b['indices']==a['indices'],name
    assert b['attributes']==a['attributes'],name
    bp=np.array(b['positions']).reshape((-1,3));ap=np.array(a['positions']).reshape((-1,3))
    bn=np.array(b['normals']).reshape((-1,3));an=np.array(a['normals']).reshape((-1,3))
    obj=scene.objects[name];original=r.world_points(obj,range(len(obj.data.vertices)))
    tree=KDTree(len(original))
    for i,point in enumerate(original):tree.insert(Vector(point),i)
    tree.balance()
    component_index={}
    for index,indices in enumerate(r.islands(obj.data)):
        for i in indices:component_index[i]=index
    expected=bp.copy();owners=[];native_components=[];nearest_errors=[]
    for i,point in enumerate(bp):
        location,vertex,distance=tree.find(Vector(point))
        nearest_errors.append(distance)
        group=membership.get((name,vertex),'unchanged')
        owners.append(group);native_components.append(component_index[vertex])
        if group!='unchanged':
            info=receipt['assemblies'][group]
            expected[i]=np.array(info['nativePivot'])+info['uniformScale']*(point-info['nativePivot'])+info['nativeTranslation']
    span=float(np.ptp(original,axis=0).max())
    bound=math.sqrt(3)*span/16383*1.06+.00001
    error=np.linalg.norm(ap-expected,axis=1)
    assert float(error.max())<=bound,(name,float(error.max()),bound)
    delta=np.linalg.norm(an-bn,axis=1)
    angle=np.degrees(2*np.arcsin(np.minimum(1.,delta/2)))
    masks={group:np.array(owners)==group for group in set(owners)}
    # The existing8-bit octahedral encoder is unchanged. Selected native
    # deviations can cross an existing quantizer cell; report these separately
    # from the .05-degree native bound. Unselected decoded normals stay exact.
    if 'unchanged'in masks:assert float(delta[masks['unchanged']].max(initial=0))==0,name
    rows.append({'object':name,'vertices':len(bp),'triangles':len(b['indices'])//3,'indexBufferExact':True,'allOtherAttributesExact':True,
                 'maximumDecodedTransformErrorM':float(error.max()),'pairedPositionQuantizationBoundM':bound,
                 'maximumSourceNearestVertexErrorM':max(nearest_errors),
                 'groups':{group:{'vertices':int(mask.sum()),'changedNormalVectors':int(np.count_nonzero(delta[mask])),
                                          'maximumDecodedTransformErrorM':float(error[mask].max(initial=0)),
                                          'maximumNormalAngleDegrees':float(angle[mask].max(initial=0))}for group,mask in masks.items()}})
    for component in sorted(set(native_components)):
        mask=np.array(native_components)==component
        group=set(np.array(owners)[mask]);assert len(group)==1
        pieces.append({'object':name,'nativeComponent':component,'group':next(iter(group)),'decodedVertices':int(mask.sum()),'changedNormalVectors':int(np.count_nonzero(delta[mask])),
                       'maximumDecodedTransformErrorM':float(error[mask].max()),'maximumNormalAngleDegrees':float(angle[mask].max())})
    if name=='study__monitor screen glass':
        for group in r.TARGET_INCHES:
            inches,spans=r.diagonal(ap[masks[group]])
            assert abs(inches-r.TARGET_INCHES[group])<.01,(group,inches)
            diagonals.append({'group':group,'decodedActiveGlassDiagonalInches':inches,'decodedSpansM':spans})
out={'decoder':'Exact delivered three-r164 GLTFLoader + same-origin Draco WASM workers in Chromium',
     'baselineSha256':hashlib.sha256((q/'baseline-room-study.glb').read_bytes()).hexdigest(),
     'candidateSha256':hashlib.sha256((q/'candidate-level10/models/room-study.glb').read_bytes()).hexdigest(),
     'sameMeshMaterialVertexTriangleCounts':True,'meshes':rows,'perNativeComponent':pieces,'actualDecodedGlass':diagonals,
     'scope':'Native selected corner normals are separately bounded at.05deg. Draco8 octahedral quantizer is unchanged; selected cell crossings are measured here, not relabeled exact.'}
(q/'decoded-verification.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'decodedGlass':diagonals,'maximumDecodedTransformErrorM':max(x['maximumDecodedTransformErrorM']for x in rows),
                  'selectedExportNormalMaximumDegrees':max(x['maximumNormalAngleDegrees']for x in pieces),
                  'unselectedExportNormalMaximumDegrees':max(x['maximumNormalAngleDegrees']for x in pieces if x['group']=='unchanged')}),flush=True)
