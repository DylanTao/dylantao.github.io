const fs=require('node:fs'),path=require('node:path');
const {chromium}=require('C:/dev/dylantao.github.io/node_modules/playwright');
const q=__dirname;
(async()=>{
 const browser=await chromium.launch({headless:true});
 try{
  const context=await browser.newContext(),page=await context.newPage();
  await page.route('**/__study-qa/*.glb',route=>route.fulfill({path:path.join(q,route.request().url().endsWith('/baseline.glb')?'baseline-room-study.glb':'candidate-level10/models/room-study.glb'),contentType:'model/gltf-binary'}));
  await page.goto('http://127.0.0.1:4154/al-folio/404.html',{waitUntil:'domcontentloaded'});
  const data=await page.evaluate(async()=>{
    const T=await import('/al-folio/assets/js/three.module.min.js');
    const {createModelLoader}=await import('/al-folio/assets/js/home-scene/model-loader.mjs');
    const {loader,decoder}=createModelLoader(),rows=[];
    try{
      for(const variant of ['baseline','candidate']){
        const gltf=await loader.loadAsync('/al-folio/__study-qa/'+variant+'.glb');
        gltf.scene.updateMatrixWorld(true);
        const meshes=[];
        gltf.scene.traverse(obj=>{
          if(!obj.isMesh)return;
          const p=obj.geometry.attributes.position,n=obj.geometry.attributes.normal;
          const assoc=gltf.parser.associations.get(obj),original=gltf.parser.json.nodes[assoc.nodes].name;
          const normalMatrix=new T.Matrix3().getNormalMatrix(obj.matrixWorld),v=new T.Vector3(),positions=[],normals=[];
          for(let i=0;i<p.count;i++){
            v.fromBufferAttribute(p,i).applyMatrix4(obj.matrixWorld);positions.push(v.x,-v.z,v.y);
            v.fromBufferAttribute(n,i).applyMatrix3(normalMatrix).normalize();normals.push(v.x,-v.z,v.y);
          }
          const attrs={};
          for(const [name,a]of Object.entries(obj.geometry.attributes))if(!['position','normal'].includes(name))attrs[name]={itemSize:a.itemSize,normalized:a.normalized,array:Array.from(a.array)};
          meshes.push({name:original,material:obj.material.name,positions,normals,indices:Array.from(obj.geometry.index.array),attributes:attrs});
          obj.geometry.dispose();obj.material.dispose();
        });
        rows.push({variant,meshes});
      }
    }finally{decoder.dispose()}
    return rows;
  });
  fs.writeFileSync(path.join(q,'decoded-exports.json'),JSON.stringify(data));
  console.log(JSON.stringify(data.map(r=>({variant:r.variant,meshes:r.meshes.length,vertices:r.meshes.reduce((n,m)=>n+m.positions.length/3,0),triangles:r.meshes.reduce((n,m)=>n+m.indices.length/3,0)}))));
  await context.close();
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
