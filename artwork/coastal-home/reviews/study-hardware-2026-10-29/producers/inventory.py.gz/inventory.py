"""Read-only native hardware inventory. Never saves or mutates the input blend."""
import hashlib
import json
from pathlib import Path
import bpy
import numpy as np

if bpy.app.version != (4, 5, 9):
    raise RuntimeError('Exact Blender 4.5.9 required')
q=Path(__file__).parent
source=q/'baseline.blend'
scene=bpy.context.scene

def connected(mesh):
    parent=list(range(len(mesh.vertices)))
    def find(x):
        while parent[x]!=x:
            parent[x]=parent[parent[x]];x=parent[x]
        return x
    for edge in mesh.edges:
        a,b=map(find,edge.vertices)
        if a!=b:parent[b]=a
    groups={}
    for i in range(len(parent)):
        groups.setdefault(find(i),[]).append(i)
    return list(groups.values())

objects=[]
for obj in scene.objects:
    if obj.type!='MESH' or not obj.name.startswith('study_'):
        continue
    if not obj.data.vertices:
        objects.append({'name':obj.name,'vertices':0,'empty':True})
        continue
    points=np.array([list(obj.matrix_world@v.co)for v in obj.data.vertices])
    record={'name':obj.name,'vertices':len(obj.data.vertices),'faces':len(obj.data.polygons),
            'materials':[m.name for m in obj.data.materials if m],
            'lo':points.min(axis=0).tolist(),'hi':points.max(axis=0).tolist(),
            'attributes':[{ 'name':a.name,'domain':a.domain,'type':a.data_type }for a in obj.data.attributes]}
    detailed=any(word in obj.name.lower()for word in ['screen','device','laptop','pc ','rtx','marble'])
    if detailed:
        pieces=[]
        for group in connected(obj.data):
            p=points[group];lo=p.min(axis=0);hi=p.max(axis=0)
            item={'indices':group,'count':len(group),'lo':lo.tolist(),'hi':hi.tolist()}
            if 'screen glass'in obj.name:
                center=p.mean(axis=0);values,axes=np.linalg.eigh(np.cov((p-center).T))
                order=np.argsort(values)[::-1];basis=axes[:,order];size=np.ptp((p-center)@basis,axis=0)
                item.update({'center':center.tolist(),'pcaAxes':basis.tolist(),'pcaSize':size.tolist(),
                    'activeDiagonalInches':float(np.hypot(size[0],size[1])/.0254)})
            pieces.append(item)
        record['components']=pieces
    objects.append(record)

floor=[]
for obj in scene.objects:
    if obj.type!='MESH' or not obj.data.vertices or not any(x in obj.name.lower()for x in ['floor','deck','slab']):continue
    p=np.array([list(obj.matrix_world@v.co)for v in obj.data.vertices]);lo=p.min(axis=0);hi=p.max(axis=0)
    if hi[0]<-12.5 or lo[0]>-8 or hi[1]<-8 or lo[1]>-3:continue
    floor.append({'name':obj.name,'lo':lo.tolist(),'hi':hi.tolist()})

data={'blender':bpy.app.version_string,'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'objects':objects,'nearbyFloorObjects':floor}
(q/'inventory.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'studyObjects':len(objects),'objects':[(o['name'],o['vertices'],len(o.get('components',[])))for o in objects],
    'screens':[(o['name'],[c['activeDiagonalInches']for c in o.get('components',[])if'activeDiagonalInches'in c])for o in objects if'screen glass'in o['name']],
    'floor':floor}),flush=True)
