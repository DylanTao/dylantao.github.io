import concurrent.futures
import hashlib
import json
from pathlib import Path
import urllib.request

q=Path(__file__).parent
site=q/'site/al-folio'
files=sorted((site/'assets/models/home').rglob('*'))
files=[p for p in files if p.is_file()]
def check(file):
    relative=file.relative_to(site).as_posix()
    expected=file.read_bytes()
    with urllib.request.urlopen('http://127.0.0.1:4154/al-folio/'+relative,timeout=30)as response:
        body=response.read()
    assert body==expected,relative
    return {'path':relative,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'exactHttp':True}
with concurrent.futures.ThreadPoolExecutor(max_workers=6)as pool:
    rows=list(pool.map(check,files))
original=json.loads((q/'compiled-baseline.json').read_text())
expected={r['path']:r for r in original['files']}
changed=[r['path']for r in rows if r['sha256']!=expected[r['path']]['sha256']]
assert changed==['assets/models/home/room-study.glb']
out={'url':'http://127.0.0.1:4154/al-folio/','completeCompiledFileCount':len(original['files']),
     'homeFiles':len(rows),'homeBytes':sum(r['bytes']for r in rows),'exactHttpBodies':rows,
     'changedHomeFiles':changed,'previewScope':'Pre-final AO/static-field lighting; all supplied compiled bytes retained except room-study; current official cache restored'}
(q/'http-readback.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in out.items()if k!='exactHttpBodies'}))
