"""A changed same-count island must fail before the migration writes anything."""
import hashlib
import json
from pathlib import Path
import sys

import bpy

q=Path(__file__).parent
sys.path.insert(0,str(q.parents[2]/'bin'))
import refresh_coastal_study_hardware as r
source=q/'baseline.blend'
bpy.ops.wm.open_mainfile(filepath=str(source))
scene=bpy.context.scene
groups=r.select(scene)
obj=scene.objects['study__matte black device']
index=groups['primary'][obj.name][0]
obj.data.vertices[index].co.x+=.0001
selected={name:indices for group in groups.values()for name,indices in group.items()}
before=r.immutable_scene_digest(scene,{})
try:r.migrate(scene)
except RuntimeError as exc:
    assert str(exc).startswith('The retained hardware geometry changed:')
    reason=str(exc)
else:raise RuntimeError('Changed same-count hardware was admitted')
after=r.immutable_scene_digest(scene,{})
assert before==after
assert not scene.get('studyHardwareRevision')
out={'test':'100micrometer change inside the original primary bounding box; same object/island/vertex counts',
     'rejectedBeforeMigration':True,'rejection':reason,'sceneDigestBefore':before,'sceneDigestAfter':after,
     'sourceFileStillSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'saved':False}
(q/'guard-negative.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out),flush=True)
