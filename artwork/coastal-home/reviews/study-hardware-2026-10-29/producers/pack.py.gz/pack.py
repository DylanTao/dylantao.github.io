import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

root=Path.cwd()
q=Path(__file__).parent
out=root/'artwork/coastal-home/reviews/study-hardware-2026-10-29'
out.mkdir(parents=True,exist_ok=True)

def copy(source,target,packed=True):
    data=source.read_bytes()
    path=out/target;path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(gzip.compress(data,mtime=0)if packed else data)

if '--seal-only'not in sys.argv:
    for name in ['inventory','support-survey','selection-plan','hardware-fingerprints','native-verification','decoded-verification',
                 'guard-negative','compiled-baseline','http-readback','final-preview-substitution','python-gates','effort-pixel-control']:
        copy(q/(name+'.json'),'data/'+name+'.json.gz')
    copy(q/'decoded-exports.json','data/actual-browser-decoded-arrays.json.gz')
    copy(q/'candidate-final/receipt.json','data/migration-receipt.json.gz')
    copy(q/'candidate-level10/export.json','data/candidate-export.json.gz')
    copy(q/'baseline-level10/export.json','data/unchanged-source-export.json.gz')
    for name in ['baseline-control-capture-3840','final-capture-3840','final-capture-2560','candidate-capture-1440',
                 'final-capture-1280','final-capture-768','candidate-capture-390','webkit-candidate-capture-390']:
        copy(q/(name+'.json'),'data/'+name+'.json.gz')
    views={
      'baseline-control-study-3840.png':'baseline-study-3840.png','baseline-control-hardware-3840.png':'baseline-tower-3840.png',
      'final-study-3840.png':'candidate-study-3840.png','final-hardware-3840.png':'candidate-tower-3840.png',
      'final-study-2560.png':'candidate-study-2560.png','final-hardware-2560.png':'candidate-tower-2560.png',
      'candidate-study-1440.png':'candidate-study-1440.png','final-study-1280.png':'candidate-study-1280.png',
      'final-study-768.png':'candidate-study-768.png','candidate-study-390.png':'candidate-study-390.png',
      'webkit-candidate-study-390.png':'webkit-study-390.png',
    }
    for src,dest in views.items():copy(q/src,'views/'+dest,False)
    copy(q/'baseline-room-study.glb','models/delivered-room-study.glb.gz')
    copy(q/'candidate-level10/models/room-study.glb','models/candidate-room-study.glb.gz')
    copy(q/'baseline-level10/models/room-study.glb','models/unchanged-source-room-study.glb.gz')
    copy(q/'candidate-final/models/room-study.glb','rejected/effort7-room-study.glb.gz')
    for name in ['attempt-1-source.py','attempt-2-source.py','attempt-1.log','attempt-2.log','python-gates.log']:
        copy(q/name,'rejected/'+name+'.gz')
    for name in ['inventory.py','support-survey.py','selection-plan.py','hardware-fingerprints.py','attribute-probe.py',
                 'verify-native.py','verify-decoded.py','decode-exports.cjs','capture.cjs','prepare-preview.py',
                 'install-candidate.py','select-final-export.py','guard-negative.py','readback.py','run-python-gates.py',
                 'navigation.config.cjs','serve.py','pack.py']:
        copy(q/name,'producers/'+name+'.gz')
    for name in ['native-verification.log','decoded-verification.log','candidate-final.log','baseline-level10.log','candidate-level10.log','python-gates-clean.log']:
        copy(q/name,'logs/'+name+'.gz')
    copy(q/'navigation-results.json','data/navigation-results.json.gz')
    for path in sorted((q/'navigation').rglob('*')):
        if not path.is_file()or path.name=='.last-run.json':continue
        copy(path,'navigation/'+path.name+(''if path.suffix=='.png'else'.gz'),path.suffix!='.png')
    for src,dest in [('index.html','index.html'),('assets/models/home/manifest.json','manifest.json'),
                     ('assets/js/home-scene/controller.mjs','controller.mjs'),('assets/js/home.js','home.js')]:
        copy(q/'site/al-folio'/src,'compiled/'+dest+'.gz')
    bindings=[]
    for name in ['bin/refresh_coastal_study_hardware.py','bin/optimize_coastal_exports.py','bin/coastal_office.py',
                 'bin/coastal_architecture_finish.py','assets/models/home/manifest.json','assets/models/home/room-study.glb',
                 'artwork/coastal-home/coastal-home.blend','test/visual/estate-redesign.spec.js','test/visual/helpers.js','test/visual/scene-clock.js']:
        data=subprocess.run(['git','show','HEAD:'+name],check=True,stdout=subprocess.PIPE).stdout
        bindings.append({'path':name,'gitBlobSha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
    control={
      'nativeInputSha256':hashlib.sha256((q/'baseline.blend').read_bytes()).hexdigest(),
      'nativeCandidateSha256':hashlib.sha256((q/'candidate-final/candidate.blend').read_bytes()).hexdigest(),
      'deliveredGlbSha256':hashlib.sha256((q/'baseline-room-study.glb').read_bytes()).hexdigest(),
      'candidateGlbSha256':hashlib.sha256((q/'candidate-level10/models/room-study.glb').read_bytes()).hexdigest(),
      'sourceCommit':'e773eb0d1','sourceBindings':bindings,
      'compiledScope':'Supplied complete frozen coordinator build,1360files; only room-study changed. Newer coordinator infinityPool/cache metadata are bound in compiled/manifest separately from worker export-input manifest.',
      'candidateScope':'pre-final vertexAO/staticlight rebuild; geometry and public-control qualification only',
    }
    (out/'SOURCE_BINDINGS.json').write_text(json.dumps(control,indent=2)+'\n',encoding='utf-8',newline='\n')

payloads=[]
for path in sorted(out.rglob('*')):
    if path.is_file()and path.name!='MANIFEST.json':
        data=path.read_bytes()
        payloads.append({'path':path.relative_to(out).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(out/'MANIFEST.json').write_text(json.dumps({'schema':1,'scope':'Native hardware recipe and private full-scene candidate; no publication or final lighting acceptance','files':payloads},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'payloads':len(payloads),'bytes':sum(x['bytes']for x in payloads),'folder':str(out)}))
