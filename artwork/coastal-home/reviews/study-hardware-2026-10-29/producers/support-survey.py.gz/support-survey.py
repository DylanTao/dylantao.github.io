"""Read-only authored support measurements; no save or changes."""
import json
from pathlib import Path

import bpy
from mathutils import Vector

if bpy.app.version != (4, 5, 9):
    raise RuntimeError("Exact Blender 4.5.9 required")

q = Path(__file__).parent
scene = bpy.context.scene
deps = bpy.context.evaluated_depsgraph_get()


def hits(x, y, high, low):
    at = high
    found = []
    for _ in range(50):
        ok, loc, normal, face, obj, matrix = scene.ray_cast(
            deps, Vector((x, y, at)), Vector((0, 0, -1)), distance=at-low
        )
        if not ok:
            break
        found.append({"object": obj.name, "z": loc.z, "normal": list(normal), "face": face})
        at = loc.z - .00002
        if at <= low:
            break
    return found


samples = []
for label, xs, ys, high, low in (
    ("old tower feet", [-10.88, -10.52], [-6.98, -6.82], -.0001, -1),
    ("under-return tower feet", [-10.88, -10.52], [-6.12, -5.96], .82, -1),
    ("primary old stand corners", [-11.848, -11.652], [-5.018, -4.682], .8799, .7),
    ("primary proposed stand corners", [-11.7254, -11.5346], [-5.0134, -4.6866], .8799, .7),
):
    for x in xs:
        for y in ys:
            samples.append({"label": label, "xy": [x, y], "hits": hits(x, y, high, low)})

near = []
for obj in scene.objects:
    if obj.type != "MESH" or not obj.data.vertices or obj.hide_render:
        continue
    corners = [obj.matrix_world @ Vector(v) for v in obj.bound_box]
    lo = [min(p[k] for p in corners) for k in range(3)]
    hi = [max(p[k] for p in corners) for k in range(3)]
    if hi[0] < -11 or lo[0] > -10.4 or hi[1] < -6.3 or lo[1] > -5.7 or hi[2] < 0 or lo[2] > .83:
        continue
    near.append({"object": obj.name, "lo": lo, "hi": hi})

out = {"source": "75afc57f664101e59150910f86662b21ccf01087c393521ab1fa1886e481c5ad", "samples": samples, "objectsNearProposedTower": near}
(q / "support-survey.json").write_text(json.dumps(out, indent=2)+"\n", encoding="utf-8", newline="\n")
print(json.dumps(out), flush=True)
