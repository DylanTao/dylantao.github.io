"""Custody the coordinator's complete frozen compiled product, never a proxy."""
import hashlib
import json
import shutil
from pathlib import Path

q = Path(__file__).parent
src = Path("C:/dev/dylantao.github.io/.jekyll-cache/visual-qa/jump-walk-20261029/site/al-folio")
dst = q / "site/al-folio"
if dst.exists():
    raise RuntimeError("Refusing to overwrite a preview custody copy")
shutil.copytree(src, dst)
rows = []
for file in sorted(src.rglob("*")):
    if not file.is_file():
        continue
    rel = file.relative_to(src)
    digest = hashlib.sha256(file.read_bytes()).hexdigest()
    if hashlib.sha256((dst / rel).read_bytes()).hexdigest() != digest:
        raise RuntimeError(str(rel))
    rows.append({"path": rel.as_posix(), "bytes": file.stat().st_size, "sha256": digest})
(q / "compiled-baseline.json").write_text(json.dumps({"source": str(src), "files": rows}, indent=2)+"\n", encoding="utf-8", newline="\n")
print(json.dumps({"files": len(rows), "bytes": sum(r["bytes"] for r in rows), "copied": str(dst)}))
