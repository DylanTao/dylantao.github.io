import json
from pathlib import Path
import bpy

q=Path(__file__).parent
mesh=bpy.context.scene.objects['study__matte black device'].data
out=[]
for attr in mesh.attributes:
    if not len(attr.data):continue
    item=attr.data[0]
    row={'name':attr.name,'type':attr.data_type,'class':item.bl_rna.identifier,'properties':[]}
    for prop in item.bl_rna.properties:
        if prop.identifier=='rna_type':continue
        value=getattr(item,prop.identifier)
        row['properties'].append({'name':prop.identifier,'type':prop.type,'array':prop.array_length if getattr(prop,'is_array',False)else 0,'value':list(value)if getattr(prop,'is_array',False)else value})
    out.append(row)
(q/'attribute-probe.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out),flush=True)
