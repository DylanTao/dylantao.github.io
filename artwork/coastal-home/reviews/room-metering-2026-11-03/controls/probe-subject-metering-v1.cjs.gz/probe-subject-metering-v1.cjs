const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {chromium,expect}=require('@playwright/test');
const q=__dirname,out=path.join(q,'subject-metering-v1');if(fs.existsSync(out))throw Error('Fresh experiment required');fs.mkdirSync(out);
const server=JSON.parse(fs.readFileSync(path.join(q,'daylight-checkpoint-v4/server.json'))),root=process.cwd(),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const original=fs.readFileSync(path.join(root,'assets/js/home-scene/controller.mjs'),'utf8').replaceAll('\r\n','\n');
const before='const exposureGain = interiorExposure.update(staticLightField?.ambientAt(camera.position.toArray(exposurePoint)), frameDelta, {';
const after='const exposureRoom = !walkMode?.active && currentRoom !== "outside" ? config?.rooms.find((room) => room.id === currentRoom) : null;\n    const exposureMeterPoint = exposureRoom?.target ?? camera.position.toArray(exposurePoint);\n    const exposureGain = interiorExposure.update(staticLightField?.ambientAt(exposureMeterPoint), frameDelta, {';
if(!original.includes(before))throw Error('Exact source guard');
const prototype=original.replace(before,after).replace('interiorExposure: interiorExposure.evidence(),','interiorExposure: { ...interiorExposure.evidence(), meterPoint: (!walkMode?.active && currentRoom !== "outside" ? config?.rooms.find((room) => room.id === currentRoom)?.target : null) ?? camera.position.toArray() },');
fs.writeFileSync(path.join(out,'prototype-controller.mjs'),prototype);fs.writeFileSync(path.join(out,'SOURCE.json'),JSON.stringify({originalSha256:hash(original),prototypeSha256:hash(prototype),server,scope:'PRIVATE camera-metering experiment only. One raw controller response is substituted explicitly for candidate; all native models, official v5 transport, modules, source powers and shader paths otherwise unchanged. Does not claim owning cache provenance/publication or performance.'},null,2));
const rows=[],errors=[];
(async()=>{const browser=await chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']});try{
for(const variant of ['reference','subject']){
 const context=await browser.newContext({viewport:{width:1440,height:1000},deviceScaleFactor:1,timezoneId:'America/Los_Angeles',reducedMotion:'reduce',colorScheme:'light'}),p=await context.newPage();p.setDefaultTimeout(45000);await p.clock.setFixedTime(new Date('2026-11-03T12:00:00-08:00'));
 await p.route(/https:\/\/(?:analytics\.google\.com|www\.google-analytics\.com|www\.googletagmanager\.com|plausible\.io)\//,r=>r.fulfill({status:204,body:''}));let served=0;
 if(variant==='subject')await p.route(/\/assets\/js\/home-scene\/controller\.mjs(?:\?|$)/,r=>{served++;return r.fulfill({contentType:'text/javascript',body:prototype});});
 p.on('pageerror',e=>errors.push({variant,error:e.message}));p.on('console',m=>{if(m.type()==='error')errors.push({variant,error:m.text()});});
 await p.goto(server.url+'?quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});
 const theme=async mode=>{await p.locator('[data-theme-toggle]:visible').first().click();await p.locator(`[data-theme-mode-option="${mode}"]:visible`).first().click();await p.locator('[data-theme-toggle]:visible').first().click();};
 await theme('noon');await p.locator('[data-home-desk-mode="3d"]').click();const scene=p.locator('[data-home-desk-scene]'),canvas=scene.locator('canvas:not(.home-world-sketch)');await scene.scrollIntoViewIfNeeded();await expect(scene).toHaveAttribute('data-scene-state','ready',{timeout:180000});
 const state=()=>scene.evaluate(e=>e.getSceneEvidence());
 const settle=async()=>{let prior;for(let i=0;i<100;i++){const e=await state();if(prior&&!e.traveling&&Math.hypot(...e.camera.map((v,n)=>v-prior[n]))<1e-5)return e;prior=e.camera;await p.waitForTimeout(120);}throw Error('Camera not settled');};
 for(const period of ['noon','evening']){
  if(period==='evening'){await p.locator('[data-world-exit]').click();await theme(period);}
  for(const room of ['sleep','gym','study']){
   await p.locator('[data-world-places]>summary').click();await p.locator(`[data-world-destination="${room}"]`).click();await settle();if(!(await state()).fullscreen)await p.locator('[data-world-fullscreen]').click();const e=await settle();
   const b=await canvas.screenshot({path:path.join(out,variant+'-'+period+'-'+room+'.png')});rows.push({variant,period,room,evidence:e,pngSha256:hash(b),prototypeResponses:served});console.log(JSON.stringify({variant,period,room,exposure:e.simulation.interiorExposure}));
  }
 }
 if(variant==='subject')expect(served).toBe(1);await context.close();
}
fs.writeFileSync(path.join(out,'REPORT.json'),JSON.stringify({scope:'Source-bound private subject-metering comparison. Actual public room/theme/fullscreen controls; only disclosed controller candidate differs. Appearance investigation, not release, timing or physical-device acceptance.',rows,errors},null,2)+'\n');expect(errors).toEqual([]);
}finally{await browser.close();}})().catch(e=>{fs.writeFileSync(path.join(out,'FAILURE.json'),JSON.stringify({error:String(e),stack:e.stack,rows,errors},null,2));console.error(e);process.exitCode=1;});
