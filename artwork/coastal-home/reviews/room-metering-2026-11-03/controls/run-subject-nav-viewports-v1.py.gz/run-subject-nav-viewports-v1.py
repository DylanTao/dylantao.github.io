from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess,time
q=Path(__file__).parent;out=q/'subject-checkpoint-v1';wt=Path('C:/dev/dqa1103');config=q/'subject-nav-viewports-v1.config.cjs'
definition="const base=require('C:/dev/dqa1103/test/visual/public.config.js');module.exports={...base,workers:1,projects:base.projects.filter(p=>['laptop-1280','tablet-768','mobile-390'].includes(p.name)),outputDir:"+json.dumps(str(out/'nav-viewport-results'))+",reporter:[['line'],['html',{open:'never',outputFolder:"+json.dumps(str(out/'nav-viewport-report'))+"}]]};\n"
assert not config.exists();config.write_text(definition,encoding='utf8')
env=dict(os.environ,NO_WEBSERVER='1',VISUAL_BASE_URL=json.loads((out/'server.json').read_bytes())['url'].rstrip('/'),CI='1')
command=['C:/Program Files/nodejs/npx.cmd','playwright','test','--config',str(config),'test/visual/desk-scene.spec.js','--grep','public room navigation works'];start=time.monotonic()
with(out/'nav-viewports.log').open('wb')as log:r=subprocess.run(command,cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1000)
(out/'NAV-VIEWPORTS.json').write_text(json.dumps({'at':datetime.now(timezone.utc).isoformat(),'command':command,'seconds':time.monotonic()-start,'exitCode':r.returncode,'scope':'Additional laptop/tablet/mobile nativeChromium public room-subject→eye Walk metering cases. Desktop was already verified in preceding3-case run. Distinct outputs and HTML report preserve prior acceptance evidence.'},indent=2)+'\n',encoding='utf8');print(json.dumps({'exitCode':r.returncode,'seconds':time.monotonic()-start}));raise SystemExit(r.returncode)
