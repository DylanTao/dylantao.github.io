const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {pathToFileURL}=require('node:url');
const {chromium,expect}=require('@playwright/test');
const q=__dirname,kind=process.argv[2],preview=path.join(q,'subject-checkpoint-v1'),built=path.join(preview,'site/al-folio');
if(!['tour','sunset'].includes(kind))throw Error('Select tour or sunset');
const out=path.join(q,'subject-'+kind+'-v1');if(fs.existsSync(out))throw Error('Fresh evidence required');fs.mkdirSync(out);
const server=JSON.parse(fs.readFileSync(path.join(preview,'server.json'))),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const rows=[],errors=[],failed=[],responses=[];
const evidence=scene=>scene.evaluate(e=>e.getSceneEvidence());
async function settle(scene){let prior;for(let i=0;i<120;i++){const e=await evidence(scene);if(prior&&!e.traveling&&Math.hypot(...e.camera.map((v,n)=>v-prior[n]))<1e-5)return e;prior=e.camera;await scene.page().waitForTimeout(100);}throw Error('Camera not settled');}
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
 try{
  const context=await browser.newContext({viewport:{width:1440,height:1000},deviceScaleFactor:1,timezoneId:'America/Los_Angeles',locale:'en-US',colorScheme:'light',reducedMotion:'reduce'});
  const p=await context.newPage();p.setDefaultTimeout(45000);    await p.addInitScript(() => {
      const fetch = window.fetch.bind(window);
      window.__daylightStreamBodies = [];
      window.fetch = async (...args) => {
        const response = await fetch(...args);
        if (/\/(?:(?:home-shell|coast)\.glb|static-light-field\.json)(?:\?|$)/.test(response.url)) {
          const row = {url: response.url, status: response.status};
          window.__daylightStreamBodies.push(row);
          response.clone().arrayBuffer().then(async bytes => {
            row.bytes = bytes.byteLength;
            row.sha256 = [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(x => x.toString(16).padStart(2,'0')).join('');
          }).catch(e => row.error = String(e));
        }
        return response;
      };
    });
await p.clock.setFixedTime(new Date('2026-11-03T12:00:00-08:00'));
  await p.route(/https:\/\/(?:analytics\.google\.com|www\.google-analytics\.com|www\.googletagmanager\.com|plausible\.io)\//,r=>r.fulfill({status:204,body:''}));
  p.on('pageerror',e=>errors.push(e.message));p.on('console',m=>{if(m.type()==='error')errors.push(m.text());});p.on('requestfailed',r=>failed.push({url:r.url(),failure:r.failure()}));
  p.on('response',r=>{if(r.url().startsWith(server.url)&&/\.(?:mjs|glb|json)(?:\?|$)/.test(r.url()))responses.push({url:r.url(),status:r.status(),owner:r.headers()['x-sirui-preview']});});
  const modules=JSON.parse(fs.readFileSync(path.join(built,'assets/js/module-build.json'))).modules;expect(Object.keys(modules)).toHaveLength(192);
  for(const [rel,row]of Object.entries(modules)){expect(hash(fs.readFileSync(path.join('C:/dev/dqa1103',rel)))).toBe(row.sourceSha256);expect(hash(fs.readFileSync(path.join(built,rel)))).toBe(row.outputSha256);}
  await p.goto(server.url+'?quality=high&resolution=fixed'+(kind==='sunset'?'&scene-lab=1':''),{waitUntil:'domcontentloaded'});
  const theme=async mode=>{await p.locator('[data-theme-toggle]:visible').first().click();await p.locator(`[data-theme-mode-option="${mode}"]:visible`).first().click();await p.locator('[data-theme-toggle]:visible').first().click();};
  await theme('noon');await p.locator('[data-home-desk-mode="3d"]').click();
  const scene=p.locator('[data-home-desk-scene]'),canvas=scene.locator('canvas:not(.home-world-sketch)');await scene.scrollIntoViewIfNeeded();await expect(scene).toHaveAttribute('data-scene-state','ready',{timeout:180000});
  const capture=async label=>{const e=await settle(scene);expect(e.simulation.lightField.cacheHit).toBe(true);expect(e.simulation.lightField.maxDiffuseBounces).toBe(3);expect(e.simulation.interiorExposure.gain).toBeLessThanOrEqual(1.8);const b=await canvas.screenshot({path:path.join(out,label+'.png')});expect(b.length).toBeGreaterThan(30000);rows.push({label,evidence:e,pngSha256:hash(b)});fs.writeFileSync(path.join(out,'PROGRESS.json'),JSON.stringify(rows,null,2));console.log(JSON.stringify({label,room:e.currentRoom,exposure:e.simulation.interiorExposure,altitude:e.daylight.altitude}));};
  if(kind==='tour'){
   for(const period of ['noon','evening']){
    if(period==='evening'){await p.locator('[data-world-exit]').click();await theme(period);}
    for(const room of ['study','kitchen','gym','lounge','sleep','library']){
     await p.locator('[data-world-places]>summary').click();await p.locator(`[data-world-destination="${room}"]`).click();await settle(scene);
     if(!(await evidence(scene)).fullscreen)await p.locator('[data-world-fullscreen]').click();
     expect((await settle(scene)).currentRoom).toBe(room);await capture(period+'-'+room);
    }
   }
  }else{
   const {coastalDaylight}=await import(pathToFileURL(path.join(process.cwd(),'assets/js/home-scene/daylight.mjs')).href);
   let low=900,high=1080;for(let i=0;i<50;i++){const mid=(low+high)/2;if(coastalDaylight('2026-11-03',mid).altitude>-.833)low=mid;else high=mid;}const sunset=(low+high)/2;
   const d=coastalDaylight('2026-11-03',sunset).direction,length=Math.hypot(d[0],d[2]),position=[3,1.5,-36],target=[position[0]+d[0]/length*60,position[1]+1,position[2]+d[2]/length*60],delta=position.map((v,n)=>v-target[n]);
   const orbit={target,yaw:Math.atan2(delta[0],delta[2]),pitch:Math.atan2(delta[1],Math.hypot(delta[0],delta[2])),radius:Math.hypot(...delta),free:true};
   await p.locator('[data-world-fullscreen]').click();
   await scene.evaluate(e=>e.labScene&&e.setLabCamera({target:[3,1.5,-70],yaw:.02,pitch:.06,radius:34,free:true}));
   const lab=p.locator('[data-world-lab]');await lab.locator('summary').first().click();await p.locator('[data-world-room="outside"]').click();
   for(const offset of [-35,-15,-4,0,4,15,35]){
    const minute=Math.round(sunset+offset);await p.locator('[data-world-time]').evaluate((input,minute)=>{input.value=String(minute);input.dispatchEvent(new Event('input',{bubbles:true}));},minute);
    await scene.evaluate((e,pose)=>e.setLabCamera(pose),orbit);await canvas.scrollIntoViewIfNeeded();
    if(await lab.getAttribute('open')!==null)await lab.locator('summary').first().click();
    await capture('sunset-'+(offset<0?'before'+(-offset):'after'+offset)+'-'+minute);
    rows.at(-1).sunsetReferenceMinute=sunset;rows.at(-1).fixtureOrbit=orbit;
    
   }
   expect(rows[0].evidence.ecology.atmosphere.sun.discTop).toBeGreaterThan(0);expect(rows.at(-1).evidence.ecology.atmosphere.sun.discTop).toBeLessThan(0);
   const heights=rows.map(r=>r.evidence.ecology.atmosphere.sun.trueElevation);expect(heights.every((h,i)=>i===0||h<heights[i-1])).toBe(true);
  }
  const backend=await canvas.evaluate(c=>{const g=c.getContext('webgl2'),e=g.getExtension('WEBGL_debug_renderer_info');return{renderer:g.getParameter(e.UNMASKED_RENDERER_WEBGL),buffer:[g.drawingBufferWidth,g.drawingBufferHeight]};});
  fs.writeFileSync(path.join(out,'REPORT.json'),JSON.stringify({at:new Date().toISOString(),kind,server,browser:browser.version(),backend,scope:kind==='tour'?'Complete final subject-metering production, without prototype response substitution. Actual public theme/Rooms/fullscreen controls, all six authored room cameras by day and evening. No model/module substitution. Native high/fixed detail; no timing or physical-phone claim.':'Complete final daylight production. Clearly disclosed authoring-clock input events (not a visible range-control usability check) and fixed seaward camera fixture at Nov3LaJolla, genuine sun/atmosphere/weather/sea; no palette, model or module substitution. Camera is offshore to isolate the visible sunset; this does not establish a seated interior view or new astronomy physics.',rows,errors,failed,responses},null,2)+'\n');
  const streamed=await p.evaluate(()=>window.__daylightStreamBodies);
  for(const row of streamed){const rel=decodeURIComponent(new URL(row.url).pathname.slice(new URL(server.url).pathname.length)),body=fs.readFileSync(path.join(built,rel));expect(row.status).toBe(200);expect(row.bytes).toBe(body.length);expect(row.sha256).toBe(hash(body));expect(row.error).toBeUndefined();}
  const delivered=url=>streamed.some(row=>row.url===url&&row.sha256&&!row.error&&rows.every(view=>/static-light-field\.json/.test(url)?view.evidence.simulation.lightField.cacheHit&&view.evidence.loading.lightCache.url===url:view.evidence.loading.models.some(model=>model.asset===new URL(url).pathname.split('/').pop()&&model.bytes===row.bytes&&model.parsedMilliseconds>0)));
  const qualifiedProtocolLoss=failed.filter(row=>row.failure?.errorText==='net::ERR_ABORTED'&&delivered(row.url));
  fs.writeFileSync(path.join(out,'STREAM-READBACK.json'),JSON.stringify({scope:'Original fetch responses returned untouched; independent response-clone hashes for exactly three streamed resources. Every allowed protocol abort requires exact complete bytes and actual parsed/restored consumption. No timing claim.',streamed,qualifiedProtocolLoss},null,2)+'\n');
  expect(errors).toEqual([]);expect(failed.filter(row=>!qualifiedProtocolLoss.includes(row))).toEqual([]);expect(responses.filter(r=>r.status>=400||r.owner!==server.header)).toEqual([]);
  await context.close();
 }finally{await browser.close();}
})().catch(e=>{fs.writeFileSync(path.join(out,'FAILURE.json'),JSON.stringify({error:String(e),stack:e.stack,rows,errors,failed,responses},null,2)+'\n');console.error(e);process.exitCode=1;});
