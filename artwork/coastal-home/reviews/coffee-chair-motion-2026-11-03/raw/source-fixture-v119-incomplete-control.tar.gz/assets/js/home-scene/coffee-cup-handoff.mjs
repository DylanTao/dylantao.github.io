import * as THREE from "../three.module.min.js";

const names = ["Hips", "Spine", "Head", "ArmL", "ForearmL", "HandL", "ArmR", "ForearmR", "HandR", "ThighL", "ShinL", "FootL", "ThighR", "ShinR", "FootR"];
const actorJoints = new WeakMap();
const duration = 0.8;
const frames = new WeakSet();
const ease = (value) => {
  const t = Math.max(0, Math.min(1, value));
  return t * t * (3 - 2 * t);
};

function snapshot(actor) {
  let bones = actorJoints.get(actor);
  actor.updateWorldMatrix(true, true);
  if (!bones) { bones = new Map(); actor.traverse((bone) => {
    if (!bone.isBone) return;
    const name = bone.name.replaceAll(".", "");
    if (names.includes(name)) bones.set(name, bone);
  }); actorJoints.set(actor,bones); }
  if (bones.size !== names.length) return null;
  const pose = {
    actor,
    root: actor.getWorldPosition(new THREE.Vector3()),
    joints: names.map((name) => {
      const bone = bones.get(name);
      return { bone, position: bone.getWorldPosition(new THREE.Vector3()), rotation: bone.getWorldQuaternion(new THREE.Quaternion()).normalize() };
    }),
  };
  return pose.root.toArray().every(Number.isFinite) &&
    pose.joints.every(({ position, rotation }) => [...position.toArray(), ...rotation.toArray()].every(Number.isFinite))
    ? pose
    : null;
}

// The fixed outgoing pose follows root translation while the new clip and the
// owning meal solve take over. Fingers, scales and every non-Hips local position
// remain animated. World rotations retain a continuous elbow plane as well as
// the wrist; independently blending just the wrist can flip an elbow.
export function blendCoffeeCupPose(actor, frame) {
  if (!frame || !frames.has(frame) || frame.from.actor !== actor) return false;
  // The incoming transfer retains the outgoing authored clip and uses the
  // same continuous, actor-relative carry grip. A second world-frozen handoff
  // would drag the cup across the turning body and delay the planted hips.
  if (frame.handMotion?.bodyFromSampler) {
    frame.handFit = { source: "authored transfer and continuous carry grip" };
    return true;
  }
  const offset = actor.getWorldPosition(new THREE.Vector3()).sub(frame.from.root);
  const goals = frame.from.joints.map(({ bone }) => ({
    bone,
    localPosition:bone.position.clone(),localRotation:bone.quaternion.clone(),
    position: bone.getWorldPosition(new THREE.Vector3()),
    rotation: bone.getWorldQuaternion(new THREE.Quaternion()).normalize(),
  }));
  const failed=reason=>{
    for(const{bone,localPosition,localRotation}of goals){bone.position.copy(localPosition);bone.quaternion.copy(localRotation);}
    actor.updateWorldMatrix(true,true);frame.handFit={failed:reason};return false;
  };
  for (let i = 0; i < goals.length; i++) {
    const { bone, position, rotation } = goals[i],
      from = frame.from.joints[i];
    if (!bone.parent) return false;
    if (bone.name === "Hips") bone.position.copy(bone.parent.worldToLocal(from.position.clone().add(offset).lerp(position, frame.blend)));
    const wanted = from.rotation.clone().slerp(rotation, frame.blend);
    bone.parent.updateWorldMatrix(true, false);
    const parent = bone.parent.getWorldQuaternion(new THREE.Quaternion()).normalize(),
      inverse = parent.clone().invert();
    bone.quaternion.copy(inverse.clone().multiply(wanted)).normalize();
    bone.updateWorldMatrix(false, true);
    for (let pass = 0; pass < 2; pass++) {
      const actual = bone.getWorldQuaternion(new THREE.Quaternion()).normalize(),
        correction = wanted.clone().multiply(actual.invert());
      bone.quaternion.premultiply(inverse.clone().multiply(correction).multiply(parent)).normalize();
      bone.updateWorldMatrix(false, true);
    }
  }
  actor.updateWorldMatrix(true, true);
  if(frame.handMotion){
    const byName=new Map(goals.map((goal,i)=>[goal.bone.name.replaceAll(".",""),{goal,from:frame.from.joints[i]}])),
      fit=[];
    const aim=(bone,child,target)=>{
      const origin=bone.getWorldPosition(new THREE.Vector3()),direction=child.getWorldPosition(new THREE.Vector3()).sub(origin).normalize(),
        wanted=target.clone().sub(origin).normalize(),world=new THREE.Quaternion().setFromUnitVectors(direction,wanted)
          .multiply(bone.getWorldQuaternion(new THREE.Quaternion())),parent=bone.parent.getWorldQuaternion(new THREE.Quaternion()).invert();
      bone.quaternion.copy(parent.multiply(world)).normalize();actor.updateWorldMatrix(true,true);
    };
    for(const [i,side]of["L","R"].entries()){
      const upper=byName.get("Arm"+side),lower=byName.get("Forearm"+side),hand=byName.get("Hand"+side);
      if(!upper||!lower||!hand)return failed("missing arm chain");
      const shoulder=upper.goal.bone.getWorldPosition(new THREE.Vector3()),elbow=lower.goal.bone.getWorldPosition(new THREE.Vector3()),
        wrist=hand.goal.bone.getWorldPosition(new THREE.Vector3()),l1=shoulder.distanceTo(elbow),l2=elbow.distanceTo(wrist),
        goal=hand.from.position.clone().add(offset).lerp(hand.goal.position,frame.blend),
        elbowAt=lower.from.position.clone().add(offset).lerp(lower.goal.position,frame.blend);
      goal.y+=frame.handMotion.lift[i]*Math.sin(Math.PI*frame.blend);
      const direction=goal.clone().sub(shoulder),asked=direction.length(),
        distance=Math.max(Math.abs(l1-l2)+1e-7,Math.min(asked,l1+l2-1e-7));
      if(!(l1>1e-5&&l2>1e-5&&asked>1e-5))return failed("invalid arm lengths");
      direction.normalize();
      const along=(l1*l1-l2*l2+distance*distance)/(2*distance),height=Math.sqrt(Math.max(0,l1*l1-along*along)),
        pole=elbowAt.sub(shoulder);
      pole.addScaledVector(direction,-pole.dot(direction));
      if(pole.lengthSq()<1e-12)return failed("degenerate elbow plane");
      pole.normalize();
      const knee=shoulder.clone().addScaledVector(direction,along).addScaledVector(pole,height),target=shoulder.clone().addScaledVector(direction,distance);
      aim(upper.goal.bone,lower.goal.bone,knee);aim(lower.goal.bone,hand.goal.bone,target);
      const wanted=hand.from.rotation.clone().slerp(hand.goal.rotation,frame.blend),parent=hand.goal.bone.parent.getWorldQuaternion(new THREE.Quaternion()).invert();
      hand.goal.bone.quaternion.copy(parent.multiply(wanted)).normalize();actor.updateWorldMatrix(true,true);
      fit.push({side,wrist:hand.goal.bone.getWorldPosition(new THREE.Vector3()).toArray(),target:goal.toArray(),
        drift:hand.goal.bone.getWorldPosition(new THREE.Vector3()).distanceTo(goal),reachViolation:Math.max(0,asked-distance)});
    }
    frame.handFit=fit;
  }
  return true;
}

// Coffee's authored seated transfers keep the outgoing clip while its idle /
// drink mixture takes over. Resetting all bindings every frame would expose a
// bind pose on exit and abruptly switch the unowned fingers and native tail.
export function createCoffeeTransferMixer(actor,mixer,actions){
  if(!actor?.isObject3D||mixer?.getRoot?.()!==actor||!(actions instanceof Map)||!actions.has("idle")||!actions.has("drink"))return null;
  const idle=actions.get("idle"),drink=actions.get("drink");
  let state=null,saved=null;
  const restore=()=>{
    if(!saved)return;
    saved.hips.quaternion.copy(saved.hipRotation);saved.spine.quaternion.copy(saved.spineRotation);
    saved=null;actor.updateWorldMatrix(true,true);
  };
  const finish=()=>{
    restore();if(!state)return null;
    const dominant=state.dominant;
    state.outgoing.stop();mixer.uncacheClip(state.clip);
    for(const action of[idle,drink])if(action!==dominant)action.stop();
    if(dominant)dominant.setEffectiveWeight(1);
    state=null;return dominant;
  };
  return{
    restore,
    finish,
    reset:finish,
    dispose:finish,
    pose({blend,seconds,fromAction,pelvisPitch=0,spinePitch=0}={}){
      if(blend?.from!=="idle"||blend.to!=="drink"||!Number.isFinite(blend.weight)||blend.weight<0||blend.weight>1||
        !Number.isFinite(seconds)||seconds<0||!Number.isFinite(pelvisPitch)||Math.abs(pelvisPitch)>.65||
        !Number.isFinite(spinePitch)||Math.abs(spinePitch)>.65)return null;
      restore();
      if(!state){
        if(!fromAction?.getClip)return null;
        const clip=fromAction.getClip().clone(),time=fromAction.time;
        mixer.stopAllAction();
        const outgoing=mixer.clipAction(clip).reset().play().setEffectiveTimeScale(0);outgoing.time=time;
        idle.reset().play().setEffectiveTimeScale(0);drink.reset().play().setEffectiveTimeScale(0);
        state={clip,outgoing,time,start:seconds,dominant:fromAction};
      }
      const progress=ease((seconds-state.start)/.45);
      state.progress=progress;
      state.outgoing.setEffectiveWeight(1-progress);state.outgoing.time=state.time;
      idle.setEffectiveWeight(progress*(1-blend.weight));drink.setEffectiveWeight(progress*blend.weight);
      idle.time=drink.time=0;mixer.update(0);
      state.dominant=blend.weight<.5?idle:drink;
      const hips=actor.getObjectByName("Hips"),spine=actor.getObjectByName("Spine");
      if(hips&&spine){
        actor.updateWorldMatrix(true,true);
        saved={hips,spine,hipRotation:hips.quaternion.clone(),spineRotation:spine.quaternion.clone()};
        const upper=spine.getWorldQuaternion(new THREE.Quaternion()),axis=new THREE.Vector3(1,0,0).applyQuaternion(actor.quaternion);
        hips.quaternion.multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1,0,0),pelvisPitch));
        actor.updateWorldMatrix(true,true);
        upper.premultiply(new THREE.Quaternion().setFromAxisAngle(axis,spinePitch));
        spine.quaternion.copy(spine.parent.getWorldQuaternion(new THREE.Quaternion()).invert().multiply(upper)).normalize();
        actor.updateWorldMatrix(true,true);
      }
      return state.dominant;
    },
    evidence:()=>state?{progress:state.progress,outgoing:state.clip.name,target:state.dominant===idle?"idle":"drink"}:null,
  };
}

export function createCoffeeCupHandoff() {
  let identity = null,
    previous = null,
    transition = null,
    saved = null,
    last = null;
  const restore = () => {
    if (!saved) return;
    for (const { bone, position, rotation } of saved.joints) {
      bone.position.copy(position);
      bone.quaternion.copy(rotation);
    }
    saved.actor.updateWorldMatrix(true, true);
    saved = null;
  };
  const reset = () => {
    restore();
    identity = previous = transition = last = null;
  };
  return {
    restore,
    reset,
    begin({ actor, key, mode, seconds, active = false, paused = false, handoffLift } = {}) {
      if (
        !active ||
        !actor?.isObject3D ||
        typeof key !== "string" ||
        key.length > 192 ||
        !["other", "carry", "seated", "depart", "transfer-in", "transfer-out"].includes(mode) ||
        !Number.isFinite(seconds) ||
        seconds < 0
      ) {
        reset();
        return null;
      }
      if (identity?.actor !== actor || identity?.key !== key || (previous && seconds < previous.seconds)) {
        reset();
        identity = { actor, key };
      }
      if (paused) return last;
      if (previous?.mode !== mode && previous?.pose && transition?.mode !== mode) {
        const kind =
          ["carry","transfer-in"].includes(previous.mode) && mode === "seated" ? "arrival" :
          (previous.mode === "seated" && ["depart", "carry", "transfer-out"].includes(mode)) ||
          (previous.mode === "carry" && mode === "transfer-in") ||
          (previous.mode === "transfer-out" && ["carry","depart"].includes(mode)) ||
          (previous.mode === "other" && mode === "carry") ? "departure" : null;
        transition = kind ? { from: previous.pose, kind, mode, start: seconds, sourceMode:previous.mode } : null;
      }
      if (!transition || transition.mode !== mode || seconds - transition.start >= duration) return (last = null);
      last = {
        from: transition.from,
        kind: transition.kind,
        seconds: seconds - transition.start,
        blend: ease((seconds - transition.start) / duration),
        ...(((["seated","transfer-in","transfer-out"].includes(mode))||["seated","transfer-in","transfer-out"].includes(transition.sourceMode))&&
          Array.isArray(handoffLift)&&handoffLift.length===2&&handoffLift.every(v=>Number.isFinite(v)&&v>=0&&v<=.12)
          ?{handMotion:{lift:[...handoffLift],bodyFromSampler:transition.sourceMode==="carry"&&mode==="transfer-in"}}:{}),
      };
      frames.add(last);
      return last;
    },
    apply(actor, frame) {
      if (!frame || !frames.has(frame) || frame.from.actor !== actor) return false;
      saved = {
        actor,
        joints: frame.from.joints.map(({ bone }) => ({ bone, position: bone.position.clone(), rotation: bone.quaternion.clone() })),
      };
      return blendCoffeeCupPose(actor, frame);
    },
    remember({ actor, key, mode, seconds, active = false, paused = false } = {}) {
      if (
        paused ||
        !active ||
        identity?.actor !== actor ||
        identity?.key !== key ||
        !["other", "carry", "seated", "depart", "transfer-in", "transfer-out"].includes(mode) ||
        !Number.isFinite(seconds) ||
        seconds < 0
      )
        return;
      previous = { mode, seconds, pose: snapshot(actor) };
    },
    evidence() {
      return last ? { kind: last.kind, seconds: last.seconds, blend: last.blend, duration, joints: names.slice(),
        ...(last.handFit?{hands:last.handFit}:{}) } : null;
    },
  };
}
