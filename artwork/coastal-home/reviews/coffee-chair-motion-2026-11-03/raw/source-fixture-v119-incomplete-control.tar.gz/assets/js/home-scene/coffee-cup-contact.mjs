import * as THREE from "../three.module.min.js";

const validPoint = (value) => Array.isArray(value) && value.length === 3 && value.every(Number.isFinite);
const validQuaternion = (value) =>
  Array.isArray(value) && value.length === 4 && value.every(Number.isFinite) && Math.abs(Math.hypot(...value) - 1) <= 1e-4;
const allowed = new Set([
  "wristOffsetWorld",
  "palmWorldQuaternion",
  "originInHand",
  "rotationInHand",
  "carryWristLocal",
  "releaseWristLocal",
  "releaseZ",
  "elbowPoleActor",
  "drawWorld",
  "seatedCarryDrop",
  "handoffLift",
  "stationCarryWristLocal",
  "stationCarryRoot",
  "stationCarryDistance",
]);
const stationFields = ["stationCarryWristLocal", "stationCarryRoot", "stationCarryDistance"];
function validStationCarry(value) {
  if (stationFields.every(key => value[key] === undefined)) return true;
  const p = value.stationCarryWristLocal, root = value.stationCarryRoot, distance = value.stationCarryDistance;
  return validPoint(p) && p[0] >= 0 && p[0] <= .4 && p[1] >= .85 && p[1] <= 1.25 && p[2] >= .08 && p[2] <= .3 &&
    validPoint(root) && root[0] >= -3.8 && root[0] <= -3.2 && Math.abs(root[1]) <= .02 && root[2] >= 7.2 && root[2] <= 7.8 &&
    Array.isArray(distance) && distance.length === 2 && distance.every(Number.isFinite) &&
    distance[0] >= .2 && distance[0] <= .4 && distance[1] >= .8 && distance[1] <= 1.2 && distance[1] - distance[0] >= .4;
}
const cache = new WeakMap();
const verified = new WeakSet();
const up = new THREE.Vector3(0, 1, 0);
const ease = (value) => {
  const u = Math.max(0, Math.min(1, value));
  return u * u * (3 - 2 * u);
};

function validGrip(value) {
  if (
    !value ||
    typeof value !== "object" ||
    Array.isArray(value) ||
    Object.keys(value).some((key) => !allowed.has(key)) ||
    !["wristOffsetWorld", "originInHand", "carryWristLocal", "releaseWristLocal", "elbowPoleActor", "drawWorld"].every((key) =>
      validPoint(value[key])
    ) ||
    !validStationCarry(value) ||
    !validQuaternion(value.palmWorldQuaternion) ||
    !validQuaternion(value.rotationInHand) ||
    Math.hypot(...value.wristOffsetWorld) > 0.25 ||
    Math.hypot(...value.originInHand) > 0.25 ||
    value.carryWristLocal[0] < 0 ||
    value.carryWristLocal[0] > 0.4 ||
    value.carryWristLocal[1] < 0.85 ||
    value.carryWristLocal[1] > 1.25 ||
    value.carryWristLocal[2] < 0.08 ||
    value.carryWristLocal[2] > 0.3 ||
    (value.seatedCarryDrop !== undefined && (!Number.isFinite(value.seatedCarryDrop) || value.seatedCarryDrop < 0 || value.seatedCarryDrop > .32)) ||
    (value.handoffLift !== undefined && (!Array.isArray(value.handoffLift) || value.handoffLift.length !== 2 ||
      value.handoffLift.some(v=>!Number.isFinite(v)||v<0||v>.12))) ||
    value.releaseWristLocal[0] < 0.08 ||
    value.releaseWristLocal[0] > 0.35 ||
    value.releaseWristLocal[1] < 0.65 ||
    value.releaseWristLocal[1] > 1.05 ||
    value.releaseWristLocal[2] < -0.12 ||
    value.releaseWristLocal[2] > 0.22 ||
    !Array.isArray(value.releaseZ) ||
    value.releaseZ.length !== 2 ||
    !value.releaseZ.every(Number.isFinite) ||
    value.releaseZ[0] < 5.2 ||
    value.releaseZ[0] > 6 ||
    value.releaseZ[1] < 6 ||
    value.releaseZ[1] > 6.6 ||
    value.releaseZ[1] - value.releaseZ[0] < 0.4 ||
    value.releaseZ[1] - value.releaseZ[0] > 1.2 ||
    Math.abs(Math.hypot(...value.elbowPoleActor) - 1) > 1e-4 ||
    value.elbowPoleActor[1] > -0.5 ||
    value.drawWorld[0] < 0.08 ||
    value.drawWorld[0] > 0.2 ||
    value.drawWorld[1] < 0 ||
    value.drawWorld[1] > 0.012 ||
    value.drawWorld[2] < -0.2 ||
    value.drawWorld[2] > 0.2 ||
    Math.hypot(...value.drawWorld) > 0.25
  )
    return false;
  const palm = new THREE.Quaternion(...value.palmWorldQuaternion).normalize(),
    held = new THREE.Quaternion(...value.rotationInHand).normalize();
  return (
    new THREE.Vector3(...value.originInHand)
      .applyQuaternion(palm)
      .add(new THREE.Vector3(...value.wristOffsetWorld))
      .length() <= 1e-6 && Math.abs(palm.multiply(held).w) >= 1 - 1e-10
  );
}
const acceptedGrip = (grip) => Boolean(grip && (verified.has(grip) || validGrip(grip)));

// Each optional frame is measured against the delivered cup and hand. Missing,
// unknown and malformed entries preserve the old coffee/cup path exactly.
export function coffeeCupGrip(coffee, avatarId) {
  if (!coffee || typeof coffee !== "object" || !validPoint(coffee.cup) || !Number.isFinite(coffee.facing)) return null;
  let frames = cache.get(coffee);
  if (!frames) {
    frames = new Map();
    const metadata = coffee.cupAttachments;
    if (metadata && typeof metadata === "object" && !Array.isArray(metadata)) {
      for (const [id, value] of Object.entries(metadata)) {
        if (!/^[a-z0-9-]{1,64}$/.test(id) || !validGrip(value)) continue;
        const palm = new THREE.Quaternion(...value.palmWorldQuaternion).normalize(),
          held = new THREE.Quaternion(...value.rotationInHand).normalize();
        const residual = new THREE.Vector3(...value.originInHand).applyQuaternion(palm).add(new THREE.Vector3(...value.wristOffsetWorld));
        if (residual.length() > 1e-6 || Math.abs(palm.clone().multiply(held).w) < 1 - 1e-10) continue;
        const result = Object.fromEntries(Object.entries(value).map(([key, value]) => [key, Array.isArray(value) ? Object.freeze([...value]) : value]));
        result.palmWorldQuaternion = Object.freeze(palm.toArray());
        result.rotationInHand = Object.freeze(held.toArray());
        Object.freeze(result);
        verified.add(result);
        frames.set(id, result);
      }
    }
    cache.set(coffee, frames);
  }
  return frames.get(avatarId) || null;
}

// The two-second pickup and three-second return keep their original ownership
// instants (1s and2.5s). A small lift clears the original saucer under the group
// head, then a short draw clears the handle before the higher tucked carry.
export function coffeeCupContactPose(coffee, state, actorPosition, actorYaw, authoredPalm) {
  const grip = state?.grip;
  if (
    !acceptedGrip(grip) ||
    !["pickup", "carry", "setdown", "release"].includes(state.mode) ||
    Object.keys(state).some((key) => !["mode", "seconds", "grip", "seatedWeight"].includes(key)) ||
    (state.seatedWeight !== undefined && (state.mode !== "carry" || grip.seatedCarryDrop === undefined ||
      !Number.isFinite(state.seatedWeight) || state.seatedWeight < 0 || state.seatedWeight > 1)) ||
    (state.seconds !== undefined && !Number.isFinite(state.seconds)) ||
    (state.mode !== "carry" && !Number.isFinite(state.seconds)) ||
    !validPoint(coffee?.cup) ||
    !Number.isFinite(coffee?.facing) ||
    !validPoint(actorPosition) ||
    !Number.isFinite(actorYaw)
  )
    return null;
  const counter = new THREE.Vector3(...coffee.cup).add(new THREE.Vector3(...grip.wristOffsetWorld));
  const counterQ = new THREE.Quaternion(...grip.palmWorldQuaternion);
  const carry = new THREE.Vector3(...grip.carryWristLocal);
  if (grip.stationCarryWristLocal) {
    const distance = new THREE.Vector3(...actorPosition).distanceTo(new THREE.Vector3(...grip.stationCarryRoot));
    const weight = ease((distance - grip.stationCarryDistance[0]) / (grip.stationCarryDistance[1] - grip.stationCarryDistance[0]));
    carry.copy(new THREE.Vector3(...grip.stationCarryWristLocal).lerp(carry, weight));
  }
  if(state.seatedWeight !== undefined)carry.y-=grip.seatedCarryDrop*state.seatedWeight;
  carry.applyAxisAngle(up, actorYaw).add(new THREE.Vector3(...actorPosition));
  const carryQ = new THREE.Quaternion().setFromAxisAngle(up, actorYaw - coffee.facing).multiply(counterQ);
  const lift = counter.clone().add(new THREE.Vector3(0, grip.drawWorld[1], 0));
  const drawX = counter.clone().add(new THREE.Vector3(...grip.drawWorld));
  const raised = drawX.clone().setY(carry.y);
  let wrist = carry,
    palm = carryQ,
    weight = 1;
  const segment = (a, b, from, to, age) => a.clone().lerp(b, ease((age - from) / (to - from)));
  if (state.mode === "pickup") {
    const age = Math.max(0, Math.min(2, Number(state.seconds) || 0));
    palm = counterQ;
    if (age < 0.4) {
      wrist = drawX;
      weight = ease(age / 0.4);
    } else if (age < 1) wrist = segment(drawX, counter, 0.4, 1, age);
    else if (age < 1.1) wrist = segment(counter, lift, 1, 1.1, age);
    else {
      wrist =
        age < 1.4 ? segment(lift, drawX, 1.1, 1.4, age) : age < 1.8 ? segment(drawX, raised, 1.4, 1.8, age) : segment(raised, carry, 1.8, 2, age);
      palm = counterQ.clone().slerp(carryQ, ease((age - 1.1) / 0.9));
    }
  } else if (state.mode === "setdown") {
    const age = Math.max(0, Math.min(3, Number(state.seconds) || 0));
    if (age < 2.4) {
      wrist =
        age < 0.7 ? segment(carry, raised, 0, 0.7, age) : age < 1.6 ? segment(raised, drawX, 0.7, 1.6, age) : segment(drawX, lift, 1.6, 2.4, age);
      palm = carryQ.clone().slerp(counterQ, ease(age / 0.6));
    } else {
      wrist = segment(lift, counter, 2.4, 2.5, age);
      palm = counterQ;
      if (age >= 2.5) wrist = segment(counter, drawX, 2.5, 3, age);
    }
  } else if (state.mode === "release") {
    const age = Math.max(0, Math.min(4, state.seconds));
    const rest = new THREE.Vector3(...grip.releaseWristLocal).applyAxisAngle(up, actorYaw).add(new THREE.Vector3(...actorPosition));
    weight = ease((actorPosition[2] - grip.releaseZ[0]) / (grip.releaseZ[1] - grip.releaseZ[0]));
    const lower = ease((grip.releaseZ[1] + .8 - actorPosition[2]) / .6);
    const away = carry.clone().lerp(rest, lower);
    wrist = segment(drawX, away, 0, .6, age);
    const freePalm = validQuaternion(authoredPalm) ? new THREE.Quaternion(...authoredPalm).normalize() : carryQ;
    palm = counterQ.clone().slerp(carryQ.clone().slerp(freePalm, 1-weight), ease(age/.6));
  }
  return {
    wrist: wrist.toArray(),
    palm: palm.toArray(),
    pole: new THREE.Vector3(...grip.elbowPoleActor).applyAxisAngle(up, actorYaw).normalize().toArray(),
    weight,
    grip,
  };
}

// Same palm-relative matrix convention as dining's vessels, with this native
// cup's measured origin. The entire original cup follows the final hand rigidly.
export function coffeeCupWorldFrame(grip, handPosition, handQuaternion) {
  if (!acceptedGrip(grip) || !validPoint(handPosition) || !validQuaternion(handQuaternion)) return null;
  const palm = new THREE.Quaternion(...handQuaternion).normalize();
  return {
    position: new THREE.Vector3(...grip.originInHand)
      .applyQuaternion(palm)
      .add(new THREE.Vector3(...handPosition))
      .toArray(),
    quaternion: palm
      .multiply(new THREE.Quaternion(...grip.rotationInHand))
      .normalize()
      .toArray(),
  };
}
