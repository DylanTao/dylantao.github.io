import * as THREE from "../three.module.min.js";
import { coffeeCupGrip } from "./coffee-cup-contact.mjs";
import { coffeeVenue, coffeeVenueSeat, coffeeVenueFeet, coffeeVenueApproach } from "./coffee-venue.mjs";
const ease = (t) => {
  t = Math.max(0, Math.min(1, t));
  return t * t * (3 - 2 * t);
};
const mix = (a, b, t) => a.map((v, i) => v + (b[i] - v) * ease(t));
const leg = (a, b, t) => ({ position: mix(a, b, t), facing: Math.atan2(b[0] - a[0], b[2] - a[2]), clip: "walk" });

// Breakfast is one story per visit (Sirui, 2026-10-24: the old 100-second loop made coffee again
// and again): sit, make the coffee, carry it to the nook, drink at its setting, eat breakfast
// with it (dining.mjs), take the cup back to the bar and sit on with the view. Seconds from arrival.
export const COFFEE_TIMELINE = Object.freeze({ table: 39, food: 64, foodEnd: 254, back: 275 });
const coffeeWalkPlans = new WeakMap();
const coffeeLegacyDurations = Object.freeze({ approach: 6, carry: 8, returnCup: 9, return: 9 });
const point3 = (point) => Array.isArray(point) && point.length === 3 && point.every(Number.isFinite);
const nearPoint = (a, b) => point3(a) && Math.hypot(...a.map((v, i) => v - b[i])) < 1e-6;
const quaternion4 = (q) => Array.isArray(q) && q.length === 4 && q.every(Number.isFinite) && Math.abs(Math.hypot(...q) - 1) <= 1e-4;
const record = (value) => value && typeof value === "object" && !Array.isArray(value);

function coffeeStationGrips(value) {
  if (!record(value) || Object.keys(value).some((phase) => !["grind", "prepare"].includes(phase))) return null;
  const result = {};
  for (const [phase, avatars] of Object.entries(value)) {
    if (!record(avatars)) return null;
    result[phase] = {};
    for (const [avatar, grip] of Object.entries(avatars)) {
      if (
        !/^[a-z0-9-]{1,64}$/.test(avatar) ||
        !record(grip) ||
        Object.keys(grip).some((key) => !["wristOffsetWorld", "palmWorldQuaternion"].includes(key)) ||
        !point3(grip.wristOffsetWorld) ||
        Math.hypot(...grip.wristOffsetWorld) > 0.25 ||
        !quaternion4(grip.palmWorldQuaternion)
      )
        return null;
      const norm = Math.hypot(...grip.palmWorldQuaternion);
      result[phase][avatar] = Object.freeze({
        wristOffsetWorld: Object.freeze([...grip.wristOffsetWorld]),
        palmWorldQuaternion: Object.freeze(grip.palmWorldQuaternion.map((v) => v / norm)),
      });
    }
    Object.freeze(result[phase]);
  }
  return Object.freeze(result);
}

function coffeeContactMotion(value) {
  if (
    !record(value) ||
    Object.keys(value).some((key) => !["reachSeconds", "releaseSeconds", "settleSeconds", "withdrawWorld", "turnSeconds"].includes(key)) ||
    !["reachSeconds", "releaseSeconds"].every((key) => Number.isFinite(value[key]) && value[key] >= 0.8 && value[key] <= 1.8) ||
    !Number.isFinite(value.settleSeconds) ||
    value.settleSeconds < 0.2 ||
    value.settleSeconds > 0.5 ||
    value.reachSeconds < value.settleSeconds + 0.2 ||
    value.releaseSeconds < value.settleSeconds + 0.45 ||
    value.reachSeconds + value.releaseSeconds > 4.5 ||
    !Number.isFinite(value.turnSeconds) ||
    value.turnSeconds < 0.3 ||
    value.turnSeconds > 1 ||
    !point3(value.withdrawWorld) ||
    value.withdrawWorld[0] < 0.1 ||
    value.withdrawWorld[0] > 0.25 ||
    value.withdrawWorld[1] !== 0 ||
    value.withdrawWorld[2] !== 0
  )
    return null;
  return Object.freeze({ ...value, withdrawWorld: Object.freeze([...value.withdrawWorld]) });
}

export function coffeeSeatedPhase(value) {
  return typeof value === "string" && value.length <= 64 && value.trim() === value && /^[\p{L}\p{N}][\p{L}\p{N} ,.'’–-]*$/u.test(value)
    ? value
    : "coffee by the ocean";
}

function coffeeAvatarStances(value) {
  const known = new Set(["lizard", "south-park", "simpsons", "ghibli"]);
  if (!record(value) || Object.keys(value).some((id) => !known.has(id))) return null;
  const result = {};
  for (const [id, stance] of Object.entries(value)) {
    if (
      !record(stance) ||
      Object.keys(stance).some((key) => !["stationOffsetWorld", "aisleZ", "settleSeconds", "withdrawMetres"].includes(key)) ||
      !point3(stance.stationOffsetWorld) ||
      stance.stationOffsetWorld[0] < -0.1 ||
      stance.stationOffsetWorld[0] > 0 ||
      stance.stationOffsetWorld[1] !== 0 ||
      stance.stationOffsetWorld[2] !== 0 ||
      !Array.isArray(stance.aisleZ) ||
      stance.aisleZ.length !== 2 ||
      !stance.aisleZ.every(Number.isFinite) ||
      stance.aisleZ[0] < 4.9 ||
      stance.aisleZ[0] > 5.2 ||
      stance.aisleZ[1] < 6.2 ||
      stance.aisleZ[1] > 6.5 ||
      !Number.isFinite(stance.settleSeconds) ||
      stance.settleSeconds < 0.6 ||
      stance.settleSeconds > 1 ||
      (stance.withdrawMetres !== undefined && (!Number.isFinite(stance.withdrawMetres) || stance.withdrawMetres < 0 || stance.withdrawMetres > 0.15))
    )
      return null;
    result[id] = Object.freeze({
      stationOffsetWorld: Object.freeze([...stance.stationOffsetWorld]),
      aisleZ: Object.freeze([...stance.aisleZ]),
      settleSeconds: stance.settleSeconds,
      withdrawMetres: stance.withdrawMetres ?? 0.15,
    });
  }
  return Object.freeze(result);
}

function coffeeChairTransfer(value, coffee) {
  const venue=coffeeVenue(coffee),ids=["lizard","south-park","simpsons","ghibli","rick-and-morty"];
  if(!venue||!record(value)||Object.keys(value).some(k=>!["version","duration","standing","avatars","chair","lizardTip"].includes(k))||
    value.version!==2||value.duration!==7||!nearPoint(value.standing,coffee.walkPath?.[1])||!record(value.avatars)||
    Object.keys(value.avatars).length!==ids.length||ids.some(id=>!Object.hasOwn(value.avatars,id))||
    !record(value.chair)||Object.keys(value.chair).length!==4||Object.keys(value.chair).some(k=>!["version","id","pullback","drawSeconds"].includes(k))||value.chair.version!==1||
    value.chair.id!=="pavilion-chair-v1"||value.chair.pullback!==.4||value.chair.drawSeconds!==2||
    !record(value.lizardTip)||Object.keys(value.lizardTip).length!==5||
    Object.keys(value.lizardTip).some(k=>!["ceiling","releaseStart","from","to","arc"].includes(k))||
    value.lizardTip.ceiling!==1.25||value.lizardTip.releaseStart!==.88||value.lizardTip.from!==1.25||
    value.lizardTip.to!==.32||value.lizardTip.arc!==-.12)return null;
  const avatars={},nearSeat=point=>point3(point)&&Math.hypot(...point.map((v,i)=>v-venue.seat[i]))<1.7;
  for(const id of ids){
    const stages=value.avatars[id];if(!Array.isArray(stages)||stages.length<2||stages.length>16)return null;
    const copied=[];
    for(const[i,stage]of stages.entries()){
      if(!record(stage)||Object.keys(stage).some(k=>!["u","position","facing","seated","feet","knees","pelvisPitch","spinePitch","tipPitch"].includes(k))||
        !Number.isFinite(stage.u)||stage.u<0||stage.u>1||(i&&stage.u<=stages[i-1].u)||
        !nearSeat(stage.position)||stage.position[1]<-.03||stage.position[1]>value.standing[1]+.55||
        !Number.isFinite(stage.facing)||Math.abs(stage.facing)>2*Math.PI||!Number.isFinite(stage.seated)||stage.seated<0||stage.seated>1||
        !Number.isFinite(stage.pelvisPitch)||Math.abs(stage.pelvisPitch)>.65||!Number.isFinite(stage.spinePitch)||Math.abs(stage.spinePitch)>.65||
        !Number.isFinite(stage.tipPitch)||stage.tipPitch<0||stage.tipPitch>1.3||(id!=="lizard"&&stage.tipPitch!==0)||
        !record(stage.feet)||!record(stage.knees)||Object.keys(stage.feet).length!==2||Object.keys(stage.knees).length!==2||
        ["L","R"].some(side=>!Object.hasOwn(stage.feet,side)||!Object.hasOwn(stage.knees,side))||
        ["L","R"].some(side=>!record(stage.feet[side])||Object.keys(stage.feet[side]).length!==2||Object.keys(stage.feet[side]).some(k=>!["position","quaternion"].includes(k))||
          !nearSeat(stage.feet[side].position)||!quaternion4(stage.feet[side].quaternion)||!point3(stage.knees[side])||
          Math.abs(Math.hypot(...stage.knees[side])-1)>1e-4))return null;
      copied.push({...stage,tipPitch:id==="lizard"?Math.min(value.lizardTip.ceiling,stage.tipPitch):stage.tipPitch,position:[...stage.position],feet:Object.fromEntries(["L","R"].map(side=>[side,
        {position:[...stage.feet[side].position],quaternion:[...stage.feet[side].quaternion]}])),
        knees:Object.fromEntries(["L","R"].map(side=>[side,[...stage.knees[side]]]))});
    }
    const seat=coffeeVenueSeat(coffee,id).map((v,i)=>v+(i===2?.4:0));
    if(copied[0].u!==0||copied.at(-1).u!==1||Math.abs(copied[0].position[0]-value.standing[0])>1e-6||Math.abs(copied[0].position[2]-value.standing[2])>1e-6||
      copied[0].position[1]>value.standing[1]||copied[0].position[1]<value.standing[1]-.008||copied[0].seated!==0||
      !nearPoint(copied.at(-1).position,seat)||copied.at(-1).seated!==1)return null;
    if(id==="lizard"&&(!copied.some(stage=>stage.u===value.lizardTip.releaseStart&&stage.tipPitch===value.lizardTip.from)||
      copied.at(-1).tipPitch!==value.lizardTip.to))return null;
    avatars[id]=copied;
  }
  return {version:2,duration:7,totalDuration:9,standing:[...value.standing],avatars,
    chair:Object.freeze({...value.chair}),lizardTip:Object.freeze({...value.lizardTip})};
}

function coffeeSeatTransfer(value, coffee) {
  if(value?.version===2)return coffeeChairTransfer(value,coffee);
  if (!record(value) || Object.keys(value).some(key => !["duration", "standing", "avatars"].includes(key)) ||
    !Number.isFinite(value.duration) || value.duration < 1.6 || value.duration > 3.4 ||
    !nearPoint(value.standing, coffee.walkPath?.[1]) || !record(value.avatars)) return null;
  const known = new Set(["lizard", "south-park", "simpsons", "ghibli", "rick-and-morty"]), avatars = {};
  const baseSeat = coffeeVenue(coffee)?.seat || coffee.seat;
  const nearSeat = p => point3(p) && Math.hypot(...p.map((v,i)=>v-baseSeat[i])) < 1.7;
  for (const [id, stages] of Object.entries(value.avatars)) {
    if (!known.has(id) || !Array.isArray(stages) || stages.length < 2 || stages.length > 10) return null;
    const copied = [];
    for (const [i, stage] of stages.entries()) {
      if (!record(stage) || Object.keys(stage).some(key => !["u","position","facing","seated","feet","knees","pelvisPitch","spinePitch","tipPitch"].includes(key)) ||
        !Number.isFinite(stage.u) || stage.u < 0 || stage.u > 1 || (i && stage.u <= stages[i-1].u) ||
        !nearSeat(stage.position) || stage.position[1] < baseSeat[1]-.03 || stage.position[1] > value.standing[1]+.55 ||
        !Number.isFinite(stage.facing) || Math.abs(stage.facing) > 2*Math.PI ||
        !Number.isFinite(stage.seated) || stage.seated < 0 || stage.seated > 1 ||
        !Number.isFinite(stage.pelvisPitch) || Math.abs(stage.pelvisPitch) > .65 ||
        !Number.isFinite(stage.spinePitch) || Math.abs(stage.spinePitch) > .65 ||
        !Number.isFinite(stage.tipPitch) || stage.tipPitch < 0 || stage.tipPitch > 1.3 ||
        (id !== "lizard" && stage.tipPitch !== 0) || !record(stage.feet) || !record(stage.knees) ||
        Object.keys(stage.feet).length !== 2 || Object.keys(stage.knees).length !== 2 ||
        ["L","R"].some(side => !record(stage.feet[side]) || Object.keys(stage.feet[side]).length !== 2 ||
          !nearSeat(stage.feet[side].position) || !quaternion4(stage.feet[side].quaternion) ||
          !point3(stage.knees[side]) || Math.abs(Math.hypot(...stage.knees[side])-1) > 1e-4)) return null;
      copied.push({ ...stage, position:[...stage.position],
        feet:Object.fromEntries(["L","R"].map(side=>[side,{position:[...stage.feet[side].position],quaternion:[...stage.feet[side].quaternion]}])),
        knees:Object.fromEntries(["L","R"].map(side=>[side,[...stage.knees[side]]])) });
    }
    if (copied[0].u !== 0 || copied.at(-1).u !== 1 || !nearPoint(copied[0].position,coffeeVenueSeat(coffee,id)||coffee.seat) ||
      !nearPoint(copied.at(-1).position,value.standing) || copied[0].seated !== 1 || copied.at(-1).seated !== 0) return null;
    avatars[id] = copied;
  }
  return {duration:value.duration,standing:[...value.standing],avatars};
}

function seatTransferPose(transfer, avatarId, progress) {
  const stages = Object.hasOwn(transfer.avatars,avatarId) && transfer.avatars[avatarId];
  if (!stages) return null;
  const u=Math.max(0,Math.min(1,progress));
  let i=stages.findIndex((s,i)=>i>0&&s.u>=u);if(i<1)i=stages.length-1;
  const a=stages[i-1],b=stages[i],weight=ease((u-a.u)/(b.u-a.u)),
    linear=(a,b)=>a+(b-a)*weight,
    vector=(a,b)=>a.map((v,i)=>linear(v,b[i])),
    orientation=(a,b)=>new THREE.Quaternion(...a).slerp(new THREE.Quaternion(...b),weight).normalize().toArray(),
    facing=a.facing+Math.atan2(Math.sin(b.facing-a.facing),Math.cos(b.facing-a.facing))*weight,
    seated=linear(a.seated,b.seated);
  const position=vector(a.position,b.position),left=new THREE.Vector3(-.22,.82,.04)
    .applyAxisAngle(new THREE.Vector3(0,1,0),facing).add(new THREE.Vector3(...position)).toArray();
  return {position,facing,clip:"idle",blend:{from:"idle",to:"drink",weight:seated},hands:[left,null],
    walkingSpeed:0,onStairs:false,routedCoffee:true,
    coffeeTransfer:{feet:Object.fromEntries(["L","R"].map(side=>[side,{position:vector(a.feet[side].position,b.feet[side].position),
      quaternion:orientation(a.feet[side].quaternion,b.feet[side].quaternion)}])),
      knees:Object.fromEntries(["L","R"].map(side=>[side,vector(a.knees[side],b.knees[side])])),
      pelvisPitch:linear(a.pelvisPitch,b.pelvisPitch),spinePitch:linear(a.spinePitch,b.spinePitch),
      tipPitch:linear(a.tipPitch,b.tipPitch),seatedWeight:seated}};
}

// Version2 is the measured incoming transfer followed by a two-second draw.
// Existing callers use outgoing progress, so zero is the original parked seat.
function chairTransferPose(transfer,id,progress){
  const incomingAge=(1-Math.max(0,Math.min(1,progress)))*transfer.totalDuration,
    pose=seatTransferPose(transfer,id,Math.min(1,incomingAge/transfer.duration));
  if(!pose)return null;
  const u=Math.min(1,incomingAge/transfer.duration),curve=transfer.lizardTip;
  if(id==="lizard"&&u>=curve.releaseStart){
    const v=(u-curve.releaseStart)/(1-curve.releaseStart);
    pose.coffeeTransfer.tipPitch=curve.from+(curve.to-curve.from)*ease(v)+curve.arc*Math.sin(Math.PI*v);
  }
  const offset=incomingAge<=transfer.duration?transfer.chair.pullback:
    transfer.chair.pullback*(1-ease((incomingAge-transfer.duration)/transfer.chair.drawSeconds)),
    delta=offset-transfer.chair.pullback;
  if(incomingAge>transfer.duration){
    pose.position[2]+=delta;
    pose.hands=pose.hands.map(p=>p&&p.map((v,i)=>v+(i===2?delta:0)));
    for(const side of["L","R"])pose.coffeeTransfer.feet[side].position[2]+=delta;
  }
  pose.coffeeChair={request:{version:transfer.chair.version,id:transfer.chair.id},offset};
  return pose;
}

function coffeeSchedule(durations) {
  const approach = 3 + durations.approach,
    grind = approach + 6,
    station = grind + 2,
    prepare = station + 6,
    brew = prepare + 6,
    pickup = brew + 2,
    table = pickup + durations.carry,
    food = table + 25,
    foodEnd = food + 190,
    returnCup = foodEnd + durations.returnCup,
    setDown = returnCup + 3,
    back = setDown + durations.return;
  return { approach, grind, station, prepare, brew, pickup, table, food, foodEnd, returnCup, setDown, back };
}

// A rebuilt nook may reach the same coffee bar through an authored stair. Keep
// its whole supported polyline instead of drawing one diagonal through a wall.
// The original two-leg sequence remains the fallback for existing manifests.
function coffeeWalkPlan(coffee) {
  if (coffeeWalkPlans.has(coffee)) return coffeeWalkPlans.get(coffee);
  const path = coffee.walkPath, venue = coffeeVenue(coffee);
  const legacy = {
    grinder: [coffee.actor[0] - 0.34, coffee.actor[1], coffee.grinder[2] - 0.2],
    brewer: [coffee.actor[0] - 0.34, coffee.actor[1], coffee.actor[2] - 0.2],
  };
  let stations = legacy,
    durations = coffeeLegacyDurations;
  const invalid = () => {
    coffeeWalkPlans.set(coffee, null);
    return null;
  };
  // Only the rebuilt, supported route may opt into nearby standing roots. The
  // equipment and its wrist/cup anchors do not move with the visitor's body.
  if (coffee.stations !== undefined) {
    if (
      !coffee.stations ||
      ["grinder", "brewer"].some(
        (id) =>
          !point3(coffee.stations[id]) ||
          Math.abs(coffee.stations[id][1] - legacy[id][1]) > 0.02 ||
          Math.hypot(...coffee.stations[id].map((v, i) => v - legacy[id][i])) > 0.5
      )
    )
      return invalid();
    stations = coffee.stations;
  }
  if (coffee.walkDurations !== undefined) {
    if (
      !coffee.walkDurations ||
      Object.keys(coffeeLegacyDurations).some(
        (id) => !Number.isFinite(coffee.walkDurations[id]) || coffee.walkDurations[id] < 6 || coffee.walkDurations[id] > (venue ? 48 : 20)
      )
    )
      return invalid();
    durations = coffee.walkDurations;
  }
  if (
    !Array.isArray(path) ||
    path.length < 2 ||
    path.length > 64 ||
    path.some((point, i) => !point3(point) || (i > 0 && nearPoint(point, path[i - 1]))) ||
    !nearPoint(path[0], venue?.seat || coffee.seat) ||
    !nearPoint(path.at(-1), stations.grinder)
  )
    return invalid();
  const schedule = coffeeSchedule(durations);
  const plans = {
    grinder: venue ? coffeeVenueApproach(coffee, stations.grinder) : path,
    brewer: venue ? coffeeVenueApproach(coffee, stations.brewer) : [...path, stations.brewer],
    stations,
    legacy,
    durations,
    schedule,
    timeline: Object.freeze({ table: schedule.table, food: schedule.food, foodEnd: schedule.foodEnd, back: schedule.back }),
    revised: coffee.stations !== undefined || coffee.walkDurations !== undefined,
    stationGrips: coffeeStationGrips(coffee.stationGrips),
    contactMotion: coffeeContactMotion(coffee.contactMotion),
    seatedPhase: coffeeSeatedPhase(coffee.seatedPhase),
    avatarStances: coffeeAvatarStances(coffee.avatarStances),
    seatTransfer: coffeeSeatTransfer(coffee.seatTransfer, coffee),
    avatarPlans: new Map(),
  };
  coffeeWalkPlans.set(coffee, plans);
  return plans;
}

export function coffeeTimeline(coffee) {
  return coffee && typeof coffee === "object" ? coffeeWalkPlan(coffee)?.timeline || COFFEE_TIMELINE : COFFEE_TIMELINE;
}

export function coffeeSeatFrame(coffee, avatarId) {
  const transfer=coffee&&typeof coffee==="object"&&coffeeWalkPlan(coffee)?.seatTransfer;
  return transfer&&Object.hasOwn(transfer.avatars,avatarId) ? (transfer.version===2?chairTransferPose(transfer,avatarId,0):seatTransferPose(transfer,avatarId,0)).coffeeTransfer : coffeeVenueFeet(coffee,avatarId);
}

export function coffeeWalkPose(path, progress, reverse = false, duration) {
  const u = Math.max(0, Math.min(1, progress));
  const ramp = 0.12;
  const traveled =
    u < ramp ? (u * u) / (2 * ramp * (1 - ramp)) : u > 1 - ramp ? 1 - (1 - u) ** 2 / (2 * ramp * (1 - ramp)) : (u - ramp / 2) / (1 - ramp);
  const points = reverse ? [...path].reverse() : path;
  const lengths = points.slice(1).map((point, i) => Math.hypot(...point.map((v, k) => v - points[i][k])));
  // Authoring uses17cm risers. Spend more time on those actual rising/falling
  // segments than on the level aisle, including when carrying the cup back.
  const costs = lengths.map((length, i) => length * (Math.abs(points[i + 1][1] - points[i][1]) > 0.1 ? 1.8 : 1));
  let distance = traveled * costs.reduce((sum, cost) => sum + cost, 0);
  let segment = lengths.length - 1;
  for (let i = 0; i < lengths.length; i++) {
    if (distance <= costs[i] || i === lengths.length - 1) {
      segment = i;
      break;
    }
    distance -= costs[i];
  }
  const a = points[segment],
    b = points[segment + 1];
  const t = costs[segment] > 0 ? Math.min(1, distance / costs[segment]) : 0;
  const pose = { position: a.map((v, i) => v + (b[i] - v) * t), facing: Math.atan2(b[0] - a[0], b[2] - a[2]), clip: "walk" };
  if (Number.isFinite(duration) && duration > 0) {
    const slope = u < ramp ? u / (ramp * (1 - ramp)) : u > 1 - ramp ? (1 - u) / (ramp * (1 - ramp)) : 1 / (1 - ramp);
    pose.walkingSpeed = (slope * costs.reduce((sum, cost) => sum + cost, 0) * lengths[segment]) / (duration * costs[segment]);
    pose.onStairs = Math.abs(b[1] - a[1]) > 0.1;
    pose.routedCoffee = true;
  }
  return pose;
}

function routedCoffeePose(coffee, paths, t, room, avatarId) {
  const venue = coffeeVenue(coffee), seat = coffeeVenueSeat(coffee, avatarId) || coffee.seat, facing = venue?.facing ?? room.facing;
  const stance = paths.avatarStances && Object.hasOwn(paths.avatarStances, avatarId) ? paths.avatarStances[avatarId] : null;
  if (stance && venue) {
    if (!paths.avatarPlans.has(avatarId)) {
      const stations = Object.fromEntries(Object.entries(paths.stations).map(([id, point]) =>
        [id, point.map((value, i) => value + stance.stationOffsetWorld[i])]));
      paths.avatarPlans.set(avatarId, {...paths, stations,
        grinder: coffeeVenueApproach(coffee, stations.grinder, stance.withdrawMetres),
        brewer: coffeeVenueApproach(coffee, stations.brewer, stance.withdrawMetres), barWithdrawal: true});
    }
    paths = paths.avatarPlans.get(avatarId);
  } else if (stance && nearPoint(paths.grinder.at(-2), [-3.35, 0, coffee.grinder[2] - 0.2]) && nearPoint(paths.grinder.at(-3), [-3.35, 0, 4.62])) {
    if (!paths.avatarPlans.has(avatarId)) {
      const stations = Object.fromEntries(
        Object.entries(paths.stations).map(([id, point]) => [id, point.map((v, i) => v + stance.stationOffsetWorld[i])])
      );
      // Keep the actual stair-head aisle centred on its original support.
      // The measured westward station stance belongs beside the coffee bar;
      // applying it to the entire aisle sends a trailing shoe into the rail.
      const aisleX = paths.grinder.at(-3)[0];
      const railClearZ = stance.aisleZ[0] + 0.55;
      const aisleCenterX = paths.stations.grinder[0];
      const grinder = [
        ...paths.grinder.slice(0, -2),
        [aisleX, stations.grinder[1], railClearZ],
        [aisleCenterX, stations.grinder[1], railClearZ + 0.35],
        [aisleCenterX, stations.grinder[1], stance.aisleZ.at(-1)],
        stations.grinder,
      ];
      const brewer = [
        ...grinder.slice(0, -1),
        ...(stance.withdrawMetres > 0 ? [[stations.brewer[0] + stance.withdrawMetres, stations.brewer[1], stations.brewer[2]]] : []),
        ...(stance.withdrawMetres === 0 ? [[stations.brewer[0], stations.brewer[1], stance.aisleZ.at(-1) + 0.2]] : []),
        stations.brewer,
      ];
      paths.avatarPlans.set(avatarId, { ...paths, stations, grinder, brewer, barWithdrawal: true });
    }
    paths = paths.avatarPlans.get(avatarId);
  }
  const S = paths.schedule,
    D = paths.durations,
    { grinder, brewer } = paths.stations;
  const cupGrip = coffeeCupGrip(coffee, avatarId);
  const cup = (mode, seconds) => (cupGrip ? { coffeeCup: { mode, ...(seconds === undefined ? {} : { seconds }), grip: cupGrip } } : {});
  const transfer=paths.seatTransfer && Object.hasOwn(paths.seatTransfer.avatars,avatarId) ? paths.seatTransfer : null;
  const transferSeconds=transfer?.totalDuration||transfer?.duration||0,
    walkingPath=path=>transfer ? (transfer.version===2?[transfer.avatars[avatarId][0].position,...path.slice(2)]:path.slice(1)) : venue ? [seat, ...path.slice(1)] : path,
    transferPose=(progress,phase,held,departing=false)=>{
      const pose=transfer&&(transfer.version===2?chairTransferPose(transfer,avatarId,progress):seatTransferPose(transfer,avatarId,progress));
      const heldCup=held?cup("carry"):{};
      if(heldCup.coffeeCup&&cupGrip.seatedCarryDrop!==undefined)heldCup.coffeeCup={...heldCup.coffeeCup,seatedWeight:pose.coffeeTransfer.seatedWeight};
      return pose&&{...pose,coffeeTransfer:{...pose.coffeeTransfer,departing},phase,cup:held,...heldCup};
    };
  const hasGrip = (phase) => (phase === "cup" ? Boolean(cupGrip) : paths.stationGrips?.[phase] && Object.hasOwn(paths.stationGrips[phase], avatarId));
  const turn = (pose, start, end, from, to, phase) => {
    const motion = paths.contactMotion;
    if (!motion || !hasGrip(phase)) return pose;
    const angle = (a, b, blend) => a + Math.atan2(Math.sin(b - a), Math.cos(b - a)) * blend;
    let facing = pose.facing;
    if (t - start < motion.turnSeconds) facing = angle(from, facing, ease((t - start) / motion.turnSeconds));
    if (end - t < motion.turnSeconds) facing = angle(facing, to, ease(1 - (end - t) / motion.turnSeconds));
    return { ...pose, facing, ...(venue&&phase==="cup"?{coffeeOffhandWeight:1-ease((Math.hypot(...pose.position.map((v,i)=>v-brewer[i]))-.4)/.6)}:{}) };
  };
  // A short genuine backward step clears the bar before the body turns.
  // Keep the authored phase endpoint; the remaining level route uses its own
  // eased departure. Only the measured optional venue/stance can request it.
  const leavingBar = (path, start, duration) => {
    const points = walkingPath(path), age = t - start;
    if (!venue || !stance || !(stance.withdrawMetres > 0))
      return coffeeWalkPose(points, age / duration, true, duration);
    const reversed = [...points].reverse(), station = reversed[0], clear = reversed[1];
    if (!nearPoint(station, brewer) || !clear || Math.abs(clear[0]-station[0]-stance.withdrawMetres) > 1e-6 ||
      Math.abs(clear[1]-station[1]) > 1e-6 || Math.abs(clear[2]-station[2]) > 1e-6 || duration <= 2)
      return coffeeWalkPose(points, age / duration, true, duration);
    const backSeconds = 1.1, turnSeconds = .8,
      next = reversed[2], nextFacing = Math.atan2(next[0]-clear[0], next[2]-clear[2]);
    if (age < backSeconds) return {...coffeeWalkPose([station,clear], age/backSeconds, false, backSeconds),
      facing:coffee.facing, coffeeWalkBackwards:true, coffeeBarWithdrawal:true};
    if (age < backSeconds+turnSeconds) return {position:[...clear],
      facing:coffee.facing+Math.atan2(Math.sin(nextFacing-coffee.facing),Math.cos(nextFacing-coffee.facing))*ease((age-backSeconds)/turnSeconds),
      clip:"idle",walkingSpeed:0,onStairs:false,routedCoffee:true,coffeeBarWithdrawal:true};
    return {...coffeeWalkPose(points.slice(0,-1), (age-backSeconds-turnSeconds)/(duration-backSeconds-turnSeconds),
      true,duration-backSeconds-turnSeconds),coffeeBarWithdrawal:true};
  };
  const withdraw = (pose, start) => {
    if (venue) pose = { ...pose, coffeeOffhandWeight: 1 - ease((t-start-2.8)/1) };
    if (!paths.barWithdrawal || pose.coffeeBarWithdrawal) return pose;
    const blend = ease((t - start - 0.8) / 0.8);
    return {
      ...pose,
      facing: coffee.facing + Math.atan2(Math.sin(pose.facing - coffee.facing), Math.cos(pose.facing - coffee.facing)) * blend,
    };
  };
  const contact = (station, pose) => {
    if (coffee.stations === undefined) return pose;
    const result = { ...pose, contactReference: paths.legacy[station] };
    const group = paths.stationGrips?.[pose.phase],
      grip = group && Object.hasOwn(group, avatarId) ? group[avatarId] : null;
    if (grip) {
      const start = pose.phase === "grind" ? S.approach : S.station,
        end = pose.phase === "grind" ? S.grind : S.prepare,
        u = Math.max(0, Math.min(1, (t - start) / 0.25, (end - t) / 0.25));
      result.coffeeGrip = grip;
      result.contactBlend = u * u * (3 - 2 * u);
      const motion = paths.contactMotion;
      if (motion) {
        const age = t - start,
          remaining = end - t,
          settle = motion.settleSeconds;
        const retreat = Math.max(
          1 - ease((age - settle) / (motion.reachSeconds - settle)),
          1 - ease((remaining - settle) / (motion.releaseSeconds - settle))
        );
        result.coffeeHandPath = motion.withdrawWorld.map((v) => v * retreat);
        result.contactBlend = ease(age / settle) * ease(remaining / settle);
        // The arm first orients beside the machine and withdraws before the
        // authored idle takes over. It never blends back through its housing.
        if (age <= motion.reachSeconds || remaining <= motion.releaseSeconds) result.clip = "idle";
      }
    }
    return result;
  };
  if (t < 3) return { position: seat, facing: facing, clip: "eat", phase: "at the table" };
  if (transfer && t < 3+transferSeconds) return transferPose((t-3)/transferSeconds,"leaving the seat",false,true);
  if (t < S.approach && stance && paths === paths.avatarPlans.get(avatarId)) {
    const duration = D.approach - stance.settleSeconds - transferSeconds;
    const pose = coffeeWalkPose(walkingPath(paths.grinder), Math.min(1, (t - 3-transferSeconds) / duration), false, duration);
    const arrivalFacing = venue ? Math.PI : 0;
    if (t > S.approach - stance.settleSeconds - 1.4) pose.facing = arrivalFacing;
    if (t >= S.approach - stance.settleSeconds) {
      pose.facing = venue ? arrivalFacing + Math.atan2(Math.sin(coffee.facing-arrivalFacing),Math.cos(coffee.facing-arrivalFacing)) * ease((t - S.approach + stance.settleSeconds) / stance.settleSeconds) : coffee.facing * ease((t - S.approach + stance.settleSeconds) / stance.settleSeconds);
      pose.clip = "idle";
      pose.walkingSpeed = 0;
      pose.onStairs = false;
    } else if (t - 3 < (paths.contactMotion?.turnSeconds || 0.6)) {
      pose.facing =
        facing +
        Math.atan2(Math.sin(pose.facing - facing), Math.cos(pose.facing - facing)) *
          ease((t - 3) / (paths.contactMotion?.turnSeconds || 0.6));
    }
    return { ...pose, phase: "approach" };
  }
  if (t < S.approach)
    return turn(
      { ...coffeeWalkPose(walkingPath(paths.grinder), (t - 3-transferSeconds) / (D.approach-transferSeconds), false, D.approach-transferSeconds), phase: "approach" },
      3,
      S.approach,
      facing,
      coffee.facing,
      "grind"
    );
  if (t < S.grind)
    return contact("grinder", { position: grinder, facing: coffee.facing, clip: "coffee-prep", hands: [null, coffee.grinder], phase: "grind" });
  if (t < S.station) {
    const pose = paths.revised ? coffeeWalkPose([grinder, brewer], (t - S.grind) / 2, false, 2) : leg(grinder, brewer, (t - S.grind) / 2);
    return turn({ ...pose, phase: "prepare" }, S.grind, S.station, coffee.facing, coffee.facing, "prepare");
  }
  if (t < S.prepare)
    return contact("brewer", { position: brewer, facing: coffee.facing, clip: "coffee-prep", hands: [null, coffee.brew], phase: "prepare" });
  if (t < S.brew) return { position: brewer, facing: coffee.facing, clip: "idle", phase: "brew", brew: true };
  if (t < S.pickup) {
    if (cupGrip)
      return { position: brewer, facing: coffee.facing, clip: "idle", phase: "pick up", cup: t >= S.pickup - 1, ...cup("pickup", t - S.brew), ...(venue ? {routedCoffee:true,coffeeOffhandWeight:ease((t-S.brew)/.6)}:{}) };
    return contact("brewer", {
      position: brewer,
      facing: coffee.facing,
      clip: "coffee-prep",
      hands: [null, coffee.cup],
      phase: "pick up",
      cup: t >= S.pickup - 1,
    });
  }
  if (transfer && t >= S.table-transferSeconds && t < S.table)
    return transferPose((S.table-t)/transferSeconds,"taking a seat",true);
  if (t < S.table)
    return withdraw({
      ...leavingBar(paths.brewer, S.pickup, D.carry-transferSeconds),
      phase: t < S.pickup + 5 ? "carry" : "return",
      cup: true,
      ...cup("carry"),
    }, S.pickup);
  if (t < S.food) return { position: seat, facing: facing, clip: "drink", phase: paths.seatedPhase, cup: true };
  if (t < S.foodEnd) return { position: seat, facing: facing, clip: "eat", phase: "breakfast", cup: true };
  if (transfer && t < S.foodEnd+transferSeconds)
    return transferPose((t-S.foodEnd)/transferSeconds,"leaving the seat",true,true);
  if (t < S.returnCup)
    return turn(
      { ...coffeeWalkPose(walkingPath(paths.brewer), (t - S.foodEnd-transferSeconds) / (D.returnCup-transferSeconds), false, D.returnCup-transferSeconds), phase: "return cup", cup: true, ...cup("carry") },
      S.foodEnd,
      S.returnCup,
      facing,
      coffee.facing,
      "cup"
    );
  if (t < S.setDown) {
    if (cupGrip)
      return {
        position: brewer,
        facing: coffee.facing,
        clip: "idle",
        phase: "set down",
        cup: t < S.setDown - 0.5,
        ...(venue?{routedCoffee:true,coffeeOffhandWeight:1}:{}),
        ...cup("setdown", t - S.returnCup),
      };
    return contact("brewer", {
      position: brewer,
      facing: coffee.facing,
      clip: "coffee-prep",
      hands: [null, coffee.cup],
      phase: "set down",
      cup: t < S.setDown - 0.5,
    });
  }
  if (transfer && t >= S.back-transferSeconds && t < S.back)
    return transferPose((S.back-t)/transferSeconds,"taking a seat",false);
  if (t < S.back)
    return withdraw({
      ...leavingBar(paths.brewer, S.setDown, D.return-transferSeconds),
      phase: "return",
      ...(cupGrip && t < S.setDown + 4 ? cup("release", t - S.setDown) : {}),
    }, S.setDown);
  return { position: seat, facing: facing, clip: "eat", phase: "at the table" };
}
// The seated breakfast's own clock (dining.mjs plans the meal on it): table time since the coffee
// arrived, paused while he walks the cup back, and whether the cup is still with him.
export function coffeeTableClock(seconds, coffee) {
  const T = coffeeTimeline(coffee),
    t = Math.max(0, Number(seconds) || 0);
  if (t < T.table) return { table: false, seconds: 0, cup: false };
  if (t < T.foodEnd) return { table: true, seconds: t - T.table, cup: true, prelude: t < T.food };
  if (t < T.back) return { table: false, seconds: T.foodEnd - T.table, cup: false };
  return { table: true, seconds: T.foodEnd - T.table + (t - T.back), cup: false, after: true };
}

// Short, deterministic sequences use only the exported equipment locations. (The gym's training
// session is choreographed by gym-session.mjs.) Time advances only while the scene is visible and
// system motion is enabled.
export function activityPose(sequence, seconds, equipment, room, avatarId) {
  if (!equipment) return null;
  if (sequence === "coffee") {
    const c = equipment.coffee,
      t = Math.max(0, seconds),
      T = COFFEE_TIMELINE;
    const brewer = [c.actor[0] - 0.34, c.actor[1], c.actor[2] - 0.2],
      grinder = [brewer[0], brewer[1], c.grinder[2] - 0.2];
    const way = c.approach[1];
    const paths = coffeeWalkPlan(c);
    if (paths) return routedCoffeePose(c, paths, t, room, avatarId);
    if (t < 3) return { position: c.seat, facing: room.facing, clip: "eat", phase: "at the table" };
    if (t < 5) return { ...leg(c.seat, way, (t - 3) / 2), phase: "approach" };
    if (t < 9) return { ...leg(way, grinder, (t - 5) / 4), phase: "approach" };
    if (t < 15) return { position: grinder, facing: c.facing, clip: "coffee-prep", hands: [null, c.grinder], phase: "grind" };
    if (t < 17) return { ...leg(grinder, brewer, (t - 15) / 2), phase: "prepare" };
    if (t < 23) return { position: brewer, facing: c.facing, clip: "coffee-prep", hands: [null, c.brew], phase: "prepare" };
    if (t < 29) return { position: brewer, facing: c.facing, clip: "idle", phase: "brew", brew: true };
    if (t < 31) return { position: brewer, facing: c.facing, clip: "coffee-prep", hands: [null, c.cup], phase: "pick up", cup: t >= 30 };
    if (t < 36) return { ...leg(brewer, way, (t - 31) / 5), phase: "carry", cup: true };
    if (t < T.table) return { ...leg(way, c.seat, (t - 36) / 3), phase: "return", cup: true };
    if (t < T.food) return { position: c.seat, facing: room.facing, clip: "drink", phase: "coffee by the ocean", cup: true };
    if (t < T.foodEnd) return { position: c.seat, facing: room.facing, clip: "eat", phase: "breakfast", cup: true };
    const u = t - T.foodEnd;
    if (u < 4) return { ...leg(c.seat, way, u / 4), phase: "return cup", cup: true };
    if (u < 9) return { ...leg(way, brewer, (u - 4) / 5), phase: "return cup", cup: true };
    if (u < 12) return { position: brewer, facing: c.facing, clip: "coffee-prep", hands: [null, c.cup], phase: "set down", cup: u < 11.5 };
    if (u < 17) return { ...leg(brewer, way, (u - 12) / 5), phase: "return" };
    if (u < 21) return { ...leg(way, c.seat, (u - 17) / 4), phase: "return" };
    return { position: c.seat, facing: room.facing, clip: "eat", phase: "at the table" };
  }
  return null;
}

const emptyHandJoints = new WeakMap();
// A brief relaxed empty hand while passing the coffee equipment. Preserve the
// animated palm and elbow plane at zero weight; the cup hand remains independent.
export function coffeeEmptyHandFrame(actor, pose) {
  const weight=pose?.coffeeOffhandWeight;
  if(!actor?.isObject3D||pose?.routedCoffee!==true||!Number.isFinite(weight)||weight<=0||weight>1)return null;
  let joints=emptyHandJoints.get(actor);
  if(!joints){joints=["ArmL","ForearmL","HandL"].map(name=>actor.getObjectByName(name));if(joints.some(b=>!b?.isBone))return null;emptyHandJoints.set(actor,joints);}
  actor.updateWorldMatrix(true,true);
  const [upper,lower,hand]=joints,shoulder=upper.getWorldPosition(new THREE.Vector3()),
    animated=hand.getWorldPosition(new THREE.Vector3()),
    desired=new THREE.Vector3(-.08,.82,.12).applyQuaternion(actor.quaternion).add(actor.position),
    wrist=animated.clone().lerp(desired,weight),axis=wrist.clone().sub(shoulder).normalize(),
    original=lower.getWorldPosition(new THREE.Vector3()).sub(shoulder),
    relaxed=new THREE.Vector3(0,-.2,1).applyQuaternion(actor.quaternion);
  original.addScaledVector(axis,-original.dot(axis));relaxed.addScaledVector(axis,-relaxed.dot(axis));
  if(original.lengthSq()<1e-16)original.copy(relaxed);
  if(original.lengthSq()<1e-16||relaxed.lengthSq()<1e-16)return null;
  original.normalize();relaxed.normalize();
  const turn=new THREE.Quaternion().slerp(new THREE.Quaternion().setFromUnitVectors(original,relaxed),weight),
    pole=original.applyQuaternion(turn).normalize();
  return {wrist:wrist.toArray(),palm:hand.getWorldQuaternion(new THREE.Quaternion()).normalize().toArray(),pole:pole.toArray(),weight};
}

export function createHandContacts(actor) {
  const named = (name) => {
    let found;
    actor.traverse((o) => {
      if (o.isBone && o.name.replaceAll(".", "") === name) found = o;
    });
    return found;
  };
  const limbs = ["L", "R"].map((s) => ({ upper: named("Arm" + s), lower: named("Forearm" + s), hand: named("Hand" + s), side: s }));
  const v = () => new THREE.Vector3(),
    a = v(),
    b = v(),
    c = v(),
    goal = v(),
    direction = v(),
    bend = v(),
    elbow = v(),
    u = v(),
    w = v();
  const q = new THREE.Quaternion(),
    parent = new THREE.Quaternion();
  function aim(bone, child, target) {
    bone.getWorldPosition(u);
    child.getWorldPosition(w);
    w.sub(u).normalize();
    u.copy(target).sub(bone.getWorldPosition(v())).normalize();
    q.setFromUnitVectors(w, u).multiply(bone.getWorldQuaternion(new THREE.Quaternion()));
    bone.parent.getWorldQuaternion(parent).invert();
    bone.quaternion.copy(parent.multiply(q));
    actor.updateMatrixWorld(true);
  }
  let drift = [],
    referenceLayer = null;
  return {
    // Only the opt-in coffee frame solve records a layer. Restore it before
    // the next mixer update: constant animation channels may otherwise skip
    // their write and accidentally reuse the preceding IK result.
    restoreReference() {
      if (!referenceLayer) return;
      for (const [bone, rotation] of referenceLayer) bone.quaternion.copy(rotation);
      referenceLayer = null;
      actor.updateMatrixWorld(true);
    },
    solve(targets, weight = 1) {
      drift = [];
      actor.updateMatrixWorld(true);
      limbs.forEach((limb, i) => {
        if (!targets?.[i] || !limb.hand) return;
        limb.upper.getWorldPosition(a);
        limb.lower.getWorldPosition(b);
        limb.hand.getWorldPosition(c);
        goal.fromArray(targets[i]).lerp(c, 1 - weight);
        const l1 = a.distanceTo(b),
          l2 = b.distanceTo(c);
        direction.copy(goal).sub(a);
        const distance = Math.min(direction.length(), l1 + l2 - 0.00001);
        direction.normalize();
        const along = (l1 * l1 - l2 * l2 + distance * distance) / (2 * Math.max(distance, 0.00001));
        bend.set(limb.side === "L" ? -0.7 : 0.7, -0.4, 0.45).applyQuaternion(actor.quaternion);
        bend.addScaledVector(direction, -bend.dot(direction)).normalize();
        elbow
          .copy(a)
          .addScaledVector(direction, along)
          .addScaledVector(bend, Math.sqrt(Math.max(0, l1 * l1 - along * along)));
        aim(limb.upper, limb.lower, elbow);
        aim(limb.lower, limb.hand, goal);
        drift.push(limb.hand.getWorldPosition(c).distanceTo(goal));
      });
    },
    // Moving the torso away from a coffee machine must not independently roll
    // the palm through its housing. Reuse the authored station's solved hand
    // orientation, then solve the arm to the same real wrist anchor. This is
    // opt-in for the nearby coffee standing-root correction only.
    solveReference(targets, reference, weight = 1, worldFrames, worldPoles, preserveLeftPalm = false) {
      if (!point3(reference) || actor.position.distanceTo(new THREE.Vector3(...reference)) > 0.5 || !targets?.some(point3)) {
        this.solve(targets, weight);
        return;
      }
      const localLeft = preserveLeftPalm === true;
      const frames = limbs.map((limb, i) =>
        !(localLeft && i===0) && point3(targets[i]) && quaternion4(worldFrames?.[i]) ? new THREE.Quaternion(...worldFrames[i]).normalize() : null
      );
      const poles = frames.map((frame, i) =>
        (frame || (localLeft && i===0)) && point3(worldPoles?.[i]) && Math.abs(Math.hypot(...worldPoles[i]) - 1) <= 1e-4
          ? new THREE.Vector3(...worldPoles[i]).normalize()
          : null
      );
      if (frames.some(Boolean) || localLeft) {
        const blend = Number.isFinite(weight) ? Math.max(0, Math.min(1, weight)) : 0;
        drift = [];
        if (blend === 0) return;
        const affected = limbs.filter((limb, i) => point3(targets[i]) && limb.hand);
        const authored = affected.flatMap((limb) => [limb.upper, limb.lower, limb.hand]).map((bone) => [bone, bone.quaternion.clone()]);
        if (frames[1] || localLeft) referenceLayer = affected.flatMap((limb)=>[limb.upper,limb.lower,limb.hand]).map((bone) => [bone, bone.quaternion.clone()]);
        if (blend < 1 || poles.some(Boolean) || localLeft) {
          limbs.forEach((limb, i) => {
            if (!point3(targets[i]) || !limb.hand) return;
            if (!frames[i] && !(localLeft && i===0)) {
              this.solve(
                targets.map((target, side) => (side === i ? target : null)),
                blend
              );
              return;
            }
            limb.upper.getWorldPosition(a);
            limb.lower.getWorldPosition(b);
            limb.hand.getWorldPosition(c);
            const localPalm=limb.hand.quaternion.clone();
            const originalFrame = limb.hand.getWorldQuaternion(new THREE.Quaternion()).normalize();
            const l1 = a.distanceTo(b),
              l2 = b.distanceTo(c);
            goal.copy(c).lerp(new THREE.Vector3(...targets[i]), blend);
            direction.copy(goal).sub(a);
            const distance = Math.min(direction.length(), l1 + l2 - 0.00001);
            direction.normalize();
            goal.copy(a).addScaledVector(direction, distance);
            const along = (l1 * l1 - l2 * l2 + distance * distance) / (2 * Math.max(distance, 0.00001));
            const initialPole = b.clone().sub(a);
            initialPole.addScaledVector(direction, -initialPole.dot(direction));
            if (poles[i]) bend.copy(poles[i]);
            else bend.set(limb.side === "L" ? -0.7 : 0.7, -0.4, 0.45).applyQuaternion(actor.quaternion);
            bend.addScaledVector(direction, -bend.dot(direction)).normalize();
            if (initialPole.lengthSq() < 1e-16) initialPole.copy(bend);
            else initialPole.normalize();
            const angle = Math.atan2(direction.dot(initialPole.clone().cross(bend)), Math.max(-1, Math.min(1, initialPole.dot(bend))));
            bend.copy(initialPole).applyAxisAngle(direction, angle * blend);
            elbow
              .copy(a)
              .addScaledVector(direction, along)
              .addScaledVector(bend, Math.sqrt(Math.max(0, l1 * l1 - along * along)));
            aim(limb.upper, limb.lower, elbow);
            aim(limb.lower, limb.hand, goal);
            if(localLeft && i===0){
              limb.hand.quaternion.copy(localPalm);
              limb.hand.updateWorldMatrix(false,true);
              return;
            }
            const wanted = originalFrame.slerp(frames[i], blend);
            limb.hand.parent.getWorldQuaternion(parent).invert();
            limb.hand.quaternion.copy(parent.multiply(wanted).normalize());
            limb.hand.updateWorldMatrix(false, true);
            const parentWorld = limb.hand.parent.getWorldQuaternion(new THREE.Quaternion()).normalize(),
              parentInverse = parentWorld.clone().invert();
            for (let pass = 0; pass < 2; pass++) {
              const measured = limb.hand.getWorldQuaternion(new THREE.Quaternion()).normalize(),
                correction = wanted.clone().multiply(measured.invert());
              limb.hand.quaternion.premultiply(parentInverse.clone().multiply(correction).multiply(parentWorld)).normalize();
              limb.hand.updateWorldMatrix(false, true);
            }
          });
          actor.updateMatrixWorld(true);
          drift = limbs.flatMap((limb, i) =>
            point3(targets[i]) && limb.hand ? [limb.hand.getWorldPosition(c).distanceTo(new THREE.Vector3(...targets[i]))] : []
          );
          return;
        }
        this.solve(targets, 1);
        limbs.forEach((limb, i) => {
          if (!frames[i] || !limb.hand) return;
          limb.hand.parent.getWorldQuaternion(parent).invert();
          limb.hand.quaternion.copy(parent.multiply(frames[i]).normalize());
          limb.hand.updateWorldMatrix(false, true);
          // Imported Float32 parent transforms can contain tiny scale/shear.
          // Correct the actual decomposed world frame without changing the
          // parent, wrist position or any animated finger-local transform.
          const parentWorld = limb.hand.parent.getWorldQuaternion(new THREE.Quaternion()).normalize(),
            parentInverse = parentWorld.clone().invert();
          for (let pass = 0; pass < 2; pass++) {
            const measured = limb.hand.getWorldQuaternion(new THREE.Quaternion()).normalize(),
              correction = frames[i].clone().multiply(measured.invert());
            limb.hand.quaternion.premultiply(parentInverse.clone().multiply(correction).multiply(parentWorld)).normalize();
            limb.hand.updateWorldMatrix(false, true);
          }
        });
        // Interpolate owned joints from the authored pose, so a zero contact
        // weight does not replace its elbow pole. Slerp chooses the short path.
        const solved = authored.map(([bone, original]) => [bone, original, bone.quaternion.clone()]);
        for (const [bone, original, target] of solved) bone.quaternion.copy(original).slerp(target, blend);
        actor.updateMatrixWorld(true);
        drift = limbs.flatMap((limb, i) =>
          point3(targets[i]) && limb.hand ? [limb.hand.getWorldPosition(c).distanceTo(new THREE.Vector3(...targets[i]))] : []
        );
        return;
      }
      const position = actor.position.clone();
      const rotations = limbs
        .flatMap((limb) => [limb.upper, limb.lower, limb.hand])
        .filter(Boolean)
        .map((bone) => [bone, bone.quaternion.clone()]);
      const orientations = [];
      try {
        actor.position.fromArray(reference);
        this.solve(targets, weight);
        limbs.forEach((limb, i) => {
          if (point3(targets[i]) && limb.hand) orientations.push([limb.hand, limb.hand.getWorldQuaternion(new THREE.Quaternion())]);
        });
      } finally {
        actor.position.copy(position);
        for (const [bone, rotation] of rotations) bone.quaternion.copy(rotation);
        actor.updateMatrixWorld(true);
      }
      this.solve(targets, weight);
      for (const [hand, orientation] of orientations) {
        hand.parent.getWorldQuaternion(parent).invert();
        hand.quaternion.copy(parent.multiply(orientation).normalize());
        hand.updateWorldMatrix(false, true);
      }
      actor.updateMatrixWorld(true);
    },
    evidence: () => drift,
  };
}
