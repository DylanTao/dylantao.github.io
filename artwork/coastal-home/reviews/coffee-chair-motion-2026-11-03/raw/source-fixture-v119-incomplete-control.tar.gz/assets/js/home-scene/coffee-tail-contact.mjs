import * as THREE from "../three.module.min.js";
import { supportHeight } from "./shore.mjs";

const smooth = (u) => {
  const t = Math.max(0, Math.min(1, u));
  return t * t * t * (10 + t * (-15 + 6 * t));
};

function validMetadata(value) {
  return (
    value &&
    typeof value === "object" &&
    !Array.isArray(value) &&
    value.avatar === "lizard" &&
    Object.keys(value).every((key) => ["avatar", "tipPitch", "transitTipPitch", "seatedTipPitch", "turnBackX", "z", "floor", "floorBand"].includes(key)) &&
    (value.seatedTipPitch === undefined || Number.isFinite(value.seatedTipPitch) && Math.abs(value.seatedTipPitch) <= 0.35) &&
    (value.turnBackX === undefined || Array.isArray(value.turnBackX) && value.turnBackX.length === 2 && value.turnBackX.every(Number.isFinite) &&
      value.turnBackX[0] >= 0 && value.turnBackX[1] <= 1 && value.turnBackX[1] - value.turnBackX[0] >= 0.15) &&
    Number.isFinite(value.tipPitch) &&
    value.tipPitch >= 0 &&
    value.tipPitch <= 1.3 &&
    Number.isFinite(value.transitTipPitch) &&
    value.transitTipPitch >= 0 &&
    value.transitTipPitch <= 0.6 &&
    value.transitTipPitch <= value.tipPitch &&
    Array.isArray(value.z) &&
    value.z.length === 2 &&
    value.z.every(Number.isFinite) &&
    value.z[0] >= 4.8 &&
    value.z[1] <= 6.5 &&
    value.z[1] - value.z[0] >= 0.75 &&
    value.z[1] - value.z[0] <= 2 &&
    Number.isFinite(value.floor) &&
    value.floor >= -1 &&
    value.floor <= 1 &&
    Number.isFinite(value.floorBand) &&
    value.floorBand >= 0.1 &&
    value.floorBand <= 0.5
  );
}

// A measured distal bend for this delivered, two-joint flexible tail. Tail and
// its native garment join stay authored; only TailTip receives a reversible
// layer. Skin weights and segment lengths stay unchanged.
export function createCoffeeTailContact(actor, avatarId, metadata) {
  if (avatarId !== "lizard" || !validMetadata(metadata)) return null;
  let tail = null,
    tip = null;
  actor.traverse((bone) => {
    if (!bone.isBone) return;
    if (bone.name === "Tail") tail = bone;
    if (bone.name === "TailTip") tip = bone;
  });
  if (!tail || !tip || tip.parent !== tail || tail.parent?.name !== "Hips" || tip.position.length() < 0.3 || tip.position.length() > 0.6) return null;
  const points = [];
  actor.traverse((mesh) => {
    if (!mesh.isSkinnedMesh) return;
    const index = mesh.geometry.attributes.skinIndex,
      weights = mesh.geometry.attributes.skinWeight;
    for (let vertex = 0; vertex < mesh.geometry.attributes.position.count; vertex++) {
      let related = false;
      for (let channel = 0; channel < 4; channel++) {
        const bone = mesh.skeleton.bones[index.getComponent(vertex, channel)];
        if (weights.getComponent(vertex, channel) > 1e-9 && (bone === tail || bone === tip)) related = true;
      }
      if (related) points.push({ mesh, vertex });
    }
  });
  if (!points.length) return null;
  const config = { ...metadata, z: [...metadata.z], turnBackX: metadata.turnBackX ? [...metadata.turnBackX] : undefined },
    axis = new THREE.Vector3(1, 0, 0),
    offset = new THREE.Quaternion(),
    point = new THREE.Vector3(),
    rootPoint = new THREE.Vector3(),
    direction = new THREE.Vector3();
  let saved = null,
    disposed = false,
    last = { active: false, weight: 0, vertices: points.length, minimumFloorGap: null };
  return {
    restore() {
      if (!saved) return;
      tip.quaternion.copy(saved);
      saved = null;
      actor.updateMatrixWorld(true);
    },
    update({ active = false, moving = true, terrain, seatedWeight = 0, transferTipPitch } = {}) {
      if (disposed) return;
      if (!active) {
        this.restore();
        last = { active: false, weight: 0, vertices: points.length, minimumFloorGap: null };
        return;
      }
      const seated = Number.isFinite(seatedWeight) && seatedWeight >= 0 && seatedWeight <= 1 && config.seatedTipPitch !== undefined ? seatedWeight : 0;
      const transfer = Number.isFinite(transferTipPitch) && transferTipPitch >= 0 && transferTipPitch <= 1.3;
      // A newly selected paused avatar composes once; subsequent paused redraws
      // hold the delivered pose and its already-applied layer exactly.
      if (!moving && !((seated > 0 || transfer) && !saved)) return;
      const weight =
        smooth((actor.position.z - config.z[0]) / (config.z[1] - config.z[0])) *
        smooth((actor.position.y - config.floor + config.floorBand) / config.floorBand);
      if (weight === 0 && seated === 0 && !transfer) {
        last = { active: true, weight, vertices: points.length, minimumFloorGap: null };
        return;
      }
      saved = tip.quaternion.clone();
      // The tip needs a modest bend beside the stone counter during transit,
      // and a tighter bend when the body actually turns toward the coffee bar.
      // During a body handoff the hips can still face the bar while the actor's
      // navigation yaw has turned. Fit the actual root segment, not that aim.
      direction.copy(tip.getWorldPosition(point)).sub(tail.getWorldPosition(rootPoint));
      const planar = Math.hypot(direction.x, direction.z);
      const bodyBackX = planar > 1e-8 ? direction.x / planar : -Math.sin(actor.rotation.y);
      const heading = config.turnBackX ? smooth((bodyBackX - config.turnBackX[0]) / (config.turnBackX[1] - config.turnBackX[0])) : smooth((bodyBackX - 0.25) / 0.55);
      const bend = transfer ? transferTipPitch : (config.transitTipPitch + (config.tipPitch - config.transitTipPitch) * heading) * weight + (config.seatedTipPitch || 0) * seated * (1 - weight);
      tip.quaternion.multiply(offset.setFromAxisAngle(axis, bend));
      actor.updateMatrixWorld(true);
      let minimum = null;
      if (terrain?.supportSurfaces)
        for (const sample of points) {
          sample.mesh.getVertexPosition(sample.vertex, point).applyMatrix4(sample.mesh.matrixWorld);
          const height = supportHeight(point.x, point.z, terrain, actor.position.y, false),
            gap = point.y - height;
          if (!minimum || gap < minimum.gap) minimum = { gap, mesh: sample.mesh.name, vertex: sample.vertex, point: point.toArray(), height };
        }
      last = { active: true, weight, seatedWeight: seated, heading, headingSource: planar > 1e-8 ? "actual root segment" : "navigation fallback", bend, vertices: points.length, minimumFloorGap: minimum };
    },
    evidence: () => ({ ...last }),
    dispose() {
      this.restore();
      disposed = true;
      points.length = 0;
    },
  };
}
