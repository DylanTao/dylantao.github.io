import{T,root,q,base,config,scene,solids as originalSolids,surfaces as originalSurfaces,unresolved,loadNativeModel}from'./pavilion-contact-geometry-v28-current-cup.mjs';
import crypto from'node:crypto';
const d=new T.Vector3(0,0,0),keys=new Set(['core_estate_pavilion__pale oak:5',...[5,6,7,8,9].map(i=>'core_estate_pavilion__honey ash:'+i),'core_estate_pavilion__linen:1','core_estate_pavilion_breakfast_footrest_top__pale oak:0','core_estate_pavilion_breakfast_footrest_west__pale oak:0','core_estate_pavilion_breakfast_footrest_east__pale oak:0','core_estate_pavilion_breakfast_seatpad__linen:0','core_estate_pavilion_breakfast_lumbar_west__pale oak:0','core_estate_pavilion_breakfast_lumbar_east__pale oak:0','core_estate_pavilion_breakfast_lumbar_post_west__honey ash:0']),movement=[];
const bindings=[];
function moved(source){if(!keys.has(source.owner+":"+source.island))return source;
 const target={...source,box:source.box.clone(),bounds:source.bounds.map(p=>[...p]),triangles:source.triangles.map(h=>({...h,triangle:h.triangle.clone()})),
 ...(source.contains?{contains:p=>source.contains(p.clone().sub(d))}:{})};bindings.push({source,target});return target;
}
const surfaces=originalSurfaces.map(moved),solids=originalSolids.map(moved);
for(const source of originalSurfaces)if(keys.has(source.owner+":"+source.island)){const body=JSON.stringify(source.triangles.map(h=>[h.id,h.triangle.a.toArray(),h.triangle.b.toArray(),h.triangle.c.toArray()]));movement.push({owner:source.owner,island:source.island,triangles:source.triangles.length,sourceTriangleSha256:crypto.createHash("sha256").update(body).digest("hex"),oldBounds:source.bounds});}
if(movement.length!==14)throw Error("Exact14parts required");
function setChairOffset(value){if(!Number.isFinite(value)||value<0||value>.4)throw Error("Invalid diagnostic chair offset");d.z=value;
 for(const{source,target}of bindings){target.box.copy(source.box).translate(d);target.bounds=[target.box.min.toArray(),target.box.max.toArray()];
  for(let i=0;i<source.triangles.length;i++)for(const side of["a","b","c"])target.triangles[i].triangle[side].copy(source.triangles[i].triangle[side]).add(d);
 }
}
const movedSurfaces=surfaces.filter(s=>keys.has(s.owner+":"+s.island));
export{T,root,q,base,config,scene,solids,surfaces,unresolved,loadNativeModel,movement,setChairOffset,movedSurfaces};
