// Private anatomy/control only. No production API or sample reduction.
// Solve an actual rigid Hand-local surface point, retaining the sampled local
// wrist/fingers. The elbow is the feasible point nearest its sampled position.
export function solveHandEndpoint(T, upper, lower, hand, readPoint, target) {
  upper.updateWorldMatrix(true, true);
  const a=upper.getWorldPosition(new T.Vector3()),b=lower.getWorldPosition(new T.Vector3()),
    end=readPoint(),l1=a.distanceTo(b),l2=b.distanceTo(end),direction=target.clone().sub(a),
    asked=direction.length(),maximum=l1+l2,minimum=Math.abs(l1-l2),
    saved=[upper,lower,hand].map(b=>[b,b.quaternion.clone()]),localHand=hand.quaternion.clone();
  if(!Number.isFinite(asked)||asked<=minimum+1e-7||asked>=maximum-1e-7)
    return {pass:false,reason:'actual-endpoint-unreachable',asked,minimum,maximum};
  direction.normalize();
  const along=(l1*l1-l2*l2+asked*asked)/(2*asked),pole=b.clone().sub(a);
  pole.addScaledVector(direction,-pole.dot(direction));
  if(pole.lengthSq()<1e-16)return{pass:false,reason:'undefined-native-elbow-plane',asked,minimum,maximum};
  pole.normalize();
  const elbow=a.clone().addScaledVector(direction,along)
    .addScaledVector(pole,Math.sqrt(Math.max(0,l1*l1-along*along)));
  function aim(bone,read,wanted){
    const pivot=bone.getWorldPosition(new T.Vector3()),from=read().sub(pivot).normalize(),
      to=wanted.clone().sub(pivot).normalize(),delta=new T.Quaternion().setFromUnitVectors(from,to),
      parent=bone.parent.getWorldQuaternion(new T.Quaternion()).normalize();
    bone.quaternion.premultiply(parent.clone().invert().multiply(delta).multiply(parent)).normalize();
    bone.updateWorldMatrix(false,true);
  }
  aim(upper,()=>lower.getWorldPosition(new T.Vector3()),elbow);
  aim(lower,readPoint,target);
  const error=readPoint().distanceTo(target);
  if(error>1e-6||!hand.quaternion.equals(localHand)){
    for(const[bone,q]of saved)bone.quaternion.copy(q);
    upper.updateWorldMatrix(true,true);
    return{pass:false,reason:'actual-point-or-local-wrist-residual',error,asked,minimum,maximum};
  }
  return{pass:true,error,asked,minimum,maximum,elbow:lower.getWorldPosition(new T.Vector3()).toArray(),
    localWristPreserved:true};
}
