import fs from 'node:fs';import crypto from 'node:crypto';
export const modelReads=[];export function boundRead(file,baseUrl){const url=new URL(file,baseUrl),bytes=fs.readFileSync(url);modelReads.push({url:url.href,sha256:crypto.createHash('sha256').update(bytes).digest('hex'),bytes:bytes.length});return bytes;}
