// Read-only QA. Actual finite delivered triangles and actual current hand points.
// No hand-volume claim or face/vertex omission. The box guard only admits more
// work around rounding boundaries; it does not relax the physical gap gate.
export function signedHandRailDistance(T,points,rail,faces,{reference=false}={}) {
  if(!points.length||!faces.length||!rail?.closed||typeof rail.contains!=="function")throw Error("Nonempty actual hand and closed rail required");
  let best=Infinity,witness=null,verticesQueried=0,triangleTests=0,parityQueries=0;
  const guard=1e-10;
  for(const row of points){
    const p=row.p;
    if(!reference&&best>=0&&rail.box.distanceToPoint(p)>best+guard)continue;
    if(!reference&&best<0&&!rail.box.containsPoint(p))continue;
    verticesQueried++;
    const inside=rail.box.containsPoint(p)&&(parityQueries++,rail.contains(p));
    if(!reference&&best<0&&!inside)continue;
    let distance=Infinity,near=null,face=null;
    for(const f of faces){
      if(!reference&&f.box.distanceToPoint(p)>distance+guard)continue;
      triangleTests++;
      const at=f.triangle.closestPointToPoint(p,new T.Vector3()),d=at.distanceTo(p);
      if(d<distance){distance=d;near=at;face=f.id;}
    }
    const signed=inside?-distance:distance;
    if(signed<best){best=signed;witness={mesh:row.mesh,vertex:row.vertex,p:p.toArray(),face,near:near.toArray(),inside,distanceM:distance};}
  }
  if(!Number.isFinite(best)||!witness)throw Error("Missing actual finite hand/rail distance");
  return{minimumSignedM:best,witness,verticesInput:points.length,railFaces:faces.length,
    verticesQueried,triangleTests,parityQueries,broadphaseGuardM:reference?0:guard};
}
