import {triangleDistance} from './finite-triangle-distance.mjs';

// Exact finite triangles with a refitted hierarchy. It retains every delivered
// face; only native shared-vertex neighbours are excluded as attached surface.
export function createPosedSelfContact(T, meshes) {
 const faces=[];
 for(const p of meshes){const geometry=p.mesh.geometry,a=geometry.attributes.position,index=geometry.index,keys=[];
  for(const vertex of p.vertices){const base=new T.Vector3().fromBufferAttribute(a,vertex.id).applyMatrix4(p.mesh.bindMatrix);keys.push([...base.toArray(),...p.mesh.bindMatrixInverse.elements,...vertex.influences.toSorted((a,b)=>a.bone.localeCompare(b.bone)).flatMap(c=>[c.bone,c.weight])].join(','));}
  for(let i=0;i<(index?.count??a.count);i+=3){const ids=[0,1,2].map(k=>index?index.getX(i+k):i+k),points=ids.map(v=>p.mesh.getVertexPosition(v,new T.Vector3()).applyMatrix4(p.mesh.matrixWorld)),box=new T.Box3().setFromPoints(points);faces.push({global:faces.length,mesh:p.mesh.name,plan:p,face:i/3,ids,keys:ids.map(i=>keys[i]),tail:ids.some(i=>p.vertices[i].tail),points,box,center:box.getCenter(new T.Vector3())});}
 }
 function build(items){const box=new T.Box3();for(const f of items)box.union(f.box);if(items.length<=12)return{box,items};const size=box.getSize(new T.Vector3()),axis=size.x>=size.y&&size.x>=size.z?'x':size.y>=size.z?'y':'z';items.sort((a,b)=>a.center[axis]-b.center[axis]);const k=items.length>>1;return{box,left:build(items.slice(0,k)),right:build(items.slice(k))};}
 const tree=build([...faces]),tails=faces.filter(f=>f.tail);
 function refit(node){node.box.makeEmpty();if(node.items){for(const f of node.items)node.box.union(f.box);}else{refit(node.left);refit(node.right);node.box.union(node.left.box).union(node.right.box);}}
 return{
  counts:{faces:faces.length,tailRelatedFaces:tails.length,excludedPairRule:'Exact common native bind-position, inverse-bind and joint/weight signature; all other finite triangles remain.'},
  measure(posed){for(const f of faces){f.points=f.ids.map(i=>posed.get(f.plan)[i]);f.box.setFromPoints(f.points);}refit(tree);let count=0,neighbours=0,queries=0;const hits=[],pairs=[];
   for(const f of tails){const triangle=new T.Triangle(...f.points),stack=[tree];while(stack.length){const node=stack.pop();if(!node.box.intersectsBox(f.box))continue;if(node.items){for(const g of node.items){if(g.global===f.global||(g.tail&&g.global<f.global)||!g.box.intersectsBox(f.box))continue;if(f.keys.some(k=>g.keys.includes(k))){neighbours++;continue;}queries++;const hit=triangleDistance(T,triangle,new T.Triangle(...g.points));if(hit.distanceSquared<1e-24){count++;pairs.push({tailMesh:f.mesh,tailFace:f.face,tailVertices:f.ids,otherMesh:g.mesh,otherFace:g.face,otherVertices:g.ids,otherTail:g.tail});if(hits.length<200)hits.push({tail:{mesh:f.mesh,face:f.face,vertices:f.ids,p:f.points.map(p=>p.toArray())},other:{mesh:g.mesh,face:g.face,vertices:g.ids,tail:g.tail,p:g.points.map(p=>p.toArray())},hit});}}}else stack.push(node.left,node.right);}}
   return{count,queries,nativeSharedVertexPairs:neighbours,storedWitnessCap:200,pairs,hits};
  }
 };
}
