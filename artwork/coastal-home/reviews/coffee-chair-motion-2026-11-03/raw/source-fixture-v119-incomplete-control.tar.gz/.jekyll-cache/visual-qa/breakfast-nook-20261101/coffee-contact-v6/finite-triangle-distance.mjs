export function boxDistanceSquared(a,b){let sum=0;for(const k of ['x','y','z']){const gap=Math.max(0,a.min[k]-b.max[k],b.min[k]-a.max[k]);sum+=gap*gap;}return sum;}

export function triangleDistance(T,A,B){
 const av=[A.a,A.b,A.c],bv=[B.a,B.b,B.c],temp=new T.Vector3();let best=null;
 function keep(a,b,kind){const d=a.distanceToSquared(b);if(!Number.isFinite(d))throw Error('Nonfinite triangle distance');if(!best||d<best.distanceSquared)best={distanceSquared:d,a:a.toArray(),b:b.toArray(),kind};}
 for(const [left,right,reverse]of[[av,B,false],[bv,A,true]])for(let i=0;i<3;i++){
  const a=left[i],b=left[(i+1)%3],direction=b.clone().sub(a),length=direction.length();
  if(length){const p=new T.Ray(a,direction.divideScalar(length)).intersectTriangle(right.a,right.b,right.c,false,temp);if(p&&p.distanceToSquared(a)<=length*length){return{distanceSquared:0,a:p.toArray(),b:p.toArray(),kind:reverse?'hardware-edge/skin-face':'skin-edge/hardware-face'};}}
 }
 if(B.getArea()>0)for(const p of av){B.closestPointToPoint(p,temp);keep(p,temp,'skin-vertex/hardware-face');}
 if(A.getArea()>0)for(const p of bv){A.closestPointToPoint(p,temp);keep(temp,p,'hardware-vertex/skin-face');}
 for(let i=0;i<3;i++)for(let j=0;j<3;j++){
  const p=av[i],q=bv[j],d1=av[(i+1)%3].clone().sub(p),d2=bv[(j+1)%3].clone().sub(q),r=p.clone().sub(q),a=d1.lengthSq(),e=d2.lengthSq(),f=d2.dot(r);let s=0,t=0;
  if(a===0&&e===0){keep(p,q,'point/point');continue;}
  if(a===0)t=Math.max(0,Math.min(1,f/e));
  else{const c=d1.dot(r);if(e===0)s=Math.max(0,Math.min(1,-c/a));else{const b=d1.dot(d2),den=a*e-b*b;if(den>0)s=Math.max(0,Math.min(1,(b*f-c*e)/den));t=(b*s+f)/e;if(t<0){t=0;s=Math.max(0,Math.min(1,-c/a));}else if(t>1){t=1;s=Math.max(0,Math.min(1,(b-c)/a));}}}
  keep(p.clone().addScaledVector(d1,s),q.clone().addScaledVector(d2,t),'finite-edge/finite-edge');
 }
 return best;
}

export function calibrateTriangleDistance(T){
 const t=(a,b,c)=>new T.Triangle(new T.Vector3(...a),new T.Vector3(...b),new T.Vector3(...c));
 const A=t([0,0,0],[2,0,0],[0,2,0]);
 const tests=[['parallel2mm',A,t([0,0,.002],[2,0,.002],[0,2,.002]),.002],['facePiercing',A,t([.5,.5,-1],[.5,.5,1],[1.5,.5,1]),0],['coplanarOverlap',A,t([.25,.25,0],[.75,.25,0],[.25,.75,0]),0],['separateFiniteEdges',A,t([3,0,0],[4,0,0],[3,1,0]),1],['zeroAreaPoint',A,t([.5,.5,1],[.5,.5,1],[.5,.5,1]),1]];
 return tests.map(([name,a,b,want])=>{const r=triangleDistance(T,a,b),actual=Math.sqrt(r.distanceSquared);if(Math.abs(actual-want)>1e-12)throw Error(name+' '+actual);return{name,actual,expected:want,passed:true};});
}
