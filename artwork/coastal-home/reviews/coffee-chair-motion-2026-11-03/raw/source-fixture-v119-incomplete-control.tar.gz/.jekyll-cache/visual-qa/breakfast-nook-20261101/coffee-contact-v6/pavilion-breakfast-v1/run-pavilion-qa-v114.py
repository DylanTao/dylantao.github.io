import pathlib,subprocess,os,sys,json,datetime,hashlib,time
q=pathlib.Path(__file__).resolve().parent; root=pathlib.Path.cwd(); label=sys.argv[1]
process_file=q/(label+'-PROCESS.json'); assert not process_file.exists()
log=q/(label+'.log'); assert not log.exists()
files=list((root/'assets/js/home-scene').glob('*.mjs'))+[q/'audit-coffee-chair-motion-v114-original-reference.mjs',q/'pavilion-contact-geometry-v51-current-withdraw.mjs',q/'PAVILION-CURRENT-WITHDRAW-V51.json',q/'hand-endpoint-ik-v86.mjs',q/'hand-rail-distance-v96.mjs',q/'actual-dining-pull-v103.mjs']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={str(p):sha(p) for p in files}; started=datetime.datetime.now(datetime.timezone.utc).isoformat(); clock=time.monotonic()
command=['node',str(q/'audit-coffee-chair-motion-v114-original-reference.mjs')]; exception=None; code=None
try:
 with log.open('wb') as stream: code=subprocess.run(command,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,timeout=1800).returncode
except BaseException as exc: exception={'type':type(exc).__name__,'message':str(exc)}
after={str(p):sha(p) for p in files}; receipt={'startedUTC':started,'endedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wallSeconds':time.monotonic()-clock,'command':command,'cwd':str(root),'environment':{k:v for k,v in os.environ.items() if k.startswith('COFFEE_')},'exitCode':code,'exception':exception,'sourceBefore':before,'sourceAfter':after,'sourceUnchanged':before==after,'logSHA256':sha(log),'scope':'Actual Node process status, numerical functional contact only; no renderer or performance admission.'}
process_file.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k] for k in ['exitCode','exception','sourceUnchanged','wallSeconds']}));sys.exit(0 if code==0 and exception is None and before==after else 1)
