import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {nativeGeometry} from '../bound-native-geometry-v1.mjs';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
export async function actualDiningPull({T,root,q,base,config,coffee,scene,cupObject}){
 const priorDocument=globalThis.document;assert.equal(priorDocument,undefined,'Isolated headless DOM-class fixture only');globalThis.document={documentElement:{classList:{contains:name=>name==='is-world-immersive'}}};
 const {createDining}=await import(pathToFileURL(path.join(root,'assets/js/home-scene/dining.mjs'))),
       {coffeeTimeline}=await import(pathToFileURL(path.join(root,'assets/js/home-scene/activities.mjs'))),
       indexFile=path.join(base,'table-setting/index.json'),indexBytes=fs.readFileSync(indexFile),index=JSON.parse(indexBytes),
       configured=structuredClone(config),modelBodies=[],loaded=new Map();
 configured.equipment.coffee=structuredClone(coffee);
 const routine={id:'breakfast',...configured.activities.breakfast,dateKey:'2026-11-03',minute:735,live:false},
       kitchen=scene.children.find(g=>g.userData.sourceFile==='room-kitchen.glb');assert.ok(kitchen);
 const dining=createDining({config:configured,baseUrl:'https://fixture.test/assets/models/home/manifest.json',
  venueRoot:id=>id==='pavilion'?scene:null,roomRoot:id=>id==='kitchen'?kitchen:null,
  fetchIndex:async()=>index,
  loadModel:async url=>{const file='table-setting/'+new URL(url).pathname.split('/').at(-1);if(!loaded.has(file)){
    const at=path.join(base,file),bytes=fs.readFileSync(at);modelBodies.push({file,sha256:sha(bytes),bytes:bytes.length});
    loaded.set(file,nativeGeometry(file,pathToFileURL(base)));}return{scene:await loaded.get(file)};}});
 for(let i=0;i<200&&!(dining.evidence().ready&&dining.evidence().level===1);i++){dining.pose({routine,actor:null,seconds:0});await new Promise(resolve=>setImmediate(resolve));}
 assert.ok(dining.evidence().ready,'Actual complete Dining did not become ready');dining.props({cup:cupObject});scene.updateMatrixWorld(true);
 const initial=dining.evidence();assert.equal(initial.level,1,'Fine actual tableware required');assert.ok(modelBodies.length>0);
 let maximumLocalDelta=0,minimumSeparationM=Infinity,frames=0;
 const localSnapshot=actor=>{const rows=[];actor.traverse(b=>{if(b.isBone)rows.push([b.name,b.position.toArray(),b.quaternion.toArray(),b.scale.toArray()]);});return rows;};
 const worldFrame=o=>({position:o.getWorldPosition(new T.Vector3()).toArray(),quaternion:o.getWorldQuaternion(new T.Quaternion()).normalize().toArray()});
 return{dining,clockStart:coffeeTimeline(coffee).table-12.2,
  pose(actor,seconds,sequencePose){const before=localSnapshot(actor),meal=dining.pose({routine,actor,sequencePose,seconds:coffeeTimeline(coffee).table-12.2+seconds,moving:true,paused:false,reduced:false,walking:false,travel:false});
   const after=localSnapshot(actor);assert.deepEqual(after,before,'Pre-table real Dining changed the intended complete pose');assert.equal(meal,null,'Pull must remain before seated Dining');return{actualSessionSeconds:coffeeTimeline(coffee).table-12.2+seconds,tableSeconds:coffeeTimeline(coffee).table,returnedPhase:meal};},
  props(actor,bodyPoints,seconds){const expected=worldFrame(cupObject);dining.props({cup:cupObject});scene.updateMatrixWorld(true);const actual=worldFrame(cupObject);
   const positionErrorM=new T.Vector3(...expected.position).distanceTo(new T.Vector3(...actual.position)),rotationErrorRad=2*Math.acos(Math.min(1,Math.abs(new T.Quaternion(...expected.quaternion).dot(new T.Quaternion(...actual.quaternion)))));assert.ok(positionErrorM<=1e-6&&rotationErrorRad<=1e-6,'Actual Dining moved the sequence-owned held cup');
   const bodyBox=new T.Box3();for(const points of bodyPoints.values())for(const p of points)bodyBox.expandByPoint(p);
   const cupBox=new T.Box3().setFromObject(cupObject,true),visible=[];scene.traverse(o=>{if(!o.isMesh||!o.userData.diningProp)return;for(let p=o;p;p=p.parent)if(!p.visible)return;visible.push(o);});assert.ok(visible.length>=5,'Nonempty actual visible full Dining roster required');
   const rows=[];let faces=0;
   for(const mesh of visible){const box=new T.Box3().setFromObject(mesh,true),faceCount=(mesh.geometry.index?.count??mesh.geometry.attributes.position.count)/3;assert.ok(faceCount>0);faces+=faceCount;const disjointBody=!box.intersectsBox(bodyBox),disjointCup=!box.intersectsBox(cupBox),gap=(a,b)=>Math.sqrt(['x','y','z'].reduce((s,k)=>s+Math.max(0,a.min[k]-b.max[k],b.min[k]-a.max[k])**2,0)),separationM=Math.min(gap(box,bodyBox),gap(box,cupBox));
    rows.push({name:mesh.name,faces:faceCount,bounds:[box.min.toArray(),box.max.toArray()],disjointBody,disjointCup,separationM});
    if(!disjointBody||!disjointCup){const file=path.join(q,'DINING-V102-FIRST-OVERLAP-'+actor.name.replace(/[^a-z0-9-]/gi,'_')+'-'+String(seconds).replace('.','_')+'.json');if(!fs.existsSync(file))fs.writeFileSync(file,JSON.stringify({seconds,bodyBounds:[bodyBox.min.toArray(),bodyBox.max.toArray()],cupBounds:[cupBox.min.toArray(),cupBox.max.toArray()],row:rows.at(-1),evidence:dining.evidence()},null,2));throw Error('Actual visible tableware overlaps body/cup conservative box; full finite fallback required, not waived: '+mesh.name);}
    minimumSeparationM=Math.min(minimumSeparationM,separationM);
   }
   assert.ok(faces>0);frames++;return{expectedSequenceCup:expected,actualCup:actual,positionErrorM,rotationErrorRad,actualDiningOwnership:dining.coffeeOwnership(actor),visibleMeshes:rows,visibleFaces:faces,bodyBounds:[bodyBox.min.toArray(),bodyBox.max.toArray()],cupBounds:[cupBox.min.toArray(),cupBox.max.toArray()]};},
  evidence:()=>({scope:'Complete actual highest-level tableware/source Dining called on every pull frame; all actual visible tableware conservative world bounds must be disjoint from whole actual body and held-cup bounds. Any overlap fails pending full finite fallback; no hidden props or empty-target pass. Before-table Dining is explicitly proved not to modify any local bone or sequence-owned cup. This does not establish seated meal, transition or final runtime choreography.',index:{file:indexFile,sha256:sha(indexBytes),bytes:indexBytes.length},modelBodies,configSHA256:sha(JSON.stringify(configured)),headlessDOMClassFixture:'is-world-immersive true; actual production immersive() path, not a browser or an injected nonexistent factory option',actualClockStart:coffeeTimeline(coffee).table-12.2,tableSeconds:coffeeTimeline(coffee).table,actualDining: dining.evidence(),frames,maximumLocalDelta,minimumSeparationM}),dispose:()=>{dining.dispose();delete globalThis.document;}};
}
