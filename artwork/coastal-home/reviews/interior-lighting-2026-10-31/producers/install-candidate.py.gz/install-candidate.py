import hashlib,json
from pathlib import Path
q=Path(__file__).parent;root=q.parents[2]
name='assets/js/home-scene/light-installations.mjs'
target=q/'site/al-folio'/name
original=q/'baseline-light-installations.mjs'
if original.exists():raise RuntimeError('Preserve baseline custody')
original.write_bytes(target.read_bytes())
target.write_text((root/name).read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
changes=[]
for row in json.loads((q/'compiled-baseline.json').read_text())['files']:
    p=q/'site/al-folio'/row['path'];b=p.read_bytes();sha=hashlib.sha256(b).hexdigest()
    if sha!=row['sha256']:changes.append({'path':row['path'],'before':row['sha256'],'after':sha,'bytes':len(b)})
assert [r['path']for r in changes]==[name]
(q/'preview-substitution.json').write_text(json.dumps({'changes':changes,'scope':'Exactly one schedule module; every source/region/intensity/shader and all1360other compiled bytes retained from complete4156candidate'},indent=2)+'\n',encoding='utf-8')
print(json.dumps(changes))
