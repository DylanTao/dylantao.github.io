import json
from pathlib import Path
import numpy as np
from PIL import Image
q=Path(__file__).parent
rows=[]
for folder,kind in [(q/'receiver-controls','gym-repair'),(q/'cage-v1/captures','rejected-cage-v1'),(q/'cage-v2-captures','rejected-cage-v2')]:
    captures=json.loads((folder/'captures.json').read_text())
    for cand in [r for r in captures if r['variant']=='candidate']:
        base=next(r for r in captures if r['variant']=='baseline'and r['room']==cand['room']and r['label']==cand['label'])
        before=np.asarray(Image.open(folder/base['file']).convert('RGB'),dtype=np.int16)
        after=np.asarray(Image.open(folder/cand['file']).convert('RGB'),dtype=np.int16)
        delta=np.abs(after-before)
        rois={'leftChairBack':(900,900,1190,1060)}if cand['room']=='library-upper'and cand['label']!='noon-body'else{}
        rows.append({'experiment':kind,'room':cand['room'],'label':cand['label'],
         'cameraBefore':base['evidence']['camera'],'cameraAfter':cand['evidence']['camera'],
         'changedPixels':int(np.count_nonzero(delta.max(axis=2))),'maximumChannelDifference':int(delta.max()),
         'rois':{name:{'bounds':box,'meanRGBBefore':before[box[1]:box[3],box[0]:box[2]].mean(axis=(0,1)).tolist(),
                        'meanRGBAfter':after[box[1]:box[3],box[0]:box[2]].mean(axis=(0,1)).tolist()}for name,box in rois.items()},
         'scope':'Raw matched captures; includes legitimate changedshading/reflections and possible capture timing. No aesthetic score or unrelatedpixelthresholdwaiver.'})
(q/'view-comparisons.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
print(json.dumps([r for r in rows if r['rois']],indent=2))
