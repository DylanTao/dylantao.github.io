import copy,hashlib,json,shutil
from pathlib import Path
q=Path(__file__).parent;site=q/'site/al-folio/assets/models/home'
out=q/'cage-baseline-products'
if out.exists():raise RuntimeError('Preserve official baseline products')
out.mkdir()
for name in ['manifest.json','static-light-field.json']:shutil.copy2(site/name,out/name)
before=json.loads((site/'manifest.json').read_text())
after=copy.deepcopy(before)
room=next(r for r in after['rooms']if r['id']=='library-upper')
assert room['lightRegion']=={'min':[-1.65,2.55,10.25],'max':[1.3,4.7,12.55]}
room['lightRegion']['max'][2]=14.1
def differences(a,b,p=''):
    if type(a)!=type(b):return[p]
    if isinstance(a,dict):return sum((differences(a[k],b[k],p+'/'+k)for k in a),[])
    if isinstance(a,list):return sum((differences(x,y,p+'/'+str(i))for i,(x,y)in enumerate(zip(a,b))),[])
    return[]if a==b else[p]
changed=differences(before,after)
assert len(changed)==1 and changed[0].endswith('/lightRegion/max/2')
(site/'manifest.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf-8',newline='\n')
(q/'cage-trial-precondition.json').write_text(json.dumps({'changed':changed,'before':before['rooms'][after['rooms'].index(room)]['lightRegion'],'after':room['lightRegion'],
 'reason':'Native chair backs reachworldz12.39; every oldprobe isseawardatz<=11.975. Actual authoredrearaisle/egressreaches14.1. Same16regions/128probes/28practicals. Positive dimtransport, notzeroweightblackout.'},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'changed':changed,'trial':room['lightRegion']}))
