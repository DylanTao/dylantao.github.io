const fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url');
const q=__dirname;
(async()=>{
 const {createStaticLightField}=await import(pathToFileURL(path.resolve(q,'../../../assets/js/home-scene/static-light-field.mjs')).href);
 const name=process.argv[2],file=name==='baseline'?path.join(q,'cage-baseline-products/static-light-field.json'):name==='v1'?path.join(q,'cage-v1/static-light-field.json'):path.join(q,'site/al-folio/assets/models/home/static-light-field.json');
 const snap=JSON.parse(fs.readFileSync(file,'utf8')),config=JSON.parse(snap.configuration),field=createStaticLightField(config);
 if(!field.restoreSnapshot(snap,{signature:snap.signature}))throw Error('Snapshot restore failed');
 field.setLighting({zenith:[1,1,1],horizon:[1,1,1],ground:[.2,.2,.2],practicalPowers:config.practicalSources.map(()=>0)});
 const native=JSON.parse(fs.readFileSync(path.join(q,'private-native.json'),'utf8'));
 const rows=native.chairBackIslands.flatMap(back=>back.rearFaceWitnesses.map(f=>({...f,sample:field.sample(f.worldPoint,f.worldNormal)})));
 const out={name,sourceCache:file,signature:snap.signature,scope:'Read-only actual restoredtransport; unitwhitesky,0.2ground,allpracticalszero. Controlledsamplerdiagnostic,notactualscenephotometry.',region:config.regions.find(r=>r.id==='library-upper'),probes:field.evidence().probes.filter(p=>p.region==='library-upper'),statistics:snap.statistics,rows};
 fs.writeFileSync(path.join(q,`private-field-${name}.json`),JSON.stringify(out,null,2));console.log(JSON.stringify({name,region:out.region,validPrivateProbes:out.probes.filter(p=>p.valid).length,rows:rows.map(r=>({point:r.worldPoint,red:r.sample.irradiance[0],weight:r.sample.weight}))}));field.dispose();
})().catch(e=>{console.error(e);process.exitCode=1});
