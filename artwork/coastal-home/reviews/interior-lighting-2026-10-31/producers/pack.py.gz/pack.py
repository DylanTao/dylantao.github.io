import gzip,hashlib,json,subprocess,sys
from pathlib import Path
root=Path.cwd();q=Path(__file__).parent;out=root/'artwork/coastal-home/reviews/interior-lighting-2026-10-31'
out.mkdir(parents=True,exist_ok=True)
def copy(src,target,packed=True):
    p=out/target;p.parent.mkdir(parents=True,exist_ok=True);b=src.read_bytes();p.write_bytes(gzip.compress(b,mtime=0)if packed else b)
if '--seal-only'not in sys.argv:
    for name in ['compiled-baseline','official-bake-input-custody','view-comparisons','restored-preview','private-native',
                 'private-field-baseline','private-field-v1','private-field-v2','cage-trial-precondition','cage-v2-precondition']:
        copy(q/(name+'.json'),'data/'+name+'.json.gz')
    copy(q/'receiver-controls/captures.json','data/gym-captures.json.gz')
    copy(q/'cage-v1/captures/captures.json','data/rejected-cage-v1-captures.json.gz')
    copy(q/'cage-v2-captures/captures.json','data/rejected-cage-v2-captures.json.gz')
    for name in ['manifest.json','static-light-field.json']:
        copy(q/'cage-baseline-products'/name,'controls/baseline-'+name+'.gz')
        copy(q/'cage-v1'/name,'rejected/v1-'+name+'.gz')
        copy(q/'cage-v2-products'/name,'rejected/v2-'+name+'.gz')
    for variant in ['baseline','candidate']:
        for label in ['noon','evening','noon-body']:
            copy(q/'receiver-controls'/f'{variant}-{label}-gym.png',f'views/gym/{variant}-{label}.png',False)
    for variant in ['baseline','candidate']:
        for label in ['noon','evening','noon-body']:
            copy(q/'cage-v2-captures'/f'{variant}-{label}-library-upper.png',f'views/private-v2/{variant}-{label}.png',False)
    for label in ['noon','evening']:
        copy(q/'cage-v1/captures'/f'candidate-{label}-library-upper.png',f'views/rejected-private-v1/{label}.png',False)
    for name in ['capture.cjs','capture-cage.cjs','capture-cage-v2.cjs','prepare-cage-capture.py','capture-public.cjs',
                 'prepare-preview.py','install-candidate.py','install-receivers.py','prepare-bake.py','prepare-cage-trial.py',
                 'prepare-cage-v2.py','private-native.py','sample-cache.cjs','restore-accepted-preview.py','compare-views.py','serve.py','pack.py']:
        copy(q/name,'producers/'+name+'.gz')
    for name in ['unit-tests.log','unit-receivers.log','unit-receivers-fixed.log','node-all.log','node-all-with-deps.log',
                 'style-contract.log','npm-ci.log','capture-receivers.log','capture-cage.log','capture-cage-v2.log',
                 'bake-baseline.log','bake-cage-trial.log','bake-cage-v2.log','public-chromium.log','public-webkit.log']:
        copy(q/name,'logs/'+name+'.gz')
    for name in ['baseline-light-installations.mjs','baseline-gym-props.mjs']:
        copy(q/name,'controls/'+name+'.gz')
    for name in ['assets/js/home-scene/controller.mjs','assets/js/home-scene/light-installations.mjs','assets/js/home-scene/gym-props.mjs']:
        copy(q/'site/al-folio'/name,'compiled/'+Path(name).name+'.gz')
    bindings=[]
    for name in ['assets/js/home-scene/light-installations.mjs','assets/js/home-scene/gym-props.mjs',
                 'test/light-installations.test.mjs','test/light-installation-receivers.test.mjs','test/gym-props-materials.test.mjs',
                 'bin/bake_coastal_static_light.cjs','bin/coastal_static_light_inputs.cjs','assets/js/home-scene/static-light-field.mjs',
                 'artwork/coastal-home/coastal-home.blend']:
        b=subprocess.run(['git','show','b636e67c6:'+name],check=True,stdout=subprocess.PIPE).stdout
        bindings.append({'path':name,'gitBlobSha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
    (out/'SOURCE_BINDINGS.json').write_text(json.dumps({'sourceCommit':'b636e67c6','sourceBindings':bindings,
       'compiledScope':'Complete1360-file70ee4eac5site and two accepted hardware/leafGLBs; only owninggym modules change. Officialcache/manifest controls isolated and rejectedcages restored.',
       'nativeMasterSha256':hashlib.sha256((root/'artwork/coastal-home/coastal-home.blend').read_bytes()).hexdigest(),
       'publication':'None. Current-root fullsuite and officialcombinedcache remain required.'},indent=2)+'\n',encoding='utf-8',newline='\n')
payloads=[]
for file in sorted(out.rglob('*')):
    if not file.is_file()or file.name=='MANIFEST.json':continue
    b=file.read_bytes();payloads.append({'path':file.relative_to(out).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(out/'MANIFEST.json').write_text(json.dumps({'schema':1,'scope':'Boundedgymreceiver/visit repair and explicitly rejected privatecage experiments; finalcoordinatorintegration/cachegates remain','files':payloads},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'payloads':len(payloads),'bytes':sum(r['bytes']for r in payloads)}))
