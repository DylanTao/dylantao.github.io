from pathlib import Path
import hashlib,json,shutil
q=Path(__file__).parent
src=q.parent/'interior-finish-20261031/site/al-folio'
dst=q/'site/al-folio'
if dst.exists():raise RuntimeError('Preserve existing preview custody')
shutil.copytree(src,dst)
rows=[]
for file in sorted(src.rglob('*')):
    if not file.is_file():continue
    rel=file.relative_to(src);b=file.read_bytes()
    assert (dst/rel).read_bytes()==b
    rows.append({'path':rel.as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(q/'compiled-baseline.json').write_text(json.dumps({'source':str(src),'scope':'Exact sealed70runtime and two whole accepted hardware/leafGLBs; cache remains pre-final','files':rows},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'files':len(rows),'bytes':sum(x['bytes']for x in rows)}))
