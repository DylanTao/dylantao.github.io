const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {chromium,expect}=require('C:/dev/dylantao.github.io/node_modules/@playwright/test');
const {preparePage,collectRuntimeErrors,screenshotMetrics}=require('../../../test/visual/helpers.js');
const q=__dirname,rows=[],width=2560,height=1440,sha=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
 try{for(const variant of ['baseline','candidate']){
  const context=await browser.newContext({viewport:{width,height},deviceScaleFactor:1,reducedMotion:'reduce',timezoneId:'America/Los_Angeles'});
  const page=await context.newPage(),errors=collectRuntimeErrors(page);page.setDefaultTimeout(90000);
  await preparePage(page,'light');await page.clock.setFixedTime(new Date('2026-10-29T12:00:00-07:00'));
  if(variant==='baseline')await page.route('**/assets/js/home-scene/light-installations.mjs',r=>r.fulfill({path:path.join(q,'baseline-light-installations.mjs'),contentType:'text/javascript'}));
  if(variant==='baseline')await page.route('**/assets/js/home-scene/gym-props.mjs',r=>r.fulfill({path:path.join(q,'baseline-gym-props.mjs'),contentType:'text/javascript'}));
  await page.goto('http://127.0.0.1:4159/al-folio/?scene-lab=1&quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});
  await page.locator('[data-home-desk-mode="3d"]').click();
  const host=page.locator('[data-home-desk-scene]'),canvas=host.locator('canvas'),ui=page.locator('[data-home-world-controls]'),details=ui.locator('details').first();
  const open=async()=>{if(!await details.evaluate(e=>e.open))await details.locator('summary').first().click()};
  const close=async()=>{if(await details.evaluate(e=>e.open))await details.locator('summary').first().click()};
  await host.scrollIntoViewIfNeeded();await expect(host).toHaveAttribute('data-scene-state','ready',{timeout:180000});
  await open();await ui.locator('[data-world-avatar]').selectOption('ghibli');
  await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().avatarId)).toBe('ghibli');await expect(ui).not.toHaveAttribute('aria-busy','true');
  await ui.locator('[data-world-fullscreen]').click();await ui.locator('[data-world-view]').click();
  await expect.poll(()=>host.evaluate(e=>['clifftop-flora','coastal-hinterland'].every(n=>e.labScene.scene.getObjectByName(n)?.visible)),{timeout:180000}).toBe(true);
  async function capture(room,label,scope){
   await close();
   const frame=await host.evaluate((e,room)=>{
    const probe=window.__lightReadback={saved:[],draws:[],limit:new Set()};
    e.labScene.scene.getObjectByName('room-'+room)?.traverse(o=>{
     if(!o.isMesh)return;
     const old=o.onAfterRender;
     const observer=function(renderer,scene,camera,geometry,material,...rest){
      old.call(this,renderer,scene,camera,geometry,material,...rest);
      const key=this.uuid+'|'+material.uuid;if(probe.limit.has(key))return;probe.limit.add(key);
      const gl=renderer.getContext(),program=renderer.properties.get(material).currentProgram;
      const read=name=>{if(!program)return null;const loc=gl.getUniformLocation(program.program,name);if(loc===null)return null;const value=gl.getUniform(program.program,loc);return typeof value==='number'?value:Array.from(value)};
      probe.draws.push({object:this.name,material:material.name,receiver:material.userData.installationReceiverGroup,
       color:material.color?.toArray(),metalness:material.metalness,roughness:material.roughness,
       gpu:{currentProgramMatches:!!program&&gl.getParameter(gl.CURRENT_PROGRAM)===program.program,slfReady:read('slfReady'),installActive:read('installActive'),
        installLineColor:Array.from({length:18},(_,i)=>read(`installLineColor[${i}]`)),installLineA:Array.from({length:18},(_,i)=>read(`installLineA[${i}]`)),installLineB:Array.from({length:18},(_,i)=>read(`installLineB[${i}]`))}});
     };
     probe.saved.push({o,old,observer});o.onAfterRender=observer;
    });e.labScene.requestFrame();return e.getSceneEvidence().frames;
   },room);
   await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().frames)).toBeGreaterThan(frame);
   await page.waitForTimeout(200);
   const state=await host.evaluate(e=>{
    const p=window.__lightReadback;let restored=true;
    for(const {o,old,observer}of p.saved){if(o.onAfterRender!==observer)throw Error('Lost observer ownership');o.onAfterRender=old;restored&&=o.onAfterRender===old}
    const draws=p.draws;delete window.__lightReadback;
    const c=e.querySelector('canvas'),gl=c.getContext('webgl2'),d=gl.getExtension('WEBGL_debug_renderer_info');
    return{draws,observerCallbacksRestoredExactly:restored,evidence:e.getSceneEvidence(),backend:{renderer:gl.getParameter(d?.UNMASKED_RENDERER_WEBGL||gl.RENDERER),buffer:[gl.drawingBufferWidth,gl.drawingBufferHeight]}};
   });
   const file=`${variant}-${label}-${room}.png`,image=await canvas.screenshot({path:path.join(q,file)});
   expect(errors).toEqual([]);expect(state.observerCallbacksRestoredExactly).toBe(true);
   rows.push({variant,room,label,scope,file,pngSha256:sha(image),metrics:screenshotMetrics(image),...state,errors:[...errors]});
   fs.writeFileSync(path.join(q,'captures.json'),JSON.stringify(rows,null,2));
   console.log(JSON.stringify({variant,room,label,frames:state.evidence.frames,gym:state.evidence.simulation.installations.levels.gym,draws:state.draws.length,cache:state.evidence.loading.lightCache,errors:errors.length}));
  }
  for(const [label,minute]of [['noon',720],['evening',1260]]){
   await open();await ui.locator('[data-world-time]').fill(String(minute));
   for(const room of ['gym','library-upper']){
    await open();await ui.locator(`[data-world-room="${room}"]`).first().click();await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().currentRoom)).toBe(room);
    await capture(room,label,'Authored room/time/avatar camera fixture; actual visit supplied by the controller, complete optional models, native2K. Passive onAfterRender reads actual per-drawGPU uniforms and restores callbacks; no geometry/light/uniform/camera override.');
   }
  }
  await open();await ui.locator('[data-world-time]').fill('720');await ui.locator('[data-world-room="gym"]').first().click();await close();
  await canvas.press('v');await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().walk?.ready),{timeout:120000}).toBe(true);
  const placed=await host.evaluate(e=>e.setLabWalk({position:[8.8,0,6.3],yaw:0,pitch:-.05}));expect(placed).toBe(true);
  await canvas.focus();await page.keyboard.down('KeyW');await page.waitForTimeout(250);await page.keyboard.up('KeyW');
  await capture('gym','noon-body','Initial disclosed body fixture on the native gym floor, followed by ordinary250msW input; actual Walk/capsule/eye camera, complete optional models. This is first-person light qualification, not a public navigation journey.');
  await context.close();
 }}finally{await browser.close()}
})().catch(e=>{fs.writeFileSync(path.join(q,'capture-failure.txt'),String(e.stack||e));console.error(e);process.exitCode=1});
