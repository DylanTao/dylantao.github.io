import json,shutil
from pathlib import Path
q=Path(__file__).parent;site=q/'site/al-folio/assets/models/home';out=q/'cage-v1'
if out.exists():raise RuntimeError('Preserve first rejected trial')
out.mkdir()
shutil.copytree(q/'cage-captures',out/'captures')
for source in [site/'manifest.json',site/'static-light-field.json',q/'bake-cage-trial.log',q/'private-field.json',q/'capture-cage.cjs']:
    shutil.copy2(source,out/source.name)
d=json.loads((site/'manifest.json').read_text());r=next(r for r in d['rooms']if r['id']=='library-upper')
assert r['lightRegion']['max'][2]==14.1
r['lightRegion']['max'][2]=13.25
(site/'manifest.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
(q/'capture-cage-v2.cjs').write_text((q/'capture-cage.cjs').read_text().replace("'cage-captures'","'cage-v2-captures'"),encoding='utf-8')
(q/'cage-v2-precondition.json').write_text(json.dumps({'trial':r['lightRegion'],'nearProbeZ':11.0,'farProbeZ':12.5,
    'reason':'Nearprobe clears actualseatfront11.21; farprobe clears measuredchairback12.46. First14.1trialworseneddimnessandput2nearprobesincushions; rejected.'},indent=2)+'\n',encoding='utf-8')
