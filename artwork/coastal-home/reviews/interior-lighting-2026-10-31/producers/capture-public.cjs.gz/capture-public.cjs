const fs=require('node:fs'),path=require('node:path');
const engine=process.env.INTERIOR_ENGINE||'chromium';
const api=require(engine==='webkit'?'C:/dev/dylantao.github.io/.jekyll-cache/visual-qa/takeover-archives/walk-audit-20261028-cache/visual-qa/walk-audit-20261028/pw165/node_modules/@playwright/test':'C:/dev/dylantao.github.io/node_modules/@playwright/test');
const {expect}=api,{preparePage,collectRuntimeErrors,screenshotMetrics}=require('../../../test/visual/helpers.js');
const q=__dirname,width=engine==='webkit'?390:1440,height=1000,rows=[];
(async()=>{
 const browser=engine==='webkit'?await api.webkit.launch({headless:true}):await api.chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']});
 try{for(const mode of ['noon','evening']){
  const context=await browser.newContext({viewport:{width,height},deviceScaleFactor:1,hasTouch:engine==='webkit',isMobile:engine==='webkit',timezoneId:'America/Los_Angeles',reducedMotion:'reduce'}),page=await context.newPage(),errors=collectRuntimeErrors(page);
  page.setDefaultTimeout(90000);await preparePage(page,'light');
  await page.addInitScript(()=>sessionStorage.setItem('theme-manual','false'));
  await page.clock.setFixedTime(new Date('2026-10-29T17:45:00-07:00'));
  for(const name of ['manifest.json','static-light-field.json'])await page.route('**/assets/models/home/'+name,r=>r.fulfill({path:path.join(q,'cage-baseline-products',name),contentType:'application/json'}));
  await page.goto('http://127.0.0.1:4159/al-folio/?quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});
  const activate=locator=>engine==='webkit'?locator.tap():locator.click();
  await activate(page.locator('[data-home-desk-mode="3d"]'));
  const host=page.locator('[data-home-desk-scene]'),canvas=host.locator('canvas'),ui=page.locator('[data-home-world-controls]');
  await host.scrollIntoViewIfNeeded();await expect(host).toHaveAttribute('data-scene-state','ready',{timeout:240000});
  await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().currentRoom)).toBe('gym');
  await activate(page.locator('[data-theme-toggle]:visible').first());
  await activate(page.locator(`[data-theme-mode-option="${mode}"]:visible`).first());
  await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().clockMode)).toBe('preview');
  await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().currentRoom)).toBe('gym');
  await host.scrollIntoViewIfNeeded();
  const embed=await canvas.screenshot({path:path.join(q,`${engine}-public-${mode}-embed.png`)});
  await activate(ui.locator('[data-world-fullscreen]'));
  await page.waitForTimeout(250);
  const image=await canvas.screenshot({path:path.join(q,`${engine}-public-${mode}-fullscreen.png`)});
  const evidence=await host.evaluate(e=>e.getSceneEvidence()),lab=await ui.locator('[data-world-lab]').evaluate(e=>({hidden:e.hidden,inert:e.inert}));
  expect(lab.hidden&&lab.inert).toBe(true);expect(errors).toEqual([]);
  expect(evidence.simulation.installations.levels.gym).toBeGreaterThanOrEqual(.65);
  rows.push({engine,browser:browser.version(),mode,url:page.url(),lab,evidence,errors,embed:screenshotMetrics(embed),fullscreen:screenshotMetrics(image),scope:'Plain public route at actualworkoutclock17:45, then ordinary publicthemeNoon/Evening choice keeps the viewedgym. No lab selectors, body/camera override or material/uniform writes. Official geometry-identicalbaselinecage/cache held fixed; boundedgymreceiver+visit repair only. Phone is WebKit emulation, not a physicaldevice/performance claim.'});
  fs.writeFileSync(path.join(q,`${engine}-public.json`),JSON.stringify(rows,null,2));console.log(JSON.stringify({engine,mode,room:evidence.currentRoom,gym:evidence.simulation.installations.levels.gym,cache:evidence.loading.lightCache,errors}));
  await context.close();
 }}finally{await browser.close()}
})().catch(e=>{fs.writeFileSync(path.join(q,`${engine}-public-failure.txt`),String(e.stack||e));console.error(e);process.exitCode=1});
