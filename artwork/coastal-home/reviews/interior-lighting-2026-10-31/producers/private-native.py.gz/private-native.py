import hashlib,json,sys
from pathlib import Path
import bpy,numpy as np
q=Path(__file__).parent
sys.path.insert(0,str(q.parents[2]/'bin'))
from refresh_coastal_study_hardware import islands,world_points
source=q.parent/'interior-finish-20261031/pothos-v2/candidate.blend'
bpy.ops.wm.open_mainfile(filepath=str(source))
o=bpy.context.scene.objects['library-upper__linen'];mesh=o.data
rows=[]
for indices in islands(mesh):
    points=world_points(o,indices);lo,hi=points.min(axis=0),points.max(axis=0)
    if hi[2]-lo[2]<.3:continue
    chosen=set(indices);faces=[]
    for f in mesh.polygons:
        if not set(f.vertices)<=chosen:continue
        n=o.matrix_world.to_3x3()@f.normal
        if n.y>=-.95:continue
        p=o.matrix_world@f.center
        faces.append({'worldPoint':[p.x,p.z,-p.y],'worldNormal':[n.x,n.z,-n.y],'area':f.area})
    faces.sort(key=lambda f:f['area'],reverse=True)
    rows.append({'vertices':len(indices),'nativeBounds':[lo.tolist(),hi.tolist()],'rearFaceWitnesses':faces[:2]})
out={'nativeSourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'object':o.name,'chairBackIslands':rows}
(q/'private-native.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out),flush=True)
