import hashlib,json,shutil
from pathlib import Path
q=Path(__file__).parent;site=q/'site/al-folio/assets/models/home';out=q/'cage-v2-products'
if out.exists():raise RuntimeError('Preserve second rejected trial')
out.mkdir()
for name in ['manifest.json','static-light-field.json']:
    shutil.copy2(site/name,out/name)
    shutil.copy2(q/'cage-baseline-products'/name,site/name)
    assert (site/name).read_bytes()==(q/'cage-baseline-products'/name).read_bytes()
(q/'restored-preview.json').write_text(json.dumps({'scope':'Both privatecage trials rejected; original12.55extent and exact officialfreshbaselinecache restored to4159. Only two boundedgymruntime modules differ from sealed4156source; geometryretained.',
 'products':[{'name':name,'sha256':hashlib.sha256((site/name).read_bytes()).hexdigest()}for name in ['manifest.json','static-light-field.json']]},indent=2)+'\n',encoding='utf-8')
