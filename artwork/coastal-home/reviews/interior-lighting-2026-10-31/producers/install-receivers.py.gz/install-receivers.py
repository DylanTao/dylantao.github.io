import hashlib,json,shutil
from pathlib import Path
q=Path(__file__).parent;root=q.parents[2]
out=q/'schedule-only'
if out.exists():raise RuntimeError('Preserve schedule-only custody')
out.mkdir()
for file in [*q.glob('*.png'),q/'captures.json',q/'capture.cjs',q/'capture.log',q/'preview-substitution.json']:
    shutil.copy2(file,out/file.name)
folder=q/'site/al-folio'
name='assets/js/home-scene/gym-props.mjs'
(q/'baseline-gym-props.mjs').write_bytes((folder/name).read_bytes())
for name in ['assets/js/home-scene/gym-props.mjs','assets/js/home-scene/light-installations.mjs']:
    (folder/name).write_text((root/name).read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
changes=[]
for row in json.loads((q/'compiled-baseline.json').read_text())['files']:
    b=(folder/row['path']).read_bytes();sha=hashlib.sha256(b).hexdigest()
    if sha!=row['sha256']:changes.append({'path':row['path'],'before':row['sha256'],'after':sha,'bytes':len(b)})
assert sorted(r['path']for r in changes)==['assets/js/home-scene/gym-props.mjs','assets/js/home-scene/light-installations.mjs']
(q/'preview-substitution.json').write_text(json.dumps({'scope':'Exactly two owning runtime modules; remaining1358compiled files, geometry, materials, authoredemitters and cache retained','changes':changes},indent=2)+'\n',encoding='utf-8')
print(json.dumps(changes))
