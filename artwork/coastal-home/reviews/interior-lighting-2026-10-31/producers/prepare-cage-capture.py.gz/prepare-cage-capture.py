from pathlib import Path
q=Path(__file__).parent
s=(q/'capture.cjs').read_text(encoding='utf-8')
s=s.replace("const q=__dirname,rows=[],width=2560,height=1440,sha=b=>crypto.createHash('sha256').update(b).digest('hex');", "const baseFolder=__dirname,q=path.join(baseFolder,'cage-captures'),rows=[],width=2560,height=1440,sha=b=>crypto.createHash('sha256').update(b).digest('hex');fs.mkdirSync(q,{recursive:true});")
start=s.index("  if(variant==='baseline')await page.route")
end=s.index("  await page.goto",start)
s=s[:start]+"  if(variant==='baseline')for(const name of ['manifest.json','static-light-field.json'])await page.route('**/assets/models/home/'+name,r=>r.fulfill({path:path.join(baseFolder,'cage-baseline-products',name),contentType:'application/json'}));\n"+s[end:]
s=s.replace("for(const room of ['gym','library-upper'])", "for(const room of ['library-upper','kitchen','gym'])")
s=s.replace("   }\n  }\n  await open();await ui.locator('[data-world-time]').fill('720');await ui.locator('[data-world-room=\"gym\"]').first().click();", "   }\n   await ui.locator('[data-world-view]').click();await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().currentRoom)).toBe('outside');await capture('outside',label,'Matched complete public outside view; cage-only control, every optional model loaded.');\n  }\n  await open();await ui.locator('[data-world-time]').fill('720');await ui.locator('[data-world-room=\"library-upper\"]').first().click();")
s=s.replace("position:[8.8,0,6.3],yaw:0,pitch:-.05", "position:[0,2.6,13.3],yaw:Math.PI,pitch:-.15")
s=s.replace("await page.keyboard.down('KeyW');await page.waitForTimeout(250);await page.keyboard.up('KeyW');", "await page.waitForTimeout(150);")
s=s.replace("await capture('gym','noon-body'", "await capture('library-upper','noon-body'")
s=s.replace("Initial disclosed body fixture on the native gym floor, followed by ordinary250msW input; actual Walk/capsule/eye camera, complete optional models. This is first-person light qualification, not a public navigation journey.", "Disclosed standing-body fixture on the native private-living rear aisle, accepted by actual Walkfield; realcapsule/eye camera, complete optional models. No camera override. First-person lighting qualification, not a navigation journey.")
(q/'capture-cage.cjs').write_text(s,encoding='utf-8',newline='\n')
assert 'cage-baseline-products'in s and "capture('outside'"in s and "capture('library-upper','noon-body'"in s
