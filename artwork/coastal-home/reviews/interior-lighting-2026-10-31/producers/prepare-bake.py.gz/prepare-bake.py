import hashlib,json,shutil,subprocess
from pathlib import Path
q=Path(__file__).parent;root=q.parents[2];site=q/'site/al-folio'
out=q/'receiver-controls'
if out.exists():raise RuntimeError('Preserve receiver controls')
out.mkdir()
for file in [*q.glob('*.png'),q/'captures.json',q/'capture.cjs',q/'capture-receivers.log',q/'preview-substitution.json']:
    shutil.copy2(file,out/file.name)
for name in ['assets/models/home/manifest.json','assets/models/home/static-light-field.json']:
    shutil.copy2(site/name,q/('original-'+Path(name).name))
for name in ['assets/js/home-scene/light-installations.mjs','assets/js/home-scene/gym-props.mjs']:
    (site/name).write_text((root/name).read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
rows=[]
for name in ['bin/bake_coastal_static_light.cjs','bin/coastal_static_light_inputs.cjs','_plugins/site_module_assets.rb','Gemfile.lock']:
    source=(root/name).read_bytes();dst=site/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(source)
    rows.append({'path':name,'sha256':hashlib.sha256(source).hexdigest(),'bytes':len(source)})
(q/'official-bake-input-custody.json').write_text(json.dumps({'isolatedRoot':str(site),'producerCopies':rows,'scope':'Unmodified official baker and dependency collector; full scene, two accepted geometry products, latest boundedgymruntime. Root and sealed4156products untouched.'},indent=2)+'\n',encoding='utf-8')
