const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {coastalLightInputs}=require('../../../bin/coastal_static_light_inputs.cjs');
(async()=>{
 const root=process.cwd(),q=__dirname,out=path.join(q,'coffee-motion-checkpoint-v1'),site=path.join(out,'site/al-folio'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
 const input=await coastalLightInputs(root),cache=fs.readFileSync(path.join(root,'assets/models/home/static-light-field.json')),manifest=JSON.parse(fs.readFileSync(path.join(root,'assets/models/home/manifest.json')));
 assert.equal(input.signature,'7c56b9414e90298ac3f50ccb5ba340ac6bf3202f0fb70f9061c4b714a7953729');assert.equal(JSON.parse(cache).signature,input.signature);assert.equal(sha(cache),'05515f737a516531216c96a4bd2f84e02a116ea668342c9a9f6f05aa79b2303e');
 const modules=JSON.parse(fs.readFileSync(path.join(site,'assets/js/module-build.json'))).modules;assert.equal(Object.keys(modules).length,193);
 const before=JSON.parse(fs.readFileSync(path.join(q,'chair-producer-checkpoint-v1/site/al-folio/assets/js/module-build.json'))).modules,rows=[];
 for(const[name,r]of Object.entries(modules)){
  assert.equal(sha(fs.readFileSync(path.join(root,name)).toString('utf8').replaceAll('\r\n','\n')),r.sourceSha256,name);
  assert.equal(sha(fs.readFileSync(path.join(site,name))),r.outputSha256,name);
  if(!before[name]||before[name].outputSha256!==r.outputSha256)rows.push({file:name,new:!before[name],sourceChanged:before[name]?.sourceSha256!==r.sourceSha256,outputSha256:r.outputSha256});
 }
 const css=fs.readFileSync(path.join(site,'assets/css/main.css'));assert.equal(sha(css),'f81623d3af019fba253ca5ace091fb4d806251f2098a0b987c9906376f88a1d0');
 const record={at:new Date().toISOString(),scope:'Current disabled optional foot/pull API and production module bindings. All actual lighting dependency/manifest/model inputs and cache bytes stay exact; neither module changes the static collector or active public routine, and the default solver passes exact all5rig controls. No owning bake is required for unchanged lighting inputs. Private garden/cliff/native/routine source remains excluded.',signature:input.signature,cacheSha256:sha(cache),cacheBytes:cache.length,compiledModules:Object.keys(modules).length,changedOutputs:rows,cssSha256:sha(css),cssExactTo7df:true};fs.writeFileSync(path.join(out,'CACHE-AND-COMPILED-BINDINGS.json'),JSON.stringify(record,null,2)+'\n');console.log(JSON.stringify(record));
})().catch(e=>{console.error(e);process.exitCode=1;});
