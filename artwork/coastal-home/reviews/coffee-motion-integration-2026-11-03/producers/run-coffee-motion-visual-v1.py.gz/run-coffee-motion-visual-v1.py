from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,os,time
q=Path(__file__).parent;out=q/'coffee-motion-checkpoint-v1';wt=Path('C:/dev/dqa1103')
env=dict(os.environ,NO_WEBSERVER='1',VISUAL_BASE_URL=json.loads((out/'server.json').read_bytes())['url'].rstrip('/'),CI='1')
command=['C:/Program Files/nodejs/npx.cmd','playwright','test','--config','test/visual/public.config.js','--project','desktop-1440','--workers','1','--output',str(out/'browser-results'),'test/visual/desk-scene.spec.js','--grep','public room navigation works']
start=time.monotonic()
with(out/'BROWSER.log').open('wb')as log:r=subprocess.run(command,cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
(out/'BROWSER.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),command=command,env={k:env[k]for k in ['NO_WEBSERVER','VISUAL_BASE_URL','CI']},exitCode=r.returncode,seconds=time.monotonic()-start,scope='Existing actual compiled public Rooms/Study/Onsen/fullscreen/Walk/Coast/return case, native Windows Chromium backend as maintained config. Private coffee/garden/cliff source is not active; no performance claim.'),indent=2)+'\n',encoding='utf8');print(json.dumps(dict(exitCode=r.returncode,seconds=time.monotonic()-start)));raise SystemExit(r.returncode)
