from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,shutil,os,time
root=Path.cwd();q=Path(__file__).parent;out=q/'coffee-pull-retained-v2';assert not out.exists();out.mkdir()
packet=root/'artwork/coastal-home/reviews/coffee-chair-motion-2026-11-03';inputs=json.loads((packet/'REPLAY-INPUTS.json').read_bytes())
long=lambda p:Path('\\\\?\\'+str(Path(p).resolve()))if os.name=='nt'else Path(p)
def sha(p):
 h=hashlib.sha256()
 with long(p).open('rb')as s:
  for b in iter(lambda:s.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
raw=json.loads(gzip.decompress((packet/'raw/RETAINED-RAW-INDEX.json.gz').read_bytes()));portable=json.loads(gzip.decompress((packet/'raw/PORTABLE-RETAINED-INDEX-V122.json.gz').read_bytes()));jobs=[]
for row in raw['files']:jobs.append((Path(row['originalAbsolutePath']),out/'raw'/row['path'],row))
roots=[Path(p)for p in portable['roots']]+[Path(raw['rawRoot'])]
for row in portable['files']:
 p=Path(row['path']);matches=[(i,r)for i,r in enumerate(roots)if p.is_relative_to(r)];assert matches
 i,r=max(matches,key=lambda item:len(item[1].parts));jobs.append((p,out/'portable'/str(i)/p.relative_to(r),row))
models=Path(raw['rawRoot'])/'current-pavilion-models-v28'
for row in inputs['models']:jobs.append((models/row['path'],out/'models'/row['path'],row))
rows=[];start=time.monotonic()
for source,dest,row in jobs:
 assert long(source).stat().st_size==row['bytes']and sha(source)==row['sha256'],source
 long(dest.parent).mkdir(parents=True,exist_ok=True);assert not long(dest).exists();shutil.copyfile(long(source),long(dest))
 assert long(dest).stat().st_size==row['bytes']and sha(dest)==row['sha256'],dest
 rows.append(dict(original=str(source),retained=dest.relative_to(out).as_posix(),bytes=row['bytes'],sha256=row['sha256']))
record=dict(at=datetime.now(timezone.utc).isoformat(),scope='Complete exact indexed dense/failed/portable pull evidence and complete121model bundle copied outside worker worktree before any cleanup. Original files retained. No publication, credentials, model changes or physics admission.',packetManifestSHA256=sha(packet/'MANIFEST.json'),files=rows,count=len(rows),bytes=sum(r['bytes']for r in rows),seconds=time.monotonic()-start)
(out/'RETAINED.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');print(json.dumps({k:v for k,v in record.items()if k!='files'}))
