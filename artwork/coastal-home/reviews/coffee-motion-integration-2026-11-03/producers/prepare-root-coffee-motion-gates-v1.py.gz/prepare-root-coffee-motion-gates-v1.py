from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess,time
root=Path.cwd();q=Path(__file__).parent;out=q/'coffee-motion-root-gates-v1';assert not out.exists();out.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for rel in ['assets/js/home-scene/locomotion.mjs','assets/js/home-scene/coffee-chair-motion.mjs','test/coastal-coffee-sole-contact.test.mjs','test/coastal-coffee-chair-motion.test.mjs']:
 p=root/rel;before=p.read_bytes();blob=subprocess.check_output(['git','show','HEAD:'+rel]);assert before.replace(b'\r\n',b'\n')==blob;assert b'\r\n'not in blob;p.write_bytes(blob);rows.append(dict(path=rel,canonicalSHA256=sha(blob),changedLineEndingsOnly=before!=blob))
(out/'SOURCE.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),sourceHead=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),rows=rows,previousFailures=[dict(scope='d461 module without measured sole prerequisite',result='4pass3fail; unavailable constructor'),dict(scope='exact legacy source assertion on CRLF checkout',result='19pass1fail before physical sample; LF-only dispatch string absent')],scope='Only exact canonical Git blobs restored with explicit LF attributes. All functional/model bytes stay unchanged. Both integration failures remain distinct from physical contact evidence.'),indent=2)+'\n',encoding='utf8')
args=['node','--test','test/coastal-coffee-chair-motion.test.mjs','test/coastal-coffee-sole-contact.test.mjs'];start=time.monotonic()
with(out/'FOCUSED.log').open('wb')as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=120)
(out/'FOCUSED.json').write_text(json.dumps(dict(command=args,exitCode=r.returncode,seconds=time.monotonic()-start),indent=2)+'\n',encoding='utf8');print(r.returncode);assert r.returncode==0
