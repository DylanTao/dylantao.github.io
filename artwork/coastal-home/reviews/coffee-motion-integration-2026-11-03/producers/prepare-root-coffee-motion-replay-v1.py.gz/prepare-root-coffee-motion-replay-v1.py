from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
root=Path.cwd();q=Path(__file__).parent;out=q/'coffee-motion-root-preparation-v1';assert not out.exists();out.mkdir()
packet=root/'artwork/coastal-home/reviews/coffee-chair-motion-2026-11-03'
manifest=json.loads((packet/'MANIFEST.json').read_bytes());rows=[]
for row in manifest['files']:
 p=packet/row['path'];before=p.read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest()
 if sha(before)==row['sha256']:continue
 rel=p.relative_to(root).as_posix();blob=subprocess.check_output(['git','show','HEAD:'+rel])
 assert sha(blob)==row['sha256'] and len(blob)==row['bytes'],rel
 assert before.replace(b'\r\n',b'\n')==blob,'Unexpected non-line-ending change: '+rel
 p.write_bytes(blob);rows.append(dict(path=rel,beforeBytes=len(before),beforeSha256=sha(before),exactGitBlobSha256=sha(blob)))
(out/'RECEIPT.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),scope='First root replay correctly stopped before fixture creation on checkout CRLF conversion of a sealed README. Explicit packet text eol=lf attributes now preserve the original immutable Git/manifest bytes. No packet content or physical result was edited.',firstExitCode=1,firstReason='Packet custody mismatch: README.md',normalizedOnlyExactGitBlobs=rows),indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(exactPacketFiles=len(manifest['files']),lineEndingRestorations=len(rows))))
