from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json,shutil
root=Path.cwd();q=Path(__file__).parent;wt=Path('C:/dev/dqa1103');out=q/'coffee-motion-checkpoint-v1';assert not out.exists();out.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=subprocess.check_output(['git','ls-files','-z']).decode().split('\0');rows=[];changed=[]
text_suffixes={'.md','.json','.js','.mjs','.cjs','.py','.scss','.css','.yml','.yaml','.liquid','.html','.xml','.svg','.sh','.txt','.toml','.rb','.lock','.csv','.bib','.rst','.tex'}
for rel in paths:
 if not rel:continue
 p=root/rel
 if not p.is_file():raise RuntimeError('Tracked source missing: '+rel)
 data=p.read_bytes()
 if p.suffix.lower() in text_suffixes or p.name in ['.gitattributes','Gemfile','Rakefile','Dockerfile']:
  try:data.decode('utf8');data=data.replace(b'\r\n',b'\n')
  except UnicodeDecodeError:pass
 dest=wt/rel
 if not dest.exists()or dest.read_bytes()!=data:dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);changed.append(rel)
 rows.append(dict(path=rel,bytes=len(data),sha256=sha(data)))
prior=q/'chair-producer-checkpoint-v1/site/al-folio/assets/img';shutil.copytree(prior,out/'site/al-folio/assets/img')
(out/'SOURCE.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),sourceHead=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),worktree=str(wt),files=rows,copiedCurrentPaths=changed,scope='All tracked current checkout files compared against LF validation worktree, with only explicit text newline normalization. The target HEAD alone is not the source binding; this complete file manifest binds the actual overlay. No private native/furniture/metadata is copied. Complete build retains every route and generated image.'),indent=2)+'\n',encoding='utf8')
s=(q/'run-chair-producer-gates-v1.py').read_text(encoding='utf8').replace("out=q/'chair-producer-checkpoint-v1'","out=q/'coffee-motion-checkpoint-v1'")
(q/'run-coffee-motion-gates-v1.py').write_text(s,encoding='utf8',newline='\n')
print(json.dumps(dict(files=len(rows),copied=len(changed))))
