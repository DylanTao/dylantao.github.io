const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {PurgeCSS}=require('purgecss');
const q=__dirname,out=path.join(q,'coffee-motion-checkpoint-v1'),built=path.join(out,'site/al-folio');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
 const results=await new PurgeCSS().purge({...require(path.join(process.cwd(),'purgecss.config.js')),content:['**/*.html','**/*.js','**/*.mjs'].map(g=>path.join(built,g).replaceAll('\\','/')),css:[path.join(built,'assets/css/*.css').replaceAll('\\','/')],skippedContentGlobs:[path.join(built,'assets/**/*.html').replaceAll('\\','/')],rejected:true});
 const rows=[];
 for(const r of results){const original=fs.readFileSync(r.file);const name=path.basename(r.file);const target=path.join(out,'postprocessed',name);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,r.css);fs.writeFileSync(r.file,r.css);rows.push({file:name,beforeSha256:hash(original),bytes:Buffer.byteLength(r.css),sha256:hash(r.css),brandStateRules:(r.css.match(/data-brand-state/g)||[]).length,rejected:r.rejected});}
 if(rows.find(r=>r.file==='main.css').brandStateRules<10)throw Error('Corrected actual brand states missing');
 const receipt={at:new Date().toISOString(),purgecssVersion:require('purgecss/package.json').version,scope:'Actual deployment CSS cleanup applied to the complete nonincremental production build. No assets omitted or module/model response substitutions.',rows};
 fs.writeFileSync(path.join(out,'POSTPROCESS.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(rows.map(({rejected,...r})=>({...r,rejected:rejected.length}))));
})().catch(e=>{console.error(e);process.exitCode=1;});
