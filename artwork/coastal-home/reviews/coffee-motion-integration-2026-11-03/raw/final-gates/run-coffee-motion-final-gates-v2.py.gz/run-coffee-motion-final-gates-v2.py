from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil,subprocess,time,os,sysconfig
root=Path.cwd();q=Path(__file__).parent;wt=Path('C:/dev/dqa1103');out=q/'coffee-motion-final-gates-v2';assert not out.exists();out.mkdir()
packet=root/'artwork/coastal-home/reviews/coffee-motion-integration-2026-11-03'
def manifest():
 rows=[]
 for p in sorted(packet.rglob('*')):
  if not p.is_file()or p.name=='MANIFEST.json':continue
  b=p.read_bytes();rows.append(dict(path=p.relative_to(packet).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
 (packet/'MANIFEST.json').write_text(json.dumps(dict(version=1,scope='Coordinator integration and source/function/browser evidence. Optional APIs remain unwired; private native and complete coffee lifecycle remain unaccepted.',files=rows),indent=2)+'\n',encoding='utf8')
# Preformatted current manifest is retained for this verification.
for rel in ['docs/october-2026-handoff.md','.gitattributes']:(wt/rel).write_bytes((root/rel).read_bytes().replace(b'\r\n',b'\n'))
target=wt/packet.relative_to(root);shutil.copytree(packet,target,dirs_exist_ok=True)
env=dict(os.environ,BUNDLE_PATH='C:/tools/site-gems-ruby33');env['PATH']='C:/tools/site-bin;C:/tools/Ruby33/bin;'+sysconfig.get_path('scripts')+';'+env['PATH'];rows=[]
for name,args in [('prettier',['C:/Program Files/nodejs/npx.cmd','prettier','.','--check']),('roster',['node','bin/run_visual_scene_group.cjs','scene-core-1','--project','all','--verify-only'])]:
 start=time.monotonic()
 with(out/(name+'.log')).open('wb')as log:r=subprocess.run(args,cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 rows.append(dict(name=name,command=args,exitCode=r.returncode,seconds=time.monotonic()-start));(out/'GATES.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),rows=rows),indent=2)+'\n',encoding='utf8');print(json.dumps(rows[-1]),flush=True);assert r.returncode==0,name
