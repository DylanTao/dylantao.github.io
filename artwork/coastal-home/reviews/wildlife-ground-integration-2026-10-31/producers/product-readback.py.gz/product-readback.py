"""Bind every compiled module and physical metadata to the exclusive preview."""
import json,hashlib,urllib.request,concurrent.futures,importlib.util
from pathlib import Path
root=Path.cwd();q=Path(__file__).resolve().parent;site=q/'site/al-folio';final=q/'final-site/al-folio'
receipt=json.loads((site/'assets/js/module-build.json').read_text());completed=json.loads((final/'assets/js/module-build.json').read_text())
assert receipt==completed,'Incremental compiler and full production build disagree'
def check(relative):
    with urllib.request.urlopen('http://127.0.0.1:4167/al-folio/'+relative,timeout=20) as response:
        header=response.headers.get('X-Sirui-Preview');body=response.read()
    expected=(final/relative).read_bytes();assert body==expected,(relative,'served bytes differ')
    assert header=='rabbit-integration-20261031-4167',(relative,'unexpected server')
    return {'path':relative,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'exactCompleteBuildBytes':True,'exclusivePreviewHeader':header}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:rows=list(pool.map(check,sorted(receipt['modules'])))
for relative in ['index.html','assets/js/home.js','assets/models/home/static-light-field.json','assets/models/home/home-shell.glb','assets/models/home/coast.glb']:
    rows.append(check(relative))
with urllib.request.urlopen('http://127.0.0.1:4167/al-folio/assets/models/home/manifest.json') as response:
    body=response.read();assert response.headers.get('X-Sirui-Preview')=='rabbit-integration-20261031-4167'
assert json.loads(body)==json.loads((final/'assets/models/home/manifest.json').read_text())==json.loads((root/'assets/models/home/manifest.json').read_text())
sp=importlib.util.spec_from_file_location('asset_budget',root/'test/test_coastal_assets.py');module=importlib.util.module_from_spec(sp);sp.loader.exec_module(module)
cls=next(v for v in vars(module).values() if isinstance(v,type) and hasattr(v,'test_complete_first_scene_budget_includes_all_rooms_furniture_and_selected_avatar'))
case=cls('test_complete_first_scene_budget_includes_all_rooms_furniture_and_selected_avatar');original=case.assertLess;budget={}
def capture(a,b,msg=None):budget.update({'completeFirstViewGzip6Bytes':a,'unchangedLimitBytes':b,'remainingBytes':b-a});original(a,b,msg)
case.assertLess=capture;case.test_complete_first_scene_budget_includes_all_rooms_furniture_and_selected_avatar()
result={'moduleCount':len(receipt['modules']),'completeBuildAndIncrementalReceiptsExact':True,'manifestParsedMetadataExact':True,'rows':rows,'budget':budget,
        'scope':'Byte readback from exclusive4167; full unmodified production build and canonical asset test, not performance timing'}
(q/'product-readback.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k!='rows'}))
