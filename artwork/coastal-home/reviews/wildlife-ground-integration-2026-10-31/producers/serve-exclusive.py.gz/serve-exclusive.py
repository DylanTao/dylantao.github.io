"""Owned complete preview; an occupied Windows port fails instead of sharing."""
import os, socket
from pathlib import Path
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from functools import partial
class ExclusiveServer(ThreadingHTTPServer):
    allow_reuse_address=False
    def server_bind(self):
        if os.name=='nt':self.socket.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
        super().server_bind()
class Handler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('X-Sirui-Preview','rabbit-integration-20261031-4167')
        super().end_headers()
q=Path(__file__).resolve().parent
server=ExclusiveServer(('127.0.0.1',4167),partial(Handler,directory=str(q/'site')))
print('Exclusive complete preview http://localhost:4167/al-folio/',flush=True)
server.serve_forever()
