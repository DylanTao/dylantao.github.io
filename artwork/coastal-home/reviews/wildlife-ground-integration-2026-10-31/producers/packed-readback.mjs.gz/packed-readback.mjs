import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {gzipSync} from 'node:zlib';
import * as THREE from '../../../assets/js/three.module.min.js';
import {createStaticLightField} from '../../../assets/js/home-scene/static-light-field.mjs';
const q=new URL('./',import.meta.url), beforeBytes=execFileSync('git',['show','d3099670c:assets/models/home/static-light-field.json'],{maxBuffer:5e6}),
 afterBytes=fs.readFileSync('assets/models/home/static-light-field.json'),before=JSON.parse(beforeBytes),after=JSON.parse(afterBytes);
const opts=JSON.parse(after.configuration),a=createStaticLightField(opts),b=createStaticLightField(opts);
assert.equal(a.restoreSnapshot(before,{signature:before.signature}),true);
assert.equal(b.restoreSnapshot(after,{signature:after.signature}),true);
const unwrapped=b.exportSnapshot({signature:after.signature});
for(const key of ['configuration','transport','moments','probes'])assert.deepEqual(unwrapped[key],before[key],key);
const shader=field=>{const mat=new THREE.MeshStandardMaterial();field.bindMaterial(mat);const s={uniforms:{},vertexShader:THREE.ShaderLib.physical.vertexShader,fragmentShader:THREE.ShaderLib.physical.fragmentShader};mat.onBeforeCompile(s);return s;};
const sa=shader(a),sb=shader(b);let comparisons=0;
for(const power of [0,.6,2]){
 const light={zenith:[.12,.25,.4],horizon:[.6,.4,.2],ground:[.1,.1,.1],practicalPowers:opts.practicalSources.map((_,i)=>power*(1+i/30))};
 a.setLighting(light);b.setLighting(light);
 for(const probe of after.probes)for(const normal of [[0,1,0],[.7,.7,0],[0,0,1],[0,-1,0]]){
   assert.deepEqual(a.sample(probe.position,normal),b.sample(probe.position,normal));comparisons++;
 }
 for(const key of ['slfPositions','slfMoments','slfCoefficients'])
   assert.deepEqual(sa.uniforms[key].value.image.data,sb.uniforms[key].value.image.data);
}
const receipt={beforeSha256:crypto.createHash('sha256').update(beforeBytes).digest('hex'),afterSha256:crypto.createHash('sha256').update(afterBytes).digest('hex'),
 transportValues:before.transport.length,momentValues:before.moments.length,allLightingNumbersExact:true,probesExact:true,configurationExact:true,
 cpuSampleComparisons:comparisons,allGpuTextureBitsExact:true,visitorRays:b.evidence().trace.rays??0,
 before:{bytes:beforeBytes.length,gzip6:gzipSync(beforeBytes,{level:6}).length},after:{bytes:afterBytes.length,gzip6:gzipSync(afterBytes,{level:6}).length}};
fs.writeFileSync(new URL('packed-readback.json',q),JSON.stringify(receipt,null,2)+'\n');console.log(receipt);a.dispose();b.dispose();
