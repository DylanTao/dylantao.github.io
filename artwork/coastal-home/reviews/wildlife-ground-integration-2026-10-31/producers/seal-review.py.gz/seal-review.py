"""Select public acceptance evidence only; never copy private machine settings."""
import gzip,json,hashlib,shutil,subprocess
from pathlib import Path
root=Path.cwd();q=Path(__file__).resolve().parent
out=root/'artwork/coastal-home/reviews/wildlife-ground-integration-2026-10-31'
def copy(relative,target=None,compressed=True):
    source=q/relative;dest=out/(target or relative)
    if compressed:dest=dest.with_name(dest.name+'.gz')
    dest.parent.mkdir(parents=True,exist_ok=True)
    data=source.read_bytes();dest.write_bytes(gzip.compress(data,mtime=0) if compressed else data)
for name in ['packed-readback.json','product-readback.json','bounded-route-patch.json','static-bake.log',
             'node-all.log','node-final.log','python-all.log','format-release.log','style.log','overrides.log',
             'build-release.log','registry.log','native-cutaway-final.log','production-cutaway.log','webkit-final.log',
             'packed-native-gpu.log','mesa-final.log','rejected-old-roof-control.log','high-no-clock.log','high-no-clock-study.log',
             'ci-b5c9.json','ci-d309.json']:
    copy(name,'proof/'+name)
for name in ['packed-readback.mjs','product-readback.py','compile-current.rb','high-no-clock.cjs','high-no-clock-study.cjs',
             'theme-pointer-check.cjs','serve-exclusive.py','mesa-final.cjs','seal-review.py']:
    copy(name,'producers/'+name)
copy('high-no-clock-study/receipt.json','proof/high-native-no-clock.json')
copy('theme-pointer/receipt.json','attempts/invalidated-shared-port.json')
copy('theme-pointer-exclusive/receipt.json','proof/theme-pointer-exclusive.json')
for image in (q/'high-no-clock-study').glob('*.png'):copy(image.relative_to(q),'views/'+image.name,False)
for case in (q/'production-cutaway').glob('desk-*'):
    width=next(x for x in ['desktop-1440','laptop-1280','tablet-768','mobile-390'] if case.name.endswith(x))
    copy((case/'rabbits-visible-support.json').relative_to(q),'proof/'+width+'-rabbits.json')
    copy((case/'rabbits-visible-cutaway.png').relative_to(q),'views/'+width+'-cutaway.png',False)
for case in (q/'packed-native-gpu').glob('static-*'):
    for file in case.glob('*.json'):copy(file.relative_to(q),'proof/packed-native-gpu.json')
copy('final-site/al-folio/assets/js/module-build.json','proof/module-build.json')
before=json.loads(subprocess.check_output(['git','show','b5c9d013c:assets/models/home/manifest.json']))
after=json.loads((root/'assets/models/home/manifest.json').read_text());old_cache=before.pop('staticLightFieldCache');new_cache=after.pop('staticLightFieldCache')
new_route=after['terrain']['habitats']['rabbitEast']['path'];old_route=before['terrain']['habitats']['rabbitEast']['path']
after['terrain']['habitats']['rabbitEast']['path']=old_route
assert after==before,'Metadata changed outside eastern path and official descriptor'
(out/'proof/manifest-delta.json').write_bytes((json.dumps({'onlyPhysicalMetadataChange':'terrain.habitats.rabbitEast.path','points':len(new_route),
    'cacheDescriptor':'Official producer only','beforeCache':old_cache,'afterCache':new_cache},indent=2)+'\n').encode('utf8'))
sources=['assets/js/home-scene/'+name+'.mjs' for name in ['controller','environment','static-light-field','wildlife','wildlife-rabbit-contact','wildlife-resting-contact','wildlife-ground-contact']]
sources+=['assets/models/home/manifest.json','assets/models/home/static-light-field.json','artwork/coastal-home/coastal-home.blend',
          'assets/models/home/home-shell.glb','assets/models/home/coast.glb','bin/bake_coastal_static_light.cjs','bin/coastal_static_light_inputs.cjs',
          'bin/rabbit_habitats.py','bin/repair_rabbit_habitats.py','bin/coastal_architecture_finish.py','test/loading-sketch.test.mjs',
          'test/static-light-cache.test.mjs','test/static-light-field.test.mjs','test/visual/desk-scene.spec.js',
          'test/visual/static-light-field.spec.js','test/visual/scene-groups.json']
bindings=[]
for relative in sources:
    data=(root/relative).read_bytes();binary=relative.endswith(('.blend','.glb'))
    if not binary:data=data.replace(b'\r\n',b'\n')
    bindings.append({'path':relative,'sha256':hashlib.sha256(data).hexdigest(),'normalization':'binary exact' if binary else 'LF'})
(out/'SOURCE_BINDINGS.json').write_bytes((json.dumps({'schema':'source-bindings-v1','files':bindings},indent=2)+'\n').encode('utf8'))
payloads=[]
for p in sorted(out.rglob('*')):
    if not p.is_file() or p.name=='MANIFEST.json':continue
    b=p.read_bytes();payloads.append({'path':p.relative_to(out).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(out/'MANIFEST.json').write_bytes((json.dumps({'schema':'sealed-review-v1','payloads':payloads},indent=2)+'\n').encode('utf8'))
print(json.dumps({'payloads':len(payloads),'sources':len(bindings),'bytes':sum(p['bytes'] for p in payloads)}))
