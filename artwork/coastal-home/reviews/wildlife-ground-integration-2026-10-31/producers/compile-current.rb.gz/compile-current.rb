require 'jekyll'
require_relative '../../../_plugins/site_module_assets'
require 'fileutils'
root=Dir.pwd
dest=File.join(__dir__,'site/al-folio')
rp=File.join(dest,'assets/js/module-build.json')
receipt=JSON.parse(File.read(rp)); changed=[]
Dir.glob(File.join(root,'assets/js/**/*.mjs')).sort.each do |full|
 relative=full.delete_prefix(root+'/'); source=File.read(full,encoding:'UTF-8')
 digest=Digest::SHA256.hexdigest(source.gsub("\r\n","\n"))
 next if receipt['modules'][relative]&.fetch('sourceSha256')==digest
 compiled=SiruiSite::ModuleAssets.compile(source)
 FileUtils.mkdir_p(File.dirname(File.join(dest,relative)))
 File.binwrite(File.join(dest,relative),compiled)
 receipt['modules'][relative]={'sourceSha256'=>digest,'outputSha256'=>Digest::SHA256.hexdigest(compiled),'bytes'=>compiled.bytesize}
 changed.push(relative)
end
File.binwrite(rp,JSON.generate(receipt)+"\n")
%w[manifest.json static-light-field.json].each do |name|
 FileUtils.cp(File.join(root,'assets/models/home',name),File.join(dest,'assets/models/home',name))
end
puts JSON.pretty_generate({'method'=>'Exact unmodified Jekyll/Terser module compiler; complete seeded production product','changed'=>changed,'totalModules'=>receipt['modules'].length})
