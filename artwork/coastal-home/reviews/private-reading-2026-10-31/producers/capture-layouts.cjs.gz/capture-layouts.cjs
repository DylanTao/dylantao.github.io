const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const engine=process.env.INTERIOR_ENGINE||'chromium';
const modern='C:/dev/dylantao.github.io/.jekyll-cache/visual-qa/takeover-archives/walk-audit-20261028-cache/visual-qa/walk-audit-20261028/pw165/node_modules/@playwright/test';
const api=require(engine==='webkit'?modern:'C:/dev/dylantao.github.io/node_modules/@playwright/test'),{expect}=api;
const {preparePage,collectRuntimeErrors,screenshotMetrics}=require('../../../test/visual/helpers.js');
const base=__dirname,q=path.join(base,'layouts-v4'),rows=[],sha=b=>crypto.createHash('sha256').update(b).digest('hex');
fs.mkdirSync(q,{recursive:true});
const viewports=engine==='webkit'?[[390,1000]]:[[1440,1000],[1280,800],[768,1024],[390,1000]];
(async()=>{
 const browser=await (engine==='webkit'?api.webkit.launch({headless:true}):api.chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']}));
 try{for(const variant of ['baseline','candidate']){
  const context=await browser.newContext({viewport:{width:viewports[0][0],height:viewports[0][1]},deviceScaleFactor:1,hasTouch:engine==='webkit',isMobile:engine==='webkit',reducedMotion:'reduce',timezoneId:'America/Los_Angeles'});
  const page=await context.newPage(),errors=collectRuntimeErrors(page);page.setDefaultTimeout(90000);
  await preparePage(page,'light');await page.clock.setFixedTime(new Date('2026-10-29T12:00:00-07:00'));
  if(variant==='baseline')for(const name of ['manifest.json','static-light-field.json','room-library-upper.glb'])await page.route('**/assets/models/home/'+name,r=>r.fulfill({path:path.join(base,'baseline-products',name),contentType:name.endsWith('.glb')?'model/gltf-binary':'application/json'}));
  if(variant==='baseline')await page.route('**/assets/js/home-scene/light-installations.mjs',r=>r.fulfill({path:path.join(base,'baseline-products/light-installations.mjs'),contentType:'text/javascript'}));
  await page.goto('http://127.0.0.1:4160/al-folio/?scene-lab=1&quality=high&resolution=fixed',{waitUntil:'domcontentloaded'});
  const activate=locator=>engine==='webkit'?locator.tap():locator.click();
  await activate(page.locator('[data-home-desk-mode="3d"]'));
  const host=page.locator('[data-home-desk-scene]'),canvas=host.locator('canvas'),ui=page.locator('[data-home-world-controls]'),details=ui.locator('details').first();
  const open=async()=>{if(!await details.evaluate(e=>e.open))await activate(details.locator('summary').first())};
  const close=async()=>{if(await details.evaluate(e=>e.open))await activate(details.locator('summary').first())};
  await host.scrollIntoViewIfNeeded();await expect(host).toHaveAttribute('data-scene-state','ready',{timeout:240000});
  await open();await ui.locator('[data-world-avatar]').selectOption('ghibli');
  await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().avatarId)).toBe('ghibli');await expect(ui).not.toHaveAttribute('aria-busy','true');
  await activate(ui.locator('[data-world-view]'));
  await expect.poll(()=>host.evaluate(e=>['clifftop-flora','coastal-hinterland'].every(n=>e.labScene.scene.getObjectByName(n)?.visible)),{timeout:180000}).toBe(true);
  for(const [width,height]of viewports){
   await page.setViewportSize({width,height});
   for(const [label,minute]of [['noon',720],['evening',1260]]){
    await open();await ui.locator('[data-world-time]').fill(String(minute));await activate(ui.locator('[data-world-room="library-upper"]').first());
    await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().currentRoom)).toBe('library-upper');await close();
    await host.scrollIntoViewIfNeeded();
    for(const mode of ['embed','fullscreen']){
     const previous=await host.evaluate(e=>e.getSceneEvidence().frames);
     if(mode==='fullscreen')await activate(ui.locator('[data-world-fullscreen]'));
     else await host.evaluate(e=>e.labScene.requestFrame());
     await expect.poll(()=>host.evaluate(e=>e.getSceneEvidence().frames)).toBeGreaterThan(previous);await page.waitForTimeout(200);
     const file=`${engine}-${variant}-${label}-${mode}-${width}.png`,buffer=await canvas.screenshot({path:path.join(q,file)});
     const state=await host.evaluate(e=>{const c=e.querySelector('canvas'),gl=c.getContext('webgl2'),d=gl.getExtension('WEBGL_debug_renderer_info');return{evidence:e.getSceneEvidence(),backend:{renderer:gl.getParameter(d?.UNMASKED_RENDERER_WEBGL||gl.RENDERER),buffer:[gl.drawingBufferWidth,gl.drawingBufferHeight]}}});
     const metrics=screenshotMetrics(buffer);expect(metrics.luminanceVariance).toBeGreaterThan(4);expect(metrics.uniqueColors).toBeGreaterThan(128);expect(errors).toEqual([]);
     expect(state.evidence.loading.lightCache.state).toBe('restored');
     rows.push({engine,browser:browser.version(),variant,width,height,label,mode,file,pngSha256:sha(buffer),metrics,...state,errors:[...errors],scope:'Complete private product, disclosed authored room/time selection with real touch/click and embed/fullscreen controls; no camera, material or uniform override. WebKit is emulation, not physical iPhone performance.'});
     fs.writeFileSync(path.join(q,engine+'-captures.json'),JSON.stringify(rows,null,2));
     console.log(JSON.stringify({engine,variant,width,label,mode,colors:metrics.uniqueColors,cache:state.evidence.loading.lightCache.state,errors:errors.length}));
    }
    await activate(ui.locator('[data-world-fullscreen]'));
   }
  }
  await context.close();
 }}finally{await browser.close()}
})().catch(e=>{fs.writeFileSync(path.join(q,engine+'-failure.txt'),String(e.stack||e));console.error(e);process.exitCode=1});
