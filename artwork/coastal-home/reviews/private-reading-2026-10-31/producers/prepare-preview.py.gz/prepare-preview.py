import hashlib,json,shutil
from pathlib import Path
q=Path(__file__).parent;root=q.parents[2]
src=q.parent/'interior-lighting-20261031/site/al-folio';dst=q/'site/al-folio'
if dst.exists():raise RuntimeError('Preserve existing preview custody')
shutil.copytree(src,dst)
rows=[]
for file in sorted(src.rglob('*')):
    if not file.is_file():continue
    rel=file.relative_to(src);b=file.read_bytes()
    assert (dst/rel).read_bytes()==b
    rows.append({'path':rel.as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(q/'compiled-baseline.json').write_text(json.dumps({'source':str(src),'scope':'Full1360-fileproduct plus4official-bake sourceinputs from frozen4159; acceptedhardware/leaf/gym candidate, original privatecage and freshbaselinecache','files':rows},indent=2)+'\n',encoding='utf-8')
old=q/'baseline-products';old.mkdir()
for name in ['assets/models/home/room-library-upper.glb','assets/models/home/manifest.json','assets/models/home/static-light-field.json','assets/js/home-scene/light-installations.mjs']:
    shutil.copy2(dst/name,old/Path(name).name)
(dst/'assets/models/home/room-library-upper.glb').write_bytes((q/'export-v1/models/room-library-upper.glb').read_bytes())
(dst/'assets/models/home/manifest.json').write_bytes((q/'native-v1/manifest.json').read_bytes())
(dst/'assets/js/home-scene/light-installations.mjs').write_text((root/'assets/js/home-scene/light-installations.mjs').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
print(json.dumps({'completeFiles':len(rows),'preview':str(dst)}))
