const fs=require('node:fs'),path=require('node:path');
const {chromium}=require('C:/dev/dylantao.github.io/node_modules/playwright');
const q=__dirname;
(async()=>{
 const browser=await chromium.launch({headless:true});
 try{
  const context=await browser.newContext(),page=await context.newPage();
  await page.route('**/__interior-qa/*.glb',route=>{const basename=path.basename(new URL(route.request().url()).pathname),[variant,room]=basename.slice(0,-4).split('--');return route.fulfill({path:path.join(q,variant==='baseline'?'baseline-products':'export-v4/models','room-'+room+'.glb'),contentType:'model/gltf-binary'})});
  await page.goto('http://127.0.0.1:4160/al-folio/404.html',{waitUntil:'domcontentloaded'});
  const data=await page.evaluate(async()=>{
   const T=await import('/al-folio/assets/js/three.module.min.js');
   const {createModelLoader}=await import('/al-folio/assets/js/home-scene/model-loader.mjs');
   const {loader,decoder}=createModelLoader(),rows=[];
   try{
    for(const room of ['library-upper'])for(const variant of ['baseline','candidate']){
     const gltf=await loader.loadAsync('/al-folio/__interior-qa/'+variant+'--'+room+'.glb');
     gltf.scene.updateMatrixWorld(true);const meshes=[];
     gltf.scene.traverse(obj=>{
      if(!obj.isMesh)return;
      const p=obj.geometry.attributes.position,n=obj.geometry.attributes.normal;
      const assoc=gltf.parser.associations.get(obj),original=gltf.parser.json.nodes[assoc.nodes].name;
      const normalMatrix=new T.Matrix3().getNormalMatrix(obj.matrixWorld),v=new T.Vector3(),positions=[],normals=[];
      for(let i=0;i<p.count;i++){
       v.fromBufferAttribute(p,i).applyMatrix4(obj.matrixWorld);positions.push(v.x,-v.z,v.y);
       v.fromBufferAttribute(n,i).applyMatrix3(normalMatrix).normalize();normals.push(v.x,-v.z,v.y);
      }
      const attributes={};
      for(const [name,a]of Object.entries(obj.geometry.attributes))if(!['position','normal'].includes(name))attributes[name]={itemSize:a.itemSize,normalized:a.normalized,array:Array.from(a.array)};
      meshes.push({name:original,material:obj.material.name,positions,normals,indices:Array.from(obj.geometry.index.array),attributes});
      obj.geometry.dispose();obj.material.dispose();
     });rows.push({room,variant,meshes,materials:gltf.parser.json.materials});
    }
   }finally{decoder.dispose()}return rows;
  });
  fs.writeFileSync(path.join(q,'decoded-v4.json'),JSON.stringify(data));
  console.log(JSON.stringify(data.map(r=>({room:r.room,variant:r.variant,meshes:r.meshes.length,vertices:r.meshes.reduce((n,m)=>n+m.positions.length/3,0),triangles:r.meshes.reduce((n,m)=>n+m.indices.length/3,0)}))));
  await context.close();
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
