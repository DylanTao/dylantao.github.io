import hashlib, json, math
from pathlib import Path
import numpy as np
from PIL import Image
q=Path(__file__).parent; folder=q/'views-final'
rows=json.loads((folder/'captures.json').read_text())
assert len(rows)==20 and all(not r['errors']and r['observerCallbacksRestoredExactly']for r in rows)
pairs=[]
for candidate in [r for r in rows if r['variant']=='candidate']:
    baseline=next(r for r in rows if r['variant']=='baseline'and r['room']==candidate['room']and r['label']==candidate['label'])
    a=np.asarray(Image.open(folder/baseline['file']).convert('RGBA')).astype(np.int16)
    b=np.asarray(Image.open(folder/candidate['file']).convert('RGBA')).astype(np.int16)
    assert a.shape==b.shape
    delta=np.abs(a-b);mask=np.any(delta,axis=2)
    pair={'room':candidate['room'],'label':candidate['label'],'changedPixels':int(mask.sum()),
          'totalPixels':int(mask.size),'maximumChannelDelta255':int(delta.max()),'meanAbsoluteChannelDelta255':float(delta.mean())}
    if candidate['room']=='library-upper'and'-body'not in candidate['label']:
        rois={}
        for name,(x0,y0,x1,y1)in {'leftChair':[980,900,1180,1030],'rightChair':[1430,930,1650,1050]}.items():
            weights=np.array([.2126,.7152,.0722])
            aa=a[y0:y1,x0:x1,:3]@weights;bb=b[y0:y1,x0:x1,:3]@weights
            rois[name]={'pixelBounds':[x0,y0,x1,y1],'baselineMeanLuma255':float(aa.mean()),'candidateMeanLuma255':float(bb.mean()),
                        'meanLumaIncrease255':float((bb-aa).mean())}
        pair['disclosedChairInteriorROIs']=rois
    if candidate['room']!='outside':
        assert all(d['gpu']['currentProgramMatches'] for d in candidate['draws'])
        beauty=[d for d in candidate['draws']if d['material'] and d['gpu']['installActive'] is not None]
        assert beauty
        assert all(d['gpu']['slfReady']==1 for d in beauty)
        pair['qualifiedBeautyDraws']=len(beauty)
        pair['observedDepthOverrideDraws']=len(candidate['draws'])-len(beauty)
    if candidate['room']=='library-upper'and'-body'not in candidate['label']:
        draws=[d for d in candidate['draws']if d['material']=='linen']
        assert draws
        expected=np.array([.65,4.855,12.65]);ends=np.array([.65,5.015,12.65])
        level=candidate['evidence']['simulation']['installations']['levels']['privateReading']
        expected_color=np.array([1,.74,.5])*3.25*level
        witness=[]
        for draw in draws:
            matches=[i for i,v in enumerate(draw['gpu']['installLineA'])if v is not None and np.max(np.abs(np.array(v)-expected))<2e-5]
            assert len(matches)==1
            i=matches[0]
            assert np.max(np.abs(np.array(draw['gpu']['installLineB'][i])-ends))<2e-5
            assert np.max(np.abs(np.array(draw['gpu']['installLineColor'][i])-expected_color))<2e-5
            witness.append({'object':draw['object'],'receiver':draw['receiver'],'slot':i,
                            'actualLineA':draw['gpu']['installLineA'][i],'actualLineB':draw['gpu']['installLineB'][i],
                            'actualLineColor':draw['gpu']['installLineColor'][i]})
        pair['actualChairGPUDrawWitnesses']=witness
    pairs.append(pair)
before=json.loads((q/'baseline-products/static-light-field.json').read_text())
after=json.loads((q/'site/al-folio/assets/models/home/static-light-field.json').read_text())
assert before['configuration']==after['configuration']
config=json.loads(after['configuration'])
assert len(config['practicalSources'])==28
delta=(after['statistics']['triangles']+after['statistics']['skippedTriangles'])-(before['statistics']['triangles']+before['statistics']['skippedTriangles'])
assert delta==572
report={'matchedViews':pairs,'actualPerDrawProgramsMatchAndBeautyReady':True,'originalTransportConfigurationByteExact':True,
        'passScope':'Unnamed depth/normal override draws have no installation/SH uniforms; every observer CURRENT_PROGRAM matches. The light-field-ready and emitter-array qualification applies to actual named beauty materials.',
        'samePracticalChannels':len(config['practicalSources']),'sameProbes':len(after['probes']),
        'fullPreROICollectorDelta':delta,'newFixtureTriangles':572,
        'sourceConfigurationScope':'Original receiver probes and transport sources are exact; the new direct-only installation is not a transport channel. Added native shade/canopy/cord/hoops remain real occluders.',
        'cache':{'bytes':(q/'site/al-folio/assets/models/home/static-light-field.json').stat().st_size,
                 'signature':after['signature'],'sha256':hashlib.sha256((q/'site/al-folio/assets/models/home/static-light-field.json').read_bytes()).hexdigest()}}
(q/'analysis-final.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'pairs':[{'room':p['room'],'label':p['label'],'changed':p['changedPixels'],'maxDelta':p['maximumChannelDelta255'],'chairs':p.get('disclosedChairInteriorROIs')}for p in pairs],'collectorDelta':delta}))
