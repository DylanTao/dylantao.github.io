from pathlib import Path
import json, shutil
q = Path(__file__).parent
site = q/'site/al-folio'
for name in ['manifest.json', 'static-light-field.json', 'room-library-upper.glb']:
    assert (q/'v1-products'/name).is_file(), name
shutil.copy2(q/'native-v2/manifest.json', site/'assets/models/home/manifest.json')
shutil.copy2(q/'export-v2/models/room-library-upper.glb', site/'assets/models/home/room-library-upper.glb')
shutil.copy2(q.parents[2]/'assets/js/home-scene/light-installations.mjs', site/'assets/js/home-scene/light-installations.mjs')
s = (q/'verify-native.py').read_text(encoding='utf-8')
s = s.replace("native-v1/", "native-v2/").replace("native-verification.json", "native-verification-v2.json")
(q/'verify-native-v2.py').write_text(s, encoding='utf-8', newline='\n')
s = (q/'capture-v1.cjs').read_text(encoding='utf-8').replace("views-v1", "views-v2")
(q/'capture-v2.cjs').write_text(s, encoding='utf-8', newline='\n')
print(json.dumps({'preview': str(site), 'fixture': json.loads((q/'native-v2/receipt.json').read_text())['triangles']}))
