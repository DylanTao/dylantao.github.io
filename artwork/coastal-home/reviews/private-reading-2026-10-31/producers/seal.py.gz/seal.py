import gzip, hashlib, json, shutil, subprocess
from pathlib import Path
q=Path(__file__).parent;root=q.parents[2]
out=root/'artwork/coastal-home/reviews/private-reading-2026-10-31'
if out.exists():raise RuntimeError('A sealed review already exists')
desktop=json.loads((q/'layouts-v4/chromium-captures.json').read_text())
phone=json.loads((q/'layouts-v4/webkit-captures.json').read_text())
assert len(desktop)==32 and len(phone)==8
assert all(not r['errors']and r['evidence']['loading']['lightCache']['state']=='restored' for r in desktop+phone)
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()
assert source.startswith('9abe4425a')
out.mkdir(parents=True)
def put(src,dst,compress=True):
    b=Path(src).read_bytes();target=out/(dst+('.gz'if compress else''));target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(b,compresslevel=9,mtime=0)if compress else b)
for row in json.loads((q/'views-final/captures.json').read_text()):
    put(q/'views-final'/row['file'],'views/'+row['file'],False)
put(q/'views-final/captures.json','data/matched-2k-captures.json')
for engine,rows in [('chromium',desktop),('webkit',phone)]:
    for row in rows:put(q/'layouts-v4'/row['file'],'layouts/'+row['file'],False)
    put(q/'layouts-v4'/f'{engine}-captures.json',f'data/{engine}-layouts.json')
for name in ['analysis-final.json','native-verification-v4.json','decoded-native-verification-v4.json','decoded-v4.json','capacity-v4.json','compiled-baseline.json']:
    put(q/name,'data/'+name)
for name in ['receipt.json','manifest.json']:put(q/'native-v4'/name,'native/'+name)
put(q/'export-v4/report.json','native/export-report.json')
for name in ['manifest.json','static-light-field.json','room-library-upper.glb','light-installations.mjs']:
    put(q/'baseline-products'/name,'controls/baseline-'+name)
for name in ['manifest.json','static-light-field.json','room-library-upper.glb']:
    put(q/'site/al-folio/assets/models/home'/name,'products/candidate-'+name)
for version in ['v1','v2','v3']:
    put(q/f'native-{version}/receipt.json',f'attempts/{version}/receipt.json')
    put(q/f'export-{version}/models/room-library-upper.glb',f'attempts/{version}/room-library-upper.glb')
    image='candidate-noon-library-upper.png'if version=='v1'else'candidate-evening-library-upper.png'
    folder=q/('views-v1'if version=='v1'else'views-checkpoint'if version=='v2'else'views-v3')
    put(folder/image,f'attempts/{version}/'+image,False)
for name in ['v1-source.py','v3-source.py']:put(q/name,'attempts/'+name)
logs=['native-v4.log','export-v4.log','bake-v4.log','native-verification-v4.log','verify-delivery-v4.log','decode-v4.log','capture-final.log','layouts-chromium-retry.log','layouts-webkit-retry.log','layouts-chromium.log','layouts-webkit.log','python-suite.log','style-contract.log','focused-node.log']
for name in logs:put(q/name,'logs/'+name)
for name in ['chromium-first-harness-failure.txt','webkit-first-harness-failure.txt']:
    put(q/'layouts-v4'/name,'logs/'+name)
for name in ['capture-final.cjs','capture-layouts.cjs','capture-layouts-retry.cjs','decode-v4.cjs','verify-native-v4.py','verify-delivery-v4.py','analyze-final.py','capacity-v4.mjs','prepare-preview.py','install-v2.py','install-v3.py','prepare-v4.py','prepare-final.py','resume-layouts.py','serve.py','seal.py']:
    put(q/name,'producers/'+name)
for name in ['assets/js/home-scene/controller.mjs','assets/js/home-scene/light-installations.mjs','assets/js/home-scene/gym-props.mjs','assets/js/home-scene/static-light-field.mjs','assets/js/home-scene/model-loader.mjs','bin/bake_coastal_static_light.cjs','bin/coastal_static_light_inputs.cjs']:
    put(q/'site/al-folio'/name,'compiled/'+name)
put(root/'test/visual/helpers.js','producers/visual-helpers.js')
owned=['bin/coastal_private_reading.py','bin/refresh_coastal_private_reading.py','bin/coastal_retreat.py','assets/js/home-scene/light-installations.mjs','test/light-installations.test.mjs','test/test_private_reading.py']
dependencies=['bin/coastal_office.py','bin/optimize_coastal_exports.py','bin/refresh_coastal_study_hardware.py','bin/bake_coastal_static_light.cjs','bin/coastal_static_light_inputs.cjs','assets/js/home-scene/static-light-field.mjs','artwork/coastal-home/coastal-home.blend']
bindings=[]
for name in owned+dependencies:
    b=subprocess.check_output(['git','show',source+':'+name],cwd=root)
    bindings.append({'path':name,'gitBlobSha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
    if name in owned:put(root/name,'source/'+name)
binding={'sourceCommit':source,'sourceBindings':bindings,
         'compiledScope':'Complete 1364-file private product based on compiled 70ee4eac5 plus accepted hardware/foliage and gym fixes. Only the new upper-room GLB, direct-light schedule, fixture metadata and official cache are substituted for this review. This is not the final combined root build.',
         'canonicalNativeMasterSha256':'75afc57f664101e59150910f86662b21ccf01087c393521ab1fa1886e481c5ad',
         'inputNativeSha256':'096724fbe0a5beb36a98804b0092d170f3a255446623a64bbb66742a90dffb2f',
         'candidateNativeSha256':'56cc9aa324c3328f4692ac69fd38151616db595dd040f888c3010689767bcce0',
         'publication':'None. Coordinator replays the recipe, runs combined AO/export/support/sketch/official-cache gates, actual public Rooms checks, full suite, CI and live verification.'}
(out/'SOURCE_BINDINGS.json').write_text(json.dumps(binding,indent=2)+'\n',encoding='utf-8',newline='\n')
readme='''# A supported reading light for private living

Source `9abe4425a` adds one small native paper lantern beside and behind the upper
living chairs. Visiting the room turns it on; otherwise it rests by day and keeps
a restrained evening glow. The previously near-black chair backs gain readable
warm fabric at noon and night. Existing fixture powers, schedules, material colors,
exposure, shadows, the original probe cage and the 28 practical transport channels
are unchanged. The earlier rejected cage experiments remain documented in the
[lighting diagnostic review](../interior-lighting-2026-10-31/README.md).

## Physical placement and preservation

The final native fixture has 572 triangles in three batched pieces: the paper
shade, cord, and brass canopy with three fine hoops. No floor stand intrudes into
the bedroom approach. Seventeen floor samples beneath the whole fixture footprint
hit the retained upper floor at native z2.6025. The shade bottom is z4.78, leaving
2.1775 m of clear height and 0.4275 m above the 1.75 m standing body. Its cord meets
a real roof surface at native [0.65, -12.65, 5.968626]; all twelve canopy rim
contacts are within 0.000477 mm of that surface. This uses actual face/ray tests,
not an attachment name. The default cutaway lifts the roof away visually; the
standing view retains it.

The decoded effort-10 export adds exactly those three meshes to the four old
upper-room meshes. Every old decoded position, normal, index, auxiliary attribute
and glTF material definition is exact. The full native retained-object digest is
also exact. Maximum observed new-piece compression position error is 0.0539 mm;
the delivered canopy contacts remain within 0.0192 mm of the native roof, and the
delivered shade preserves 2.1775 m clearance. All new native pieces are closed,
manifold solids with positive volume. The canonical master remains byte-exact at
`75afc57f664101e59150910f86662b21ccf01087c393521ab1fa1886e481c5ad`.

## Actual rendered evidence

Twenty matched native RTX 3080 Ti/D3D11 captures cover noon/evening private-room
default cameras, actual supported standing-eye fixtures, kitchen, gym and exterior.
The disclosed standing placement uses the real Walkfield/capsule and eye camera;
it is a lighting/clearance qualification, not a public navigation journey.

Kitchen and gym pixels are exact in both times. Exterior noon changes twenty
pixels by at most 1/255; evening has the small visible interior glow (2,361 changed
pixels, at most 7/255). The unchanged dark fabric stays dark, with visible weave
and form instead of the old black silhouette. The two disclosed chair-interior
ROIs gain about 4.84/7.04 luma levels by noon and 6.97/9.93 by evening on the
0-255 scale. These are local comparison witnesses, not a whole-scene brightness
or measured illumination claim.

Passive `onAfterRender` observers confirm the actual current GPU program and
read the live emitter endpoints/colors for the linen beauty draws. The field is
ready and all observer callbacks restore exactly. Unnamed depth/normal override
draws have no lighting uniforms and are identified separately. No observer
changes a camera, material or uniform. The real shade's emissive strength follows
the schedule: approximately 0.715 on a noon visit and 1.1 on an evening visit.

The 32 Chromium captures cover all four standard widths, noon/evening,
embed/fullscreen, and baseline/candidate. Eight WebKit 27.2 phone captures cover
the same two times and display modes at 390 px. All are nonblank, restore the
official cache and have zero runtime errors. The phone is emulation, not physical
iPhone or frame-rate evidence. The existing 390 px default camera crops part of
the peripheral shade at the right edge; it does not cover the chair view. The
final coordinator build must check its actual public Rooms framing separately.

The first layout producer incorrectly tried to exit fullscreen through its hidden
enter button. The corrected producer uses the visible Back button, retains the
two valid initial captures, and completes the remaining states. Both failed
harness logs remain. This was a selector error, not a blank-scene result.

## Bounded lighting and retained attempts

The single new analytic line is direct-only. Its shortened segment retains the
authored integral intensity of the first attempt (0.52 in scene units); no watt
measurement is implied. The existing 18-line/10-point shader budgets stay fixed.
Actual region overlap places architecture at 18 lines/10 points and upper at
13/10; other packs remain within capacity. Combined arrival changes must repeat
this test. Geometry labels alone do not prove emitter exclusion.

The original transport configuration is byte-exact. The unmodified official
baker includes all 572 new triangles: 620,345 accepted plus 116,123 skipped =
736,468 before ROI, below its 750,000 gate. The final private cache is 792,584 bytes,
below the 800,000 gate. It has 128 probes and 28 practical channels plus the three
sky terms. The lantern is a real occluder, but its own indirect bounce is omitted
because the practical-channel budget is full. There is no new PointLight,
shadow map, full paper transmission or additional diffuse-bounce claim.

Retained native receipts, candidate GLBs and representative renders explain the
form iterations: V1 was too tall and clipped the 2K default frame; V2 fitted but
looked plain and polygonal; V3 rounded the profile but its mismatched hoop/shade
tessellation produced broken ribs. V4 matches the angular samples and offsets
the fine hoops just above the paper, producing continuous details with fewer
triangles. Only V4 is offered for replay.

## Replay and remaining integration gates

Use exact Blender 4.5.9. On an existing final-retreat source, replay
`bin/refresh_coastal_private_reading.py::migrate(scene, config)` after the accepted
hardware/foliage recipes. Its CLI defaults write an ignored private candidate,
never the canonical master or input manifest. A fresh `coastal_retreat.build`
adds the same fixture after its final frame; do not apply both routes to one
source. Double application rejects, and independent cage/frame/fixture changes
fail closed. `finish_metadata` registers only its one installation idempotently.

The 322 Python tests, 29 focused Node tests, style contract, compile, targeted
formatter and diff checks pass. The earlier source-only gym checkpoint records
the expected signed-production-cache failure; no worker has weakened that gate.
The coordinator owns the combined native AO/export/support/sketch pipeline,
official final cache, actual public desktop/phone Rooms views, complete current
root checks, CI, publication and live check. These isolated products are evidence,
not canonical assets or an independent deployment.

`MANIFEST.json` binds the portable payloads. `SOURCE_BINDINGS.json` binds the
source commit, canonical input and actual compiled scope. No independent push
occurred.
'''
(out/'README.md').write_text(readme,encoding='utf-8',newline='\n')
files=[]
for p in sorted(out.rglob('*')):
    if not p.is_file()or p.name=='MANIFEST.json':continue
    b=p.read_bytes();files.append({'path':p.relative_to(out).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
manifest={'schema':1,'scope':'Supported direct-only private reading fixture; source and isolated actual renders. Combined root integration/publication gates remain.','files':files}
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'review':str(out),'sourceCommit':source,'payloads':len(files),'bytes':sum(f['bytes']for f in files),'sourceBindings':len(bindings)}))
