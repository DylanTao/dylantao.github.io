import hashlib,json,sys
from pathlib import Path
from types import SimpleNamespace
import bpy,bmesh
from mathutils import Vector
q=Path(__file__).parent;sys.path.insert(0,str(q.parents[2]/'bin'))
from refresh_coastal_study_hardware import immutable_scene_digest
import coastal_private_reading as r
source=q.parent/'interior-finish-20261031/pothos-v2/candidate.blend'
candidate=q/'native-v4/candidate.blend'
receipt=json.loads((q/'native-v4/receipt.json').read_text())
bpy.ops.wm.open_mainfile(filepath=str(source))
names=set(bpy.context.scene.objects.keys())
before=immutable_scene_digest(bpy.context.scene,{})
bpy.ops.wm.open_mainfile(filepath=str(candidate))
scene=bpy.context.scene
old=SimpleNamespace(objects=[o for o in scene.objects if o.name in names])
assert immutable_scene_digest(old,{})==before==receipt['unchangedSceneDigestBefore']
new=[o for o in scene.objects if o.name not in names]
assert set(o.name for o in new)==set(receipt['objects'])
pieces=[]
for obj in new:
    bm=bmesh.new();bm.from_mesh(obj.data)
    open_edges=sum(not e.is_manifold for e in bm.edges);volume=bm.calc_volume(signed=True);bm.free()
    assert open_edges==0 and volume>0,(obj.name,open_edges,volume)
    points=[obj.matrix_world@v.co for v in obj.data.vertices]
    obj.data.calc_loop_triangles()
    pieces.append({'object':obj.name,'triangles':len(obj.data.loop_triangles),'nonmanifoldEdges':open_edges,'signedVolumeM3':volume,
                   'boundsNative':[[min(p[i]for p in points)for i in range(3)],[max(p[i]for p in points)for i in range(3)]]})
roof=scene.objects[receipt['nativeCeilingAttachment']['owner']]
anchor=Vector(receipt['nativeCeilingAttachment']['point']);normal=Vector(receipt['nativeCeilingAttachment']['normal'])
canopy=next(o for o in new if any(m.name=='brushed brass'for m in o.data.materials))
rim=[]
for v in canopy.data.vertices:
    p=canopy.matrix_world@v.co
    if abs((p-anchor).dot(normal))>1e-5:continue
    inv=roof.matrix_world.inverted();origin=inv@(p-normal*.02);direction=inv.to_3x3()@normal
    ok,hit,n,face=roof.ray_cast(origin,direction,distance=.05)
    assert ok
    point=roof.matrix_world@hit;gap=(p-point).length
    assert gap<.002
    rim.append({'nativeVertex':list(p),'roofFace':face,'surfaceGapM':gap})
assert len(rim)==12
try:r.build(scene)
except RuntimeError as e:
    assert str(e)=='The reading lantern is already present';repeat=str(e)
else:raise RuntimeError('Repeat unexpectedly accepted')
out={'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'candidateSha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),
     'allRetainedMeshAttributesAndTransformsExact':True,'unchangedSceneDigest':before,'newPieces':pieces,'canopyTopRimContact':rim,
     'minimumClearFloorHeightM':receipt['minimumClearHeightM'],'maximumStandingBodyHeightM':1.75,
     'minimumVerticalBodyClearanceM':receipt['minimumClearHeightM']-1.75,
     'scope':'Originalprivate/bedroomapproachfloors,chairs,andallothergeometry unchanged. Every fixturevertex is >=4.78m; measuredfloor2.6025m, so completefloorpathsunderitretain>2.1mclearance.',
     'doubleApplicationRejected':repeat}
(q/'native-verification-v4.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'newTriangles':sum(r['triangles']for r in pieces),'canopyRimMaximumGapM':max(r['surfaceGapM']for r in rim),'minimumClearHeightM':receipt['minimumClearHeightM'],'bodyClearanceM':out['minimumVerticalBodyClearanceM']}),flush=True)
