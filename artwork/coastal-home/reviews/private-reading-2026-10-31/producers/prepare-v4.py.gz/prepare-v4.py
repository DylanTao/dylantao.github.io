from pathlib import Path
import shutil
q=Path(__file__).parent
dst=q/'v3-products';dst.mkdir()
for name in ['manifest.json','static-light-field.json','room-library-upper.glb']:
    shutil.copy2(q/'site/al-folio/assets/models/home'/name,dst/name)
for src,dst in [('verify-native-v2.py','verify-native-v4.py'),('verify-delivery.py','verify-delivery-v4.py'),('decode-v2.cjs','decode-v4.cjs'),('capacity.mjs','capacity-v4.mjs')]:
    s=(q/src).read_text(encoding='utf-8').replace('native-v2','native-v4').replace('export-v2','export-v4').replace('decoded-v2','decoded-v4').replace('verification-v2','verification-v4').replace('capacity-v2','capacity-v4')
    (q/dst).write_text(s,encoding='utf-8',newline='\n')
s=(q/'capture-v3.cjs').read_text(encoding='utf-8').replace('views-v3','views-v4')
(q/'capture-v4.cjs').write_text(s,encoding='utf-8',newline='\n')
