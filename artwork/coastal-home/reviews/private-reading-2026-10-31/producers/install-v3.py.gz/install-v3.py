from pathlib import Path
import shutil
q=Path(__file__).parent;site=q/'site/al-folio'
assert (q/'v2-products/static-light-field.json').is_file()
shutil.copy2(q/'native-v3/manifest.json',site/'assets/models/home/manifest.json')
shutil.copy2(q/'export-v3/models/room-library-upper.glb',site/'assets/models/home/room-library-upper.glb')
for src,dst in [('verify-native-v2.py','verify-native-v3.py'),('verify-delivery.py','verify-delivery-v3.py'),('decode-v2.cjs','decode-v3.cjs'),('capacity.mjs','capacity-v3.mjs')]:
    s=(q/src).read_text(encoding='utf-8').replace('v2','v3')
    (q/dst).write_text(s,encoding='utf-8',newline='\n')
s=(q/'capture-v2.cjs').read_text(encoding='utf-8').replace('views-v2','views-v3').replace("[['noon',720]]", "[['noon',720],['evening',1260]]")
(q/'capture-v3.cjs').write_text(s,encoding='utf-8',newline='\n')
