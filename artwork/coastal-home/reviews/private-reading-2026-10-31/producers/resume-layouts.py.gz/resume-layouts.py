from pathlib import Path
q=Path(__file__).parent
s=(q/'capture-layouts.cjs').read_text(encoding='utf-8')
s=s.replace("    await activate(ui.locator('[data-world-fullscreen]'));", "    await activate(page.locator('[data-world-exit]:visible'));")
assert s.count("[data-world-exit]:visible")==1
s=s.replace('(async()=>{', "if(fs.existsSync(path.join(q,engine+'-captures.json')))rows.push(...JSON.parse(fs.readFileSync(path.join(q,engine+'-captures.json'),'utf8')));\n(async()=>{",1)
s=s.replace("     const file=`${engine}-${variant}-${label}-${mode}-${width}.png`,buffer=await canvas.screenshot({path:path.join(q,file)});", "     if(rows.some(r=>r.variant===variant&&r.width===width&&r.label===label&&r.mode===mode))continue;\n     const file=`${engine}-${variant}-${label}-${mode}-${width}.png`,buffer=await canvas.screenshot({path:path.join(q,file)});")
s=s.replace("  await preparePage(page,'light');", "  console.log(JSON.stringify({phase:'starting',engine,variant}));\n  await preparePage(page,'light');")
s=s.replace("  await open();await ui.locator('[data-world-avatar]')", "  console.log(JSON.stringify({phase:'ready',engine,variant}));\n  await open();await ui.locator('[data-world-avatar]')")
(q/'capture-layouts-retry.cjs').write_text(s,encoding='utf-8',newline='\n')
