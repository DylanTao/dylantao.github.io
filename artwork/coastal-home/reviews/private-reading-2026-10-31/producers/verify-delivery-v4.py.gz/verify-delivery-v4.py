import json, hashlib
from pathlib import Path
import bpy
from mathutils import Vector, kdtree
q=Path(__file__).parent
data=json.loads((q/'decoded-v4.json').read_text())
baseline,candidate=data
before={m['name']:m for m in baseline['meshes']}
after={m['name']:m for m in candidate['meshes']}
assert before.keys()<=after.keys()
assert all(before[n]==after[n] for n in before)
assert all(m in candidate['materials'] for m in baseline['materials'])
receipt=json.loads((q/'native-v4/receipt.json').read_text())
bpy.ops.wm.open_mainfile(filepath=str(q/'native-v4/candidate.blend'))
scene=bpy.context.scene
roof=scene.objects[receipt['nativeCeilingAttachment']['owner']]
anchor=Vector(receipt['nativeCeilingAttachment']['point'])
normal=Vector(receipt['nativeCeilingAttachment']['normal'])
new=[]
for name in after.keys()-before.keys():
    mesh=after[name]
    obj=scene.objects[name]
    vertices=[obj.matrix_world@v.co for v in obj.data.vertices]
    kd=kdtree.KDTree(len(vertices))
    for i,v in enumerate(vertices):kd.insert(v,i)
    kd.balance()
    p=mesh['positions'];points=[Vector(p[i:i+3])for i in range(0,len(p),3)]
    worst=max(kd.find(v)[2] for v in points)
    assert worst<.0001,(name,worst)
    row={'name':name,'deliveredVertices':len(points),'triangles':len(mesh['indices'])//3,
         'maximumObservedPositionErrorM':worst,
         'nativeBounds':[[min(v[i]for v in points)for i in range(3)],[max(v[i]for v in points)for i in range(3)]]}
    if mesh['material']=='private living washi diffuser':
        clearance=min(v.z for v in points)-max(s['nativePoint'][2]for s in receipt['floorAndClearanceSamples'])
        assert clearance>2.1
        row['deliveredMinimumFloorClearanceM']=clearance
    if mesh['material']=='brushed brass':
        gaps=[]
        for point in points:
            if abs((point-anchor).dot(normal))>2e-5:continue
            inv=roof.matrix_world.inverted()
            ok,hit,n,face=roof.ray_cast(inv@(point-normal*.02),inv.to_3x3()@normal,distance=.05)
            assert ok
            gap=(roof.matrix_world@hit-point).length
            assert gap<.002
            gaps.append(gap)
        assert len(gaps)>=12
        row['canopyRoofContacts']=len(gaps)
        row['maximumDeliveredRoofContactGapM']=max(gaps)
    new.append(row)
report={'allRetainedDecodedPositionsNormalsIndicesAuxAttributesExact':True,
        'allRetainedGLTFMaterialDefinitionsExact':True,
        'oldMeshCount':len(before),'newPieceCount':len(new),'newPieces':new,
        'sourceSha256':hashlib.sha256((q/'native-v4/candidate.blend').read_bytes()).hexdigest(),
        'deliveredGLBSha256':hashlib.sha256((q/'export-v4/models/room-library-upper.glb').read_bytes()).hexdigest()}
(q/'decoded-native-verification-v4.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report),flush=True)
