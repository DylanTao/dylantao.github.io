from pathlib import Path
q=Path(__file__).parent
s=(q/'capture-checkpoint-retry.cjs').read_text(encoding='utf-8').replace('views-checkpoint','views-final')
(q/'capture-final.cjs').write_text(s,encoding='utf-8',newline='\n')
