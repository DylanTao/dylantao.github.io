import fs from 'node:fs';
import {createLightInstallations, MAX_LINES, MAX_POINTS, roomLightSources} from '../../../assets/js/home-scene/light-installations.mjs';
const q=new URL('.',import.meta.url),file=n=>new URL(n,q),config=JSON.parse(fs.readFileSync(file('site/al-folio/assets/models/home/manifest.json'),'utf8'));
const lights=createLightInstallations(config);
try{
 const packs=lights.evidence().receiverPacks;
 for(const pack of Object.values(packs))if(pack.lines>MAX_LINES||pack.points>MAX_POINTS)throw Error('Capacity overflow');
 const fixture=lights.lines.find(l=>l.source==='private-living-reading-lantern');
 if(!fixture||fixture.transport!==false)throw Error('Expected direct-only source');
 const transport=roomLightSources(config);
 const baseline=JSON.parse(fs.readFileSync(file('baseline-products/manifest.json'),'utf8'));
 const beforeTransport=roomLightSources(baseline);
 const cache=JSON.parse(fs.readFileSync(file('site/al-folio/assets/models/home/static-light-field.json'),'utf8'));
 const configuration=JSON.parse(cache.configuration);
 const channels=configuration.practicalSources.length;
 if(cache.transport.length!==cache.probes.length*(channels+3)*12)throw Error('Unexpected SH layout');
 const result={limits:{lines:MAX_LINES,points:MAX_POINTS},receiverPacks:packs,
  authoredTransportSourceCount:transport.length,totalBakedChannels:channels,
  authoredTransportSourcesExact:JSON.stringify(transport)===JSON.stringify(beforeTransport),
  fixtureIncludedInTransport:transport.some(l=>l.id==='installation:'+fixture.source),
  method:'Actual runtime region overlap and pack construction; final combined root replay must repeat this audit.'};
 if(channels!==28||result.fixtureIncludedInTransport||!result.authoredTransportSourcesExact)throw Error('Transport channels changed');
 fs.writeFileSync(file('capacity-v4.json'),JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify({packs:Object.fromEntries(Object.entries(packs).map(([n,p])=>[n,[p.lines,p.points]])),authoredTransport:transport.length,totalBakedChannels:channels}));
}finally{lights.dispose()}
