from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
class Server(ThreadingHTTPServer):
    request_queue_size=128
    daemon_threads=True
class Handler(SimpleHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def log_message(self,fmt,*args):pass
Server(('127.0.0.1',4160),partial(Handler,directory=str(Path(__file__).parent/'site'))).serve_forever()
