import gzip, hashlib, json, subprocess, sys
from pathlib import Path
q=Path(__file__).parent;root=q.parents[2];rel='artwork/coastal-home/reviews/private-reading-2026-10-31';packet=root/rel
commit=sys.argv[1]if len(sys.argv)>1 else None
def read(name):
    return subprocess.check_output(['git','show',commit+':'+rel+'/'+name],cwd=root)if commit else(packet/name).read_bytes()
manifest=json.loads(read('MANIFEST.json'))
for row in manifest['files']:
    b=read(row['path']);assert len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256'],row['path']
bindings=json.loads(read('SOURCE_BINDINGS.json'))
for row in bindings['sourceBindings']:
    b=subprocess.check_output(['git','show',bindings['sourceCommit']+':'+row['path']],cwd=root)
    assert len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['gitBlobSha256'],row['path']
    source='source/'+row['path']+'.gz'
    if any(r['path']==source for r in manifest['files']):assert gzip.decompress(read(source)).replace(b'\r\n',b'\n')==b
rows=json.loads(gzip.decompress(read('data/matched-2k-captures.json.gz')))
assert len(rows)==20
for row in rows:assert hashlib.sha256(read('views/'+row['file'])).hexdigest()==row['pngSha256']
for engine,count in [('chromium',32),('webkit',8)]:
    rows=json.loads(gzip.decompress(read('data/'+engine+'-layouts.json.gz')));assert len(rows)==count
    for row in rows:assert hashlib.sha256(read('layouts/'+row['file'])).hexdigest()==row['pngSha256']
product=json.loads(gzip.decompress(read('products/candidate-manifest.json.gz')))
cache=gzip.decompress(read('products/candidate-static-light-field.json.gz'))
descriptor=product['staticLightFieldCache'];snapshot=json.loads(cache)
assert descriptor['sha256']==hashlib.sha256(cache).hexdigest()and descriptor['signature']==snapshot['signature']
assert len(cache)==json.loads(gzip.decompress(read('data/analysis-final.json.gz')))['cache']['bytes']
print(json.dumps({'readback':'git'if commit else'disk','commit':commit,'payloads':len(manifest['files']),'sourceBindings':len(bindings['sourceBindings']),'imageHashes':60,'cacheBytes':len(cache),'verified':True}))
