import json
from pathlib import Path

q = Path(__file__).resolve().parent
report = json.loads((q/'attempt-2/result.json').read_bytes())
rows = []
for view in report['views']:
    frames = view['frames']
    rows.append({'view':view['room'],'activity':view['activity'],
      'movingExactTileFractions':[r['exact']['dirtyTileCapacityFraction'] for r in view['comparisons']['moving']],
      'movingDiagnosticTileFractions':[r['diagnostic']['dirtyTileCapacityFraction'] for r in view['comparisons']['moving']],
      'movingCameraDeltasM':[sum((a-b)**2 for a,b in zip(frames[i]['evidence']['camera'],frames[i+1]['evidence']['camera']))**.5 for i in range(3)],
      'movingIntervalsMs':[r['intervalMs'] for r in view['comparisons']['moving']],
      'observedRoomCounts':[f['evidence']['roomCount'] for f in frames[:4]],
      'pausedExactPixels':view['comparisons']['paused']['exact']['changedPixels'],
      'draggedExactPixels':view['comparisons']['dragged']['exact']['changedPixels'],
      'buffer':frames[0]['gl']['buffer'],'renderer':frames[0]['gl']['renderer'],
      'qualities':[f['evidence']['quality']['tier'] for f in frames[:4]],
      'oracleReconstructionExact':all(x['oracleReconstructionExact'] for x in view['comparisons']['moving'])})
result = {'method':'Readback-based change census, no reuse predictor or timing claim. Threshold2 is diagnostic only; exact masks remain qualification input. Camera deltas and actual sampling intervals retained.','sourceDeclaration':report['sourceDeclaration'],'responseBodies':len(report['responses']),'errors':report['errors'],'failures':report['failures'],'views':rows}
(q/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps(result))
