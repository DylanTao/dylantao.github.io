const path=require('node:path');
const root=process.cwd(),base=require(path.join(root,'test/visual/public.config.js'));
module.exports={...base,workers:1,testMatch:['sitewide.spec.js','brand-finish.spec.js'],grep:/CV preserves semantic|project reading dock stays|public route: (cv|project-designweaver)$|brand mark: the sun stays fixed/,outputDir:path.join(__dirname,'runtime-navigation-visual-v3/playwright'),reporter:[['line'],['json',{outputFile:path.join(__dirname,'runtime-navigation-visual-v3/VISUAL.json')}]],webServer:undefined};
