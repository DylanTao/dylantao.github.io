from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess,time
root=Path.cwd();q=Path(__file__).parent;out=q/'runtime-navigation-visual-v3';assert not out.exists();out.mkdir();server=json.loads((q/'runtime-navigation-checkpoint-v2/server.json').read_text())
env=dict(os.environ,NO_WEBSERVER='1',VISUAL_BASE_URL=server['url'].rstrip('/'),VISUAL_ROUTE_IDS='cv,project-designweaver',VISUAL_THEMES='light,dark')
args=['C:/Program Files/nodejs/npx.cmd','playwright','test','--config',str(q/'runtime-navigation-checkpoint.config.cjs')]
start=time.monotonic()
with(out/'visual.log').open('wb')as log:r=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
record={'at':datetime.now(timezone.utc).isoformat(),'command':args,'baseURL':env['VISUAL_BASE_URL'],'server':server,'exitCode':r.returncode,'seconds':time.monotonic()-start,'priorAttempt':'v2 incorrectly removed /al-folio from the base URL and inspected404 pages. Stopped its exact owned process tree; original logs and failure traces are retained. No application evidence was admitted from v2.'}
(out/'PROCESS.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');print(json.dumps(record));assert r.returncode==0
