const { test, expect } = require("@playwright/test");
const { attachScreenshot, collectRuntimeErrors, preparePage, screenshotDiffRatio, stabilizeVisuals } = require("./helpers");
const { ALL_SITEWIDE_ROUTES, SITEWIDE_ROUTES, publicRouteUrl } = require("./public-routes");

const FUN_PROJECT_ROUTE_IDS = new Set([
  "project-house-in-the-cliff",
  "project-graphics-performance",
  "project-graphics-lab",
  "project-openai-build-week",
  "project-paper-constellation",
  "project-build-rhythm",
  "project-homepage-desk-scene",
  "project-pip",
  "project-la-jolla",
  "project-light-paths",
  "project-hci-spooder-man",
  "project-scholar-lens",
  "project-wall-of-rejection",
  "project-ikea-project-cards",
  "project-website-revamp",
  "project-dogtor-portal",
  "project-not-a-good-driver",
]);
// Children keep their pages (and every fun-project check) but are listed on their parent's page, not the index:
// the Graphics Lab's deck shows them as rows of its record, not as project cards.
const CHILD_PROJECT_ROUTE_IDS = new Set(["project-light-paths", "project-graphics-performance"]);
const INDEXED_FUN_PROJECT_COUNT = FUN_PROJECT_ROUTE_IDS.size - CHILD_PROJECT_ROUTE_IDS.size;

const COASTAL_THEME_MODES = [
  { mode: "morning", label: "Morning", computedTheme: "light" },
  { mode: "noon", label: "Noon", computedTheme: "light" },
  { mode: "afternoon", label: "Afternoon", computedTheme: "light" },
  { mode: "evening", label: "Evening", computedTheme: "dark" },
];

function selectedRouteThemes() {
  const value = process.env.VISUAL_THEMES?.trim();
  if (!value) return ["light", "dark"];

  const themes = [
    ...new Set(
      value
        .split(",")
        .map((theme) => theme.trim())
        .filter(Boolean)
    ),
  ];
  const unknownThemes = themes.filter((theme) => !["light", "dark"].includes(theme));
  if (unknownThemes.length > 0 || themes.length === 0) {
    throw new Error('VISUAL_THEMES must contain "light", "dark", or both.');
  }
  return themes;
}

const SITEWIDE_ROUTE_THEMES = selectedRouteThemes();

test("CV preserves semantic sections, native navigation and printable current text", async ({ page, browser }, testInfo) => {
  const runtimeErrors = collectRuntimeErrors(page);
  await preparePage(page);
  await page.goto(publicRouteUrl("/cv/"), { waitUntil: "domcontentloaded" });
  const cv = page.locator(".cv");
  await expect(cv.locator("h2.card-title").first()).toBeVisible();
  await expect(page.locator(".cv-page h1")).toHaveText("CV");
  await expect(cv.locator("h4, h5, h6")).toHaveCount(0);
  expect(await cv.locator("h3.cv-item-title").count()).toBeGreaterThan(10);
  await expect(cv.locator(".cv-entry-meta").first()).toHaveJSProperty("tagName", "P");

  const inspectSections = (root) =>
    root.evaluate(() => {
      const ids = Array.from(document.querySelectorAll("[id]"), (element) => element.id);
      const headings = Array.from(document.querySelectorAll(".cv h2.card-title"));
      const links = Array.from(document.querySelectorAll("[data-cv-section-links] a"));
      return {
        duplicateIds: ids.filter((id, index) => ids.indexOf(id) !== index),
        sectionIds: headings.map((heading) => heading.id),
        linkIds: links.map((link) => decodeURIComponent(link.hash.slice(1))),
        wrongTargets: links.filter((link) => document.getElementById(decodeURIComponent(link.hash.slice(1)))?.tagName !== "H2").length,
      };
    });
  const sections = await inspectSections(page);
  expect(sections.duplicateIds).toEqual([]);
  expect(sections.linkIds).toEqual(sections.sectionIds);
  expect(sections.wrongTargets).toBe(0);
  await expect(cv.getByRole("rowheader", { name: "Email", exact: true })).toHaveAttribute("scope", "row");
  await expect(cv.getByRole("link", { name: "s1tao@ucsd.edu", exact: true })).toHaveAttribute("href", "mailto:s1tao@ucsd.edu");
  await expect(page.getByRole("link", { name: "Open current CV PDF", exact: true })).toHaveAttribute("href", /Sirui_Tao_CV_Public\.pdf$/);

  const compactNavigation = page.viewportSize().width < 992;
  if (compactNavigation) {
    const control = page.locator("[data-cv-mobile-sections]");
    await expect(control).toHaveAttribute("data-cv-enhanced", "");
    expect(await control.evaluate((element) => getComputedStyle(element).position)).toBe("sticky");
    await page.evaluate(() => window.scrollTo({ top: 750, behavior: "instant" }));
    const controlBounds = await control.boundingBox();
    expect(controlBounds.y).toBeGreaterThanOrEqual(60);
    expect(controlBounds.y).toBeLessThan(100);
    await control.locator("summary").focus();
    await page.keyboard.press("Enter");
    await expect(control).toHaveAttribute("open", "");
    await control.getByRole("link", { name: "Research Experience", exact: true }).focus();
    await page.keyboard.press("Enter");
    await expect(control).not.toHaveAttribute("open", "");
    await expect(cv.locator("#academia")).toBeFocused();
    await expect(page).toHaveURL(/#academia$/);
  }

  // Reflow changes renderer whitespace; words and punctuation must remain identical.
  const readableText = (text) => text.replace(/\s+/gu, " ").trim();
  const beforePrint = readableText(await cv.innerText());
  await page.emulateMedia({ media: "print" });
  for (const selector of ["#top", ".toc-sidebar-column", "footer", "[data-cv-mobile-sections]", ".cv-pdf-link"]) {
    await expect(page.locator(selector).first()).toBeHidden();
  }
  await expect(cv.locator("#education")).toBeVisible();
  expect(readableText(await cv.innerText())).toBe(beforePrint);
  const printLayout = await page.locator("#main").evaluate((main) => ({
    width: main.getBoundingClientRect().width,
    viewport: window.innerWidth,
    background: getComputedStyle(document.body).backgroundColor,
    entryBreak: getComputedStyle(document.querySelector(".cv .list-group-item")).breakInside,
  }));
  expect(printLayout.width).toBeGreaterThan(printLayout.viewport * 0.95);
  expect(printLayout.background).toBe("rgb(255, 255, 255)");
  expect(printLayout.entryBreak).toBe("avoid");
  await attachScreenshot(page, testInfo, "cv-print", { fullPage: false });
  expect(runtimeErrors).toEqual([]);

  const noScriptContext = await browser.newContext({ viewport: page.viewportSize(), javaScriptEnabled: false, reducedMotion: "reduce" });
  try {
    const noScriptPage = await noScriptContext.newPage();
    await preparePage(noScriptPage);
    await noScriptPage.goto(publicRouteUrl("/cv/"), { waitUntil: "domcontentloaded" });
    const nativeSections = await inspectSections(noScriptPage);
    expect(nativeSections).toEqual(sections);
    expect(readableText(await noScriptPage.locator(".cv").innerText())).toBe(beforePrint);
    const nativeSidebarIds = await noScriptPage
      .locator("#toc-sidebar a")
      .evaluateAll((links) => links.map((link) => decodeURIComponent(link.hash.slice(1))));
    expect(nativeSidebarIds).toEqual(sections.sectionIds);
    if (compactNavigation) {
      const nativeControl = noScriptPage.locator("[data-cv-mobile-sections]");
      await nativeControl.locator("summary").focus();
      await noScriptPage.keyboard.press("Enter");
      await nativeControl.getByRole("link", { name: "Research Experience", exact: true }).focus();
      await noScriptPage.keyboard.press("Enter");
      await expect(noScriptPage).toHaveURL(/#academia$/);
      await expect(noScriptPage.locator("#academia")).toBeFocused();
      const nativeArrival = await noScriptPage.locator("#academia").boundingBox();
      expect(nativeArrival.y).toBeGreaterThanOrEqual(70);
      expect(nativeArrival.y).toBeLessThan(noScriptPage.viewportSize().height / 2);
      expect(await nativeControl.evaluate((element) => getComputedStyle(element).position)).toBe("static");
    } else {
      const nativeLink = noScriptPage.locator("#toc-sidebar").getByRole("link", { name: "Research Experience", exact: true });
      await expect(nativeLink).toBeVisible();
      await nativeLink.focus();
      await noScriptPage.keyboard.press("Enter");
      await expect(noScriptPage).toHaveURL(/#academia$/);
      await expect(noScriptPage.locator("#academia")).toBeFocused();
    }
    await attachScreenshot(noScriptPage, testInfo, "cv-native-no-script", { fullPage: false });
  } finally {
    await noScriptContext.close();
  }
});

test("project reading dock stays available while scrolling and returns keyboard focus to the selected section", async ({ page }, testInfo) => {
  const runtimeErrors = collectRuntimeErrors(page);
  await preparePage(page);
  await page.goto(publicRouteUrl("/projects/designweaver/"), { waitUntil: "domcontentloaded" });
  const dock = page.locator(".section-reading-aid-mobile-dock");
  await expect(dock).toBeAttached();
  expect(await dock.evaluate((element) => getComputedStyle(element).position)).toBe("fixed");
  // The dock intentionally stays quiet over the hero and inline contents.
  // Crossing an actual body heading supplies the normal navigation cue.
  await page
    .locator(".project-detail article > h2")
    .nth(1)
    .evaluate((heading) => {
      window.scrollTo({ top: window.scrollY + heading.getBoundingClientRect().top - 150, behavior: "instant" });
    });
  await expect(dock).toBeVisible();
  const bounds = await dock.boundingBox();
  expect(bounds.x).toBeGreaterThanOrEqual(0);
  expect(bounds.y).toBeGreaterThan(60);
  expect(bounds.x + bounds.width).toBeLessThanOrEqual(page.viewportSize().width + 1);
  expect(bounds.y + bounds.height).toBeLessThan(page.viewportSize().height);
  const toggle = dock.locator("button");
  await toggle.focus();
  await page.keyboard.press("Enter");
  await expect(toggle).toHaveAttribute("aria-expanded", "true");
  const destination = dock.locator("a[data-section-id]").nth(1);
  const target = await destination.getAttribute("data-section-id");
  await destination.focus();
  await page.keyboard.press("Enter");
  await expect(page.locator(`[id="${target}"]`)).toBeFocused();
  await expect(toggle).toHaveAttribute("aria-expanded", "false");
  await expect(page).toHaveURL(new RegExp(`#${target}$`));
  await attachScreenshot(page, testInfo, "project-reading-dock", { fullPage: false });
  expect(runtimeErrors).toEqual([]);
});

// Keep the homepage last: its richer desk surface should not precede the
// lighter-weight route samples in the same Chromium process.
const COASTAL_THEME_ROUTE_SAMPLES = [
  {
    path: "/projects/",
    readySelector: ".projects [data-project-card-grid]",
    surfaceSelector: ".projects [data-project-card] .card",
  },
  {
    path: "/publications/",
    readySelector: "[data-publication-workbench]",
    surfaceSelector: ".scholar-lens-card",
  },
  {
    path: "/blog/",
    readySelector: ".blog-index .header-bar",
    surfaceSelector: ".blog-pinned-card",
  },
  {
    path: "/",
    readySelector: '[data-home-section="start"]',
    // The thesis is an unboxed note; sample the retained research-focus card.
    surfaceSelector: ".home-motion-detail.is-active",
  },
];

async function switchToCoastalThemeMode(page, { mode, computedTheme }) {
  const root = page.locator("html");

  if ((await root.getAttribute("data-theme-mode")) !== mode) {
    await page.locator("#theme-toggle").click();
    await page.locator(`#theme-menu [data-theme-mode-option="${mode}"]`).click();
    // Choices stay open for comparison; this surface sampler explicitly dismisses the menu.
    await page.keyboard.press("Escape");
  }

  await expect(root).toHaveAttribute("data-theme-mode", mode);
  await expect(root).toHaveAttribute("data-theme-setting", mode);
  await expect(root).toHaveAttribute("data-theme", computedTheme);
  await expect(root).not.toHaveClass(/\btransition\b/, { timeout: 3000 });
  await expect
    .poll(
      () =>
        page.evaluate(
          () =>
            document
              .getAnimations()
              .filter(
                (animation) =>
                  animation.constructor.name === "CSSTransition" &&
                  ["pending", "running"].includes(animation.playState) &&
                  /color$|^(background|fill|stroke|box-shadow|text-shadow|filter)$/.test(animation.transitionProperty)
              ).length
        ),
      { message: `${mode} theme surfaces kept transitioning after html.transition cleared`, timeout: 3000 }
    )
    .toBe(0);
}

async function readSettledCoastalThemeSample(page, surfaceSelector) {
  return page.evaluate(async (selector) => {
    if (document.fonts?.ready) await document.fonts.ready;
    await new Promise((resolve) => window.requestAnimationFrame(() => window.requestAnimationFrame(resolve)));

    const root = document.documentElement;
    const navbar = document.querySelector("#navbar");
    const surface = document.querySelector(selector);
    const footer = document.querySelector("footer");
    if (!navbar || !surface || !footer) throw new Error(`Missing coastal theme sample surface for ${selector}`);

    const rootStyle = getComputedStyle(root);
    const value = (name) => rootStyle.getPropertyValue(name).trim().toLowerCase();
    const computed = (element) => {
      const style = getComputedStyle(element);
      return {
        background: style.backgroundColor,
        border: style.borderTopColor,
        color: style.color,
      };
    };

    const controls = Array.from(document.querySelectorAll("[data-theme-control]"));
    const controlSelections = controls.map((control) => {
      const selected = Array.from(control.querySelectorAll('[data-theme-mode-option][aria-selected="true"]'));
      return {
        activeCount: selected.length,
        activeMode: selected[0]?.getAttribute("data-theme-mode-option") || null,
      };
    });

    return {
      attributes: {
        computedTheme: root.getAttribute("data-theme"),
        mode: root.getAttribute("data-theme-mode"),
        setting: root.getAttribute("data-theme-setting"),
      },
      controlSelections,
      darkIntegrationClass: root.classList.contains("cc--darkmode"),
      semantic: {
        background: value("--global-bg-color"),
        card: value("--global-card-bg-color"),
        footer: value("--global-footer-bg-color"),
        mutedText: value("--global-text-color-light"),
        navigation: value("--global-nav-bg-color"),
        outline: value("--global-outline-color"),
        primary: value("--global-primary-color"),
        primaryContainer: value("--global-primary-container-color"),
        surface: value("--global-surface-color"),
        surfaceContainer: value("--global-surface-container-color"),
        surfaceHigh: value("--global-surface-container-high-color"),
        surfaceLow: value("--global-surface-container-low-color"),
        text: value("--global-text-color"),
      },
      session: {
        manual: window.sessionStorage.getItem("theme-manual"),
        mode: window.sessionStorage.getItem("theme"),
      },
      settledChrome: {
        body: computed(document.body),
        footer: computed(footer),
        navbar: computed(navbar),
        surface: computed(surface),
      },
      // P may begin an opacity/transform transition during these samples.
      // Keep it moving, while checking the color transitions this test owns.
      themeTransitionCount: document
        .getAnimations()
        .filter(
          (animation) =>
            animation.constructor.name === "CSSTransition" &&
            ["pending", "running"].includes(animation.playState) &&
            /color$|^(background|fill|stroke|box-shadow|text-shadow|filter)$/.test(animation.transitionProperty)
        ).length,
      toggleLabels: Array.from(document.querySelectorAll("[data-theme-toggle]"), (toggle) => ({
        ariaLabel: toggle.getAttribute("aria-label"),
        title: toggle.getAttribute("title"),
      })),
      transitioning: root.classList.contains("transition"),
      colorScheme: rootStyle.colorScheme,
    };
  }, surfaceSelector);
}

function changedRoleCount(first, second) {
  return Object.keys(first).filter((role) => JSON.stringify(first[role]) !== JSON.stringify(second[role])).length;
}

async function expectMobileChromeInViewport(page, routePath) {
  const viewport = page.viewportSize();
  expect(viewport, `${routePath} has no mobile viewport`).not.toBeNull();

  const chrome = [
    ["brand name", page.locator(".site-brand-name")],
    ["site actions", page.locator(".navbar-actions")],
    ["navigation toggle", page.locator(".navbar-toggler")],
  ];
  const boxes = {};

  for (const [label, locator] of chrome) {
    await expect(locator, `${routePath} hides the mobile ${label}`).toBeVisible();
    const box = await locator.boundingBox();
    expect(box, `${routePath} mobile ${label} has no rendered box`).not.toBeNull();
    expect(box.x, `${routePath} mobile ${label} begins outside the viewport`).toBeGreaterThanOrEqual(-1);
    expect(box.y, `${routePath} mobile ${label} begins above the viewport`).toBeGreaterThanOrEqual(-1);
    expect(box.x + box.width, `${routePath} mobile ${label} is clipped horizontally`).toBeLessThanOrEqual(viewport.width + 1);
    expect(box.y + box.height, `${routePath} mobile ${label} is clipped vertically`).toBeLessThanOrEqual(viewport.height + 1);
    boxes[label] = box;
  }

  expect(boxes["brand name"].x + boxes["brand name"].width, `${routePath} mobile brand overlaps site actions`).toBeLessThanOrEqual(
    boxes["site actions"].x + 1
  );
  expect(boxes["site actions"].x + boxes["site actions"].width, `${routePath} mobile actions overlap the navigation toggle`).toBeLessThanOrEqual(
    boxes["navigation toggle"].x + 1
  );
}

async function expectCompactBlogOpening(page) {
  const toc = page.locator("details.blog-inline-toc");
  await expect(toc).toBeVisible();
  await expect(toc.locator("summary")).toHaveText("On this page");
  await expect(toc).not.toHaveAttribute("open", "");

  const separators = page.locator(".blog-post .post-meta-separator");
  expect(await separators.count()).toBeGreaterThan(0);
  await expect(separators.first()).toBeHidden();

  const openingParagraph = page.locator(".blog-post #markdown-content > p").first();
  await expect(openingParagraph).toBeVisible();
  const openingBox = await openingParagraph.boundingBox();
  expect(openingBox, "mobile blog opening paragraph has no rendered box").not.toBeNull();
  expect(openingBox.y, "mobile blog chrome delays the opening paragraph too far down").toBeLessThan(780);
}

async function exerciseScrollReveals(page, { selector, visibleClass }) {
  const items = page.locator(selector);
  const count = await items.count();

  for (let index = 0; index < count; index += 1) {
    await items.nth(index).scrollIntoViewIfNeeded();
    await page.waitForTimeout(60);
  }

  await expect(page.locator(`${selector}:not(.${visibleClass})`)).toHaveCount(0);
  await page.evaluate(() => window.scrollTo({ top: 0, behavior: "instant" }));
  await page.waitForTimeout(450);
}

async function getResearchMotionState(stage) {
  return stage.evaluate((element) => {
    let snapshot = null;
    element.addEventListener(
      "research-motion-state",
      (event) => {
        snapshot = event.detail;
      },
      { once: true }
    );
    element.dispatchEvent(new Event("research-motion-request-state"));
    if (!snapshot) throw new Error("research motion did not return a state snapshot");
    return snapshot;
  });
}

async function getNarrowAiChromeGeometry(page) {
  return page.evaluate(() => {
    const rect = (selector) => {
      const box = document.querySelector(selector)?.getBoundingClientRect();
      return box ? { left: box.left, top: box.top, right: box.right, bottom: box.bottom, width: box.width, height: box.height } : null;
    };
    const brandName = document.querySelector(".site-brand-name");
    return {
      nav: rect("#navbar"),
      article: rect(".ai-view-page"),
      brandMark: rect(".site-brand-mark"),
      brand: rect(".site-brand"),
      actions: rect(".navbar-actions"),
      toggler: rect(".navbar-toggler"),
      formatLinks: Array.from(document.querySelectorAll(".site-format-link")).map((link) => {
        const box = link.getBoundingClientRect();
        return { left: box.left, top: box.top, right: box.right, bottom: box.bottom, width: box.width, height: box.height };
      }),
      brandNameVisible: Boolean(brandName && getComputedStyle(brandName).display !== "none"),
      clientWidth: document.documentElement.clientWidth,
      scrollWidth: document.documentElement.scrollWidth,
    };
  });
}

async function getAnchorLandingGeometry(page, targetId) {
  return page.evaluate((id) => {
    const nav = document.getElementById("navbar")?.getBoundingClientRect();
    const target = document.getElementById(id)?.getBoundingClientRect();
    return nav && target ? { navBottom: nav.bottom, targetTop: target.top } : null;
  }, targetId);
}

async function expectStableHumanCounterpart(page, expectedPathAndHash, frameCount = 8) {
  const humanLink = page.locator('[data-site-format="human"]');
  await expect
    .poll(async () => {
      const target = new URL((await humanLink.getAttribute("href")) || "", page.url());
      return `${target.pathname}${target.hash}`;
    })
    .toBe(expectedPathAndHash);

  const samples = await page.evaluate(async (count) => {
    const values = [];
    for (let index = 0; index < count; index += 1) {
      window.dispatchEvent(new Event("scroll"));
      await new Promise((resolve) => window.requestAnimationFrame(resolve));
      const link = document.querySelector('[data-site-format="human"]');
      const target = new URL(link?.getAttribute("href") || "", window.location.href);
      values.push(`${target.pathname}${target.hash}`);
    }
    return values;
  }, frameCount);
  expect(samples, `Human counterpart changed during settled scroll frames: ${samples.join(", ")}`).toEqual(
    Array(frameCount).fill(expectedPathAndHash)
  );
}

// The 3D home's build diary (_includes/build-diary.liquid, 2026-10-24): dated entries in chapters, a
// before/after slider for every same-camera pair, side-by-side views for the rest, and a still page under
// automation. The slider answers the keyboard and keeps its value in words for screen readers.
async function exerciseBuildDiary(page, route) {
  const diary = page.locator("[data-build-diary]");
  await expect(diary).toHaveCount(1);
  await expect(page.locator("html")).not.toHaveClass(/cinematic-live/);

  const entries = diary.locator(".build-diary-entry");
  const entryCount = await entries.count();
  expect(entryCount, `${route.path} diary has too few entries`).toBeGreaterThanOrEqual(route.id === "project-homepage-desk-scene" ? 12 : 5);
  expect(
    await entries.evaluateAll((items) => items.every((item) => item.querySelector(".build-diary-title") && item.querySelector(".build-diary-note")))
  ).toBe(true);

  // Chapter links land on real chapters.
  const chapterTargets = await diary
    .locator(".build-diary-chapters a")
    .evaluateAll((links) => links.map((link) => Boolean(document.getElementById(link.getAttribute("href").slice(1)))));
  expect(chapterTargets.length).toBeGreaterThan(1);
  expect(chapterTargets.every(Boolean)).toBe(true);

  const sliders = diary.locator('[data-diary-compare="slider"]');
  const sliderCount = await sliders.count();
  expect(sliderCount).toBeGreaterThan(0);
  await expect(diary.locator('[data-diary-compare="slider"].is-slider')).toHaveCount(sliderCount);
  await expect(diary.locator('[data-diary-compare="pair"].is-slider')).toHaveCount(0);

  const slider = sliders.first();
  await slider.scrollIntoViewIfNeeded();
  const images = slider.locator("img");
  await expect(images).toHaveCount(2);
  await expect.poll(() => images.evaluateAll((items) => items.every((image) => image.complete && image.naturalWidth > 0))).toBe(true);
  expect(await images.evaluateAll((items) => items.every((image) => image.alt.trim().length >= 40))).toBe(true);

  const range = slider.locator('input[type="range"]');
  await expect(range).toBeVisible();
  const rangeBox = await range.boundingBox();
  expect(rangeBox.height, `${route.path} diary slider is shorter than 44px`).toBeGreaterThanOrEqual(44);
  await expect(range).toHaveAttribute("aria-valuetext", "50% before, 50% after");
  await range.focus();
  for (let step = 0; step < 5; step += 1) await range.press("ArrowRight");
  await expect(range).toHaveAttribute("aria-valuetext", "55% before, 45% after");
  await expect(slider).toHaveClass(/is-adjusted/);
  expect(await slider.evaluate((figure) => getComputedStyle(figure).getPropertyValue("--diary-split").trim())).toBe("55%");
  await range.press("End");
  await expect(range).toHaveAttribute("aria-valuetext", "All before");
  const focusRing = await range.evaluate((element) => getComputedStyle(element).outlineStyle);
  expect(focusRing, `${route.path} diary slider has no focus outline`).not.toBe("none");

  // The same-camera views overlap in one frame; the before view is cut at the divider, so it reads
  // before on the left and after on the right.
  const overlap = await slider.evaluate((figure) => {
    const [before, after] = figure.querySelectorAll(".build-diary-frame");
    const a = before.getBoundingClientRect();
    const b = after.getBoundingClientRect();
    return { sameTop: Math.abs(a.top - b.top) < 1, sameLeft: Math.abs(a.left - b.left) < 1, clip: getComputedStyle(before).clipPath };
  });
  expect(overlap.sameTop && overlap.sameLeft).toBe(true);
  expect(overlap.clip).toContain("inset");
}

async function exercisePublicRoute(page, route, theme, testInfo) {
  const runtimeErrors = collectRuntimeErrors(page);

  if (route.id === "secret-locked") {
    await page.addInitScript(() => sessionStorage.removeItem("siruiSecretFruitPass"));
  }
  await preparePage(page, theme);
  const response = await page.goto(publicRouteUrl(route.path), { waitUntil: "domcontentloaded" });

  expect(response, `${route.path} did not return a document response`).not.toBeNull();
  expect(response.status(), `${route.path} returned HTTP ${response.status()}`).toBeLessThan(400);

  const readySelector =
    route.id === "github-activity"
      ? "[data-github-activity][data-state='ready'], [data-github-activity][data-state='unavailable']"
      : route.readySelector;
  const ready = page.locator(readySelector).first();
  const content = page.locator(route.contentSelector).first();
  await expect(ready).toBeVisible();
  await expect(content).toBeVisible();
  await expect(page.locator("html")).toHaveAttribute("data-theme", theme);

  await page.evaluate(async () => {
    if (document.fonts?.ready) await document.fonts.ready;
  });
  await stabilizeVisuals(page);
  await page.waitForTimeout(350);

  // Structural accessibility baseline. The 2026-10-12 audit found every public route passing at 1440
  // and 390 px: one rendered h1, the skip link as the first Tab stop, and an alt attribute on every image.
  await page.keyboard.press("Tab");
  await expect(page.locator(".skip-link"), `${route.path} skip link is not the first Tab stop`).toBeFocused();
  await page.evaluate(() => document.activeElement?.blur?.());
  const structure = await page.evaluate(() => ({
    headings: Array.from(document.querySelectorAll("h1")).map((heading) => {
      const box = heading.getBoundingClientRect();
      return box.width > 0 && box.height > 0 && getComputedStyle(heading).visibility !== "hidden" && !heading.closest("[hidden]");
    }),
    imagesWithoutAlt: Array.from(document.querySelectorAll("img:not([alt])")).map((image) => image.getAttribute("src")),
  }));
  expect(structure.headings, `${route.path} should have exactly one rendered h1`).toEqual([true]);
  expect(structure.imagesWithoutAlt, `${route.path} has images without an alt attribute`).toEqual([]);

  let githubActivityState = null;
  if (route.id === "home") {
    const sections = await page.locator("[data-home-section]").evaluateAll((nodes) => nodes.map((node) => node.dataset.homeSection));
    expect(sections).toEqual(["start", "taste", "focus", "publications", "updates", "students", "connect"]);
    await expect(page.locator("#taste")).toHaveCount(1);
    await expect(page.locator("#focus")).toHaveCount(1);
    await expect(page.locator("#publications")).toHaveCount(1);
    await expect(page.locator("#focus-details, .home-research-summary")).toHaveCount(0);
    await expect(page.locator("#focus .home-motion-mode")).toHaveCount(3);
    await expect(page.locator("#focus .home-motion-exploring")).toBeAttached();
    await expect(page.locator("#focus .home-motion-credit")).toHaveCount(2);
  }
  if (route.id === "github-activity") {
    githubActivityState = await ready.getAttribute("data-state");
    expect(["ready", "unavailable"]).toContain(githubActivityState);
    if (githubActivityState === "unavailable") {
      await expect(page.locator("[data-personal-code-unavailable]")).toHaveText("Code history is being rebuilt.");
      await expect(page.locator("[data-build-rhythm-overview]")).toBeHidden();
      await expect(page.locator("[data-rhythm-method]")).toBeHidden();
    } else {
      await expect(page.locator("[data-personal-code-unavailable]")).toBeHidden();
      await expect(page.locator("[data-personal-daily-copy]").first()).toBeVisible();
      await expect(page.locator("[data-build-rhythm-overview]")).toBeVisible();
      await expect(page.locator("[data-rhythm-cumulative-line]")).toHaveCount(1);
      await expect(page.locator("[data-rhythm-slot]")).toHaveCount(365);
      await expect(page.locator("[data-rhythm-view]")).toHaveCount(2);
      await expect(page.locator("[data-rhythm-chart]")).toHaveCount(1);
      await expect(page.locator("[data-rhythm-detail-chart]")).toHaveCount(1);
      await expect(page.locator('[data-rhythm-inspector][tabindex="0"]')).toHaveCount(2);
    }
  }

  if (route.id === "publications") {
    const guides = page.locator("[data-publication-why-cite]");
    await expect(guides).toHaveCount(5);
    await expect(guides.first().locator(".publication-why-cite-title")).toHaveText("When this paper helps.");
    await expect(guides.first().locator("summary")).toHaveAccessibleName(/When .* helps/);
    await guides.first().locator("summary").click();
    await expect(guides.first()).toHaveAttribute("open", "");
    await expect(guides.first().locator(".publication-why-cite-provenance")).toContainText("I checked this against the paper");
    await expect(page.getByText("Source-reviewed guide", { exact: true })).toHaveCount(0);
    await guides.first().locator("summary").click();
  }

  if (route.id === "publication-context-designweaver") {
    await expect(page.getByText("When this paper helps", { exact: false }).first()).toBeVisible();
    await expect(page.getByText(/I checked this against the paper on/)).toBeVisible();
    const details = page.locator(".publication-context-details");
    await expect(details).not.toHaveAttribute("open", "");
    await details.locator("summary").click();
    await expect(details).toHaveAttribute("open", "");
    await expect(details.getByText("What the paper reports", { exact: true })).toBeVisible();
    await details.locator("summary").click();
    await expect(page.getByText("Source-reviewed citation guide", { exact: true })).toHaveCount(0);
  }

  const geometry = await page.evaluate(() => {
    const documentElement = document.documentElement;
    return {
      clientWidth: documentElement.clientWidth,
      scrollHeight: documentElement.scrollHeight,
      scrollWidth: documentElement.scrollWidth,
    };
  });
  const contentBox = await content.boundingBox();

  expect(geometry.scrollWidth - geometry.clientWidth, `${route.path} has horizontal document overflow`).toBeLessThanOrEqual(1);
  expect(geometry.scrollHeight, `${route.path} has no meaningful document height`).toBeGreaterThan(400);
  expect(contentBox, `${route.path} content has no rendered box`).not.toBeNull();
  expect(contentBox.height, `${route.path} content box is unexpectedly short`).toBeGreaterThan(route.minContentHeight ?? 120);
  expect(runtimeErrors, `${route.path} raised browser runtime errors`).toEqual([]);

  if (FUN_PROJECT_ROUTE_IDS.has(route.id)) {
    const hero = page.locator(".project-case-hero").first();
    const copy = hero.locator(":scope > .project-case-copy");
    const media = hero.locator(":scope > .project-case-media");
    const visual = hero.locator(":scope > .project-case-media, :scope > .build-week-boundary-figure, :scope > .pip-studio");
    await expect(hero).toBeVisible();
    await expect(copy).toBeVisible();
    const mediaCount = await media.count();
    const visualCount = await visual.count();

    if (visualCount > 0) {
      await expect(visual).toBeVisible();
      if (mediaCount > 0) {
        const heroImage = media.locator("img").first();
        await expect(heroImage).toHaveJSProperty("complete", true);
        expect(await heroImage.evaluate((image) => image.naturalWidth), `${route.path} hero image did not decode`).toBeGreaterThan(0);
        expect((await heroImage.getAttribute("alt"))?.trim().length, `${route.path} hero image has no useful alt text`).toBeGreaterThan(12);
      }

      const heroGeometry = await hero.evaluate((element) => {
        const copy = element.querySelector(":scope > .project-case-copy");
        const copyBox = copy.getBoundingClientRect();
        const mediaBox = element
          .querySelector(":scope > .project-case-media, :scope > .build-week-boundary-figure, :scope > .pip-studio")
          .getBoundingClientRect();
        return {
          copyBottom: copyBox.bottom,
          copyHeight: copyBox.height,
          copyMaxWidth: Number.parseFloat(getComputedStyle(copy).maxWidth) || null,
          copyTop: copyBox.top,
          copyWidth: copyBox.width,
          mediaBottom: mediaBox.bottom,
          mediaHeight: mediaBox.height,
          mediaTop: mediaBox.top,
          mediaWidth: mediaBox.width,
          heroWidth: element.getBoundingClientRect().width,
        };
      });
      // The opening copy fills the shared reading column (or the hero, when that is narrower),
      // never a half-width grid column beside empty space.
      const readingColumn = Math.min(heroGeometry.heroWidth, heroGeometry.copyMaxWidth ?? heroGeometry.heroWidth);
      expect(heroGeometry.copyWidth).toBeGreaterThan(220);
      expect(heroGeometry.mediaWidth).toBeGreaterThan(220);
      expect(heroGeometry.mediaTop, `${route.path} media overlaps the opening reading column`).toBeGreaterThanOrEqual(heroGeometry.copyBottom - 1);
      expect(heroGeometry.copyWidth, `${route.path} opening reserves an unused second column`).toBeGreaterThan(readingColumn - 2);
    } else {
      const singleChildGeometry = await hero.evaluate((element) => {
        const copy = element.querySelector(":scope > .project-case-copy");
        const copyBox = copy.getBoundingClientRect();
        const heroBox = element.getBoundingClientRect();
        return {
          childCount: element.children.length,
          copyMaxWidth: Number.parseFloat(getComputedStyle(copy).maxWidth) || null,
          copyWidth: copyBox.width,
          heroWidth: heroBox.width,
        };
      });
      const readingColumn = Math.min(singleChildGeometry.heroWidth, singleChildGeometry.copyMaxWidth ?? singleChildGeometry.heroWidth);
      expect(singleChildGeometry.childCount, `${route.path} reserves an empty hero column`).toBe(1);
      expect(singleChildGeometry.copyWidth, `${route.path} single-child hero stays squeezed`).toBeGreaterThan(readingColumn - 2);
    }

    if (route.id === "project-hci-spooder-man") {
      await page.evaluate(() => window.scrollTo(0, 0));
      await expect.poll(() => page.evaluate(() => window.scrollY)).toBe(0);
      await attachScreenshot(page, testInfo, `${route.id}-${theme}-${testInfo.project.name}-initial`, { fullPage: false });
    }

    const projectActions = page.locator(".project-case-actions a");
    const projectActionBoxes = await projectActions.evaluateAll((elements) =>
      elements.map((element) => {
        const box = element.getBoundingClientRect();
        return { height: box.height, width: box.width };
      })
    );
    expect(projectActionBoxes.length, `${route.path} exposes no project action`).toBeGreaterThan(0);
    expect(
      projectActionBoxes.every((box) => box.height >= 44 && box.width >= 44),
      `${route.path} has a project action smaller than 44px`
    ).toBe(true);

    await projectActions.first().focus();
    const projectActionFocus = await projectActions.first().evaluate((element) => {
      const style = getComputedStyle(element);
      return { style: style.outlineStyle, width: Number.parseFloat(style.outlineWidth) || 0 };
    });
    expect(projectActionFocus.style, `${route.path} project action focus outline is missing`).not.toBe("none");
    expect(projectActionFocus.width, `${route.path} project action focus outline has no width`).toBeGreaterThan(0);

    const pinnedProvenance = page.locator(".project-case-media .project-story-provenance");
    if ((await pinnedProvenance.count()) > 0) {
      const contrastRatios = await pinnedProvenance.evaluateAll((elements) => {
        const channels = (value) =>
          value
            .match(/[\d.]+/g)
            .slice(0, 3)
            .map(Number);
        const luminance = (value) => {
          const linear = channels(value).map((channel) => {
            const normalized = channel / 255;
            return normalized <= 0.04045 ? normalized / 12.92 : ((normalized + 0.055) / 1.055) ** 2.4;
          });
          return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2];
        };

        return elements.map((element) => {
          const foreground = luminance(getComputedStyle(element).color);
          const background = luminance(getComputedStyle(element.closest(".project-case-media")).backgroundColor);
          return (Math.max(foreground, background) + 0.05) / (Math.min(foreground, background) + 0.05);
        });
      });
      expect(
        contrastRatios.every((ratio) => ratio >= 4.5),
        `${route.path} provenance text does not reach 4.5:1 contrast`
      ).toBe(true);
    }
  }

  if (FUN_PROJECT_ROUTE_IDS.has(route.id)) {
    const disclosure = page.locator("details.project-story-disclosure").first();
    const summary = disclosure.locator(":scope > summary");
    await expect(disclosure).toBeVisible();
    await expect(disclosure).not.toHaveAttribute("open", "");
    await summary.scrollIntoViewIfNeeded();

    const summaryGeometry = await summary.evaluate((element) => {
      const box = element.getBoundingClientRect();
      return { height: box.height, width: box.width };
    });
    expect(summaryGeometry.height, `${route.path} disclosure summary is shorter than 44px`).toBeGreaterThanOrEqual(44);
    expect(summaryGeometry.width, `${route.path} disclosure summary has no usable width`).toBeGreaterThan(220);

    await summary.press("Enter");
    await expect(disclosure).toHaveAttribute("open", "");
    await expect(summary).toBeFocused();
    const focusRing = await summary.evaluate((element) => {
      const style = getComputedStyle(element);
      return { style: style.outlineStyle, width: Number.parseFloat(style.outlineWidth) };
    });
    expect(focusRing.style, `${route.path} disclosure focus outline is missing`).not.toBe("none");
    expect(focusRing.width, `${route.path} disclosure focus outline has no width`).toBeGreaterThan(0);

    await summary.press("Enter");
    await expect(disclosure).not.toHaveAttribute("open", "");
    await expect(summary).toBeFocused();
  }

  if (["project-build-rhythm", "project-paper-constellation"].includes(route.id)) {
    const story = page.locator(".project-story-beats").first();
    const beats = story.locator(":scope > .project-story-beat");
    const privacyNote = page.locator(".project-story-note--privacy").first();
    if (route.id === "project-build-rhythm") {
      await story.locator("xpath=ancestor::details[1]").evaluate((details) => {
        details.open = true;
      });
    }
    await expect(story).toBeVisible();
    await expect(beats).toHaveCount(3);
    await expect(privacyNote).toBeVisible();

    const beatBoxes = await beats.evaluateAll((elements) =>
      elements.map((element) => {
        const box = element.getBoundingClientRect();
        return { bottom: box.bottom, left: box.left, right: box.right, top: box.top, width: box.width };
      })
    );
    expect(
      beatBoxes.every((box) => box.width >= 220),
      `${route.path} story beats are squeezed`
    ).toBe(true);
    expect(
      beatBoxes.every((box, index) => index === 0 || box.top >= beatBoxes[index - 1].top),
      `${route.path} story beats do not preserve source order`
    ).toBe(true);
    expect(beatBoxes[1].top).toBeGreaterThanOrEqual(beatBoxes[0].bottom);
    expect(beatBoxes[2].top).toBeGreaterThanOrEqual(beatBoxes[1].bottom);

    const measure = await privacyNote.evaluate((element) => {
      const articleBox = element.closest("article").getBoundingClientRect();
      const box = element.getBoundingClientRect();
      return { articleLeft: articleBox.left, articleRight: articleBox.right, left: box.left, right: box.right, width: box.width };
    });
    expect(measure.width, `${route.path} privacy note is squeezed`).toBeGreaterThanOrEqual(220);
    expect(measure.left).toBeGreaterThanOrEqual(measure.articleLeft - 1);
    expect(measure.right).toBeLessThanOrEqual(measure.articleRight + 1);
  }

  if (route.id === "project-openai-build-week") {
    const story = page.locator("[data-openai-build-week-story]");
    const storySteps = story.locator("[data-build-week-step]");
    const receipts = page.locator(".build-week-receipts > li");
    const constellationImages = page.locator(".build-week-constellation-pair img");

    await expect(story).toHaveAttribute("data-state", "ready");
    await expect(storySteps).toHaveCount(6);
    await expect(receipts).toHaveCount(7);
    await expect(constellationImages).toHaveCount(2);
    await storySteps.nth(3).evaluate((step) => {
      const targetTop = window.innerHeight * 0.22;
      window.scrollBy({ top: step.getBoundingClientRect().top - targetTop, behavior: "instant" });
    });
    await expect.poll(() => story.getAttribute("data-active-chapter")).toBe("constellation");
    await constellationImages.first().scrollIntoViewIfNeeded();
    await expect
      .poll(() => constellationImages.evaluateAll((images) => images.every((image) => image.complete && image.naturalWidth > 0)), {
        message: "Build Week constellation evidence did not decode",
      })
      .toBe(true);
    expect(
      await story.evaluate((element) => element.scrollWidth - element.clientWidth),
      "Build Week story overflows its own canvas"
    ).toBeLessThanOrEqual(1);
  }

  if (route.id === "project-build-rhythm") {
    const questions = page.locator(".build-rhythm-questions").first();
    const questionRows = questions.locator(":scope > li");
    const reproduce = page.locator(".site-experiment-reproduce").first();
    await expect(questionRows).toHaveCount(2);
    await expect(questionRows.locator("h3")).toHaveCount(2);
    await expect(reproduce).toBeVisible();
    const boxes = await questionRows.evaluateAll((elements) =>
      elements.map((element) => {
        const box = element.getBoundingClientRect();
        return { bottom: box.bottom, left: box.left, right: box.right, top: box.top, width: box.width };
      })
    );
    expect(
      boxes.every((box) => box.width >= 220),
      "Build Rhythm question rows are squeezed"
    ).toBe(true);
    expect(boxes[1].top).toBeGreaterThanOrEqual(boxes[0].bottom);

    const reproduceMeasure = await reproduce.evaluate((element) => {
      const box = element.getBoundingClientRect();
      const paragraphBox = element.querySelector("p:not(.project-case-kicker)").getBoundingClientRect();
      return { width: box.width, paragraphWidth: paragraphBox.width };
    });
    expect(reproduceMeasure.width, "Build Rhythm reproduction prose is too wide").toBeLessThanOrEqual(800);
    expect(reproduceMeasure.paragraphWidth, "Build Rhythm reproduction paragraph is too wide").toBeLessThanOrEqual(800);
  }

  if (route.id === "project-paper-constellation") {
    const comparison = page.locator(".paper-constellation-evidence-pair").first();
    await expect(comparison).toHaveAttribute("data-desktop-checkpoint", "6832a6a05b5ff2b6c692bb3f5e3654a535e4401e");
    await expect(comparison).toHaveAttribute("data-desktop-capture-date", "2026-07-16");
    await expect(comparison).toHaveAttribute("data-desktop-source-viewport", "1440x1000");
    await expect(comparison).toHaveAttribute("data-desktop-device-pixel-ratio", "1");
    await expect(comparison).toHaveAttribute("data-desktop-theme", "light");
    await expect(comparison).toHaveAttribute("data-desktop-view", "constellation-active");
    await expect(comparison).toHaveAttribute("data-desktop-state", "no-paper-pinned");
    await expect(comparison).toHaveAttribute("data-desktop-artifact-size", "1012x753");
    await expect(comparison).toHaveAttribute("data-mobile-checkpoint", "6832a6a05b5ff2b6c692bb3f5e3654a535e4401e");
    await expect(comparison).toHaveAttribute("data-mobile-capture-date", "2026-07-16");
    await expect(comparison).toHaveAttribute("data-mobile-source-viewport", "390x1000");
    await expect(comparison).toHaveAttribute("data-mobile-theme", "light");
    await expect(comparison).toHaveAttribute("data-mobile-view", "constellation-active");
    await expect(comparison).toHaveAttribute("data-mobile-state", "no-paper-pinned");
    await expect(comparison).toHaveAttribute("data-mobile-artifact-size", "360x270");

    const figures = comparison.locator(":scope > figure");
    await expect(figures).toHaveCount(2);
    const images = figures.locator("img");
    await expect(images).toHaveCount(2);
    const expectedImagePaths = [
      "assets/img/project_pics/paper-constellation/paper-constellation-desktop-surface-6832a6a05-1440-light.png",
      "assets/img/project_pics/paper-constellation/paper-constellation-mobile-trail-390-light-2026-07-16.png",
    ].map((path) => new URL(path, publicRouteUrl("/")).pathname);
    expect(await images.evaluateAll((elements) => elements.map((element) => new URL(element.src).pathname))).toEqual(expectedImagePaths);
    await expect.poll(() => images.evaluateAll((elements) => elements.every((element) => element.complete && element.naturalWidth > 0))).toBe(true);
    const mobileImageBox = await images.nth(1).boundingBox();
    expect(mobileImageBox, "mobile Paper Constellation evidence image has no rendered box").not.toBeNull();
    expect(mobileImageBox.width, "mobile Paper Constellation evidence is upscaled past its source width").toBeLessThanOrEqual(361);

    const figureBoxes = await figures.evaluateAll((elements) =>
      elements.map((element) => {
        const box = element.getBoundingClientRect();
        return { bottom: box.bottom, left: box.left, right: box.right, top: box.top };
      })
    );
    expect(figureBoxes[1].top, "Paper Constellation evidence should stack in reading order").toBeGreaterThan(figureBoxes[0].bottom);
  }

  if (route.id === "project-scholar-lens") {
    const trace = page.locator("[data-scholar-story-trace]");
    const steps = trace.locator(":scope > .scholar-story-trace-steps > .scholar-story-trace-step");
    const annualBars = trace.locator(".scholar-story-year-bar");

    await expect(trace).toBeVisible();
    await expect(trace).toHaveAttribute("data-bibliography-key", "tao2024designweaver");
    await expect(trace).toHaveAttribute("data-lifetime-sync", /^\d{4}-\d{2}-\d{2}$/);
    await expect(trace).toHaveAttribute("data-annual-snapshot", /^\d{4}-\d{2}-\d{2}$/);
    await expect(steps).toHaveCount(3);
    await expect(steps.locator(":scope .scholar-story-trace-label svg")).toHaveCount(3);
    expect(await annualBars.count(), "Scholar Lens trace exposes no dated annual contribution").toBeGreaterThan(0);

    const traceValues = await trace.evaluate((element) => ({
      annualSnapshot: element.dataset.annualSnapshot,
      displayedLifetime: Number.parseInt(element.querySelector(".scholar-story-citation-cue strong")?.textContent || "", 10),
      lifetimeCitations: Number.parseInt(element.dataset.lifetimeCitations || "", 10),
      lifetimeSync: element.dataset.lifetimeSync,
    }));
    expect(traceValues.displayedLifetime).toBe(traceValues.lifetimeCitations);
    expect(traceValues.lifetimeSync >= traceValues.annualSnapshot, "Lifetime sync predates the annual snapshot").toBe(true);

    const stepBoxes = await steps.evaluateAll((elements) =>
      elements.map((element) => {
        const box = element.getBoundingClientRect();
        return { bottom: box.bottom, left: box.left, right: box.right, top: box.top, width: box.width };
      })
    );
    expect(
      stepBoxes.every((box) => box.width >= 220),
      "Scholar Lens evidence cues are squeezed"
    ).toBe(true);
    expect(stepBoxes[1].top).toBeGreaterThan(stepBoxes[0].bottom);
    expect(stepBoxes[2].top).toBeGreaterThan(stepBoxes[1].bottom);

    const evidenceHero = page.locator('.project-case-media[data-evidence-kind="responsive-runtime-crop"]');
    const evidenceImage = evidenceHero.locator("img");
    await expect(evidenceHero).toHaveAttribute("data-evidence-source-commit", "497b222662fa198ad5e6a43d2727cdb06ec3babf");
    await expect(evidenceHero).toHaveAttribute("data-evidence-desktop-source-viewport", "1440x1000");
    await expect(evidenceHero).toHaveAttribute("data-evidence-mobile-source-viewport", "390x1000");
    await expect(evidenceHero).toHaveAttribute("data-evidence-theme", "light");
    await expect(evidenceHero).toHaveAttribute("data-evidence-theme-mode", "noon");
    await expect(evidenceHero).toHaveAttribute("data-evidence-interaction", "keyboard-focus-on-designweaver-title-link");
    await expect(evidenceHero).toHaveAttribute("data-evidence-browser", "Chromium 145.0.7632.6");
    await expect(evidenceImage).toHaveAttribute("alt", "DesignWeaver highlighted in Scholar Lens's responsive publication and citation view");
    await expect(evidenceHero.locator('source[media="(max-width: 767px)"]')).toHaveAttribute(
      "srcset",
      /scholar-lens-designweaver-497b22266-390-light\.png/
    );
    await expect
      .poll(() => evidenceImage.evaluate((image) => new URL(image.currentSrc).pathname))
      .toMatch(testInfo.project.name === "mobile-390" ? /497b22266-390-light\.png$/ : /497b22266-1440-light\.png$/);
  }

  if (route.id === "project-hci-spooder-man") {
    const carousel = page.locator("[data-spooder-image-carousel]");
    const stage = carousel.locator(".hci-spooder-gallery-stage");
    const arrows = carousel.locator(".hci-spooder-gallery-arrow");
    const thumbs = carousel.locator("[data-spooder-image-thumb]");
    const slides = carousel.locator("[data-spooder-image-slide]");
    await expect(stage).toBeVisible();
    await expect(arrows).toHaveCount(2);
    await expect(thumbs).toHaveCount(9);
    await expect(slides).toHaveCount(9);

    const controlSizes = await carousel.locator(".hci-spooder-gallery-arrow, [data-spooder-image-thumb]").evaluateAll((elements) =>
      elements.map((element) => {
        const box = element.getBoundingClientRect();
        return { height: box.height, width: box.width };
      })
    );
    expect(
      controlSizes.every((size) => size.height >= 44 && size.width >= 44),
      "Spooder carousel controls need 44px targets"
    ).toBe(true);

    await arrows.first().focus();
    await expect(arrows.first()).toBeFocused();
    const focusRing = await arrows.first().evaluate((element) => {
      const style = getComputedStyle(element);
      return { style: style.outlineStyle, width: Number.parseFloat(style.outlineWidth) };
    });
    expect(focusRing.style).not.toBe("none");
    expect(focusRing.width).toBeGreaterThan(0);

    await stage.focus();
    await stage.press("ArrowRight");
    await expect(thumbs.nth(1)).toHaveAttribute("aria-current", "true");
    await expect(slides.nth(1)).toHaveAttribute("aria-hidden", "false");
    await stage.press("Home");
    await expect(thumbs.first()).toHaveAttribute("aria-current", "true");

    const viewportWidth = page.viewportSize()?.width ?? 0;
    const backToTop = page.locator("#back-to-top");
    const backToTopTarget = viewportWidth <= 575 ? page.locator(".mobile-back-to-top") : backToTop;
    await expect(backToTop).toHaveCount(1);
    await expect(backToTopTarget).toBeVisible();
    const backToTopSize = await backToTopTarget.evaluate((element) => {
      const box = element.getBoundingClientRect();
      return { height: box.height, width: box.width };
    });
    expect(backToTopSize.height).toBeGreaterThanOrEqual(44);
    expect(backToTopSize.width).toBeGreaterThanOrEqual(44);

    if (viewportWidth <= 767) {
      await expect(backToTop).toHaveCSS("visibility", "hidden");
      await expect(backToTop).toHaveCSS("pointer-events", "none");
      await expect(backToTop).toHaveCSS("opacity", "0");
      await expect(slides.first().locator("img")).toHaveCSS("object-fit", "contain");

      const activeThumbIsInsideScroller = async (thumb) =>
        thumb.evaluate((element) => {
          const thumbBox = element.getBoundingClientRect();
          const scrollerBox = element.parentElement.getBoundingClientRect();
          return thumbBox.left >= scrollerBox.left - 1 && thumbBox.right <= scrollerBox.right + 1;
        });

      await stage.press("End");
      await expect(thumbs.last()).toHaveAttribute("aria-current", "true");
      await expect.poll(() => activeThumbIsInsideScroller(thumbs.last())).toBe(true);

      await stage.press("Home");
      await expect.poll(() => activeThumbIsInsideScroller(thumbs.first())).toBe(true);
      await thumbs.first().focus();
      await thumbs.first().press("End");
      await expect(thumbs.last()).toBeFocused();
      await expect.poll(() => activeThumbIsInsideScroller(thumbs.last())).toBe(true);

      const promptCopy = page.locator("[data-spooder-copy-prompt]").first();
      await page.evaluate(() => {
        Object.defineProperty(navigator, "clipboard", {
          configurable: true,
          value: {
            writeText: async () => {
              throw new Error("exercise selection fallback");
            },
          },
        });
        document.execCommand = () => true;
      });
      await promptCopy.scrollIntoViewIfNeeded();
      await promptCopy.focus();
      await promptCopy.press("Enter");
      await expect(promptCopy).toBeFocused();
      await expect(promptCopy).toHaveText("Copied");
    }

    await attachScreenshot(page, testInfo, `${route.id}-${theme}-${testInfo.project.name}-interaction`, { fullPage: false });
  }

  if (route.id === "project-ikea-project-cards") {
    const figure = page.locator(".site-experiment-evidence-figure");
    const image = figure.locator("img");
    await expect(image).toHaveAttribute("src", /\/assets\/img\/project_pics\/site-experiments\/ikea-card-expanded\.png$/);
    await expect(image).toHaveAttribute(
      "alt",
      "Projects index with Paper Constellation expanded beside Build Rhythm while other project cards remain visible"
    );
    const caption = figure.locator("figcaption");
    await expect(caption).toContainText("One preview opens in place; the surrounding collection remains readable.");
    await expect(caption.locator(".project-story-provenance")).toContainText("asset checkpoint b51609f0d");
    expect(
      await image.evaluate((element) => ({
        complete: element.complete,
        naturalHeight: element.naturalHeight,
        naturalWidth: element.naturalWidth,
      }))
    ).toEqual({ complete: true, naturalHeight: 650, naturalWidth: 1200 });

    const anatomy = page.locator(".ikea-state-anatomy");
    const stateFrames = anatomy.locator(":scope .ikea-state-frame");
    await expect(anatomy).toHaveAttribute("data-evidence-kind", "annotated-current-state-anatomy");
    await expect(anatomy).toHaveAttribute("data-runtime-contract", "2026-10-17-spring");
    await expect(stateFrames).toHaveCount(3);
    await expect(anatomy.locator("figcaption")).toContainText("it remains readable with reduced motion");
    const stateBoxes = await stateFrames.evaluateAll((elements) =>
      elements.map((element) => {
        const box = element.getBoundingClientRect();
        return { bottom: box.bottom, top: box.top, width: box.width };
      })
    );
    expect(
      stateBoxes.every((box) => box.width >= 200),
      "IKEA state anatomy is squeezed"
    ).toBe(true);
    if (testInfo.project.name === "mobile-390") {
      expect(stateBoxes[1].top).toBeGreaterThan(stateBoxes[0].bottom);
      expect(stateBoxes[2].top).toBeGreaterThan(stateBoxes[1].bottom);
    } else {
      expect(Math.max(...stateBoxes.map((box) => box.top)) - Math.min(...stateBoxes.map((box) => box.top))).toBeLessThanOrEqual(2);
    }
  }

  if (route.id === "project-homepage-desk-scene") {
    const comparison = page.locator(".desk-scene-evidence-pair").first();
    await comparison.scrollIntoViewIfNeeded();
    const eras = comparison.locator(":scope > .desk-scene-comparison-era");
    await expect(eras).toHaveCount(2);
    expect(await eras.evaluateAll((elements) => elements.map((element) => element.getAttribute("data-desk-comparison-era")))).toEqual([
      "june-exact-commit-replay",
      "july-current",
    ]);

    const june = eras.nth(0);
    await expect(june).toHaveAttribute("data-source-commit", "588e365090e883323d836f5da023f7d40632f096");
    await expect(june).toHaveAttribute("data-source-commit-date", "2026-06-21");
    await expect(june).toHaveAttribute("data-capture-date", "2026-07-16");
    await expect(june).toHaveAttribute("data-capture-viewport", "1440x1000");
    await expect(june).toHaveAttribute("data-capture-theme", "light");
    await expect(june).toHaveAttribute("data-capture-rubric", "default-representation-view");
    await expect(june).toHaveAttribute("data-capture-state", "yellow-submarine-stopped-zero-discoveries");
    await expect(june).toHaveAttribute("data-capture-sequence", "2d-then-mode-switch-only");
    await expect(june).toHaveAttribute("data-capture-device-pixel-ratio", "1");
    await expect(june).toHaveAttribute("data-capture-browser", "Chromium 145.0.7632.6");
    await expect(june).toHaveAttribute("data-model-provenance", "GPT-5.5/xhigh");
    await expect(june.locator(".project-story-provenance")).toContainText("Source 588e36509 · captured July 16");

    const july = eras.nth(1);
    await expect(july).toHaveAttribute("data-capture-date", "2026-07-16");
    await expect(july).toHaveAttribute("data-capture-source", "8fc9bf7d3");
    await expect(july).toHaveAttribute("data-scene-checkpoint", "1b07cea4c");
    await expect(july).toHaveAttribute("data-capture-viewport", "1440x1000");
    await expect(july).toHaveAttribute("data-capture-theme", "light");
    await expect(july).toHaveAttribute("data-capture-rubric", "default-representation-view");
    await expect(july).toHaveAttribute("data-capture-state", "yellow-submarine-stopped-zero-discoveries");
    await expect(july).toHaveAttribute("data-capture-device-pixel-ratio", "3");
    await expect(july).toHaveAttribute("data-webgl-buffer-cap", "near-2x");
    await expect(july).toHaveAttribute("data-model-provenance", "GPT-5.6 Sol/ultra");
    await expect(july.locator(".project-story-provenance")).toContainText("Runtime source 8fc9bf7d3 · accepted scene 1b07cea4c");

    const figures = comparison.locator("[data-desk-evidence-mode]");
    await expect(figures).toHaveCount(4);
    expect(await figures.evaluateAll((elements) => elements.map((element) => element.getAttribute("data-desk-evidence-mode")))).toEqual([
      "2d",
      "3d",
      "2d",
      "3d",
    ]);

    const images = figures.locator("img");
    await expect(images).toHaveCount(4);
    const expectedImagePaths = [
      "assets/img/project_pics/site-experiments/homepage-desk-588e36509-2d-2026-07-16.png",
      "assets/img/project_pics/site-experiments/homepage-desk-588e36509-3d-2026-07-16.png",
      "assets/img/project_pics/site-experiments/homepage-desk-2d-2026-07-16.png",
      "assets/img/project_pics/site-experiments/homepage-desk-3d-2026-07-16.png",
    ].map((path) => new URL(path, publicRouteUrl("/")).pathname);
    expect(await images.evaluateAll((elements) => elements.map((element) => new URL(element.src).pathname))).toEqual(expectedImagePaths);
    expect(await images.evaluateAll((elements) => elements.map((element) => element.alt))).toEqual([
      "Exact replay of commit 588e36509 in the light-theme 2D homepage view, with Sirui's portrait, research slips, and a coffee-stain desk cue",
      "Exact replay of commit 588e36509 in the light-theme 3D homepage view, where a small desk-room stage occupies the right half while a black backdrop obscures much of the page",
      "July 16 homepage capture in the light-theme 2D desk representation with Sirui's portrait, paper research slips, Yellow Submarine queued and stopped, and no discovered record cards",
      "July 16 homepage capture in the light-theme 3D desk representation showing the reciprocal cliff room, onsen, lounge chair, record player, welcome note, and ocean window, with Yellow Submarine stopped and no discoveries",
    ]);
    await expect.poll(() => images.evaluateAll((elements) => elements.every((element) => element.complete && element.naturalWidth > 0))).toBe(true);
    expect(
      await images.evaluateAll((elements) =>
        elements.map((element) => ({
          naturalHeight: element.naturalHeight,
          naturalWidth: element.naturalWidth,
        }))
      )
    ).toEqual([
      { naturalHeight: 1000, naturalWidth: 1440 },
      { naturalHeight: 1000, naturalWidth: 1440 },
      { naturalHeight: 1000, naturalWidth: 1440 },
      { naturalHeight: 1000, naturalWidth: 1440 },
    ]);

    const eraBoxes = await eras.evaluateAll((elements) =>
      elements.map((element) => {
        const box = element.getBoundingClientRect();
        return { bottom: box.bottom, left: box.left, right: box.right, top: box.top };
      })
    );
    const figureBoxes = await figures.evaluateAll((elements) =>
      elements.map((element) => {
        const box = element.getBoundingClientRect();
        return { bottom: box.bottom, left: box.left, right: box.right, top: box.top };
      })
    );
    expect(eraBoxes[1].top, "evidence eras should follow the article's reading order").toBeGreaterThan(eraBoxes[0].bottom);
    expect(figureBoxes[1].top, "June 3D should follow June 2D").toBeGreaterThan(figureBoxes[0].bottom);
    expect(figureBoxes[3].top, "July 3D should follow July 2D").toBeGreaterThan(figureBoxes[2].bottom);
  }

  if (route.id === "project-homepage-desk-scene" || route.id === "project-house-in-the-cliff") {
    await exerciseBuildDiary(page, route);
  }

  if (route.id === "secret-locked") {
    await expect(ready).toContainText("locked.");
    await expect(ready.locator("h1")).toHaveText("locked.");
    await expect(page.locator("#sirui-crack-map")).toBeHidden();
  }

  if (route.id === "blog-archive-2026") {
    const archiveRows = page.locator(".archive table tr");
    // The October 23 reflection leads the explicit 2026 fixture; retain every
    // older row in chronological order with compact month/day dates.
    await expect(archiveRows.locator("th")).toHaveText([
      "Oct 23",
      "Oct 16",
      "Jul 05",
      "Jul 05",
      "May 23",
      "May 20",
      "May 13",
      "Apr 27",
      "Apr 23",
      "Mar 04",
    ]);
    await expect(archiveRows.first().getByRole("link", { name: "When the website talks back", exact: true })).toHaveAttribute(
      "href",
      /\/blog\/2026\/when-the-website-talks-back\/$/
    );
    await expect(archiveRows.nth(1).getByRole("link", { name: "Got to hold an Emmy at the Design Lab retreat!", exact: true })).toHaveAttribute(
      "href",
      /\/blog\/2026\/design-lab-retreat-emmy\/$/
    );
    await expect(archiveRows.nth(2).getByRole("link", { name: "technical papers i want to remember", exact: true })).toBeVisible();
    await expect(
      archiveRows.nth(3).getByRole("link", { name: "specialists, generalists, and AI as distributed cognition", exact: true })
    ).toBeVisible();
    await expect(archiveRows.last().getByRole("link", { name: "an afternoon with don norman", exact: true })).toBeVisible();
  }

  if (testInfo.project.name === "mobile-390") {
    await expectMobileChromeInViewport(page, route.path);
    if (route.id === "blog-distributed-cognition") {
      await expectCompactBlogOpening(page);
    }
    if (route.id === "blog-page-2") {
      await expect(page.locator(".featured-posts")).toHaveCount(0);
    }
    if (route.id === "cv") {
      const sections = page.locator("[data-cv-mobile-sections]");
      await expect(sections).toBeVisible();
      await expect(sections).not.toHaveAttribute("open", "");
      await sections.locator("summary").click();
      expect(await sections.locator("a").count()).toBeGreaterThan(4);
      await sections.locator("summary").click();
    }
    if (route.id === "publications") {
      const paperTop = await page.locator(".publication-list-column").evaluate((element) => element.getBoundingClientRect().top);
      const lensTop = await page.locator(".publication-lens-column").evaluate((element) => element.getBoundingClientRect().top);
      expect(paperTop, "mobile publications should place papers before the Scholar lens").toBeLessThan(lensTop);
    }
    if (route.id === "ai-profile") {
      await expect(page.locator("[data-publication-key]")).toHaveCount(5);
      await expect(page.locator('.site-format-link[aria-current="page"]')).toHaveText("AI");
    }
    if (route.id === "github-activity") {
      if (githubActivityState === "ready") {
        for (const width of [320, 350, 390]) {
          await page.setViewportSize({ width, height: 1000 });
          const layout = await page.locator("[data-build-rhythm-overview]").evaluate((node) => {
            const box = node.getBoundingClientRect();
            return {
              left: box.left,
              right: box.right,
              overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth,
              controls: [...node.querySelectorAll("[data-rhythm-view]")].map((button) => {
                const bounds = button.getBoundingClientRect();
                return { left: bounds.left, right: bounds.right, height: bounds.height };
              }),
            };
          });
          expect(layout.overflow, `${width}px Build Rhythm overflows`).toBeLessThanOrEqual(1);
          expect(layout.left).toBeGreaterThanOrEqual(0);
          expect(layout.right).toBeLessThanOrEqual(width);
          expect(layout.controls).toHaveLength(2);
          expect(layout.controls.every((box) => box.left >= 0 && box.right <= width + 1 && box.height >= 44)).toBe(true);
        }
      } else {
        for (const width of [320, 350, 390]) {
          await page.setViewportSize({ width, height: 1000 });
          const awaitingGeometry = await page.locator(".github-activity-unavailable").evaluate((element) => {
            const bounds = element.getBoundingClientRect();
            return {
              left: bounds.left,
              right: bounds.right,
              clientWidth: document.documentElement.clientWidth,
              scrollWidth: document.documentElement.scrollWidth,
            };
          });
          expect(awaitingGeometry.scrollWidth - awaitingGeometry.clientWidth, `${width}px awaiting page overflows`).toBeLessThanOrEqual(1);
          expect(awaitingGeometry.left).toBeGreaterThanOrEqual(0);
          expect(awaitingGeometry.right).toBeLessThanOrEqual(width);
        }
      }
      await page.setViewportSize({ width: 390, height: 1000 });
    }
  }

  await attachScreenshot(page, testInfo, `${route.id}-${theme}-${testInfo.project.name}`, { fullPage: false });

  if (route.id === "projects-index") {
    // Every fun project keeps its icon in the page; the ones inside a closed deck are drawn when it opens.
    const icons = page.locator(".projects [data-project-card-icon]");
    await expect(icons).toHaveCount(INDEXED_FUN_PROJECT_COUNT);
    expect(await icons.evaluateAll((elements) => elements.every((element) => element.getAttribute("aria-hidden") === "true"))).toBe(true);
    const iconsDrawn = () =>
      icons.evaluateAll((elements) =>
        elements
          .filter((element) => element.getClientRects().length)
          .every((element) => {
            const box = element.getBoundingClientRect();
            return box.width >= 24 && box.width <= 36 && box.height >= 24 && box.height <= 36;
          })
      );
    expect(await iconsDrawn()).toBe(true);

    const driverCard = page.locator("[data-project-card]", {
      has: page.getByRole("heading", { name: "Not A Good Driver", exact: true }),
    });
    await expect(driverCard.locator("[data-project-card-origin]")).toHaveCount(1);
    await expect(driverCard.locator("[data-project-card-evolution]")).toHaveCount(0);
    await expect(page.locator("[data-project-card-evolution]")).toHaveCount(INDEXED_FUN_PROJECT_COUNT - 1);

    // The site experiments are one deck, the website revamp; it opens in place into its projects. Wide screens
    // (at least 992 px) start with it open (2026-10-19); narrower ones open it with a click.
    const revamp = page.locator("[data-project-deck='website-revamp']");
    await revamp.scrollIntoViewIfNeeded();
    if (page.viewportSize().width < 992) {
      await expect(revamp).toHaveAttribute("data-project-deck-state", "closed");
      await revamp.locator(":scope > .card [data-project-deck-trigger]").click({ position: { x: 12, y: 12 } });
    }
    await expect(revamp).toHaveAttribute("data-project-deck-state", "open");
    await expect(page.locator("[data-project-deck-trail]")).toBeVisible();
    await expect
      .poll(
        () =>
          page.evaluate(
            () =>
              document
                .querySelector("[data-project-deck-stage]")
                .getAnimations({ subtree: true })
                .filter((animation) => animation.playState !== "finished").length
          ),
        { message: "deck motion did not settle" }
      )
      .toBe(0);
    expect(await iconsDrawn()).toBe(true);

    const card = revamp.locator(":scope > [data-project-deck-children] [data-project-card]:not([data-project-deck])").first();
    const trigger = card.locator("[data-project-card-trigger]");
    const panel = card.locator("[data-project-card-panel]");
    const primaryAction = card.locator("[data-project-card-primary-action]");
    const closeButton = card.locator("[data-project-card-close]");
    const story = card.locator("[data-project-card-story]");

    await expect(story).toBeHidden();

    await card.scrollIntoViewIfNeeded();
    // The direct project link sits above the full-card preview button. Click
    // the image corner, where a visitor can open the expanding preview.
    await trigger.click({ position: { x: 12, y: 12 } });
    await expect(card).toHaveAttribute("data-project-card-state", "expanded");
    await expect(panel).toBeVisible();
    await expect(primaryAction).toBeVisible();
    await expect(story).toBeVisible();
    await expect(story.locator("[data-project-card-origin] .project-card-story-label")).toHaveText("Why it began");
    await expect(story.locator("[data-project-card-evolution] .project-card-story-label")).toHaveText("What changed");
    await expect
      .poll(() => card.evaluate((element) => element.getAnimations({ subtree: true }).length), {
        message: `${testInfo.project.name} project preview did not settle`,
      })
      .toBe(0);

    const expandedGeometry = await card.evaluate((element) => {
      const cardBounds = element.getBoundingClientRect();
      const actionBounds = element.querySelector("[data-project-card-primary-action]")?.getBoundingClientRect();
      const closeBounds = element.querySelector("[data-project-card-close]")?.getBoundingClientRect();
      const panelElement = element.querySelector("[data-project-card-panel]");
      const surface = element.querySelector(".card");
      const storyBeatBounds = Array.from(element.querySelectorAll(".project-card-story-beat")).map((beat) => beat.getBoundingClientRect());
      return {
        actionHeight: actionBounds?.height ?? 0,
        actionWidth: actionBounds?.width ?? 0,
        cardLeft: cardBounds.left,
        cardRight: cardBounds.right,
        closeHeight: closeBounds?.height ?? 0,
        closeWidth: closeBounds?.width ?? 0,
        documentOverflow: document.documentElement.scrollWidth - document.documentElement.clientWidth,
        panelAnimationName: panelElement ? getComputedStyle(panelElement).animationName : null,
        storyBeatWidths: storyBeatBounds.map((box) => box.width),
        surfaceClipPath: surface ? getComputedStyle(surface).clipPath : null,
      };
    });
    expect(expandedGeometry.actionHeight).toBeGreaterThanOrEqual(44);
    expect(expandedGeometry.actionWidth).toBeGreaterThan(80);
    expect(expandedGeometry.cardLeft).toBeGreaterThanOrEqual(-1);
    expect(expandedGeometry.cardRight).toBeLessThanOrEqual(page.viewportSize().width + 1);
    expect(expandedGeometry.closeHeight).toBeGreaterThanOrEqual(44);
    expect(expandedGeometry.closeWidth).toBeGreaterThanOrEqual(44);
    expect(expandedGeometry.documentOverflow).toBeLessThanOrEqual(1);
    expect(expandedGeometry.panelAnimationName).toBe("none");
    expect(expandedGeometry.storyBeatWidths.every((width) => width >= 200)).toBe(true);
    expect(expandedGeometry.surfaceClipPath).toBe("none");

    await card.evaluate((element) => {
      const navBottom = document.getElementById("navbar")?.getBoundingClientRect().bottom || 0;
      const cardTop = element.getBoundingClientRect().top;
      window.scrollBy({ top: cardTop - navBottom - 12, behavior: "instant" });
    });
    await attachScreenshot(page, testInfo, `projects-index-expanded-${theme}-${testInfo.project.name}`, { fullPage: false });

    await closeButton.evaluate((button) => button.click());
    await expect(card).toHaveAttribute("data-project-card-state", "collapsed");
    await expect(panel).toBeHidden();
    await expect.poll(() => card.evaluate((element) => element.getAnimations({ subtree: true }).length)).toBe(0);
    expect(runtimeErrors, `${route.path} project preview raised browser runtime errors`).toEqual([]);
  }

  if (theme === "light" && route.fullPage && ["desktop-1440", "mobile-390"].includes(testInfo.project.name)) {
    if (route.id === "home") {
      await exerciseScrollReveals(page, { selector: ".home-reveal", visibleClass: "home-visible" });
    }
    if (route.id === "publications") {
      await exerciseScrollReveals(page, {
        selector: ".publications ol.bibliography > li.site-reveal",
        visibleClass: "site-visible",
      });
    }
    if (route.id === "projects-index") {
      // Cards inside a closed deck are revealed with their level, not by scrolling.
      await exerciseScrollReveals(page, {
        selector: ".projects .card.site-reveal:not([hidden] *):not(.is-folded *)",
        visibleClass: "site-visible",
      });
    }
    await attachScreenshot(page, testInfo, `${route.id}-light-${testInfo.project.name}-full-page`, { fullPage: true });
  }
}

test("Build Week story exposes a complete reduced-motion view", async ({ page }, testInfo) => {
  test.skip(
    !["desktop-1440", "mobile-390"].includes(testInfo.project.name),
    "one desktop and one mobile viewport cover the reduced-motion story contract"
  );

  const runtimeErrors = collectRuntimeErrors(page);
  await page.emulateMedia({ reducedMotion: "reduce" });
  await preparePage(page, "light");
  const response = await page.goto(publicRouteUrl("/projects/openai-build-week/"), { waitUntil: "domcontentloaded" });
  expect(response).not.toBeNull();
  expect(response.status()).toBeLessThan(400);

  const story = page.locator("[data-openai-build-week-story]");
  await expect(story).toHaveAttribute("data-state", "ready");
  await expect(story).toHaveAttribute("data-active-chapter", "all");
  await expect(story.locator("[data-build-week-step]")).toHaveCount(6);
  await expect(story.locator("[data-build-week-chapter]")).toHaveCount(6);
  expect(await story.evaluate((element) => element.scrollWidth - element.clientWidth)).toBeLessThanOrEqual(1);

  await page.evaluate(() => window.scrollTo(0, 0));
  await attachScreenshot(page, testInfo, `openai-build-week-hero-${testInfo.project.name}`, { fullPage: false });
  await story.scrollIntoViewIfNeeded();
  await attachScreenshot(page, testInfo, `openai-build-week-reduced-${testInfo.project.name}`, { fullPage: false });
  expect(runtimeErrors, "Build Week reduced-motion view raised browser runtime errors").toEqual([]);
});

for (const route of SITEWIDE_ROUTES) {
  test(`public route: ${route.id}`, async ({ page, context }, testInfo) => {
    for (const [index, theme] of SITEWIDE_ROUTE_THEMES.entries()) {
      const themePage = index === 0 ? page : await context.newPage();
      await exercisePublicRoute(themePage, route, theme, testInfo);
      // Headless pages can both remain visible and render their coastal worlds.
      // Release each completed theme before opening the next one; keep the
      // failing/current page open for Playwright's error screenshot and trace.
      if (index < SITEWIDE_ROUTE_THEMES.length - 1) await themePage.close();
    }
  });
}

test("Wall of Rejection capture state remains exactly reproducible", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "desktop-1440", "one exact 700x1000 source viewport covers the archived Wall state");

  await page.setViewportSize({ width: 700, height: 1000 });
  const runtimeErrors = collectRuntimeErrors(page);
  await preparePage(page, "noon");
  const response = await page.goto(publicRouteUrl("/publications/#wall-of-rejection-title"), { waitUntil: "domcontentloaded" });
  expect(response).not.toBeNull();
  expect(response.status()).toBeLessThan(400);

  const wall = page.locator(".wall-of-rejection");
  const highlights = wall.locator('[data-rejection-view-button][data-rejection-view-target="highlights"]');
  await expect(wall).toBeVisible();
  await highlights.click();
  await expect(highlights).toHaveAttribute("aria-pressed", "true");

  const visibleCards = wall.locator("[data-rejection-card]:visible");
  await expect(visibleCards).toHaveCount(5);
  const chi = wall.locator('[data-rejection-card][data-rejection-source-id="chi-rejection"]:visible');
  await chi.click();
  await expect(chi).toHaveAttribute("aria-expanded", "true");
  await expect(chi).toHaveClass(/rejection-badge-pinned/);

  const receipt = wall.locator("[data-rejection-receipt-tray]");
  await expect(receipt).toBeVisible();
  await expect(receipt).toHaveClass(/rejection-receipt-tray-pinned/);
  await expect(receipt).toContainText("CHI 2026 did not accept this paper");
  await expect(wall.locator(".rejection-xp-panel")).toContainText("38 / 50 XP");
  await expect(wall.locator("[data-rejected-title], [data-draft], [data-collaborator-note], [data-future-venue]")).toHaveCount(0);
  expect(await wall.innerText()).not.toMatch(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);

  await attachScreenshot(page, testInfo, "wall-of-rejection-dd801b99-700-noon-highlights-chi-open", { locator: wall });
  expect(runtimeErrors, "Wall exact capture state raised browser runtime errors").toEqual([]);
});

test("coastal time modes settle coherently across representative human routes", async ({ page }, testInfo) => {
  test.setTimeout(180000);
  test.skip(
    !["desktop-1440", "mobile-390"].includes(testInfo.project.name),
    "one desktop and one mobile viewport cover the sitewide time-mode contract"
  );

  const runtimeErrors = collectRuntimeErrors(page);
  await preparePage(page, "morning");

  for (const route of COASTAL_THEME_ROUTE_SAMPLES) {
    const response = await page.goto(publicRouteUrl(route.path), { waitUntil: "domcontentloaded" });
    expect(response, `${route.path} did not return a document response`).not.toBeNull();
    expect(response.status(), `${route.path} returned HTTP ${response.status()}`).toBeLessThan(400);
    await expect(page.locator(route.readySelector).first()).toBeVisible();
    await expect(page.locator(route.surfaceSelector).first()).toBeAttached();
    await stabilizeVisuals(page);

    const samples = {};
    for (const theme of COASTAL_THEME_MODES) {
      await switchToCoastalThemeMode(page, theme);
      const first = await readSettledCoastalThemeSample(page, route.surfaceSelector);
      await page.waitForTimeout(80);
      const repeated = await readSettledCoastalThemeSample(page, route.surfaceSelector);

      expect(repeated, `${route.path} ${theme.mode} chrome or surface kept changing after theme settlement`).toEqual(first);
      expect(first.transitioning, `${route.path} ${theme.mode} retained html.transition`).toBe(false);
      expect(first.themeTransitionCount, `${route.path} ${theme.mode} retained a running color transition`).toBe(0);
      expect(first.attributes).toEqual({
        computedTheme: theme.computedTheme,
        mode: theme.mode,
        setting: theme.mode,
      });
      expect(first.session).toEqual({ manual: "true", mode: theme.mode });
      expect(first.colorScheme).toBe(theme.computedTheme);
      expect(first.darkIntegrationClass).toBe(theme.computedTheme === "dark");
      expect(first.controlSelections.length, `${route.path} has no time-mode control`).toBeGreaterThan(0);
      expect(
        first.controlSelections.every((selection) => selection.activeCount === 1 && selection.activeMode === theme.mode),
        `${route.path} ${theme.mode} left a theme control in a mixed state`
      ).toBe(true);
      expect(first.toggleLabels.length).toBe(first.controlSelections.length);
      expect(
        first.toggleLabels.every(
          ({ ariaLabel, title }) => ariaLabel === `Change theme. Current theme: ${theme.label}` && title === `Theme: ${theme.label}`
        ),
        `${route.path} ${theme.mode} left stale theme-control labels`
      ).toBe(true);
      expect(Object.values(first.semantic).every(Boolean), `${route.path} ${theme.mode} has an empty semantic color role`).toBe(true);
      expect(first.settledChrome.body.background).not.toBe("rgba(0, 0, 0, 0)");
      expect(first.settledChrome.navbar.background).not.toBe("rgba(0, 0, 0, 0)");
      expect(first.settledChrome.surface.background).not.toBe("rgba(0, 0, 0, 0)");
      expect(first.settledChrome.footer.background).not.toBe("rgba(0, 0, 0, 0)");
      samples[theme.mode] = first;
      if (route.path === "/projects/" && theme.mode === "afternoon") {
        await attachScreenshot(page, testInfo, `coastal-projects-afternoon-${testInfo.project.name}`, { fullPage: false });
      }
      if (route.path === "/") {
        await attachScreenshot(page, testInfo, `coastal-home-${theme.mode}-${testInfo.project.name}`, { fullPage: false });
      }
    }

    for (const [earlier, later] of [
      ["morning", "noon"],
      ["noon", "afternoon"],
    ]) {
      const earlierSample = samples[earlier];
      const laterSample = samples[later];
      expect(
        changedRoleCount(earlierSample.semantic, laterSample.semantic),
        `${route.path} ${earlier} and ${later} need meaningfully different semantic color roles`
      ).toBeGreaterThanOrEqual(8);
      expect(
        changedRoleCount(earlierSample.settledChrome, laterSample.settledChrome),
        `${route.path} ${earlier} and ${later} need visibly different settled surfaces and chrome`
      ).toBeGreaterThanOrEqual(3);
      expect(earlierSample.semantic.background).not.toBe(laterSample.semantic.background);
      expect(earlierSample.semantic.primary).not.toBe(laterSample.semantic.primary);
      expect(earlierSample.settledChrome.navbar).not.toEqual(laterSample.settledChrome.navbar);
      expect(earlierSample.settledChrome.surface).not.toEqual(laterSample.settledChrome.surface);
    }
  }

  expect(runtimeErrors, "sitewide coastal time-mode matrix raised browser runtime errors").toEqual([]);
});

test("sun arc moves the time of day, hands it back to the clock, and pauses motion sitewide", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "desktop-1440", "one viewport covers the control's behavior");
  const runtimeErrors = collectRuntimeErrors(page);
  await page.clock.install({ time: new Date("2026-10-13T13:20:00-07:00") });
  await page.goto(publicRouteUrl("/"), { waitUntil: "domcontentloaded" });
  const root = page.locator("html");
  const now = page.locator("#theme-menu [data-sun-now]");
  const motion = page.locator("#theme-menu [data-motion-toggle]");
  const reducedQuery = () => page.evaluate(() => matchMedia("(prefers-reduced-motion: reduce)").matches);
  await expect(root).toHaveAttribute("data-theme-mode", "noon");

  await page.locator("#theme-toggle").click();
  const knob = page.locator("#theme-menu [data-sun-knob]");
  await expect(knob).toBeFocused();
  await expect(knob).toHaveAttribute("aria-valuetext", "Noon, 1:20 pm");
  await expect(now).toHaveAttribute("aria-pressed", "true");

  // Keys: eight hours later is evening, and the site follows the chosen hour, not the clock.
  for (let step = 0; step < 8; step++) await knob.press("PageUp");
  await expect(knob).toHaveAttribute("aria-valuetext", "Evening, 9:20 pm");
  await expect(root).toHaveAttribute("data-theme-mode", "evening");
  await expect(now).toHaveAttribute("aria-pressed", "false");
  expect(await root.evaluate((element) => element.style.getPropertyValue("--site-sky"))).toMatch(/^\d+ \d+ \d+$/);

  // Pointer: drag the sun over to the morning side of the day arc.
  const box = await page.locator("#theme-menu [data-sun-arc]").boundingBox();
  const point = (x, y) => [box.x + (x / 240) * box.width, box.y + (y / 124) * box.height];
  await page.mouse.move(...point(196, 99));
  await page.mouse.down();
  await page.mouse.move(...point(120, 18), { steps: 6 });
  await page.mouse.move(...point(45, 40), { steps: 6 });
  await page.mouse.up();
  await expect(root).toHaveAttribute("data-theme-mode", "morning");
  await expect(knob).toHaveAttribute("aria-valuetext", /^Morning, /);

  // Pause motion: every reduced-motion query now matches, and the choice survives a reload.
  await motion.click();
  await expect(motion).toHaveAttribute("aria-checked", "true");
  await expect(root).toHaveAttribute("data-motion", "paused");
  expect(await reducedQuery()).toBe(true);
  await page.reload({ waitUntil: "domcontentloaded" });
  await expect(root).toHaveAttribute("data-motion", "paused");
  await expect(root).toHaveAttribute("data-theme-mode", "morning");
  await page.locator("#theme-toggle").click();
  await motion.click();
  await expect(root).not.toHaveAttribute("data-motion", "paused");
  expect(await reducedQuery()).toBe(false);

  // Now hands the time back to the clock.
  await now.click();
  await expect(root).toHaveAttribute("data-theme-mode", "noon");
  await expect(now).toHaveAttribute("aria-pressed", "true");
  expect(runtimeErrors).toEqual([]);
});

test("all project cards disclose and recover their stories", async ({ page }, testInfo) => {
  test.setTimeout(180000);
  test.skip(!["desktop-1440", "mobile-390"].includes(testInfo.project.name), "desktop and mobile exercise every expandable story");

  const runtimeErrors = collectRuntimeErrors(page);
  await page.emulateMedia({ reducedMotion: "reduce" });
  await preparePage(page, "light");
  const response = await page.goto(publicRouteUrl("/projects/"), { waitUntil: "domcontentloaded" });
  expect(response).not.toBeNull();
  expect(response.status()).toBeLessThan(400);
  await stabilizeVisuals(page);

  // Decks (the website revamp, the 3D home, the Graphics Lab) disclose their story as the banner of the
  // level they open; every other card previews in place inside its level (2026-10-18).
  const cards = page.locator(".projects [data-project-card]").filter({ has: page.locator("[data-project-card-story]") });
  await expect(cards).toHaveCount(INDEXED_FUN_PROJECT_COUNT);
  await expect(page.locator(".projects [data-project-card-origin]")).toHaveCount(INDEXED_FUN_PROJECT_COUNT);
  await expect(page.locator(".projects [data-project-card-evolution]")).toHaveCount(INDEXED_FUN_PROJECT_COUNT - 1);
  await expect(page.locator(".projects [data-project-card-state='expanded']")).toHaveCount(0);
  const decks = page.locator(".projects [data-project-deck]");
  await expect(decks).toHaveCount(3);

  for (let index = 0; index < 3; index += 1) {
    const deck = decks.nth(index);
    const slug = await deck.getAttribute("data-project-deck");
    const parent = await deck.getAttribute("data-project-deck-parent");
    await page.evaluate((target) => window.SiteDecks.go(target || ""), parent);
    const surface = deck.locator(":scope > .card");
    const deckTrigger = surface.locator("[data-project-deck-trigger]");
    await deckTrigger.scrollIntoViewIfNeeded();
    await deckTrigger.focus();
    await deckTrigger.press("Enter");
    await expect(deck, `${slug} deck did not open`).toHaveAttribute("data-project-deck-state", "open");
    await expect(deckTrigger).toHaveAttribute("aria-expanded", "true");
    await expect(surface.locator(":scope [data-project-card-origin]")).toBeVisible();
    await expect(surface.locator("[data-project-card-primary-action]")).toBeVisible();
    await expect(page.locator(`[data-project-deck-trail] li[aria-current]`)).toHaveText((await surface.locator(".card-title").innerText()).trim());
    const closeDeck = surface.locator("[data-project-deck-close]");
    const closeBox = await closeDeck.boundingBox();
    expect(closeBox.width, `${slug} close action is narrower than 44px`).toBeGreaterThanOrEqual(44);
    expect(closeBox.height, `${slug} close action is shorter than 44px`).toBeGreaterThanOrEqual(44);
    await closeDeck.focus();
    await closeDeck.press("Enter");
    await expect(deck, `${slug} deck did not close`).toHaveAttribute("data-project-deck-state", "closed");
    await expect(deckTrigger, `${slug} did not return focus to its deck`).toBeFocused();
  }

  const previews = page.locator(".projects [data-project-card]:not([data-project-deck])").filter({ has: page.locator("[data-project-card-story]") });
  await expect(previews).toHaveCount(INDEXED_FUN_PROJECT_COUNT - 3);
  for (let index = 0; index < INDEXED_FUN_PROJECT_COUNT - 3; index += 1) {
    const card = previews.nth(index);
    await page.evaluate((target) => window.SiteDecks.go(target || ""), await card.getAttribute("data-project-deck-parent"));
    const title = (await card.locator(".card-title").innerText()).trim();
    const trigger = card.locator("[data-project-card-trigger]");
    const panel = card.locator("[data-project-card-panel]");
    const primaryAction = card.locator("[data-project-card-primary-action]");
    const closeButton = card.locator("[data-project-card-close]");
    const story = card.locator("[data-project-card-story]");
    const origin = story.locator("[data-project-card-origin]");
    const evolution = story.locator("[data-project-card-evolution]");

    if (title === "Scholar Lens") {
      const image = card.locator(".project-card-img");
      await image.evaluate((element) => element.decode());
      const responsiveEvidence = await image.evaluate((element) => ({
        currentPath: new URL(element.currentSrc).pathname,
        naturalHeight: element.naturalHeight,
        naturalWidth: element.naturalWidth,
      }));
      if (testInfo.project.name === "mobile-390") {
        expect(responsiveEvidence.currentPath).toMatch(/scholar-lens-designweaver-497b22266-390-light\.png$/);
        expect(responsiveEvidence).toMatchObject({ naturalHeight: 270, naturalWidth: 360 });
      } else {
        expect(responsiveEvidence.currentPath).toMatch(/scholar-lens-designweaver-497b22266-1440-light\.png$/);
        expect(responsiveEvidence).toMatchObject({ naturalHeight: 900, naturalWidth: 1440 });
      }
    }

    await card.scrollIntoViewIfNeeded();
    await trigger.focus();
    await expect(trigger, `${title} preview trigger cannot receive focus`).toBeFocused();
    await trigger.press("Enter");

    await expect(card, `${title} did not expand`).toHaveAttribute("data-project-card-state", "expanded");
    await expect(page.locator(".projects [data-project-card-state='expanded']")).toHaveCount(1);
    await expect(panel).toBeVisible();
    await expect(story).toBeVisible();
    await expect(primaryAction).toBeVisible();
    await expect(primaryAction, `${title} keyboard expansion did not advance focus`).toBeFocused();
    await expect(origin.locator(".project-card-story-label")).toHaveText("Why it began");
    expect((await origin.locator("p:last-child").innerText()).trim().length, `${title} origin story is too slight`).toBeGreaterThan(30);

    if (title === "Not A Good Driver") {
      await expect(evolution).toHaveCount(0);
    } else {
      await expect(evolution).toHaveCount(1);
      await expect(evolution.locator(".project-card-story-label")).toHaveText("What changed");
      expect((await evolution.locator("p:last-child").innerText()).trim().length, `${title} evolution story is too slight`).toBeGreaterThan(30);
    }

    await expect
      .poll(() => card.evaluate((element) => element.getAnimations({ subtree: true }).length), {
        message: `${title} expanded preview did not settle`,
      })
      .toBe(0);

    const geometry = await card.evaluate((element) => {
      const bounds = element.getBoundingClientRect();
      const action = element.querySelector("[data-project-card-primary-action]")?.getBoundingClientRect();
      const close = element.querySelector("[data-project-card-close]")?.getBoundingClientRect();
      const storyBeats = Array.from(element.querySelectorAll(".project-card-story-beat"));
      return {
        actionHeight: action?.height ?? 0,
        actionWidth: action?.width ?? 0,
        cardLeft: bounds.left,
        cardRight: bounds.right,
        closeHeight: close?.height ?? 0,
        closeWidth: close?.width ?? 0,
        documentOverflow: document.documentElement.scrollWidth - document.documentElement.clientWidth,
        clippedStoryBeats: storyBeats.filter((beat) => beat.scrollWidth > beat.clientWidth + 1 || beat.scrollHeight > beat.clientHeight + 1).length,
        storyBeatWidths: storyBeats.map((beat) => beat.getBoundingClientRect().width),
      };
    });
    expect(geometry.actionHeight, `${title} primary action is shorter than 44px`).toBeGreaterThanOrEqual(44);
    expect(geometry.actionWidth, `${title} primary action is narrower than 44px`).toBeGreaterThanOrEqual(44);
    expect(geometry.closeHeight, `${title} close action is shorter than 44px`).toBeGreaterThanOrEqual(44);
    expect(geometry.closeWidth, `${title} close action is narrower than 44px`).toBeGreaterThanOrEqual(44);
    expect(geometry.cardLeft, `${title} expands left of the viewport`).toBeGreaterThanOrEqual(-1);
    expect(geometry.cardRight, `${title} expands right of the viewport`).toBeLessThanOrEqual((page.viewportSize()?.width ?? 0) + 1);
    expect(geometry.documentOverflow, `${title} expansion creates horizontal overflow`).toBeLessThanOrEqual(1);
    expect(geometry.clippedStoryBeats, `${title} clips expanded story copy`).toBe(0);
    expect(
      geometry.storyBeatWidths.every((width) => width >= 200),
      `${title} expanded story is squeezed`
    ).toBe(true);

    await closeButton.focus();
    await expect(closeButton).toBeFocused();
    await closeButton.press("Enter");
    await expect(card, `${title} did not close`).toHaveAttribute("data-project-card-state", "collapsed");
    await expect(page.locator(".projects [data-project-card-state='expanded']")).toHaveCount(0);
    await expect(panel).toBeHidden();
    await expect(trigger, `${title} did not restore focus to its preview trigger`).toBeFocused();
  }

  expect(runtimeErrors, "project-card expansion raised browser runtime errors").toEqual([]);
});

test("all fun stories fit a high-DPR scaled canvas", async ({ browser }, testInfo) => {
  test.setTimeout(180000);
  test.skip(testInfo.project.name !== "desktop-1440", "one Chromium context covers the high-DPR effective viewport");

  const routes = ALL_SITEWIDE_ROUTES.filter((route) => FUN_PROJECT_ROUTE_IDS.has(route.id));
  expect(routes).toHaveLength(FUN_PROJECT_ROUTE_IDS.size);

  // A 720x500 CSS viewport at DPR 2 retains a 1440x1000 pixel canvas while
  // independently exercising the compact responsive layout.
  const context = await browser.newContext({
    deviceScaleFactor: 2,
    locale: "en-US",
    screen: { width: 1440, height: 1000 },
    timezoneId: "America/Los_Angeles",
    viewport: { width: 720, height: 500 },
  });
  const page = await context.newPage();
  const runtimeErrors = collectRuntimeErrors(page);

  try {
    await preparePage(page, "light");
    for (const route of routes) {
      const response = await page.goto(publicRouteUrl(route.path), { waitUntil: "domcontentloaded" });
      expect(response, `${route.path} has no response at the scaled viewport`).not.toBeNull();
      expect(response.status(), `${route.path} failed at the scaled viewport`).toBeLessThan(400);
      await expect(page.locator(route.readySelector).first()).toBeVisible();
      await page.evaluate(async () => {
        if (document.fonts?.ready) await document.fonts.ready;
      });
      await stabilizeVisuals(page);

      const geometry = await page.evaluate(() => ({
        clientWidth: document.documentElement.clientWidth,
        devicePixelRatio: window.devicePixelRatio,
        scrollWidth: document.documentElement.scrollWidth,
      }));
      expect(geometry.clientWidth).toBe(720);
      expect(geometry.devicePixelRatio).toBe(2);
      expect(geometry.scrollWidth - geometry.clientWidth, `${route.path} overflows at the scaled viewport`).toBeLessThanOrEqual(1);

      const hero = page.locator(".project-case-hero").first();
      const copy = hero.locator(":scope > .project-case-copy");
      const media = hero.locator(":scope > .project-case-media");
      await expect(copy).toBeVisible();
      if ((await media.count()) > 0) {
        await expect(media).toBeVisible();
        const order = await hero.evaluate((element) => {
          const copyBox = element.querySelector(":scope > .project-case-copy")?.getBoundingClientRect();
          const mediaBox = element.querySelector(":scope > .project-case-media")?.getBoundingClientRect();
          return copyBox && mediaBox ? { copyTop: copyBox.top, mediaTop: mediaBox.top } : null;
        });
        expect(order, `${route.path} has no measurable hero at the scaled viewport`).not.toBeNull();
        expect(order.mediaTop, `${route.path} puts media before its story at the scaled viewport`).toBeGreaterThan(order.copyTop);
      }

      expect(runtimeErrors, `${route.path} raised errors at DPR 2`).toEqual([]);
      runtimeErrors.length = 0;
    }
  } finally {
    await context.close();
  }
});

test("all fun stories reflow at 200% root text size", async ({ page }, testInfo) => {
  test.setTimeout(180000);
  test.skip(testInfo.project.name !== "desktop-1440", "one desktop context covers text-only 200% reflow");

  const routes = ALL_SITEWIDE_ROUTES.filter((route) => FUN_PROJECT_ROUTE_IDS.has(route.id));
  expect(routes).toHaveLength(FUN_PROJECT_ROUTE_IDS.size);
  const runtimeErrors = collectRuntimeErrors(page);
  await preparePage(page, "light");

  for (const route of routes) {
    const response = await page.goto(publicRouteUrl(route.path), { waitUntil: "domcontentloaded" });
    expect(response, `${route.path} has no response at 200% root text size`).not.toBeNull();
    expect(response.status(), `${route.path} failed at 200% root text size`).toBeLessThan(400);
    await page.addStyleTag({ content: "html { font-size: 200% !important; }" });
    await expect(page.locator(route.readySelector).first()).toBeVisible();
    await page.evaluate(async () => {
      if (document.fonts?.ready) await document.fonts.ready;
      await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    });
    await stabilizeVisuals(page);

    const geometry = await page.evaluate(() => {
      const root = document.documentElement;
      const textElements = Array.from(
        document.querySelectorAll(
          ".project-case-copy h1, .project-case-copy p, .project-detail article > p, .project-detail article > h2, .project-case-summary p, .project-story-beat h3, .project-story-beat p, .scholar-story-trace h3, .scholar-story-trace p, .project-story-note h2, .project-story-note p, .site-experiment-reproduce h2, .site-experiment-reproduce p, .site-experiment-evidence-figure figcaption"
        )
      ).filter((element) => element.getClientRects().length > 0 && !element.matches(".sr-only, .visually-hidden"));
      const controls = Array.from(document.querySelectorAll(".project-case-actions a, details.project-story-disclosure > summary")).filter(
        (element) => element.getClientRects().length > 0
      );
      return {
        clippedText: textElements
          .filter((element) => {
            const style = getComputedStyle(element);
            const clips = (value) => ["auto", "clip", "hidden", "scroll"].includes(value);
            return (
              (clips(style.overflowX) && element.scrollWidth > element.clientWidth + 1) ||
              (clips(style.overflowY) && element.scrollHeight > element.clientHeight + 1)
            );
          })
          .map((element) => element.textContent.replace(/\s+/g, " ").trim().slice(0, 80)),
        controlSizes: controls.map((element) => {
          const box = element.getBoundingClientRect();
          return { height: box.height, width: box.width };
        }),
        fontSize: Number.parseFloat(getComputedStyle(root).fontSize),
        overflow: Math.max(root.scrollWidth, document.body.scrollWidth) - root.clientWidth,
        textCount: textElements.length,
      };
    });

    expect(geometry.fontSize, `${route.path} did not receive 200% root text`).toBe(32);
    expect(geometry.overflow, `${route.path} overflows with 200% root text`).toBeLessThanOrEqual(1);
    expect(geometry.textCount, `${route.path} exposes too little story text for a reflow check`).toBeGreaterThan(5);
    expect(geometry.clippedText, `${route.path} clips text at 200%: ${geometry.clippedText.join(" | ")}`).toEqual([]);
    expect(geometry.controlSizes.length, `${route.path} exposes no story controls at 200%`).toBeGreaterThan(1);
    expect(
      geometry.controlSizes.every((box) => box.height >= 44 && box.width >= 44),
      `${route.path} has an undersized control at 200% root text`
    ).toBe(true);
    expect(runtimeErrors, `${route.path} raised errors at 200% root text`).toEqual([]);
    runtimeErrors.length = 0;
  }
});

test("Human focus and AI research keep reciprocal format context", async ({ page, browser }, testInfo) => {
  test.setTimeout(120000);
  test.skip(testInfo.project.name !== "desktop-1440", "one browser covers the reciprocal format journey");

  const runtimeErrors = collectRuntimeErrors(page);
  await preparePage(page, "light");
  const humanFocusUrl = new URL(publicRouteUrl("/"));
  humanFocusUrl.hash = "#focus";
  const aiResearchUrl = new URL(publicRouteUrl("/ai/"));
  aiResearchUrl.hash = "#research";

  await page.addInitScript(() => {
    window.__formatArrivalTargets = [];
    window.addEventListener("home-active-section-change", () => {
      queueMicrotask(() => {
        if (location.hash !== "#focus") return;
        const link = document.querySelector('[data-site-format="ai"]');
        if (link) window.__formatArrivalTargets.push(new URL(link.getAttribute("href"), location.href).href);
      });
    });
  });

  await page.goto(humanFocusUrl.href, { waitUntil: "domcontentloaded" });
  const focusAiLink = page.locator('[data-site-format="ai"]');
  await expect.poll(async () => new URL((await focusAiLink.getAttribute("href")) || "", page.url()).href).toBe(aiResearchUrl.href);
  await page.evaluate(() => document.fonts.ready);
  await expect(page.locator("#focus")).toBeInViewport({ ratio: 0.5 });
  const arrivalTargets = await page.evaluate(() => window.__formatArrivalTargets);
  await testInfo.attach("human-focus-arrival-targets", {
    body: Buffer.from(JSON.stringify({ arrivalTargets, performanceBenchmark: false }, null, 2)),
    contentType: "application/json",
  });
  expect(arrivalTargets.length).toBeGreaterThan(0);
  expect(arrivalTargets.every((target) => target === aiResearchUrl.href)).toBe(true);
  await expect(focusAiLink).toHaveAttribute("rel", /(?:^|\s)alternate(?:\s|$)/);
  await focusAiLink.focus();
  await expect(focusAiLink).toBeFocused();
  await page.keyboard.press("Enter");
  await expect(page).toHaveURL(aiResearchUrl.href);
  // The URL commits before DOMContentLoaded. Chromium then handles the #research fragment, whose section cannot take
  // focus, and moves focus back to <body>. Focusing earlier raced that (CI d684c7eb2), so wait for the page to load.
  await page.waitForLoadState("load");

  const researchHumanLink = page.locator('[data-site-format="human"]');
  await expect.poll(async () => new URL((await researchHumanLink.getAttribute("href")) || "", page.url()).href).toBe(humanFocusUrl.href);
  await expect(researchHumanLink).toHaveAttribute("rel", /(?:^|\s)alternate(?:\s|$)/);
  await attachScreenshot(page, testInfo, "ai-research-reciprocal-format-desktop-1440", { fullPage: false });
  await researchHumanLink.focus();
  await expect(researchHumanLink).toBeFocused();
  await page.keyboard.press("Enter");
  await expect(page).toHaveURL(humanFocusUrl.href);
  await page.goBack();
  await expect(page).toHaveURL(aiResearchUrl.href);
  await expect
    .poll(async () => new URL((await page.locator('[data-site-format="human"]').getAttribute("href")) || "", page.url()).href)
    .toBe(humanFocusUrl.href);

  const noScriptContext = await browser.newContext({ javaScriptEnabled: false, viewport: { width: 390, height: 900 } });
  const noScriptPage = await noScriptContext.newPage();
  try {
    await noScriptPage.goto(humanFocusUrl.href, { waitUntil: "domcontentloaded" });
    const noScriptAiLink = noScriptPage.locator('[data-site-format="ai"]');
    const noScriptAiTarget = new URL((await noScriptAiLink.getAttribute("href")) || "", noScriptPage.url());
    expect(noScriptAiTarget.pathname).toBe(new URL(publicRouteUrl("/ai/")).pathname);
    expect(noScriptAiTarget.hash).toBe("");
    await noScriptAiLink.click();
    await expect(noScriptPage).toHaveURL(publicRouteUrl("/ai/"));
  } finally {
    await noScriptContext.close();
  }

  expect(runtimeErrors).toEqual([]);
});

test("Human and AI formats keep stable, auditable route counterparts", async ({ page, browser }, testInfo) => {
  test.setTimeout(420000);
  test.skip(testInfo.project.name !== "desktop-1440", "one browser covers deterministic format routing and narrow chrome");

  await preparePage(page, "light");
  const routeTargets = [
    { route: "/", hash: "", alternate: true },
    { route: "/publications/", hash: "#publications", alternate: true },
    { route: "/publications/designweaver/", hash: "#designweaver", alternate: true },
    { route: "/projects/", hash: "#projects", alternate: true },
    { route: "/projects/designweaver/", hash: "#project-designweaver", alternate: true },
    { route: "/projects/house-in-the-cliff/", hash: "#project-house-in-the-cliff", alternate: true },
    { route: "/blog/", hash: "#writing", alternate: true },
    { route: "/blog/2026/research-skills-starter-pack/", hash: "#writing", alternate: true },
    { route: "/cv/", hash: "#cv", alternate: true },
  ];

  for (const { route, hash, alternate } of routeTargets) {
    await page.goto(publicRouteUrl(route), { waitUntil: "domcontentloaded" });
    const expectedHuman = new URL(publicRouteUrl(route));
    const humanLink = page.locator('[data-site-format="human"]');
    const aiLink = page.locator('[data-site-format="ai"]');
    const humanTarget = new URL((await humanLink.getAttribute("href")) || "", page.url());
    const aiTarget = new URL((await aiLink.getAttribute("href")) || "", page.url());

    await expect(humanLink).toHaveAttribute("aria-current", "page");
    expect(humanTarget.pathname).toBe(expectedHuman.pathname);
    expect(humanTarget.search).toBe(expectedHuman.search);
    expect(humanTarget.hash).toBe(expectedHuman.hash);
    expect(aiTarget.pathname).toBe(new URL(publicRouteUrl("/ai/")).pathname);
    expect(aiTarget.hash).toBe(hash);
    if (alternate) {
      await expect(aiLink).toHaveAttribute("rel", /(?:^|\s)alternate(?:\s|$)/);
    } else {
      await expect(aiLink).not.toHaveAttribute("rel", /(?:^|\s)alternate(?:\s|$)/);
    }
  }

  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto(publicRouteUrl("/"), { waitUntil: "domcontentloaded" });
  await page.locator('[data-home-section="publications"]').scrollIntoViewIfNeeded();
  await expect
    .poll(async () => new URL((await page.locator('[data-site-format="ai"]').getAttribute("href")) || "", page.url()).hash)
    .toBe("#publications");
  expect(new URL(page.url()).hash, "manual homepage reading should not synthesize a URL hash").toBe("");

  await page.evaluate(() => {
    window.location.hash = "#focus";
  });
  await expect(page).toHaveURL(/#focus$/);
  await expect
    .poll(async () => new URL((await page.locator('[data-site-format="ai"]').getAttribute("href")) || "", page.url()).hash)
    .toBe("#research");
  await page.evaluate(() => document.fonts.ready);
  await expect(page.locator("#focus")).toBeInViewport({ ratio: 0.5 });
  await page.mouse.move(page.viewportSize().width / 2, page.viewportSize().height / 3);
  const publicationsScroll = await page.locator("#publications").evaluate((section) => {
    const navbarBottom = document.getElementById("navbar")?.getBoundingClientRect().bottom || 0;
    return section.getBoundingClientRect().top - navbarBottom - 12;
  });
  await page.mouse.wheel(0, publicationsScroll);
  await expect(page.locator("#publications")).toBeInViewport();
  await expect
    .poll(async () => new URL((await page.locator('[data-site-format="ai"]').getAttribute("href")) || "", page.url()).hash)
    .toBe("#publications");
  expect(new URL(page.url()).hash, "intentional reading keeps the explicit URL while updating its counterpart").toBe("#focus");

  // A newer hash supersedes pending arrival callbacks; native history then
  // restores each section without letting an older transition retake context.
  await page.evaluate(() => {
    window.location.hash = "#connect";
    window.location.hash = "#publications";
  });
  await expect(page).toHaveURL(/#publications$/);
  await expect(page.locator("#publications")).toBeInViewport();
  await expect
    .poll(async () => new URL((await page.locator('[data-site-format="ai"]').getAttribute("href")) || "", page.url()).hash)
    .toBe("#publications");
  await page.goBack();
  await expect(page).toHaveURL(/#connect$/);
  await expect(page.locator("#connect")).toBeInViewport();
  await expect
    .poll(async () => new URL((await page.locator('[data-site-format="ai"]').getAttribute("href")) || "", page.url()).hash)
    .toBe("#sources");
  await page.goForward();
  await expect(page).toHaveURL(/#publications$/);
  await expect(page.locator("#publications")).toBeInViewport();
  await expect
    .poll(async () => new URL((await page.locator('[data-site-format="ai"]').getAttribute("href")) || "", page.url()).hash)
    .toBe("#publications");

  await page.goto(publicRouteUrl("/ai/"), { waitUntil: "domcontentloaded" });
  const aiCounterparts = [
    { hash: "#identity", human: "/", alternate: true },
    { hash: "#research", human: "/#focus", alternate: true },
    { hash: "#projects", human: "/projects/", alternate: true },
    { hash: "#project-designweaver", human: "/projects/designweaver/", alternate: true },
    { hash: "#project-house-in-the-cliff", human: "/projects/house-in-the-cliff/", alternate: true },
    { hash: "#publications", human: "/publications/", alternate: true },
    { hash: "#designweaver", human: "/publications/designweaver/", alternate: true },
    { hash: "#writing", human: "/blog/", alternate: true },
    { hash: "#cv", human: "/cv/", alternate: true },
    { hash: "#routes", human: "/", alternate: false },
    { hash: "#sources", human: "/", alternate: false },
    { hash: "#not-real", human: "/", alternate: false },
  ];

  for (const { hash, human, alternate } of aiCounterparts) {
    const expectedHuman = new URL(publicRouteUrl(human));
    const expectedPathAndHash = `${expectedHuman.pathname}${expectedHuman.hash}`;
    await page.evaluate((nextHash) => {
      window.location.hash = nextHash;
    }, hash);
    await expect(page).toHaveURL(new RegExp(`${hash}$`));
    const humanLink = page.locator('[data-site-format="human"]');
    if (hash === "#not-real") {
      await expect
        .poll(async () => {
          const target = new URL((await humanLink.getAttribute("href")) || "", page.url());
          return `${target.pathname}${target.hash}`;
        })
        .toBe(expectedPathAndHash);
    } else {
      await expectStableHumanCounterpart(page, expectedPathAndHash);
    }
    const humanTarget = new URL((await humanLink.getAttribute("href")) || "", page.url());
    expect(humanTarget.pathname).toBe(expectedHuman.pathname);
    expect(humanTarget.hash).toBe(expectedHuman.hash);
    if (alternate) {
      await expect(humanLink).toHaveAttribute("rel", /(?:^|\s)alternate(?:\s|$)/);
    } else {
      await expect(humanLink).not.toHaveAttribute("rel", /(?:^|\s)alternate(?:\s|$)/);
    }
  }

  await page.evaluate(() => {
    window.location.hash = "#research";
  });
  await expect(page).toHaveURL(/#research$/);
  await expectStableHumanCounterpart(page, `${new URL(publicRouteUrl("/")).pathname}#focus`);
  await page.evaluate(() => {
    window.location.hash = "#publications";
  });
  await expect(page).toHaveURL(/#publications$/);
  await expectStableHumanCounterpart(page, new URL(publicRouteUrl("/publications/")).pathname);
  await page.goBack();
  await expect(page).toHaveURL(/#research$/);
  await expectStableHumanCounterpart(page, `${new URL(publicRouteUrl("/")).pathname}#focus`);
  await page.goForward();
  await expect(page).toHaveURL(/#publications$/);
  await expectStableHumanCounterpart(page, new URL(publicRouteUrl("/publications/")).pathname);

  await page.goto(publicRouteUrl("/ai/"), { waitUntil: "domcontentloaded" });
  const desktopResearchLink = page.locator('[data-ai-nav-link="research"]');
  await desktopResearchLink.focus();
  await page.keyboard.press("Enter");
  await expect(page).toHaveURL(/\/ai\/#research$/);
  await expect(page.locator("#research")).toBeFocused();
  await expect
    .poll(async () => {
      const landing = await getAnchorLandingGeometry(page, "research");
      if (!landing) return false;
      const gap = landing.targetTop - landing.navBottom;
      return gap >= 8 && gap <= 24;
    })
    .toBe(true);

  await page.setViewportSize({ width: 390, height: 1000 });
  await page.goto(publicRouteUrl("/ai/#projects"), { waitUntil: "domcontentloaded" });
  await expect(page.locator(".ai-jump-nav")).toHaveCount(0);
  await expect(page.locator("[data-project-slug]")).toHaveCount(23);
  const houseRecord = page.locator('[data-project-slug="house-in-the-cliff"]');
  await expect(houseRecord).toHaveCount(1);
  await expect(houseRecord.locator('a[href$="/projects/house-in-the-cliff/"]')).toHaveText("Human project page");
  await expect(houseRecord.locator('a[href$="/ai/projects/house-in-the-cliff.md"]')).toHaveText("Machine-readable Markdown");
  await expect(page.locator('#project-website-revamp a[href$="/projects/website-revamp/"]')).toHaveText("Human project page");
  await expect(page.locator('#writing a[href$="/blog/"]')).toHaveText("Human writing index");
  await expect(page.locator('#cv a[href$="/cv/"]')).toHaveText("Current human CV");
  await expect(page.locator('#cv a[href$="/assets/json/resume.json"]')).toHaveText("Current JSON Resume");
  await expect(page.locator('#cv a[href$="/assets/pdf/Sirui_Tao_CV_Public.pdf"]')).toHaveText("Current PDF");
  await expect(page.locator("#cv")).toContainText("The web CV, JSON Resume, and PDF share the same current public record.");

  const aiHeaderLinks = page.locator("#navbarNav [data-ai-nav-link]");
  await expect(aiHeaderLinks).toHaveCount(7);
  const headerTargetsAreMachineLocal = await aiHeaderLinks.evaluateAll((links) =>
    links.every((link) => {
      const target = new URL(link.href);
      return target.pathname === window.location.pathname && Boolean(target.hash);
    })
  );
  expect(headerTargetsAreMachineLocal).toBe(true);
  await expect(page.locator('[data-ai-nav-link="projects"]')).toHaveAttribute("aria-current", "location");
  await expect(page.locator('[data-site-format="human"]')).toHaveAttribute("href", /\/projects\/$/);

  const navbarToggle = page.locator(".navbar-toggler");
  const mobileNavigation = page.locator("#navbarNav");
  await navbarToggle.click();
  await expect(navbarToggle).toHaveAttribute("aria-expanded", "true");
  await expect(mobileNavigation).toHaveClass(/show/);
  const sourcesHeaderLink = page.locator('[data-ai-nav-link="sources"]');
  await sourcesHeaderLink.focus();
  await page.keyboard.press("Enter");
  await expect(page).toHaveURL(/\/ai\/#sources$/);
  await expect(page.locator("#sources")).toHaveClass(/site-anchor-arrival/);
  await expect(mobileNavigation).toBeHidden();
  await expect(navbarToggle).toHaveAttribute("aria-expanded", "false");
  await expect(page.locator('[data-site-format="human"]')).toHaveAttribute("href", /\/$/);
  await expect(page.locator("#sources")).toBeFocused();
  await expect
    .poll(async () => {
      const landing = await getAnchorLandingGeometry(page, "sources");
      if (!landing) return false;
      const gap = landing.targetTop - landing.navBottom;
      return gap >= 8 && gap <= 24;
    })
    .toBe(true);
  const sourcesLanding = await getAnchorLandingGeometry(page, "sources");
  expect(sourcesLanding.targetTop).toBeGreaterThanOrEqual(sourcesLanding.navBottom + 8);
  expect(sourcesLanding.targetTop).toBeLessThanOrEqual(sourcesLanding.navBottom + 24);

  await page.goBack();
  await expect(page).toHaveURL(/\/ai\/#projects$/);
  await expect(mobileNavigation).toBeHidden();
  await expect(navbarToggle).toHaveAttribute("aria-expanded", "false");
  await expect(page.locator('[data-site-format="human"]')).toHaveAttribute("href", /\/projects\/$/);
  await expect
    .poll(async () => {
      const landing = await getAnchorLandingGeometry(page, "projects");
      if (!landing) return false;
      const gap = landing.targetTop - landing.navBottom;
      return gap >= 8 && gap <= 24;
    })
    .toBe(true);

  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto(publicRouteUrl("/ai/"), { waitUntil: "domcontentloaded" });
  await page.locator("#sources").evaluate((section) => {
    const navbarBottom = document.getElementById("navbar")?.getBoundingClientRect().bottom || 0;
    const targetTop = section.getBoundingClientRect().top;
    window.scrollBy({ top: targetTop - navbarBottom - 12, behavior: "instant" });
  });
  await expect(page.locator('[data-ai-nav-link="sources"]')).toHaveAttribute("aria-current", "location");
  expect(new URL(page.url()).hash, "manual reading should not pollute browser history with synthetic hashes").toBe("");
  await expect(page.locator('[data-site-format="human"]')).toHaveAttribute("href", /\/$/);

  const widths = [320, 350, 375, 384, 390];
  await page.goto(publicRouteUrl("/ai/"), { waitUntil: "domcontentloaded" });
  for (const width of widths) {
    await page.setViewportSize({ width, height: 900 });
    await page.evaluate(() => window.scrollTo({ top: 0, behavior: "instant" }));
    const geometry = await getNarrowAiChromeGeometry(page);
    expect(geometry.scrollWidth - geometry.clientWidth, `${width}px JavaScript page overflows`).toBeLessThanOrEqual(1);
    expect(geometry.article.top, `${width}px article is occluded by fixed navigation`).toBeGreaterThanOrEqual(geometry.nav.bottom - 1);
    expect(geometry.brandMark).not.toBeNull();
    expect(geometry.brandNameVisible).toBe(width >= 375);
    expect(geometry.brand.right, `${width}px brand overlaps format controls`).toBeLessThanOrEqual(geometry.actions.left - 2);
    expect(Math.abs(geometry.actions.top + geometry.actions.height / 2 - (geometry.toggler.top + geometry.toggler.height / 2))).toBeLessThanOrEqual(
      1
    );
    for (const box of geometry.formatLinks) {
      expect(box.width).toBeGreaterThanOrEqual(44);
      expect(box.height).toBeGreaterThanOrEqual(44);
      expect(box.left).toBeGreaterThanOrEqual(0);
      expect(box.right).toBeLessThanOrEqual(width);
    }
    if ([320, 384, 390].includes(width)) {
      await attachScreenshot(page, testInfo, `ai-format-switch-${width}`, { fullPage: false });
    }
  }

  const noScriptContext = await browser.newContext({ javaScriptEnabled: false, viewport: { width: 390, height: 900 } });
  const noScriptPage = await noScriptContext.newPage();
  try {
    await noScriptPage.goto(publicRouteUrl("/ai/"), { waitUntil: "domcontentloaded" });
    await expect(noScriptPage.locator(".ai-jump-nav")).toHaveCount(0);
    const noScriptNavigation = noScriptPage.locator(".ai-noscript-nav");
    await expect(noScriptNavigation).toBeVisible();
    await expect(noScriptNavigation).toHaveAccessibleName("AI profile sections");
    const noScriptHeaderLinks = noScriptPage.locator("#navbarNav [data-ai-nav-link]");
    await expect(noScriptHeaderLinks.first()).toBeHidden();
    const expectedHeaderHashes = ["#identity", "#research", "#projects", "#publications", "#writing", "#cv", "#sources"];
    const expectedNoScriptHashes = ["#identity", "#research", "#projects", "#publications", "#writing", "#cv", "#routes", "#sources"];
    await expect(noScriptHeaderLinks).toHaveCount(expectedHeaderHashes.length);
    const noScriptJumpLinks = noScriptNavigation.locator("a");
    await expect(noScriptJumpLinks).toHaveCount(expectedNoScriptHashes.length);
    for (let index = 0; index < expectedHeaderHashes.length; index += 1) {
      const link = noScriptHeaderLinks.nth(index);
      await expect(link).toHaveAttribute("href", new RegExp(`${expectedHeaderHashes[index]}$`));
    }
    for (let index = 0; index < expectedNoScriptHashes.length; index += 1) {
      await expect(noScriptJumpLinks.nth(index)).toHaveAttribute("href", expectedNoScriptHashes[index]);
      expect(await noScriptPage.locator(expectedNoScriptHashes[index]).count()).toBe(1);
    }
    const humanHomePath = new URL(publicRouteUrl("/")).pathname;
    const noScriptHumanHref = new URL((await noScriptPage.locator('[data-site-format="human"]').getAttribute("href")) || "", noScriptPage.url());
    expect(noScriptHumanHref.pathname).toBe(humanHomePath);

    for (const width of widths) {
      await noScriptPage.setViewportSize({ width, height: 900 });
      await noScriptPage.evaluate(() => window.scrollTo({ top: 0, behavior: "instant" }));
      const geometry = await getNarrowAiChromeGeometry(noScriptPage);
      expect(geometry.scrollWidth - geometry.clientWidth, `${width}px no-JavaScript page overflows`).toBeLessThanOrEqual(1);
      expect(geometry.article.top, `${width}px no-JavaScript article is occluded`).toBeGreaterThanOrEqual(geometry.nav.bottom - 1);
      expect(geometry.brandNameVisible).toBe(width >= 375);
      expect(geometry.brand.right, `${width}px no-JavaScript brand overlaps format controls`).toBeLessThanOrEqual(geometry.actions.left - 2);
      expect(Math.abs(geometry.actions.top + geometry.actions.height / 2 - (geometry.toggler.top + geometry.toggler.height / 2))).toBeLessThanOrEqual(
        1
      );
      for (const box of geometry.formatLinks) {
        expect(box.width).toBeGreaterThanOrEqual(44);
        expect(box.height).toBeGreaterThanOrEqual(44);
        expect(box.right).toBeLessThanOrEqual(width);
      }
    }

    await noScriptPage.setViewportSize({ width: 390, height: 900 });
    await noScriptJumpLinks.last().click();
    await expect(noScriptPage).toHaveURL(/\/ai\/#sources$/);
    await expect(noScriptPage.locator("#sources")).toBeVisible();

    const noScriptResearchUrl = new URL(publicRouteUrl("/ai/"));
    noScriptResearchUrl.hash = "research";
    await noScriptPage.goto(noScriptResearchUrl.toString(), { waitUntil: "domcontentloaded" });
    const noScriptLanding = await getAnchorLandingGeometry(noScriptPage, "research");
    expect(noScriptLanding.targetTop).toBeGreaterThanOrEqual(noScriptLanding.navBottom - 1);
  } finally {
    await noScriptContext.close();
  }
});

test("no-JavaScript AI hash routes keep current state neutral", async ({ browser }, testInfo) => {
  test.skip(testInfo.project.name !== "desktop-1440", "one browser proves the server-rendered no-JavaScript state");

  const context = await browser.newContext({ javaScriptEnabled: false, viewport: { width: 390, height: 900 } });
  const page = await context.newPage();
  try {
    const researchUrl = new URL(publicRouteUrl("/ai/"));
    researchUrl.hash = "research";
    const response = await page.goto(researchUrl.toString(), { waitUntil: "domcontentloaded" });

    expect(response, "the no-JavaScript AI route did not return a document response").not.toBeNull();
    expect(response.status(), `the no-JavaScript AI route returned HTTP ${response.status()}`).toBeLessThan(400);
    await expect(page.locator("#research")).toBeVisible();
    await expect(page.locator("#navbarNav .nav-item.active")).toHaveCount(0);
    await expect(page.locator("#navbarNav [data-ai-nav-link][aria-current]")).toHaveCount(0);
    await expect(page.locator('.ai-route-grid a[href$="/news/"]')).not.toHaveAttribute("rel", /alternate/);
  } finally {
    await context.close();
  }
});

test("head alternates are scoped to equivalent machine-readable documents", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "desktop-1440", "one browser covers the document-equivalence matrix");

  const cases = [
    { route: "/", expected: [["text/plain", "/llms.txt"]] },
    { route: "/ai/", expected: [["text/plain", "/llms-full.txt"]] },
    { route: "/publications/", expected: [["application/json", "/ai/publications.json"]] },
    {
      route: "/publications/designweaver/",
      expected: [
        ["text/markdown", "/ai/papers/designweaver.md"],
        ["application/x-bibtex", "/ai/papers/designweaver.bib"],
        ["application/x-research-info-systems", "/ai/papers/designweaver.ris"],
      ],
    },
    { route: "/projects/designweaver/", expected: [] },
    { route: "/blog/2026/research-skills-starter-pack/", expected: [] },
    { route: "/cv/", expected: [["application/json", "/assets/json/resume.json"]] },
  ];
  const machineTypes = new Set(["text/plain", "application/json", "text/markdown", "application/x-bibtex", "application/x-research-info-systems"]);

  for (const entry of cases) {
    await page.goto(publicRouteUrl(entry.route), { waitUntil: "domcontentloaded" });
    const alternates = await page.locator('head link[rel~="alternate"]').evaluateAll((links) =>
      links.map((link) => ({
        type: link.getAttribute("type") || "",
        pathname: new URL(link.href).pathname,
      }))
    );
    const machineAlternates = alternates.filter((link) => machineTypes.has(link.type));
    expect(machineAlternates, `${entry.route} advertises an over-broad machine alternate`).toHaveLength(entry.expected.length);
    for (const [type, pathnameSuffix] of entry.expected) {
      expect(machineAlternates.some((link) => link.type === type && link.pathname.endsWith(pathnameSuffix))).toBe(true);
    }
  }
});

test("home connect note links to the revamp story and Build Rhythm without numbers", async ({ page }, testInfo) => {
  const runtimeErrors = collectRuntimeErrors(page);
  for (const theme of ["noon", "evening"]) {
    await preparePage(page, theme);
    await page.goto(publicRouteUrl("/"), { waitUntil: "domcontentloaded" });
    await stabilizeVisuals(page);

    const note = page.locator(".home-connect-note");
    await note.scrollIntoViewIfNeeded();
    await expect(note).toBeVisible();
    const links = note.locator("a");
    await expect(links).toHaveCount(2);
    await expect(links.nth(0)).toHaveAttribute("href", /\/projects\/website-revamp\/$/);
    await expect(links.nth(1)).toHaveAttribute("href", /\/github-activity\/$/);
    await expect(note).not.toContainText(/\d/);
    await attachScreenshot(page, testInfo, `home-connect-note-${theme}-${testInfo.project.name}`, { locator: note });
  }
  expect(runtimeErrors).toEqual([]);
});

test("mobile back-to-top control yields the reading surface to an inline footer link", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "mobile-390", "the fixed control only risks narrow-screen prose");

  const runtimeErrors = collectRuntimeErrors(page);
  await preparePage(page, "light");
  await page.goto(publicRouteUrl("/projects/paper-constellation/"), { waitUntil: "domcontentloaded" });
  await stabilizeVisuals(page);
  await page.locator(".site-experiment-reproduce").scrollIntoViewIfNeeded();

  const floatingControl = page.locator("#back-to-top");
  const footerControl = page.locator(".mobile-back-to-top");
  await expect(floatingControl).toBeHidden();
  await expect(footerControl).toBeVisible();
  await expect(footerControl).toHaveAttribute("href", "#top");
  await expect(footerControl).toHaveAccessibleName("Back to top");
  const target = await footerControl.evaluate((element) => {
    const box = element.getBoundingClientRect();
    return { height: box.height, width: box.width };
  });
  expect(target.height).toBeGreaterThanOrEqual(44);
  expect(target.width).toBeGreaterThanOrEqual(44);
  expect(runtimeErrors).toEqual([]);
});

test("Build Rhythm exact-value table remains readable and keyboard accessible at narrow widths", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "desktop-1440", "one browser covers the compact table widths");
  const errors = collectRuntimeErrors(page);
  const personal = require("../../_data/code_activity.json").sources.find((source) => source.id === "personal");
  const cutoff = personal.complete_through;
  await preparePage(page, "light");
  await page.goto(publicRouteUrl("/github-activity/"), { waitUntil: "domcontentloaded" });
  const activity = page.locator("[data-github-activity]");
  await expect(activity).toHaveAttribute("data-state", /^(ready|unavailable)$/);
  if ((await activity.getAttribute("data-state")) === "unavailable") {
    await expect(page.locator("[data-personal-code-unavailable]")).toHaveText("Code history is being rebuilt.");
    return;
  }
  await page.locator("[data-rhythm-year]").selectOption(cutoff.slice(0, 4));
  await page.locator("[data-rhythm-method] > summary").click();
  await page.locator("[data-rhythm-records] > summary").click();
  const table = page.locator(".build-rhythm-table-wrap");
  await expect(table).toHaveAccessibleName("Recorded Personal daily values");
  await expect(table.locator("thead th")).toHaveText(["Date label", "Total commits", "Authored commits"]);
  for (const width of [768, 390, 320]) {
    await page.setViewportSize({ width, height: 1000 });
    expect(await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth)).toBeLessThanOrEqual(1);
    const box = await table.boundingBox();
    expect(box.x).toBeGreaterThanOrEqual(0);
    expect(box.x + box.width).toBeLessThanOrEqual(width);
    await page.locator("[data-rhythm-records] > summary").focus();
    await page.keyboard.press("Tab");
    await expect(table).toBeFocused();
    expect(await table.evaluate((node) => parseFloat(getComputedStyle(node).outlineWidth))).toBeGreaterThanOrEqual(2);
    await expect(table.locator("tbody tr").last()).toContainText(cutoff);
  }
  expect(errors).toEqual([]);
});

test("home research motion responds locally and keeps a reduced-motion still", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "desktop-1440", "representative semantic-motion checkpoint");

  const runtimeErrors = collectRuntimeErrors(page);
  await preparePage(page, "light");
  const response = await page.goto(publicRouteUrl("/"), { waitUntil: "domcontentloaded" });
  expect(response).not.toBeNull();
  expect(response.status()).toBeLessThan(400);

  const stage = page.locator("[data-research-motion]");
  const canvas = page.locator("[data-research-motion-canvas]");
  await stage.scrollIntoViewIfNeeded();
  await expect(canvas).toBeVisible();
  await expect.poll(async () => (await getResearchMotionState(stage)).visible).toBe(true);
  await expect(stage).toHaveAttribute("data-motion-energy", "resting");
  await attachScreenshot(page, testInfo, "research-motion-resting-desktop-1440", { locator: stage });

  await page.locator('[data-research-mode="evaluate"]').click();
  await expect(page.locator("[data-research-motion-readout]")).toHaveText("Evaluate");
  await expect(stage).toHaveAttribute("data-motion-energy", "engaged");
  await page.mouse.move(2, 2);
  await expect(stage).toHaveAttribute("data-motion-energy", "resting", { timeout: 2400 });

  const box = await canvas.boundingBox();
  expect(box).not.toBeNull();
  const centerX = box.x + box.width / 2;
  const centerY = box.y + box.height / 2;

  await page.mouse.move(centerX, box.y - 24);
  await page.waitForTimeout(120);
  const outsideState = await getResearchMotionState(stage);
  expect(outsideState.active, "a pointer 24px above the canvas must not engage motion").toBe(false);
  expect(outsideState.targetIntent, "nearby section space must not act like canvas input").toBe(0);
  expect(outsideState.kineticEnergy).toBeLessThanOrEqual(outsideState.maxInteractionIntent);
  await expect(stage).toHaveAttribute("data-motion-energy", "resting");

  const edgeDepths = [1 / box.width, 0.04, 0.1];
  const edgeStates = [];
  for (const depth of edgeDepths) {
    await page.mouse.move(box.x + box.width * depth, centerY);
    await page.waitForTimeout(60);
    const edgeState = await getResearchMotionState(stage);
    expect(edgeState.targetIntent).toBeGreaterThanOrEqual(0);
    expect(edgeState.targetIntent).toBeLessThanOrEqual(edgeState.maxInteractionIntent);
    expect(edgeState.kineticEnergy).toBeLessThanOrEqual(edgeState.maxInteractionIntent);
    edgeStates.push(edgeState);
  }
  expect(edgeStates[0].targetIntent, "the first inner pixel should not jump to full intent").toBeLessThan(0.1);
  expect(edgeStates[1].targetIntent).toBeGreaterThan(edgeStates[0].targetIntent);
  expect(edgeStates[2].targetIntent).toBeGreaterThan(edgeStates[1].targetIntent);
  expect(edgeStates[2].targetIntent).toBeCloseTo(edgeStates[2].maxInteractionIntent, 5);

  await page.mouse.move(centerX, centerY);
  await expect(stage).toHaveAttribute("data-motion-energy", "engaged");
  await expect.poll(async () => (await getResearchMotionState(stage)).kineticEnergy).toBeGreaterThanOrEqual(0.69);
  const centerState = await getResearchMotionState(stage);
  expect(centerState.active).toBe(true);
  expect(centerState.targetIntent).toBeCloseTo(centerState.maxInteractionIntent, 5);
  expect(centerState.kineticEnergy).toBeGreaterThanOrEqual(centerState.maxInteractionIntent - 0.03);
  expect(centerState.targetIntent).toBeLessThanOrEqual(0.72);
  expect(centerState.kineticEnergy).toBeLessThanOrEqual(centerState.maxInteractionIntent);
  expect(
    await page.evaluate(([x, y]) => Boolean(document.elementFromPoint(x, y)?.closest(".pip-companion")), [centerX, centerY]),
    "P must leave the interactive research canvas available to the pointer"
  ).toBe(false);
  await attachScreenshot(page, testInfo, "research-motion-engaged-desktop-1440", { locator: stage });

  await page.mouse.move(centerX, box.y - 24);
  const directExitState = await getResearchMotionState(stage);
  expect(directExitState.active).toBe(false);
  expect(directExitState.targetIntent).toBe(0);
  expect(directExitState.kineticEnergy).toBeLessThanOrEqual(directExitState.maxInteractionIntent);
  await expect
    .poll(async () => (await getResearchMotionState(stage)).intent, { message: "pointer intent should decay after leaving the canvas" })
    .toBeLessThan(0.02);
  await expect.poll(async () => (await getResearchMotionState(stage)).kineticEnergy).toBeLessThan(0.02);
  await expect(stage).toHaveAttribute("data-motion-energy", "resting");

  await page.mouse.move(box.x + box.width * 0.1, centerY);
  await expect.poll(async () => (await getResearchMotionState(stage)).kineticEnergy).toBeGreaterThanOrEqual(0.69);
  const reengagedState = await getResearchMotionState(stage);
  expect(reengagedState.active).toBe(true);
  expect(reengagedState.targetIntent).toBeCloseTo(reengagedState.maxInteractionIntent, 5);
  expect(reengagedState.intent).toBeGreaterThanOrEqual(reengagedState.maxInteractionIntent - 0.03);
  expect(reengagedState.kineticEnergy).toBeGreaterThanOrEqual(reengagedState.maxInteractionIntent - 0.03);

  await page.evaluate(() => window.scrollTo({ top: 0, behavior: "instant" }));
  await expect
    .poll(async () => getResearchMotionState(stage))
    .toMatchObject({
      active: false,
      targetIntent: 0,
      intent: 0,
      kineticEnergy: 0,
      visible: false,
      running: false,
    });

  await stage.scrollIntoViewIfNeeded();
  await expect
    .poll(async () => getResearchMotionState(stage))
    .toMatchObject({
      active: false,
      targetIntent: 0,
      intent: 0,
      kineticEnergy: 0,
      visible: true,
      running: true,
    });

  await page.emulateMedia({ reducedMotion: "reduce" });
  await expect(stage).toHaveAttribute("data-motion-energy", "resting");
  await expect.poll(async () => getResearchMotionState(stage)).toMatchObject({ reducedMotion: true, running: false, kineticEnergy: 0 });
  await page.waitForTimeout(180);
  const stillBefore = await canvas.screenshot();
  await page.waitForTimeout(260);
  const stillAfter = await canvas.screenshot();
  expect(screenshotDiffRatio(stillAfter, stillBefore), "reduced motion should render a stable still composition").toBeLessThan(0.0001);
  await attachScreenshot(page, testInfo, "research-motion-reduced-desktop-1440", { locator: stage });
  expect(runtimeErrors, "research motion raised browser runtime errors").toEqual([]);
});

test("projects nest the site experiments under the website revamp, newest first at every level", async ({ page }, testInfo) => {
  await preparePage(page, "light");
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.goto(publicRouteUrl("/projects/"), { waitUntil: "domcontentloaded" });

  // One deck at the top of the experiments: the website revamp, holding everything else (2026-10-18).
  const root = page.locator("[data-site-experiment-grid]");
  await expect(root).toBeVisible();
  await expect(root.locator(":scope > [data-project-card]")).toHaveCount(1);
  const revamp = root.locator(":scope > [data-project-deck='website-revamp']");
  await expect(revamp.locator(":scope > .card h4.card-title")).toHaveText("Vibe-Coding a Research Portfolio");
  await expect(revamp).toHaveAttribute("data-project-deck-size", "11");

  // Its face names what it holds, the 3D home's branch first, each name a link to its page (2026-10-19: Sirui
  // could not find the graphics work two closed decks down).
  const revampInside = revamp.locator(":scope > .card [data-project-deck-inside]");
  // The 3D home's build-diary pages (2026-10-24) are its newest children, so they lead its branch.
  await expect(revampInside.locator("a")).toHaveText(["The 3D home", "The house", "Graphics Lab", "Performance", "Light Paths", "La Jolla"]);
  await expect(revampInside.getByRole("link", { name: "Performance", exact: true })).toHaveAttribute("href", /\/projects\/graphics-performance\/$/);
  await expect(revampInside.locator(".project-deck-inside-more")).toHaveText("and 9 more");

  // Wide screens start with the revamp open and leave the address alone; narrower ones open it with a click.
  if (page.viewportSize().width >= 992) {
    await expect(revamp).toHaveAttribute("data-project-deck-state", "open");
    await expect(page).not.toHaveURL(/#deck\//);
    await expect(revampInside).toBeVisible();
  } else {
    await expect(revamp).toHaveAttribute("data-project-deck-state", "closed");
    await expect(revampInside).toBeVisible();
    await revamp.locator(":scope > .card [data-project-deck-trigger]").click({ position: { x: 12, y: 12 } });
    await expect(revamp).toHaveAttribute("data-project-deck-state", "open");
    await expect(page).toHaveURL(/#deck\/website-revamp$/);
  }
  const cards = revamp.locator(":scope > [data-project-deck-children] > .project-card-grid > [data-project-card]");
  await expect(cards).toHaveCount(11);
  await expect(cards.locator(":scope > .card h5.card-title")).toHaveCount(11);
  expect(await cards.locator(":scope > .card .card-title").allTextContents()).toEqual([
    "A little La Jolla",
    "duh & P, a Little Company",
    "Scaffolding for Taste — OpenAI Build Week",
    "Paper Constellation",
    "Build Rhythm",
    "The Desk That Learned Depth",
    "HCI Spooder-Man",
    "Scholar Lens",
    "Wall of Rejection",
    "The IKEA Card Experiment",
    "Dogtor's Hidden Portal",
  ]);

  // The level's pictures load once it opens.
  const images = cards.locator(":scope > .card .project-card-media img");
  await expect(images).toHaveCount(11);
  await expect.poll(() => images.evaluateAll((list) => list.every((image) => image.complete && image.naturalWidth > 0))).toBe(true);
  expect(await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth)).toBeLessThanOrEqual(0);

  const ikeaCard = cards.filter({ has: page.getByRole("heading", { name: "The IKEA Card Experiment", exact: true }) });
  await expect(ikeaCard).toHaveCount(1);
  const ikeaImage = ikeaCard.locator(".project-card-media img");
  await expect(ikeaImage).toHaveAttribute("src", /\/assets\/img\/project_pics\/site-experiments\/ikea-card-expanded\.png$/);
  expect(
    await ikeaImage.evaluate((element) => ({
      complete: element.complete,
      naturalHeight: element.naturalHeight,
      naturalWidth: element.naturalWidth,
    }))
  ).toEqual({ complete: true, naturalHeight: 650, naturalWidth: 1200 });
  await attachScreenshot(page, testInfo, `projects-site-experiments-${testInfo.project.name}`, { fullPage: true });

  // The 3D home holds the Graphics Lab, and the lab holds every indexed experiment of its record
  // (_data/design_records/graphics-lab.yml), grouped by system, plus one card for the performance write-up; the
  // deck and each group name their own count, so the check follows the record as it grows.
  const desk = cards.filter({ has: page.getByRole("heading", { name: "The Desk That Learned Depth", exact: true }) });
  await expect(desk.locator(":scope > .card [data-project-deck-inside] a")).toHaveText(["Graphics Lab", "Performance", "Light Paths", "The house"]);
  await desk.locator(":scope > .card [data-project-deck-trigger]").click({ position: { x: 12, y: 12 } });
  await expect(page.locator("[data-project-deck-trail] li")).toHaveText([
    "Site experiments",
    "Vibe-Coding a Research Portfolio",
    "The Desk That Learned Depth",
  ]);
  const lab = page.locator("[data-project-deck='graphics-lab']");
  await expect(lab.locator(":scope > .card h6.card-title")).toHaveText("Graphics Lab");
  // The lab's face names its record's groups, each linked to its group on the lab page, and its write-up.
  const labInside = lab.locator(":scope > .card [data-project-deck-inside] a");
  await expect(labInside.first()).toHaveAttribute("href", /\/projects\/graphics-lab\/#lab-group-light-transport$/);
  await expect(labInside.last()).toHaveText("Performance");
  await expect(labInside.last()).toHaveAttribute("href", /\/projects\/graphics-performance\/$/);
  await lab.locator(":scope > .card [data-project-deck-trigger]").click({ position: { x: 12, y: 12 } });
  await expect(page).toHaveURL(/#deck\/graphics-lab$/);
  const labSize = Number(await lab.getAttribute("data-project-deck-size"));
  const writeUps = lab.locator(".lab-card[data-where='page']");
  await expect(writeUps).toHaveCount(1);
  await expect(writeUps).toHaveAttribute("href", /\/projects\/graphics-performance\/$/);
  expect(labSize - 1, "the lab deck counts its experiments").toBeGreaterThanOrEqual(19);
  await expect(lab.locator(":scope > .card .project-deck-count")).toHaveText(`${labSize - 1} experiments`);
  await expect(lab.locator(".lab-card")).toHaveCount(labSize);
  const labGroups = await lab.locator(".lab-deck-group").evaluateAll((groups) =>
    groups.map((group) => ({
      said: Number(group.querySelector(".lab-deck-group-label span")?.textContent),
      cards: group.querySelectorAll(".lab-card").length,
    }))
  );
  expect(labGroups.length, "the experiments are grouped by system").toBeGreaterThanOrEqual(5);
  expect(labGroups.every((group) => group.cards > 0 && group.cards === group.said)).toBe(true);
  await expect(lab.locator(".lab-card", { hasText: "Light paths through the onsen" })).toHaveAttribute("href", /\/projects\/light-paths\/$/);
  await attachScreenshot(page, testInfo, `projects-graphics-lab-deck-${testInfo.project.name}`, { fullPage: false });

  // The trail walks back up; Escape goes up one level and the deck that closed keeps focus.
  await page.locator("[data-project-deck-crumb='website-revamp']").click();
  await expect(page).toHaveURL(/#deck\/website-revamp$/);
  await expect(cards).toHaveCount(11);
  await page.keyboard.press("Escape");
  await expect(revamp).toHaveAttribute("data-project-deck-state", "closed");
  await expect(revamp.locator(":scope > .card [data-project-deck-trigger]")).toBeFocused();
  await expect(page.locator("[data-project-deck-trail]")).toBeHidden();
});

test("Research Focus Paper field stays semantic, bounded, pausable, and optional", async ({ page, browser }, testInfo) => {
  test.setTimeout(300000);
  test.skip(testInfo.project.name !== "desktop-1440", "one desktop browser covers the single-context progressive-enhancement contract");

  const fallbackContext = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  const fallbackPage = await fallbackContext.newPage();
  const fallbackErrors = collectRuntimeErrors(fallbackPage);
  await fallbackPage.addInitScript(() => {
    const originalGetContext = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function getContext(type, ...args) {
      if (type === "webgl2" && this.closest?.("[data-paper-research-field]")) return null;
      return originalGetContext.call(this, type, ...args);
    };
  });

  let fallbackGeometry;
  try {
    await preparePage(fallbackPage, "light");
    await fallbackPage.goto(publicRouteUrl("/"), { waitUntil: "domcontentloaded" });
    const fallbackField = fallbackPage.locator("[data-paper-research-field]");
    // The field mounts only as the reader scrolls toward it.
    await expect(fallbackField).toHaveAttribute("data-paper-shader-state", "pending");
    await fallbackField.scrollIntoViewIfNeeded();
    await expect(fallbackField).toHaveAttribute("data-paper-shader-state", "fallback");
    await expect(fallbackPage.locator("[data-research-motion-canvas]")).toBeVisible();
    await expect(fallbackPage.locator("[data-research-mode]")).toHaveCount(3);
    fallbackGeometry = await fallbackPage.locator("[data-research-motion]").evaluate((stage) => {
      const box = stage.getBoundingClientRect();
      const semanticCanvas = stage.querySelector("[data-research-motion-canvas]").getBoundingClientRect();
      return {
        height: box.height,
        semanticHeight: semanticCanvas.height,
        semanticWidth: semanticCanvas.width,
        width: box.width,
      };
    });
    expect(fallbackErrors).toEqual([]);
  } finally {
    await fallbackContext.close();
  }

  const runtimeErrors = collectRuntimeErrors(page);
  await preparePage(page, "light");
  await page.goto(publicRouteUrl("/"), { waitUntil: "domcontentloaded" });
  const field = page.locator("[data-paper-research-field]");
  const stage = page.locator("[data-research-motion]");
  // Below the first screen, nothing mounts until the reader scrolls toward the field.
  await expect(field).toHaveAttribute("data-paper-shader-state", "pending");
  expect(await page.evaluate(() => window.__siruiPaperResearchField.getState().contextCount)).toBe(0);
  await stage.scrollIntoViewIfNeeded();
  await expect(field).toHaveAttribute("data-paper-shader-state", "ready");
  await expect.poll(() => page.evaluate(() => window.__siruiPaperResearchField?.getState().inViewport)).toBe(true);
  await expect.poll(() => page.evaluate(() => window.__siruiPaperResearchField?.getState().currentSpeed)).toBeGreaterThan(0);

  const readyGeometry = await stage.evaluate((element) => {
    const box = element.getBoundingClientRect();
    const semanticCanvas = element.querySelector("[data-research-motion-canvas]").getBoundingClientRect();
    return {
      height: box.height,
      semanticHeight: semanticCanvas.height,
      semanticWidth: semanticCanvas.width,
      width: box.width,
    };
  });
  for (const key of Object.keys(fallbackGeometry)) {
    expect(Math.abs(readyGeometry[key] - fallbackGeometry[key]), `Research Focus ${key} shifted after shader initialization`).toBeLessThanOrEqual(1);
  }

  const designState = await page.evaluate(() => window.__siruiPaperResearchField.getState());
  expect(designState.contextCount).toBe(1);
  expect(designState.canvasPixels).toBeGreaterThan(0);
  expect(designState.canvasPixels).toBeLessThanOrEqual(480000);
  await expect(field.locator("canvas")).toHaveCount(1);
  await page.locator('[data-research-mode="evaluate"]').click();
  const evaluateState = await page.evaluate(() => window.__siruiPaperResearchField.getState());
  expect(evaluateState.mode).toBe("evaluate");
  expect(evaluateState.uniforms).not.toEqual(designState.uniforms);
  expect(evaluateState.currentSpeed).toBeLessThan(designState.currentSpeed);
  await page.locator('[data-research-mode="situated"]').click();
  const situatedState = await page.evaluate(() => window.__siruiPaperResearchField.getState());
  expect(situatedState.mode).toBe("situated");
  expect(situatedState.uniforms.spreading).toBeGreaterThan(evaluateState.uniforms.spreading);
  expect(situatedState.uniforms.scale).toBeGreaterThan(evaluateState.uniforms.scale);

  await page.evaluate(() => {
    Object.defineProperty(document, "hidden", { configurable: true, value: true });
    document.dispatchEvent(new Event("visibilitychange"));
  });
  await expect.poll(() => page.evaluate(() => window.__siruiPaperResearchField.getState().currentSpeed)).toBe(0);
  await expect.poll(() => page.evaluate(() => window.__siruiPaperResearchField.getState().running)).toBe(false);
  await page.evaluate(() => {
    delete document.hidden;
    document.dispatchEvent(new Event("visibilitychange"));
  });
  await stage.scrollIntoViewIfNeeded();
  await expect.poll(() => page.evaluate(() => window.__siruiPaperResearchField.getState().currentSpeed)).toBeGreaterThan(0);

  await page.evaluate(() => window.scrollTo({ top: document.documentElement.scrollHeight, behavior: "instant" }));
  await expect.poll(() => page.evaluate(() => window.__siruiPaperResearchField.getState().inViewport)).toBe(false);
  await expect.poll(() => page.evaluate(() => window.__siruiPaperResearchField.getState().currentSpeed)).toBe(0);
  await expect.poll(() => page.evaluate(() => window.__siruiPaperResearchField.getState().running)).toBe(false);

  await stage.scrollIntoViewIfNeeded();
  const beforeLoss = await stage.boundingBox();
  await field.locator("canvas").evaluate((canvas) => canvas.getContext("webgl2")?.getExtension("WEBGL_lose_context")?.loseContext());
  await expect(field).toHaveAttribute("data-paper-shader-state", "fallback");
  await expect(field).toHaveAttribute("data-paper-shader-contexts", "0");
  await expect(page.locator("[data-research-motion-canvas]")).toBeVisible();
  const afterLoss = await stage.boundingBox();
  expect(Math.abs(afterLoss.width - beforeLoss.width)).toBeLessThanOrEqual(1);
  expect(Math.abs(afterLoss.height - beforeLoss.height)).toBeLessThanOrEqual(1);
  expect(runtimeErrors).toEqual([]);

  await page.goto(publicRouteUrl("/projects/build-rhythm/"), { waitUntil: "domcontentloaded" });
  await expect(page.locator("[data-paper-research-field]")).toHaveCount(0);
  expect(
    await page.evaluate(() => performance.getEntriesByType("resource").filter((entry) => entry.name.includes("paper-research-field.js")).length)
  ).toBe(0);

  const reducedContext = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  const reducedPage = await reducedContext.newPage();
  try {
    await reducedPage.emulateMedia({ reducedMotion: "reduce", contrast: "more" });
    await preparePage(reducedPage, "light");
    await reducedPage.goto(publicRouteUrl("/"), { waitUntil: "domcontentloaded" });
    const reducedField = reducedPage.locator("[data-paper-research-field]");
    await reducedField.scrollIntoViewIfNeeded();
    await expect(reducedField).toHaveAttribute("data-paper-shader-state", "still");
    const reducedState = await reducedPage.evaluate(() => window.__siruiPaperResearchField.getState());
    expect(reducedState.contextCount).toBe(1);
    expect(reducedState.currentSpeed).toBe(0);
    expect(reducedState.running).toBe(false);
    expect(await reducedField.evaluate((element) => getComputedStyle(element).opacity)).toBe("0.2");
    await reducedPage.emulateMedia({ forcedColors: "active", reducedMotion: "reduce" });
    expect(await reducedField.evaluate((element) => getComputedStyle(element).display)).toBe("none");
  } finally {
    await reducedContext.close();
  }
});

test("the desk's coffee ring rests on the top slip clear of its words, stays whole, and settles in only for people", async ({ page }, testInfo) => {
  test.skip(!["desktop-1440", "mobile-390"].includes(testInfo.project.name), "one desktop and one phone viewport cover the stain");
  const errors = collectRuntimeErrors(page);
  await preparePage(page, "light");
  const stack = page.locator(".home-artifact-stack.has-coffee-stain");
  const read = () =>
    stack.evaluate(async (node) => {
      const stain = getComputedStyle(node, "::before");
      const wet = getComputedStyle(node, "::after");
      const card = node.querySelector(".home-artifact-card");
      const box = node.getBoundingClientRect();
      const column = node.parentElement.getBoundingClientRect();
      // Inspect the actual generated alpha mask, including deposits and drops, rather
      // than assuming an annulus. Transparent padding is not a clipping boundary.
      const size = parseFloat(stain.width);
      const left = box.right - parseFloat(stain.right) - size,
        top = box.top + parseFloat(stain.top);
      const matrix = new DOMMatrixReadOnly(stain.transform === "none" ? undefined : stain.transform);
      const cx = left + size / 2 + matrix.e,
        cy = top + size / 2 + matrix.f;
      const words = [];
      for (const text of node.querySelectorAll(".home-artifact-copy > *")) {
        const range = document.createRange();
        range.selectNodeContents(text);
        words.push(...range.getClientRects());
      }
      const image = new Image();
      image.src = stain.backgroundImage.slice(5, -2);
      await image.decode();
      const canvas = document.createElement("canvas");
      canvas.width = image.naturalWidth;
      canvas.height = image.naturalHeight;
      const context = canvas.getContext("2d");
      context.drawImage(image, 0, 0);
      const pixels = context.getImageData(0, 0, canvas.width, canvas.height).data;
      let crossed = false,
        minX = Infinity,
        maxX = -Infinity,
        inside = 0,
        clear = 0,
        alphaFingerprint = 2166136261;
      for (let y = 0; y < canvas.height; y++)
        for (let x = 0; x < canvas.width; x++) {
          const alpha = pixels[(y * canvas.width + x) * 4 + 3];
          alphaFingerprint = Math.imul(alphaFingerprint ^ alpha, 16777619);
          if (Math.hypot(x - canvas.width / 2, y - canvas.height / 2) < canvas.width * 0.22) {
            inside++;
            if (alpha < 8) clear++;
          }
          if (alpha < 8) continue;
          const lx = ((x + 0.5) / canvas.width) * size - size / 2,
            ly = ((y + 0.5) / canvas.height) * size - size / 2;
          const px = cx + matrix.a * lx + matrix.c * ly,
            py = cy + matrix.b * lx + matrix.d * ly;
          minX = Math.min(minX, px);
          maxX = Math.max(maxX, px);
          if (words.some((r) => px >= r.left - 1 && px <= r.right + 1 && py >= r.top - 1 && py <= r.bottom + 1)) crossed = true;
        }
      return {
        painted: stain.backgroundImage.startsWith('url("data:image/png'),
        onTop: Number(stain.zIndex) > Number(getComputedStyle(card).zIndex),
        // One dried ring: no wet layer, and no mask sweeping it open.
        wetLayer: wet.content !== "none" && wet.content !== "normal",
        unmasked: !(stain.maskImage || stain.webkitMaskImage || "").includes("gradient"),
        multiplied: stain.mixBlendMode === "multiply",
        clearOfWords: words.length > 0 && !crossed,
        animation: stain.animationName,
        pointerEvents: stain.pointerEvents,
        iterations: stain.animationIterationCount,
        drying: node.getAttribute("data-coffee-stain-drying"),
        seed: node.dataset.coffeeStainSeed,
        insideColumn: minX >= column.left - 1 && maxX <= column.right + 1,
        clearCenter: clear / inside,
        rasterSize: canvas.width,
        alphaFingerprint: alphaFingerprint >>> 0,
        transform: stain.transform,
        source: node.dataset.coffeeStainSource,
      };
    });
  await page.goto(publicRouteUrl("/?coffeeSeed=52"));
  await expect(stack).toHaveAttribute("data-coffee-stain-ready", "true", { timeout: 20000 });
  // Where the mug stood: on the top slip, multiplied into it, never across its words.
  expect(await read()).toMatchObject({
    painted: true,
    onTop: true,
    wetLayer: false,
    unmasked: true,
    multiplied: true,
    clearOfWords: true,
    insideColumn: true,
    seed: "52",
    drying: null,
    animation: "none",
    pointerEvents: "none",
    source: "procedural",
  });
  expect((await read()).clearCenter).toBeGreaterThan(0.98);
  expect((await read()).rasterSize).toBeGreaterThanOrEqual(1024);
  expect((await read()).rasterSize).toBeLessThanOrEqual(1536);
  const placementNames = ["--home-coffee-stain-rotation", "--home-coffee-stain-x", "--home-coffee-stain-y", "--home-coffee-stain-scale"];
  const placement = await stack.evaluate((node, names) => names.map((n) => node.style.getPropertyValue(n)), placementNames);
  for (const rotation of [-24, 0, 24])
    for (const x of [-0.3, 0.45]) {
      await stack.evaluate(
        (node, { rotation, x }) => {
          node.style.setProperty("--home-coffee-stain-rotation", rotation + "deg");
          node.style.setProperty("--home-coffee-stain-x", x + "rem");
          node.style.setProperty("--home-coffee-stain-y", ".2rem");
          node.style.setProperty("--home-coffee-stain-scale", "1.06");
        },
        { rotation, x }
      );
      expect(await read()).toMatchObject({ clearOfWords: true, insideColumn: true });
    }
  await stack.evaluate((node, { names, values }) => names.forEach((name, i) => node.style.setProperty(name, values[i])), {
    names: placementNames,
    values: placement,
  });
  const replay = await stack.evaluate((node) => getComputedStyle(node).getPropertyValue("--home-coffee-stain-image"));
  await page.waitForTimeout(350);
  expect(await stack.evaluate((node) => getComputedStyle(node).getPropertyValue("--home-coffee-stain-image"))).toBe(replay);
  await page.reload();
  await expect(stack).toHaveAttribute("data-coffee-stain-ready", "true", { timeout: 20000 });
  expect(await stack.evaluate((node) => getComputedStyle(node).getPropertyValue("--home-coffee-stain-image"))).toBe(replay);
  for (const seed of ["7", "31", "103"]) {
    await page.goto(publicRouteUrl("/?coffeeSeed=" + seed));
    await expect(stack).toHaveAttribute("data-coffee-stain-ready", "true", { timeout: 20000 });
    expect(await read()).toMatchObject({ clearOfWords: true, insideColumn: true });
    expect((await read()).clearCenter).toBeGreaterThan(0.98);
    expect(await stack.evaluate((node) => getComputedStyle(node).getPropertyValue("--home-coffee-stain-image"))).not.toBe(replay);
  }
  await page.goto(publicRouteUrl("/?coffeeSeed=52"));
  await expect(stack).toHaveAttribute("data-coffee-stain-ready", "true", { timeout: 20000 });
  await attachScreenshot(page, testInfo, `home-coffee-ring-${testInfo.project.name}`, { locator: stack });
  const pigmentRequest = await page.evaluate(
    () => performance.getEntriesByType("resource").find((entry) => entry.name.includes("/coffee-deposit-"))?.name
  );
  expect(pigmentRequest).toBeUndefined();
  // Failed or indefinitely delayed legacy images cannot affect the primary
  // pigment: ordinary visits do not request them at all.
  let legacyRequests = 0;
  await page.route("**/coffee-deposit-*.webp", (route) => {
    legacyRequests++;
    return route.abort();
  });
  await page.goto(publicRouteUrl("/?coffeeSeed=52"));
  await expect(stack).toHaveAttribute("data-coffee-stain-ready", "true", { timeout: 20000 });
  expect(await read()).toMatchObject({ source: "procedural", clearOfWords: true, insideColumn: true });
  expect(legacyRequests).toBe(0);
  await page.unroute("**/coffee-deposit-*.webp");
  // The timer backstop services a starved idle scheduler. A null async encoder
  // also retains the same locally generated pigment via the Canvas PNG path.
  await page.addInitScript(() => {
    if (location.search.includes("coffeeIdleFixture")) {
      window.requestIdleCallback = () => 1;
      window.cancelIdleCallback = () => {};
      HTMLCanvasElement.prototype.toBlob = function (done) {
        done(null);
      };
    }
    if (location.search.includes("coffeeCanvasFixture"))
      HTMLCanvasElement.prototype.toBlob = function () {
        throw new Error("retained Canvas failure fixture");
      };
  });
  await page.goto(publicRouteUrl("/?coffeeSeed=52&coffeeIdleFixture=1"));
  await expect(stack).toHaveAttribute("data-coffee-stain-ready", "true", { timeout: 20000 });
  expect(await read()).toMatchObject({ source: "procedural", clearOfWords: true, insideColumn: true });
  // A failed Canvas encoder can still use the retained complete raster as a
  // last resort; that path is explicit and is not counted as generation.
  await page.goto(publicRouteUrl("/?coffeeSeed=52&coffeeCanvasFixture=1"));
  await expect(stack).toHaveAttribute("data-coffee-stain-source", "raster-fallback", { timeout: 20000 });
  expect(await read()).toMatchObject({ source: "raster-fallback", rasterSize: 512, clearOfWords: true, insideColumn: true });
  // A person sees the mark settle in once the slips are in view...
  await page.goto(publicRouteUrl("/?coffeeSeed=52&cinematic=live"));
  await stack.scrollIntoViewIfNeeded();
  await expect(stack).toHaveAttribute("data-coffee-stain-drying", "true", { timeout: 20000 });
  expect(await read()).toMatchObject({ animation: "home-coffee-stain-settle", iterations: "1", wetLayer: true });
  const footprint = (await read()).transform;
  await page.waitForTimeout(100);
  expect((await read()).transform).toBe(footprint);
  await page.waitForTimeout(3400);
  await expect(stack).toHaveAttribute("data-coffee-stain-settled", "true");
  expect(await read()).toMatchObject({ animation: "none", wetLayer: false });
  // Global pause settles the deposit immediately and resume must not replay it.
  await page.goto(publicRouteUrl("/?coffeeSeed=52&cinematic=live"));
  await stack.scrollIntoViewIfNeeded();
  await expect(stack).toHaveAttribute("data-coffee-stain-drying", "true", { timeout: 20000 });
  await page.evaluate(() => window.siteMotion.setPaused(true));
  await expect(stack).toHaveAttribute("data-coffee-stain-settled", "true");
  expect(await read()).toMatchObject({ animation: "none", wetLayer: false });
  await page.evaluate(() => window.siteMotion.setPaused(false));
  expect(await read()).toMatchObject({ animation: "none", wetLayer: false });
  // ...unless they prefer stillness; a theme change repaints it for the evening desk.
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.goto(publicRouteUrl("/?coffeeSeed=52&cinematic=live"));
  await expect(stack).toHaveAttribute("data-coffee-stain-ready", "true", { timeout: 20000 });
  expect(await read()).toMatchObject({ drying: null, animation: "none" });
  const light = await stack.evaluate((node) => getComputedStyle(node).getPropertyValue("--home-coffee-stain-image"));
  const lightAlpha = (await read()).alphaFingerprint;
  // theme.js declares setThemeSetting as a top-level binding, not a window property.
  await page.evaluate(() => setThemeSetting("evening"));
  await expect.poll(() => stack.evaluate((node) => getComputedStyle(node).getPropertyValue("--home-coffee-stain-image"))).not.toBe(light);
  expect((await read()).alphaFingerprint).toBe(lightAlpha);
  expect(errors).toEqual([]);
});

test("desk mode switch keeps two reachable controls and no origin speck", async ({ page }, testInfo) => {
  await preparePage(page, "light");
  await page.goto(publicRouteUrl("/"), { waitUntil: "domcontentloaded" });

  // The at-rest origin glint beside 2D/3D was retired on 2026-10-12 (it read as a stray speck).
  const switcher = page.locator("[data-home-desk-mode-switch]");
  await expect(switcher).toBeVisible();
  await expect(switcher.locator(".widget-origin-link, [data-origin-cue]")).toHaveCount(0);

  const geometry = await page.evaluate(() => {
    const modeSwitcher = document.querySelector("[data-home-desk-mode-switch]");
    const controls = Array.from(modeSwitcher?.querySelectorAll("[data-home-desk-mode]") ?? []);
    const rects = controls.map((control) => control.getBoundingClientRect());
    const centers = rects.map((rect) => rect.top + rect.height / 2);
    return {
      documentOverflow: document.documentElement.scrollWidth - document.documentElement.clientWidth,
      modeTargets: rects.map((rect) => ({ height: rect.height, width: rect.width })),
      sameRow: centers.length === 2 && Math.max(...centers) - Math.min(...centers) <= 2,
    };
  });

  expect(geometry.documentOverflow).toBeLessThanOrEqual(0);
  expect(geometry.modeTargets).toHaveLength(2);
  // WCAG 2.2 target size (minimum): 24 x 24 CSS px.
  for (const target of geometry.modeTargets) {
    expect(target.width).toBeGreaterThanOrEqual(24 - 0.01);
    expect(target.height).toBeGreaterThanOrEqual(24 - 0.01);
  }
  expect(geometry.sameRow).toBe(true);

  const threeD = switcher.locator('[data-home-desk-mode="3d"]');
  await threeD.focus();
  await expect(threeD).toBeFocused();

  await attachScreenshot(page, testInfo, `desk-mode-switch-${testInfo.project.name}`, { fullPage: false });
});

// Keep this last: unlocking starts the secret route's Three/WebGL work.
test("secret checkpoint tells the truth, contains focus, and survives a refresh", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "desktop-1440", "representative hidden-route journey checkpoint");

  await page.addInitScript(() => {
    window.__siruiGeolocationRequests = 0;
    Object.defineProperty(navigator, "permissions", {
      configurable: true,
      value: {
        query: async ({ name }) => (name === "geolocation" ? { state: "prompt" } : { state: "denied" }),
      },
    });
    Object.defineProperty(navigator, "geolocation", {
      configurable: true,
      value: {
        getCurrentPosition: (_success, error) => {
          window.__siruiGeolocationRequests += 1;
          error?.({ code: 1, message: "test prompt" });
        },
      },
    });
  });

  await preparePage(page, "light");
  await page.goto(publicRouteUrl("/blog/"), { waitUntil: "domcontentloaded" });

  const trigger = page.locator("#sirui-secret-dog");
  const dialog = page.locator("#sirui-secret-dialog");
  const close = page.locator("#sirui-secret-close");
  const mango = page.locator('[data-sirui-fruit="mango"]');
  const banana = page.locator('[data-sirui-fruit="banana"]');
  const origin = page.locator("[data-sirui-secret-origin]");

  await expect(origin).toBeHidden();

  await trigger.click();
  await expect(dialog).toBeVisible();
  await expect(page.locator("body")).toHaveClass(/sirui-secret-dialog-open/);
  await expect(mango).toBeFocused();
  await page.keyboard.press("Shift+Tab");
  await expect(close).toBeFocused();
  await page.keyboard.press("Shift+Tab");
  await expect(banana).toBeFocused();
  await page.keyboard.press("Tab");
  await expect(close).toBeFocused();
  await page.keyboard.press("Escape");
  await expect(dialog).toBeHidden();
  await expect(trigger).toBeFocused();
  await expect(trigger).toHaveAttribute("aria-expanded", "false");
  await expect(page.locator("body")).not.toHaveClass(/sirui-secret-dialog-open/);

  await trigger.click();
  // Dispatch synchronously so Playwright does not absorb the deliberately delayed
  // route transition into click auto-waiting on a loaded CI runner.
  await mango.evaluate((button) => button.click());
  const status = page.locator("#sirui-secret-status");
  await expect(status).toContainText("mango is on Sirui's list.");
  expect(await status.textContent()).not.toMatch(/guess|correct/i);
  await expect(origin).toBeVisible();
  await expect(origin.getByRole("link", { name: "Read how this portal began" })).toHaveAttribute("href", /\/projects\/dogtor-portal\/$/);
  await page.keyboard.press("Escape");
  await page.waitForTimeout(800);
  await expect(page).toHaveURL(/\/blog\/?$/);
  await expect(origin).toBeVisible();

  await trigger.click();
  await mango.click();
  await page.waitForURL(/sirui-research-thoughts\/?$/);
  await expect(page.locator("#sirui-crack-map")).toBeVisible({ timeout: 20_000 });
  await expect(page.locator("#sirui-sharpen-location")).toHaveText("use precise location");
  await expect(page.locator("#sirui-sharpen-location")).toBeVisible();
  await page.waitForTimeout(650);
  expect(await page.evaluate(() => window.__siruiGeolocationRequests)).toBe(0);
  await page.locator("#sirui-sharpen-location").click();
  await expect.poll(() => page.evaluate(() => window.__siruiGeolocationRequests)).toBe(1);
  const storedPass = await page.evaluate(() => JSON.parse(sessionStorage.getItem("siruiSecretFruitPass")));
  expect(storedPass.fruit).toBe("mango");
  expect(storedPass.unlockedAt).toBeGreaterThan(0);

  await page.reload({ waitUntil: "domcontentloaded" });
  await expect(page.locator("#sirui-crack-map")).toBeVisible({ timeout: 20_000 });
  expect(await page.evaluate(() => sessionStorage.getItem("siruiSecretFruitPass"))).not.toBeNull();
});
