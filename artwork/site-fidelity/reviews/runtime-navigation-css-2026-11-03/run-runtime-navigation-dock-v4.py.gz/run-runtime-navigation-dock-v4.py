from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess,time
root=Path.cwd();q=Path(__file__).parent;out=q/'runtime-navigation-dock-v4';assert not out.exists();out.mkdir();server=json.loads((q/'runtime-navigation-checkpoint-v2/server.json').read_text())
env=dict(os.environ,NO_WEBSERVER='1',VISUAL_BASE_URL=server['url'].rstrip('/'),VISUAL_ROUTE_IDS='cv,project-designweaver',VISUAL_THEMES='light,dark')
args=['C:/Program Files/nodejs/npx.cmd','playwright','test','--config',str(q/'runtime-navigation-dock-v4.config.cjs')];start=time.monotonic()
with(out/'visual.log').open('wb')as log:r=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
record={'at':datetime.now(timezone.utc).isoformat(),'command':args,'baseURL':env['VISUAL_BASE_URL'],'server':server,'exitCode':r.returncode,'seconds':time.monotonic()-start,'priorAttempt':'v3 navigation assertion requested the dock over the hero at a fixed750px. The product intentionally keeps it quiet there. This run crosses the actual second body heading to supply normal navigation intent. The original four assertion failures and the16other passing cases are retained.'}
(out/'PROCESS.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');print(json.dumps(record));assert r.returncode==0
