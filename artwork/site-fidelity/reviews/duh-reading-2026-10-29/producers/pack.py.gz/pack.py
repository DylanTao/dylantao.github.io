import gzip
import hashlib
import json
import subprocess
from pathlib import Path

root=Path.cwd();q=Path(__file__).parent
folder=root/'artwork/site-fidelity/reviews/duh-reading-2026-10-29'
folder.mkdir(parents=True,exist_ok=True)
def put(relative,data):
    p=folder/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
def copy(source,target,packed=True):
    data=source.read_bytes();put(target,gzip.compress(data,mtime=0)if packed else data)

for run in ['native-full','native-widths','webkit','negative']:
    for source in sorted((q/run).rglob('live-reading-*.json')):
        width=source.parent.name.rsplit('-',1)[-1];theme=source.stem.rsplit('-',1)[-1]
        prefix='webkit'if run=='webkit'else'chromium'
        if run=='negative':
            copy(source,'negative/live.json.gz')
        else:
            copy(source,f'data/{prefix}-{width}-{theme}.json.gz')
            copy(source.with_suffix('.png'),f'views/{prefix}-{width}-{theme}.png',False)

reported=Path('C:/dev/dylantao.github.io/.jekyll-cache/visual-qa/ui-integrated-20261029/reading-linux/cases/navigation-motion-article--b7be2-pass-the-fixed-header-dark--mobile-390/test-failed-1.png')
copy(reported,'views/reported-reading-failure.png',False)
for name in ['duh-card-drop-settled.png','duh-3d-drop-settled.png']:
    matches=list((q/'webkit-pointer').rglob(name));assert len(matches)==1
    copy(matches[0],'views/webkit-'+name,False)

for name in ['native-full','native-widths','native-iteration','native-intent','webkit','webkit-pointer','native-harness','negative']:
    copy(q/(name+'.json'),('negative/results.json.gz'if name=='negative'else'runs/'+name+'.json.gz'))
    copy(q/(name+'.log'),'runs/'+name+'.log.gz')
for name in ['summary.json','baseline-trace.json','candidate-trace.json','playground-trace.json','gsap-attribution.json','sdk-touch.json','readback.json','compile.json']:
    copy(q/name,'data/'+name+'.gz')
copy(q/'build.log','build/jekyll.log.gz')
for name in ['rejected-all-relocations.mjs.gz','rejected-all-relocations-compiled.mjs.gz']:
    copy(q/name,'attempts/'+name,False)
failed=list((q/'native-iteration').glob('*scrolling*/*failed-1.png'));assert len(failed)==1
copy(failed[0],'attempts/placement-jump.png',False)
for width in [390,768]:
    for theme in ['light','dark']:
        copy(q/f'baseline-{width}-{theme}.png',f'attempts/baseline-settled-{width}-{theme}.png',False)
        copy(q/f'candidate-{width}-{theme}.png',f'attempts/first-candidate-{width}-{theme}.png',False)
for name in ['probe-reading.cjs','probe-playground.cjs','capture-gsap.cjs','compile-duh.rb','prepare-negative.cjs','negative.spec.js','negative.config.cjs','webkit.config.cjs','webkit-pointer.config.cjs','readback.py','summarize.py']:
    copy(q/name,'producers/'+name+'.gz')
copy(Path(__file__),'producers/pack.py.gz')
before=q.parent/'identity-footer-20261029/depth-production/al-folio/assets/js/companion/duh-page.mjs'
copy(before,'source/before-compiled.mjs.gz')
copy(q/'production/al-folio/assets/js/companion/duh-page.mjs','source/after-compiled.mjs.gz')
before_raw=subprocess.check_output(['git','show','5d54676d8f287c6eaeba1f802f975adf9a823b16:assets/js/companion/duh-page.mjs'])
put('source/before.mjs.gz',gzip.compress(before_raw,mtime=0))
for relative in ['assets/js/companion/duh-page.mjs','test/visual/duh.spec.js','docs/duh-companion.md']:
    put('source/'+Path(relative).name+'.gz',gzip.compress((root/relative).read_bytes().replace(b'\r\n',b'\n'),mtime=0))

paths=[p.relative_to(root).as_posix()for p in sorted((root/'assets/js/companion').glob('*.mjs'))]
paths+=['test/visual/duh.spec.js','docs/duh-companion.md','assets/js/cinematic.js','_plugins/site_module_assets.rb','Gemfile.lock','package-lock.json']
manifest={'schema':'sirui-duh-reading-review-v1','productCommit':'bd2942a7171a7b937d6647b3499feb845f142221','harnessCommit':'435ccef03b0cd166442cf3e8c5dc87349e6cc78b','sourceBindings':[],'payloads':[]}
for relative in paths:
    data=(root/relative).read_bytes().replace(b'\r\n',b'\n')
    manifest['sourceBindings'].append({'path':relative,'mode':'text-lf','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
for p in sorted(folder.rglob('*')):
    if not p.is_file()or p.name=='manifest.json':continue
    text=p.name in ['README.md','verify.py'];data=p.read_bytes().replace(b'\r\n',b'\n')if text else p.read_bytes()
    manifest['payloads'].append({'path':p.relative_to(folder).as_posix(),'mode':'text-lf'if text else'binary','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
put('manifest.json',(json.dumps(manifest,indent=2)+'\n').encode())
print('Packed',len(manifest['payloads']),'payloads,',len(manifest['sourceBindings']),'source bindings')
