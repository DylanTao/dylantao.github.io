const fs=require('node:fs'),path=require('node:path');
const {chromium}=require('playwright');
const {preparePage,collectRuntimeErrors}=require('../../../test/visual/helpers.js');
const q=__dirname,base='http://127.0.0.1:4151/al-folio',variant=process.env.DUH_PROBE_VARIANT||'baseline';
async function install(){
  window.__readingAnimations=[];
  const animate=Element.prototype.animate;
  Element.prototype.animate=function(keys,options){
    if(this.closest('#main'))window.__readingAnimations.push({at:performance.now(),node:this.tagName,text:this.textContent?.slice(0,80),keys,options,stack:new Error().stack});
    return animate.call(this,keys,options);
  };
}
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--use-angle=d3d11','--ignore-gpu-blocklist']});const report=[];
 try {for(const width of[390,768])for(const theme of['light','dark']){
  const context=await browser.newContext({viewport:{width,height:1000},deviceScaleFactor:1,reducedMotion:'no-preference',timezoneId:'America/Los_Angeles'});
  const page=await context.newPage();await preparePage(page,theme);await page.addInitScript(install);const errors=collectRuntimeErrors(page);
  await page.goto(base+'/blog/2026/research-skills-starter-pack/?cinematic=live',{waitUntil:'domcontentloaded'});
  await page.evaluate(()=>document.fonts.ready);await page.waitForFunction(()=>document.querySelector('.duh-companion')?.getDuhEvidence);
  const before=await page.evaluate(()=>document.querySelector('.duh-companion').getDuhEvidence());
  const trace=await page.evaluate(async()=>{
   const paragraph=document.querySelector('#markdown-content p'),header=document.querySelector('#navbar'),duh=document.querySelector('.duh-companion'),trace=[];
   function sample(label){
    const r=paragraph.getBoundingClientRect(),style=getComputedStyle(paragraph),e=duh.getDuhEvidence(),canvas=duh.querySelector('canvas'),c=canvas.getBoundingClientRect();
    const overlap=[];
    for(const p of document.querySelectorAll('#markdown-content p,#markdown-content h1,#markdown-content h2,#markdown-content li')){
      const range=document.createRange();range.selectNodeContents(p);
      for(const ink of range.getClientRects())if(c.left+c.width/2+29>ink.left&&c.left+c.width/2-29<ink.right&&c.top+c.height/2+29>ink.top&&c.top+c.height/2-29<ink.bottom)overlap.push({text:p.textContent.slice(0,50),rect:[ink.left,ink.top,ink.width,ink.height]});
    }
    trace.push({label,at:performance.now(),scrollY,paragraph:{x:r.x,y:r.y,width:r.width,height:r.height,documentY:r.y+scrollY,transform:style.transform,translate:style.translate,animations:paragraph.getAnimations().map(a=>({currentTime:a.currentTime,playState:a.playState,frames:a.effect?.getKeyframes()}))},duh:e,canvas:[c.x,c.y,c.width,c.height],opacity:getComputedStyle(duh).opacity,overlap});
   }
   sample('before-scroll');for(let i=0;i<2;i++){
    window.scrollTo({top:scrollY+paragraph.getBoundingClientRect().top-header.getBoundingClientRect().bottom+10,behavior:'instant'});
    await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));sample('scroll-'+i);
   }
   for(let i=0;i<35;i++){await new Promise(r=>setTimeout(r,60));sample('after-'+i);}
   return{trace,animations:window.__readingAnimations};
  });
  await page.screenshot({path:path.join(q,`${variant}-${width}-${theme}.png`)});
  report.push({width,theme,before,...trace,errors});await context.close();
 }fs.writeFileSync(path.join(q,`${variant}-trace.json`),JSON.stringify(report,null,2));console.log(report.map(r=>({width:r.width,theme:r.theme,overlapFrames:r.trace.filter(f=>f.overlap.length&&f.duh.visible&&Number(f.opacity)>.01).length,contacts:[r.before.pageContacts,...r.trace.map(f=>f.duh.pageContacts)],paragraphAnimations:r.animations.length,errors:r.errors})));}
 finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
