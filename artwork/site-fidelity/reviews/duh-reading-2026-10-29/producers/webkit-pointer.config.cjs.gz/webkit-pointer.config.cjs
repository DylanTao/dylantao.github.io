const path=require('node:path');
const base=require('./webkit.config.cjs');
module.exports={...base,outputDir:path.join(__dirname,'webkit-pointer'),reporter:[['line'],['json',{outputFile:path.join(__dirname,'webkit-pointer.json')}]]};
