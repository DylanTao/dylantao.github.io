import json
from pathlib import Path

q=Path(__file__).parent
result={'schema':'sirui-duh-reading-results-v1','runtimeCommit':'bd2942a7171a7b937d6647b3499feb845f142221','harnessCommit':'435ccef03b0cd166442cf3e8c5dc87349e6cc78b','runs':{},'liveInk':[]}
for name in ['native-full','native-widths','native-iteration','native-intent','webkit','webkit-pointer','native-harness','negative']:
    doc=json.loads((q/(name+'.json')).read_bytes())
    result['runs'][name]=doc['stats']
for name in ['native-full','native-widths','webkit','negative']:
    for path in sorted((q/name).rglob('live-reading-*.json')):
        doc=json.loads(path.read_bytes());frames=doc['frames']
        result['liveInk'].append({'run':name,'viewport':path.parent.name.rsplit('-',1)[-1],'theme':path.stem.rsplit('-',1)[-1],
            'frames':len(frames),'minPainted':min(f['painted']for f in frames),'minOpacity':min(f['opacity']for f in frames),
            'occludedFrames':sum(f['occluded']>0 for f in frames),'maxOccludedPixels':max(f['occluded']for f in frames),
            'visibleFrames':sum(f['visible']for f in frames),'forms':sorted(set(f['form']for f in frames)),
            'outings':sorted(set(f['outing']for f in frames if f['outing'])),
            'maxContacts':max(f['contacts']for f in frames),'maxRepairs':max(f['repairs']for f in frames),'domAnimations':len(doc['animations'])})
(q/'summary.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps({'runs':result['runs'],'liveInk':result['liveInk']},indent=2))
