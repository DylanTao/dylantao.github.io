const fs=require('node:fs'),path=require('node:path'),{chromium}=require('playwright');
const{preparePage}=require('../../../test/visual/helpers.js');
(async()=>{const b=await chromium.launch({args:['--use-angle=d3d11','--ignore-gpu-blocklist']});try{
const c=await b.newContext({viewport:{width:390,height:1000},hasTouch:true,isMobile:true,deviceScaleFactor:1});const p=await c.newPage();
await p.clock.install({time:new Date('2026-10-09T08:00:00Z')});await preparePage(p,'light');
await p.addInitScript(()=>{window.scrollDuh=[];addEventListener('scroll',()=>{const h=document.querySelector('.duh-companion');if(!h?.getDuhEvidence)return;const e=h.getDuhEvidence(),hits=[];for(const n of document.querySelectorAll('#main p,#main h1,#main h2,#main h3,#main li')){const range=document.createRange();range.selectNodeContents(n);for(const r of range.getClientRects())if(e.x+29>r.left&&e.x-29<r.right&&e.y+29>r.top&&e.y-29<r.bottom)hits.push({text:n.textContent.slice(0,80),rect:[r.x,r.y,r.width,r.height]});}window.scrollDuh.push({eventAt:performance.now(),e,hits,scrollY});},{passive:true});});
await p.goto('http://127.0.0.1:4151/al-folio/projects/p/',{waitUntil:'load'});await p.waitForFunction(()=>document.querySelector('.duh-companion')?.getDuhEvidence);
await p.locator('[data-duh-playground]').evaluate(e=>e.scrollIntoView({block:'center',behavior:'instant'}));await p.clock.pauseAt((await p.evaluate(()=>Date.now()))+10000);await p.clock.runFor(600);
await p.getByRole('button',{name:'Invite duh here',exact:true}).click();await p.clock.runFor(100);
const before=await p.locator('.duh-companion').evaluate(e=>e.getDuhEvidence());const steps=[];
for(let i=0;i<6;i++){await p.evaluate(()=>scrollBy({top:35,behavior:'instant'}));await p.clock.runFor(40);steps.push(await p.locator('.duh-companion').evaluate(e=>e.getDuhEvidence()));}
const logs=await p.evaluate(()=>window.scrollDuh);fs.writeFileSync(path.join(__dirname,'playground-trace.json'),JSON.stringify({before,steps,logs},null,2));console.log(JSON.stringify({before:{x:before.x,y:before.y,state:before.state,blockers:before.blockers},steps:steps.map(e=>({x:e.x,y:e.y,state:e.state,blockers:e.blockers})),lastLogs:logs.slice(-6).map(e=>({x:e.e.x,y:e.e.y,hits:e.hits}))},null,2));await c.close();}finally{await b.close()}})().catch(e=>{console.error(e);process.exitCode=1});
