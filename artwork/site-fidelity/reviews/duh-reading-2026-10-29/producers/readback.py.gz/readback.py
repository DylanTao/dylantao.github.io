import hashlib
import json
from pathlib import Path
from urllib.request import urlopen

root=Path.cwd()
q=Path(__file__).parent
production=q/'production/al-folio'
preview=q.parent/'identity-footer-20261029/site/al-folio'
module='assets/js/companion/duh-page.mjs'
receipt=json.loads((production/'assets/js/module-build.json').read_bytes())
entry=receipt['modules'][module]
digest=lambda b: hashlib.sha256(b).hexdigest()
source=(root/module).read_bytes().replace(b'\r\n',b'\n')
actual=(production/module).read_bytes()
served=urlopen('http://127.0.0.1:4151/al-folio/'+module).read()
assert digest(source)==entry['sourceSha256']
assert digest(actual)==entry['outputSha256']
assert actual==(preview/module).read_bytes()==served
unchanged=[]
for path in sorted((root/'assets/js/companion').glob('*.mjs')):
    relative=path.relative_to(root).as_posix()
    if relative==module:
        continue
    before=q.parent/'identity-footer-20261029/depth-production/al-folio'/relative
    assert (production/relative).read_bytes()==before.read_bytes()==(preview/relative).read_bytes()
    unchanged.append(relative)
record={'schema':'sirui-duh-reading-build-v1','pipeline':receipt['pipeline'],'changedModule':{'path':module,**entry,'servedExact':True},'unchangedCompanionModules':unchanged,'completeBuildFiles':sum(1 for p in production.rglob('*')if p.is_file())}
(q/'readback.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())

sdk=[]
for label,package in [
    ('pinned',Path('C:/dev/dylantao.github.io/node_modules/playwright-core')),
    ('modern',Path('C:/dev/dylantao.github.io/.jekyll-cache/visual-qa/takeover-archives/walk-audit-20261028-cache/visual-qa/walk-audit-20261028/pw165/node_modules/playwright-core')),
]:
    data=(package/'types/types.d.ts').read_bytes()
    text=data.decode()
    start=text.index('export interface Touchscreen {')
    snippet=text[start:text.index('\n}',start)+2]
    assert 'tap(x: number, y: number): Promise<void>' in snippet
    assert 'move(' not in snippet and 'down(' not in snippet and 'up(' not in snippet
    sdk.append({'label':label,'version':json.loads((package/'package.json').read_bytes())['version'],'typesSha256':digest(data),'touchscreenInterfaceSha256':digest(snippet.encode()),'touchscreenMethods':['tap']})
(q/'sdk-touch.json').write_bytes((json.dumps({'localPackages':sdk,'officialReferences':['https://playwright.dev/docs/api/class-touchscreen','https://playwright.dev/docs/api/class-browsercontext#browser-context-new-cdp-session'],'scope':'Public Touchscreen API is tap-only; Chromium CDP is the true drag-stream qualification. WebKit uses actual mouse-pointer drop, never physical-iPhone acceptance.'},indent=2)+'\n').encode())
print('PASS exact source/production/preview/HTTP module;',len(unchanged),'other companion modules unchanged; both pinned/modern touch APIs inspected')
