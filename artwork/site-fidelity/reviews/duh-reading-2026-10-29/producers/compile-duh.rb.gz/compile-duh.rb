require "jekyll"
require "json"
require "digest"
require_relative "../../../_plugins/site_module_assets"
q = File.expand_path(__dir__)
dest = File.expand_path("../identity-footer-20261029/site/al-folio", q)
name = "assets/js/companion/duh-page.mjs"
source = File.read(name, encoding: "UTF-8")
compiled = SiruiSite::ModuleAssets.compile(source)
File.binwrite(File.join(dest, name), compiled)
record = { sourceSha256: Digest::SHA256.hexdigest(source.gsub("\r\n", "\n")), outputSha256: Digest::SHA256.hexdigest(compiled), bytes: compiled.bytesize }
receipt_path = File.join(dest, "assets/js/module-build.json")
receipt = JSON.parse(File.read(receipt_path))
receipt["modules"][name] = record
File.binwrite(receipt_path, JSON.generate(receipt))
File.binwrite(File.join(q, "compile.json"), JSON.pretty_generate(record))
puts JSON.generate(record)
