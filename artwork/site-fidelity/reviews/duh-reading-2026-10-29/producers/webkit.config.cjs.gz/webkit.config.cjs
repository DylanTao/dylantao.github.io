const path=require('node:path');
const base=require('../../../test/visual/public.config.js');
module.exports={...base,testDir:path.resolve(__dirname,'../../../test/visual'),testMatch:['duh.spec.js'],workers:1,timeout:180000,webServer:undefined,
 outputDir:path.join(__dirname,'webkit'),reporter:[['line'],['json',{outputFile:path.join(__dirname,'webkit.json')}]],
 use:{...base.use,browserName:'webkit',launchOptions:{},trace:'off'},
 projects:[{name:'mobile-390',use:{browserName:'webkit',hasTouch:true,isMobile:true,deviceScaleFactor:1,viewport:{width:390,height:1000}}}]};
