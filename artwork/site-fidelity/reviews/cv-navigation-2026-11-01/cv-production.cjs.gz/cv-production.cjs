const { chromium, expect } = require('@playwright/test');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { preparePage, collectRuntimeErrors } = require('../../../test/visual/helpers.js');
(async () => {
  const browser = await chromium.launch();
  const rows = [];
  try {
    for (const width of [1440, 2560, 390]) for (const theme of ['afternoon', 'evening']) {
      const page = await browser.newPage({ viewport: { width, height: width === 2560 ? 1440 : 1000 }, deviceScaleFactor: 1 });
      const errors = collectRuntimeErrors(page);
      await preparePage(page, theme);
      const response = await page.goto('http://127.0.0.1:4207/al-folio/cv/', { waitUntil: 'domcontentloaded' });
      expect(response.headers()['x-sirui-preview']).toBe('cv-roles-20261101-4207');
      await page.evaluate(() => document.fonts.ready);
      await page.waitForTimeout(350);
      await expect(page.locator('.toc-layout-cv')).toHaveCount(1);
      const state = await page.evaluate(() => {
        const rect = selector => { const element = document.querySelector(selector), r = element.getBoundingClientRect(), c = getComputedStyle(element); return { x: r.x, y: r.y, width: r.width, height: r.height, background: c.backgroundColor, border: c.borderWidth, shadow: c.boxShadow, display: c.display }; };
        return { rail: rect('#toc-sidebar'), main: rect('.toc-main-column'), link: rect('#toc-sidebar .toc-link'), overflow: document.documentElement.scrollWidth > innerWidth + 1 };
      });
      expect(state.overflow).toBe(false);
      if (width >= 992) { expect(state.rail.background).toBe('rgba(0, 0, 0, 0)'); expect(state.rail.shadow).toBe('none'); expect(state.link.height).toBeGreaterThan(30); }
      const file = `cv-production-${width}-${theme}.png`;
      await page.screenshot({ path: path.join(__dirname, file) });
      if (width >= 992) {
        const education = page.locator('#toc-sidebar a[href="#education"]');
        await education.focus(); await expect(education).toBeFocused(); await page.keyboard.press('Enter');
        await expect(education).toHaveClass(/is-active-link/);
      } else {
        await page.locator('.cv-mobile-sections summary').click();
        await page.locator('.cv-mobile-sections a[href="#education"]').click();
      }
      expect(errors).toEqual([]);
      rows.push({ width, theme, htmlSha256: crypto.createHash('sha256').update(await response.body()).digest('hex'), state, file, errors });
      await page.close();
    }
    fs.writeFileSync(path.join(__dirname, 'cv-production.json'), JSON.stringify({ scope: 'Exact production-built route on owned4207. No CSS overlay or DOM shape substitution. Existing theme transition allowed to finish.', rows }, null, 2));
    console.log(JSON.stringify({ states: rows.length, errors: rows.flatMap(r => r.errors) }));
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
