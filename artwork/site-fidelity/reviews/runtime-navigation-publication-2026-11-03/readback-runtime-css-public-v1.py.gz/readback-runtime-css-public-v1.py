from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,urllib.request
root=Path.cwd();q=Path(__file__).parent;out=q/'runtime-css-live-v1';assert not out.exists();out.mkdir()
head='db85127b4398b2b6f9a11140c0be2094609b9ec9';pages='43a7cf5576f994b28f1eb0a8e2d3ad129fea8d9b'
run=lambda args:subprocess.check_output(args,cwd=root);sha=lambda b:hashlib.sha256(b).hexdigest();subject=run(['git','log','-1','--format=%s',pages]).decode().strip();assert head in subject
rows=[]
for rel in ['index.html','blog/index.html','cv/index.html','projects/designweaver/index.html','assets/css/main.css','assets/js/brand-orange.js','assets/js/module-build.json','assets/img/favicon.svg','assets/models/home/manifest.json','assets/models/home/static-light-field.json','assets/models/home/room-kitchen.glb','assets/js/home-scene/controller.mjs','assets/js/home-scene/diffuse-paths.mjs','assets/js/home-scene/interior-exposure.mjs']:
    expected=run(['git','show',pages+':'+rel]);url='https://dylantao.github.io/'+(''if rel=='index.html'else rel)+'?delivery='+head
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Sirui-site-deployment-verification'}),timeout=45)as response:body=response.read();status=response.status
    row={'path':rel,'url':url,'status':status,'bytes':len(body),'sha256':sha(body),'expectedSha256':sha(expected),'exact':body==expected};rows.append(row)
    (out/'PROGRESS.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8');assert status==200 and row['exact'],row
    if rel=='assets/js/module-build.json':
        modules=json.loads(body)['modules'];assert len(modules)==192
        for name,record in modules.items():
            assert sha(run(['git','show',head+':'+name]).replace(b'\r\n',b'\n'))==record['sourceSha256'],name
            assert sha(run(['git','show',pages+':'+name]))==record['outputSha256'],name
    if rel=='assets/css/main.css':assert row['sha256']=='f81623d3af019fba253ca5ace091fb4d806251f2098a0b987c9906376f88a1d0'
    if rel=='assets/models/home/static-light-field.json':assert row['sha256']=='05515f737a516531216c96a4bd2f84e02a116ea668342c9a9f6f05aa79b2303e'
record={'at':datetime.now(timezone.utc).isoformat(),'sourceHead':head,'pagesHead':pages,'pagesSubject':subject,'compiledSourceAndOutputBindings':len(modules),'responses':rows,'scope':'Exact current published runtime navigation CSS readback against pinned main/Pages commits, independently of separate private native/cliff/coffee work. CI and actual UI acceptance are separate receipts.'}
(out/'DELIVERY.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');print(json.dumps({'responses':len(rows),'compiledModules':len(modules),'pages':pages,'source':head}))
