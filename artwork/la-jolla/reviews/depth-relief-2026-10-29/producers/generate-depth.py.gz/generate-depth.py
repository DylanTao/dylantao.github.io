from pathlib import Path
import importlib.util,json,numpy as np,math,time,hashlib
from PIL import Image
q=Path('.jekyll-cache/visual-qa/identity-footer-20261029/relief')
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
m=load('skyline','bin/coastal_skyline.py');t=load('terrain','bin/coastal_terrain.py');g=m.Ground(m.load_ground());anchors=json.loads((q/'bearing-anchors.json').read_text());old=np.array(Image.open(m.RELIEF));N=80;START=153;image=np.zeros((235,929,3),dtype=np.uint8);image[:147]=old;image[147]=old[-1];xnative=[];ynative=[];hnative=[]
for i in range(t.TERRAIN_GRID[0]+1):
 x,_,back=t._terrain_column(i);xnative.append(x);ynative.append(back);hnative.append(t.ground_height(x,back)+.014*math.sin(x*4+17))
base=json.loads(Path('assets/models/la-jolla/manifest.json').read_text());pos=base['camera']['position'];tar=base['camera']['target'];dy=pos[1]-tar[1];dz=pos[2]-tar[2];L=math.hypot(dy,dz);uy=dz/L;uz=-dy/L;proof=[];started=time.time()
def u16(v):return (v>>8,v&255)
def h8(v):return 0 if v<=0 else max(1,int(round(min(280.,v)/280*255)))
def normal(b,d):
 lat,lon=g.point(b,d);sx=20/(111320*g.cos);sy=20/110574;n=np.array([-(g.at(lat,lon+sx)-g.at(lat,lon-sx))/40,-(g.at(lat+sy,lon)-g.at(lat-sy,lon))/40,1]);n/=np.linalg.norm(n);return [round((n[0]*.5+.5)*255),round((n[1]*.5+.5)*255)]
for i,a in enumerate(anchors):
 b=a['b'];samples=m.ray(g,b,step=8.);land=[s for s in samples if s[1]>0];
 if not land:continue
 shore=land[0];crest=max(land,key=lambda s:s[2]);ds,hs,_=shore;dc,hc,_=crest
 hbase=float(np.interp(a['x'],xnative,hnative));zbase=-float(np.interp(a['x'],xnative,ynative));hsq=h8(hs)*280/255;hcq=h8(hc)*280/255;oldy=-3.4+a['far']*.5;margin=uy*oldy+uz*(-24)-(uy*hbase+uz*zbase);denom=uy*(hcq-hsq)-uz*(dc-ds);scale=margin/denom if denom>0 and margin>0 and a['b']<214.5 else 0
 image[148,i]=(*u16(round(ds)),h8(hs));image[149,i]=(*u16(round(dc)),h8(hc));cot=round(dz/dy*4096);image[150,i]=(*u16(round(hbase*1000)),cot>>8);image[151,i]=(*u16(round(-zbase*1000)),cot&255)
 for j in range(N+1):
  d=ds+(dc-ds)*j/N;h=g.at(*g.point(b,d));image[START+j,i]=(*normal(b,d),h8(h))
 image[152,i]=image[START,i];image[234,i]=image[START+N,i]
 proof.append({'bearing':b,'stageX':a['x'],'shore':[ds,hs],'crest':[dc,hc],'measuredFarAngle':a['far'],'nativeBack':[hbase,zbase],'projectedMargin':margin,'metresToStage':scale,'valid':scale>0})
assert np.array_equal(image[:147],old)
Image.fromarray(image,'RGB').save(q/'depth-atlas.png',optimize=True);r={'sourceRawSha256':hashlib.sha256((m.CACHE/'3dep.tif').read_bytes()).hexdigest(),'baselineAngularRowsExact':True,'layout':{'width':929,'rows':235,'angularRows':[0,146],'angularGutter':147,'metadataRows':[148,151],'radialGutterBefore':152,'radialRows':[153,233],'radialGutterAfter':234,'heightRangeM':280,'radialIntervals':80},'encodedChannels':{'angular':['normalEast','normalNorth','distance8km'],'radial':['normalEast','normalNorth','height280m']},'bytes':(q/'depth-atlas.png').stat().st_size,'sha256':hashlib.sha256((q/'depth-atlas.png').read_bytes()).hexdigest(),'seconds':time.time()-started,'validColumns':sum(x['valid'] for x in proof),'columns':proof};(q/'depth-generation.json').write_text(json.dumps(r,indent=2)+'\n');print({k:v for k,v in r.items() if k!='columns'})
