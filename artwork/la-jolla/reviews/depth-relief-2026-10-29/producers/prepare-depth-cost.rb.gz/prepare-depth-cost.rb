require "jekyll"
require "digest"
require "json"
require_relative "../../../_plugins/site_module_assets"
q = File.expand_path(__dir__)
source = File.read("assets/js/footer-coast/scene.mjs", encoding: "UTF-8")
needle = "    if (disposed || lost || warming) return;\n    camera.position.copy(cameraBase);"
raise "draw entry mismatch" unless source.scan(needle).size == 1
source = source.sub(needle, "    if (disposed || lost || warming) return;\n    window.__coastDrawProbe?.begin(renderer, host);\n    try {\n    camera.position.copy(cameraBase);")
needle = "    host.dataset.frames = String(++frameCount);\n  }\n\n  function progress()"
raise "draw exit mismatch" unless source.scan(needle).size == 1
source = source.sub(needle, "    host.dataset.frames = String(++frameCount);\n    } finally { window.__coastDrawProbe?.end(renderer, host); }\n  }\n\n  function progress()")
File.write(File.join(q, "relief", "cost-scene-source.mjs"), source)
compiled = SiruiSite::ModuleAssets.compile(source)
File.write(File.join(q, "relief", "cost-scene.mjs"), compiled)
File.write(File.join(q, "relief", "cost-scene-receipt.json"), JSON.pretty_generate({
  "diagnosticOnly" => true,
  "originalSceneSha256" => Digest::SHA256.hexdigest(File.read("assets/js/footer-coast/scene.mjs", encoding: "UTF-8").gsub("\r\n", "\n")),
  "sourceSha256" => Digest::SHA256.hexdigest(source.gsub("\r\n", "\n")),
  "compiledSha256" => Digest::SHA256.hexdigest(compiled),
  "compilerKey" => SiruiSite::ModuleAssets::COMPILER_KEY
}))
puts "Diagnostic scene compiled; canonical source unchanged"
