import gzip
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

root = Path.cwd()
q = Path(__file__).parent
relief = q / "relief"
review = root / "artwork/la-jolla/reviews/depth-relief-2026-10-29"
source_checkpoint = "6d24859d92e0d6351b2cf7cc538b697e3c35e7a2"
review.mkdir(parents=True, exist_ok=True)

def put(relative, raw):
    target = review / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)

def copy(source, target, packed=False):
    raw = source.read_bytes()
    put(target, gzip.compress(raw, mtime=0) if packed else raw)

for width in [1440, 390, 3840]:
    for theme in ["morning", "noon", "afternoon", "evening"]:
        copy(relief / f"canonical-{width}-{theme}.png", f"views/{width}-{theme}.png")

for folder in sorted((relief / "native-final").iterdir()):
    if not folder.is_dir():
        continue
    width = next(w for w in ["1440", "1280", "768", "390"] if folder.name.endswith(w))
    copy(folder / "source-depth-ground.png", f"views/ground-{width}.png")
    copy(folder / "retained-angular-ground.png", f"views/control-{width}.png")
    copy(folder / "source-depth-proof.json", f"browser/ground-{width}.json.gz", True)

for source in sorted((relief / "original-posters").iterdir()):
    if source.is_file():
        copy(source, f"before-posters/{source.name}" + (".gz" if source.suffix == ".txt" else ""), source.suffix == ".txt")

files = {
    "canonical-views.json": "browser/native-views.json.gz",
    "coverage.json": "attempts/coverage.json.gz",
    "generation.json": "attempts/extended-generation.json.gz",
    "land-hit-generation.json": "attempts/land-generation.json.gz",
    "land-hit-views.json": "attempts/land-views.json.gz",
    "depth-generation.json": "attempts/depth-v1-generation.json.gz",
    "bearing-anchors.json": "attempts/bearing-anchors.json.gz",
    "png-alpha-upload.json": "attempts/alpha-upload.json.gz",
    "depth-readback.json": "build/readback.json.gz",
    "native-final.log": "browser/native-ground.log.gz",
    "native-regression.json": "browser/native-regression.json.gz",
    "native-regression.log": "browser/native-regression.log.gz",
    "node-coast-final.log": "checks/node.log.gz",
    "python-final.log": "checks/python.log.gz",
    "cost-preflight.json": "cost/rounding-controls.json.gz",
    "cost-results.json": "cost/results.json.gz",
    "cost-summary.json": "cost/summary.json.gz",
    "cost-scene-receipt.json": "cost/scene-receipt.json.gz",
    "cost-scene-source.mjs": "cost/scene-source.mjs.gz",
    "cost-scene.mjs": "cost/scene.mjs.gz",
}
for source, target in files.items():
    copy(relief / source, target, True)
for source in relief.glob("rejected-*.json"):
    copy(source, f"cost/{source.name}.gz", True)
for source in relief.glob("hook-*.png"):
    copy(source, f"cost/{source.name}")
for source in ["baseline-1440.png", "baseline-390.png", "coverage-mask-1440.png", "coverage-mask-390.png", "extended-1440.png", "extended-390.png", "land-hit-1440.png", "land-hit-390.png", "extended.png", "land-hit.png"]:
    copy(relief / source, f"attempts/{source}")
for source in ["coverage-mask-source.mjs", "coverage-mask-compiled.mjs", "extended-source.mjs", "extended-compiled.mjs", "land-hit-source.mjs", "land-hit-compiled.mjs", "land-hit-producer.py"]:
    copy(relief / source, f"attempts/{source}.gz", True)
copy(relief / "depth-v1-radial-houses.mjs.gz", "attempts/depth-v1-houses.mjs.gz")
for source in sorted((relief / "canonical-v1-radial-houses").glob("*.png")):
    copy(source, f"attempts/depth-v1/{source.name.replace('canonical-', '')}")
copy(q / "sky-controls/rejected-level-apron-sky.mjs", "attempts/apron-source.mjs.gz", True)
copy(q / "sky-controls/rejected-level-apron-compiled.mjs", "attempts/apron-compiled.mjs.gz", True)
for width in [1440, 390]:
    for theme in ["noon", "evening"]:
        copy(q / f"candidate-2/footer-{width}-{theme}.png", f"attempts/apron-{width}-{theme}.png")

copy(q / "production/al-folio/assets/js/footer-coast/sky.mjs", "cost/base-sky.mjs.gz", True)
copy(relief / "baseline.png", "cost/base-hills.png")
copy(q / "usgs-source-read.json", "source/usgs-read.json.gz", True)
copy(q / "ui-compiler.json", "build/preview-compiler.json.gz", True)
copy(q / "baseline-copy.json", "build/full-baseline.json.gz", True)
copy(q / "depth-build-final.log", "build/jekyll.log.gz", True)
copy(q / "depth-build.log", "build/first-missing-parent.log.gz", True)
copy(q / "webkit-depth-results.json", "browser/webkit.json.gz", True)
for source in ["capture-depth.cjs", "depth-cost.cjs", "prepare-depth-cost.rb", "probe-relief.cjs", "probe-land-hit.cjs", "generate-depth.py", "probe-depth.cjs", "compile-ui.rb", "readback-depth.py", "analyze-mask.py", "webkit-depth.config.cjs"]:
    copy(q / source, f"producers/{source}.gz", True)
copy(Path(__file__), "producers/pack-depth.py.gz", True)

source_paths = subprocess.check_output(["git", "diff-tree", "--no-commit-id", "--name-only", "-r", source_checkpoint], text=True).splitlines()
source_paths += ["assets/js/footer-coast/skyline.mjs", "assets/js/footer-coast/skyline-data.mjs", "assets/js/footer-coast/sky-look.mjs", "assets/js/footer-coast/view-tilt.mjs", "assets/js/footer-coast/water.mjs", "assets/models/la-jolla/manifest.json", "assets/models/la-jolla/la-jolla.glb", "assets/models/la-jolla/miniature.glb", "bin/coastal_terrain.py", "bin/render_coast_posters.cjs", "_plugins/site_module_assets.rb", "Gemfile.lock", "package-lock.json"]
source_bindings = []
for relative in sorted(set(source_paths)):
    source = root / relative
    if not source.is_file():
        continue
    raw = source.read_bytes()
    binary = source.suffix in [".png", ".webp", ".glb"]
    normalized = raw if binary else raw.replace(b"\r\n", b"\n")
    source_bindings.append({"path": relative, "mode": "binary" if binary else "text-lf", "bytes": len(normalized), "sha256": hashlib.sha256(normalized).hexdigest()})
    if relative in source_paths[:22] and not binary:
        copy(source, f"source/{relative.replace('/', '__')}.gz", True)

manifest = {
    "schema": "sirui-footer-depth-review-v1",
    "sourceCheckpoint": source_checkpoint,
    "sourceBindings": source_bindings,
    "payloads": [],
}
for path in sorted(review.rglob("*")):
    if not path.is_file() or path.name == "manifest.json":
        continue
    text = path.name in ["README.md", "verify.py"]
    raw = path.read_bytes().replace(b"\r\n", b"\n") if text else path.read_bytes()
    manifest["payloads"].append({"path": path.relative_to(review).as_posix(), "mode": "text-lf" if text else "binary", "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
put("manifest.json", (json.dumps(manifest, indent=2) + "\n").encode())
print("Packed", len(manifest["payloads"]), "payloads,", len(source_bindings), "source bindings")
