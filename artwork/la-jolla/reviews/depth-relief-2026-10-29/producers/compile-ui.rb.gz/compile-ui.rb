require "jekyll"
require "json"
require "digest"
require "fileutils"
require "stringio"

repo = Dir.pwd
q = File.expand_path(__dir__)
scratch = File.join(q, "compiled")
dest = File.join(q, "site", "al-folio")
write_preview = ARGV.include?("--write")
site = Jekyll::Site.new(Jekyll.configuration({
  "source" => repo, "destination" => scratch, "baseurl" => "/al-folio",
  "url" => "https://dylantao.github.io", "quiet" => true, "incremental" => false
}))
site.reset
site.read
prior_stdout = $stdout
generated_log = StringIO.new
begin
  $stdout = generated_log
  site.generate
ensure
  $stdout = prior_stdout
end
File.binwrite(File.join(q, "ui-generation.log"), generated_log.string)
receipt = { "compiler" => "Jekyll page renderer + configured Sass converter and jekyll-terser; source .mjs uses site_module_assets.rb", "assets" => {} }
hash = ->(bytes) { Digest::SHA256.hexdigest(bytes) }

css = site.pages.find { |page| page.relative_path == "assets/css/main.scss" || page.path.end_with?("/assets/css/main.scss") }
raise "No production main.scss page" unless css
css.render(site.layouts, site.site_payload)
FileUtils.mkdir_p(File.join(scratch, "assets/css"))
File.binwrite(File.join(scratch, "assets/css/main.css"), css.output)

javascript = site.static_files.find { |file| file.relative_path == "/assets/js/brand-orange.js" }
raise "No production brand-orange.js static asset" unless javascript
javascript.write(scratch)
receipt["javascriptClass"] = javascript.class.name
paths = ["assets/css/main.css", "assets/js/brand-orange.js"]
%w[scene.mjs view-tilt.mjs sky.mjs sky-look.mjs].each do |name|
  rel = "/assets/js/footer-coast/#{name}"
  file = site.static_files.find { |asset| asset.relative_path == rel }
  raise "No production module #{rel}" unless file
  file.write(scratch)
  paths << rel.delete_prefix("/")
end
%w[assets/img/favicon.svg assets/img/favicon.ico assets/img/apple-touch-icon.png assets/models/la-jolla/hills.png].each do |rel|
  file = site.static_files.find { |asset| asset.relative_path == "/#{rel}" }
  raise "No production icon #{rel}" unless file
  file.write(scratch)
  paths << rel
end
paths.each do |rel|
  bytes = File.binread(File.join(scratch, rel))
  prior = File.binread(File.join(dest, rel))
  receipt["assets"][rel] = { "bytes" => bytes.bytesize, "sha256" => hash.call(bytes), "matchesPreviousPreview" => bytes == prior }
  File.binwrite(File.join(dest, rel), bytes) if write_preview
end

if ARGV.include?("--fragments")
  fragments = []
  documents = site.pages + site.collections.values.flat_map(&:docs)
  documents.uniq(&:url).each do |document|
    next unless document.output_ext == ".html"
    relative = Jekyll::URL.unescape_path(document.url).delete_prefix("/")
    relative += "index.html" if relative.empty? || relative.end_with?("/")
    target = File.expand_path(File.join(dest, relative))
    next unless File.file?(target)
    prefix = File.expand_path(dest).tr("\\", "/").downcase + "/"
    raise "Preview path escaped owned build: #{target.inspect} vs #{prefix.inspect}" unless target.tr("\\", "/").downcase.start_with?(prefix)
    html = File.read(target, encoding: "UTF-8")
    changed = false
    { "header.liquid" => /<header\b(?=[^>]*\bid=(?:"top"|'top'|top(?=\s|>)))[\s\S]*?<\/header>/,
      "la-jolla-footer.liquid" => /<figure\b(?=[^>]*\bid=(?:"la-jolla"|'la-jolla'|la-jolla(?=\s|>)))[\s\S]*?<\/figure>/ }.each do |include_name, pattern|
      next unless html.match?(pattern)
      fragment = Jekyll::PageWithoutAFile.new(site, site.source, "", "ui-#{include_name.delete_suffix('.liquid')}.html")
      fragment.data = document.data.merge("layout" => nil, "permalink" => document.url, "render_with_liquid" => true)
      fragment.content = "{% include #{include_name} %}"
      fragment.render(site.layouts, site.site_payload)
      output = fragment.output.match(pattern)&.to_s
      File.binwrite(File.join(q, "failed-fragment.html"), fragment.output) unless output
      raise "Production Liquid did not render #{include_name} for #{document.url}" unless output && !output.match?(/\{[{%]/)
      html = html.sub(pattern, output)
      changed = true
    end
    if changed
      fragments << { "route" => document.url, "sha256" => hash.call(html) }
      File.binwrite(target, html) if write_preview
    end
  end
  receipt["fragments"] = fragments
end

if write_preview
  build = JSON.parse(File.read(File.join(dest, "assets/js/module-build.json")))
  actual = site.instance_variable_get(:@sirui_module_records)
  actual.each { |name, record| build["modules"][name] = record }
  File.binwrite(File.join(dest, "assets/js/module-build.json"), JSON.generate(build) + "\n")
end
File.binwrite(File.join(q, "ui-compiler.json"), JSON.pretty_generate(receipt) + "\n")
puts JSON.generate(receipt.reject { |key, _| key == "fragments" }.merge("fragmentCount" => receipt.fetch("fragments", []).size))
