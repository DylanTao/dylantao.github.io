import hashlib
import json
from pathlib import Path

root = Path.cwd()
q = Path(__file__).parent
production = q / "depth-production/al-folio"
preview = q / "site/al-folio"
digest = lambda b: hashlib.sha256(b).hexdigest()
receipt = json.loads((production / "assets/js/module-build.json").read_text())
records = []
for source in sorted((root / "assets/js/footer-coast").glob("*.mjs")):
    relative = source.relative_to(root).as_posix()
    entry = receipt["modules"][relative]
    normalized = source.read_bytes().replace(b"\r\n", b"\n")
    actual = (production / relative).read_bytes()
    assert digest(normalized) == entry["sourceSha256"], relative
    assert digest(actual) == entry["outputSha256"], relative
    assert actual == (preview / relative).read_bytes(), relative
    records.append({"path": relative, **entry, "previewExact": True})

for source in sorted((root / "assets/models/la-jolla").rglob("*")):
    if not source.is_file():
        continue
    relative = source.relative_to(root).as_posix()
    actual = (production / relative).read_bytes()
    if source.suffix == ".json":
        assert json.loads(actual) == json.loads(source.read_bytes()), relative
        assert json.loads(actual) == json.loads((preview / relative).read_bytes()), relative
    else:
        assert actual == source.read_bytes() == (preview / relative).read_bytes(), relative
    records.append({"path": relative, "bytes": len(actual), "sha256": digest(actual), "previewExactOrJsonSemantic": True})

home = list((root / "assets/models/home").rglob("*"))
home_checked = 0
for source in home:
    if not source.is_file():
        continue
    relative = source.relative_to(root)
    actual = (production / relative).read_bytes()
    if source.suffix == ".json":
        assert json.loads(actual) == json.loads(source.read_bytes()), str(relative)
    else:
        assert actual == source.read_bytes(), str(relative)
    home_checked += 1

script = production / "assets/js/footer-coast/sky.mjs"
assert digest(script.read_bytes()) == "e3d81a3ade02fa81b4b2e9c9d7d9cbb46fe3e1cc14e3a78fc07d5b3094f05150"
data = {"schema": "sirui-footer-depth-build-readback-v1", "pipeline": receipt["pipeline"],
        "footerRecords": records, "completeHomeAssetsChecked": home_checked,
        "completeBuildFileCount": sum(1 for p in production.rglob("*") if p.is_file()),
        "timedAndCapturedSkyExact": True}
(q / "relief/depth-readback.json").write_text(json.dumps(data, indent=2) + "\n")
print("Complete production/preview/source footer readback PASS", len(records), "footer assets;", home_checked, "home assets present and exact/semantic")
