// Diagnostic-only full delivered footer draw. Never imported by the product.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { chromium } = require('playwright');
const { preparePage, collectRuntimeErrors } = require('../../../test/visual/helpers.js');
const q = __dirname, out = path.join(q, 'relief');
const base = 'http://127.0.0.1:4151/al-folio';
const sample = process.argv.includes('--sample');
const oldSky = fs.readFileSync(path.join(q, 'production/al-folio/assets/js/footer-coast/sky.mjs'));
const oldPng = fs.readFileSync(path.join(out, 'baseline.png'));
const diagnosticScene = fs.readFileSync(path.join(out, 'cost-scene.mjs'));
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');

function installProbe() {
  let renderer = null, host = null, gl = null, ext = null, active = false, at = 0, query = null;
  let oldAuto = null, lastAt = null, samples = [], pending = [], gpu = [], disjoint = false;
  const poll = () => {
    while (pending.length && gl.getQueryParameter(pending[0].query, gl.QUERY_RESULT_AVAILABLE)) {
      const entry = pending.shift();
      const invalid = gl.getParameter(ext.GPU_DISJOINT_EXT);
      disjoint ||= invalid;
      gpu.push({ frame: entry.frame, ms: invalid ? null : gl.getQueryParameter(entry.query, gl.QUERY_RESULT) / 1e6 });
      gl.deleteQuery(entry.query);
    }
  };
  window.__coastDrawProbe = {
    begin(r, h) {
      if (h.closest('footer') == null) return;
      renderer = r; host = h; gl ||= r.getContext(); ext ||= gl.getExtension('EXT_disjoint_timer_query_webgl2');
      if (!active) return;
      if (ext) poll();
      r.info.reset();
      if (ext) { query = gl.createQuery(); gl.beginQuery(ext.TIME_ELAPSED_EXT, query); }
      at = performance.now();
    },
    end(r, h) {
      if (!active || r !== renderer || h !== host) return;
      const end = performance.now(), cpuMs = end - at;
      if (ext && query) {
        gl.endQuery(ext.TIME_ELAPSED_EXT);
        pending.push({ query, frame: Number(h.dataset.frames) }); query = null;
      }
      samples.push({ frame: Number(h.dataset.frames), cpuMs, intervalMs: lastAt == null ? null : at - lastAt,
        calls: r.info.render.calls, triangles: r.info.render.triangles, programs: r.info.programs.length });
      lastAt = at;
    },
    start() {
      if (!renderer) throw new Error('Renderer never bound');
      if (active) throw new Error('Probe already active');
      oldAuto = renderer.info.autoReset; renderer.info.autoReset = false; active = true;
    },
    stop() {
      active = false;
      if (renderer && oldAuto !== null) renderer.info.autoReset = oldAuto;
      if (ext) poll();
      return this.read();
    },
    read() {
      const debug = gl?.getExtension('WEBGL_debug_renderer_info');
      return { bound: !!renderer, active, samples, gpu, pending: pending.length, disjoint,
        extension: !!ext, renderer: debug ? gl.getParameter(debug.UNMASKED_RENDERER_WEBGL) : null,
        vendor: debug ? gl.getParameter(debug.UNMASKED_VENDOR_WEBGL) : null,
        buffer: gl ? [gl.drawingBufferWidth, gl.drawingBufferHeight] : null,
        resources: renderer?.info.memory, programs: renderer?.info.programs.length,
        autoReset: renderer?.info.autoReset, evidence: host?.getCoastEvidence?.() };
    },
    pixels() {
      const pixels = new Uint8Array(gl.drawingBufferWidth * gl.drawingBufferHeight * 4);
      gl.readPixels(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
      return Array.from(pixels);
    },
    dispose() {
      this.stop();
      for (const p of pending) gl.deleteQuery(p.query);
      pending = []; renderer = host = gl = ext = null;
    }
  };
}

async function open(browser, { width = 2560, variant = 'candidate', instrument = true, live = false, seed = false } = {}) {
  const context = await browser.newContext({ viewport: { width, height: 1000 }, deviceScaleFactor: 1,
    reducedMotion: live ? 'no-preference' : 'reduce', timezoneId: 'America/Los_Angeles' });
  const page = await context.newPage();
  await preparePage(page, 'noon');
  if (seed) await page.addInitScript(() => {
    let state = 0x14ab37cd;
    Math.random = () => { state = (Math.imul(state, 1664525) + 1013904223) >>> 0; return state / 4294967296; };
  });
  await page.clock.setFixedTime(new Date('2026-10-23T12:30:00-07:00'));
  if (instrument) {
    await page.addInitScript(installProbe);
    await page.route(/\/footer-coast\/scene\.mjs(?:\?.*)?$/, route => route.fulfill({ contentType: 'text/javascript', body: diagnosticScene }));
  }
  if (variant === 'baseline') {
    await page.route(/\/footer-coast\/sky\.mjs(?:\?.*)?$/, route => route.fulfill({ contentType: 'text/javascript', body: oldSky }));
    await page.route(/\/models\/la-jolla\/hills\.png(?:\?.*)?$/, route => route.fulfill({ contentType: 'image/png', body: oldPng }));
  }
  const errors = collectRuntimeErrors(page), requests = [];
  page.on('response', response => { if (/\/models\/la-jolla\/.*\.glb/.test(response.url())) requests.push(response.url()); });
  await page.goto(base + '/blog/' + (live ? '?cinematic=live' : ''), { waitUntil: 'domcontentloaded' });
  const host = page.locator('footer [data-footer-coast]');
  await host.scrollIntoViewIfNeeded();
  await page.waitForFunction(() => document.querySelector('footer [data-footer-coast]')?.dataset.state === 'ready', null, { timeout: 30000 });
  await page.waitForFunction(() => document.querySelector('footer [data-footer-coast]')?.getCoastEvidence?.().reveal === 1);
  // Let the page's bounded initial theme transition finish before a pixel
  // control; it is unrelated to reduced scene motion or shader compilation.
  await page.waitForTimeout(1000);
  const read = instrument ? await page.evaluate(() => window.__coastDrawProbe.read()) : { evidence: await host.evaluate(h => h.getCoastEvidence()) };
  assert.equal(read.evidence.miniature, false);
  assert.equal(read.evidence.theme, 'noon');
  assert.equal(read.evidence.buildings, 13);
  assert.equal(read.evidence.landmarks.length, 13);
  assert.ok(requests.some(url => url.includes('la-jolla.glb')));
  assert.equal(!!read.evidence.sky.depthRelief, variant === 'candidate');
  if (instrument) {
    assert.equal(read.bound, true); assert.equal(read.active, false); assert.equal(read.samples.length, 0); assert.equal(read.gpu.length, 0);
    assert.match(read.renderer, /NVIDIA.*(?:3080|D3D11)|ANGLE.*NVIDIA/i);
    assert.equal(read.buffer[0], width);
    const canvas = await host.locator('canvas').evaluate(c => [c.width, c.height, c.clientWidth, c.clientHeight]);
    assert.deepEqual(read.buffer, canvas.slice(0, 2)); assert.equal(canvas[0], canvas[2]); assert.equal(canvas[1], canvas[3]);
    assert.ok(read.programs > 5);
  }
  if (live) { assert.equal(read.evidence.running, true); assert.equal(read.evidence.people.live, true); }
  return { context, page, host, read, errors, requests };
}

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const report = { mode: sample ? 'coordinated quiet sampled run' : 'preflight only: zero timing samples', date: new Date().toISOString(),
    dependencies: { baselineSkySha256: hash(oldSky), baselinePngSha256: hash(oldPng), diagnosticSceneSha256: hash(diagnosticScene) }, rows: [] };
  const timeout = setTimeout(() => { fs.writeFileSync(path.join(out, 'cost-timeout.json'), JSON.stringify(report, null, 2)); browser.close(); }, sample ? 84000 : 60000);
  try {
    if (process.argv.includes('--pixel-diagnose')) {
      const { PNG } = require('pngjs');
      const p = await open(browser, { width: 2560, seed: true });
      const frames = await p.page.evaluate(() => {
        const host = document.querySelector('footer [data-footer-coast]'), canvas = host.querySelector('canvas'), probe = window.__coastDrawProbe;
        const frames = [];
        try { for (const hook of [false,false,false,false,true,true,true,true,false,false,false,false]) {
          window.__coastDrawProbe = hook ? probe : null;
          host.dispatchEvent(new Event('coast:place'));
          frames.push({ hook, png: canvas.toDataURL(), evidence: host.getCoastEvidence() });
        }} finally { window.__coastDrawProbe = probe; }
        return frames;
      });
      let previous = null;
      frames.forEach((frame, i) => {
        const encoded=Buffer.from(frame.png.split(',')[1],'base64'), png=PNG.sync.read(encoded);
        fs.writeFileSync(path.join(out,`hook-${i}.png`),encoded);
        let changed=0,sum=0,max=0;
        if(previous)for(let j=0;j<png.data.length;j++){const d=Math.abs(png.data[j]-previous.data[j]);if(d)changed++;sum+=d;max=Math.max(max,d);}
        delete frame.png;frame.rgbaSha256=hash(png.data);frame.differenceToPrevious={changedChannels:changed,sum,max}; previous=png;
      });
      report.rows.push({frames,probe:await p.page.evaluate(()=>window.__coastDrawProbe.read()),errors:p.errors});
      await p.context.close();
    } else if (!sample) {
      if (!process.argv.includes('--parity-only')) for (const width of [2560, 3840]) for (const variant of ['baseline', 'candidate']) {
        const p = await open(browser, { width, variant, live: true });
        report.rows.push({ width, variant, preflight: p.read, errors: p.errors, models: p.requests });
        assert.deepEqual(p.errors, []); await p.page.evaluate(() => window.__coastDrawProbe.dispose()); await p.context.close();
      }
      // Production and wrapped modules in independent native contexts with
      // the same contact-noise seed. No clocks, GPU work or source geometry
      // are suppressed. Samples remain disabled throughout preflight.
      const parity = [];
      for (const instrument of [false, true]) {
        const p = await open(browser, { width: 2560, instrument, seed: true });
        const pixels = await p.page.evaluate(async () => {
          const host = document.querySelector('footer [data-footer-coast]'), canvas = host.querySelector('canvas');
          const gl = canvas.getContext('webgl2');
          host.dispatchEvent(new Event('coast:place'));
          const bytes = new Uint8Array(canvas.width*canvas.height*4);
          gl.readPixels(0,0,canvas.width,canvas.height,gl.RGBA,gl.UNSIGNED_BYTE,bytes);
          return { rgbaSha256: Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)), x=>x.toString(16).padStart(2,'0')).join(''),
            zeroSampleProof: window.__coastDrawProbe?.read() ?? null };
        });
        parity.push({ instrument, ...pixels, errors: p.errors });
        assert.deepEqual(p.errors, []); await p.context.close();
      }
      report.rows.push({ parity });
      assert.equal(parity[0].rgbaSha256, parity[1].rgbaSha256);
      assert.equal(parity[1].zeroSampleProof.samples.length, 0);
      assert.equal(parity[1].zeroSampleProof.gpu.length, 0);
    } else {
      for (const width of [2560, 3840]) for (const variant of ['baseline', 'candidate', 'candidate', 'baseline']) {
        const p = await open(browser, { width, variant, live: true });
        await p.page.evaluate(() => window.__coastDrawProbe.start());
        await p.page.waitForFunction(() => window.__coastDrawProbe.read().samples.length >= 60, null, { polling: 50, timeout: 7000 });
        const result = await p.page.evaluate(() => window.__coastDrawProbe.stop());
        assert.ok(result.samples.length >= 60); assert.equal(result.active, false); assert.equal(result.autoReset, true);
        assert.deepEqual(p.errors, []);
        report.rows.push({ width, variant, preflight: p.read, result, errors: p.errors });
        await p.page.evaluate(() => window.__coastDrawProbe.dispose()); await p.context.close();
        fs.writeFileSync(path.join(out, 'cost-progress.json'), JSON.stringify(report, null, 2));
      }
    }
    report.complete = true;
  } finally {
    clearTimeout(timeout); await browser.close();
    fs.writeFileSync(path.join(out, sample ? 'cost-results.json' : 'cost-preflight.json'), JSON.stringify(report, null, 2));
  }
  console.log(JSON.stringify({ mode: report.mode, complete: report.complete, rows: report.rows.length }));
})().catch(e => { console.error(e); process.exitCode = 1; });
