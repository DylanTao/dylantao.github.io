"""Correctly classify the saved rendered magenta diagnostic, without recapture."""
import json
from pathlib import Path
import numpy as np
from PIL import Image

q = Path(__file__).parent / "relief"
rows = json.loads((q / "coverage.json").read_bytes())
result = []
for row in rows:
    if row["variant"] != "coverage-mask":
        continue
    pixels = np.asarray(Image.open(q / f"coverage-mask-{row['width']}.png").convert("RGBA")).astype(int)
    height, width, _ = pixels.shape
    mask = (pixels[:, :, 0] > 200) & (pixels[:, :, 2] > 200) & (pixels[:, :, 0] > 2 * pixels[:, :, 1])
    y, x = np.where(mask)
    a, b, c = row["mapE"]
    angles = np.sort(a * (x + 0.5) / width + b * (1 - (y + 0.5) / height) + c)
    assert len(angles) == row["unsupported"]["pixels"]
    assert abs(float(angles[0]) - row["unsupported"]["min"]) < 1e-10
    result.append({"width": row["width"], "unsupportedPixels": len(angles), "minElevation": float(angles[0]),
                   "maskRule": "R>200 and B>200 and R>2*G; the original G<75 test missed actual G near82"})
print(json.dumps(result, indent=2))
