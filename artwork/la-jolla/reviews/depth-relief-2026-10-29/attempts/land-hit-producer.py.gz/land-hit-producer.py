def relief(ground):
    """What the bay sees along each bearing and elevation: the ground's slope (its normal's east and
    north components) and its distance, as an RGB image with the highest elevation on top. Rows above
    the skyline repeat the crest, so the shader's filtering never mixes the sky into the slopes."""
    import numpy as np

    image = np.zeros((RELIEF_ROWS, RELIEF_BEARINGS, 4), dtype=np.uint8)
    for b in range(RELIEF_BEARINGS):
        bearing = b * RELIEF_BEARING_STEP
        samples = ray(ground, bearing, step=8.0)
        filled = None
        for j in range(RELIEF_ROWS):
            elevation = RELIEF_LOW + j * RELIEF_STEP
            hit = next((s for s in samples if s[2] >= elevation), None)
            if hit is None:
                break
            d, h, _ = hit
            lat, lon = ground.point(bearing, d)
            # The slope over about 40 m, from the ground's gradient.
            step_lon = 20.0 / (111320.0 * ground.cos)
            step_lat = 20.0 / 110574.0
            gx = (ground.at(lat, lon + step_lon) - ground.at(lat, lon - step_lon)) / 40.0
            gy = (ground.at(lat + step_lat, lon) - ground.at(lat - step_lat, lon)) / 40.0
            n = np.array([-gx, -gy, 1.0])
            n /= np.linalg.norm(n)
            filled = (round((n[0] * 0.5 + 0.5) * 255), round((n[1] * 0.5 + 0.5) * 255), max(1, min(255, round(d / 1000 / RELIEF_KM * 255))), 255 if h > 0 else 0)
            image[RELIEF_ROWS - 1 - j, b] = filled
        if filled is not None:
            for j in range(RELIEF_ROWS):
                if image[RELIEF_ROWS - 1 - j, b, 2] == 0:
                    image[RELIEF_ROWS - 1 - j, b] = filled
    # A small angular filter keeps source-raster noise from striping the hills without averaging
    # across the old nine degrees of distance, which erased the canyon's relief.
    slopes = image[..., :2].astype(np.float64)
    padded = np.pad(slopes, ((1, 1), (1, 1), (0, 0)), mode="edge")
    image[..., :2] = np.round(sum(padded[dy : dy + RELIEF_ROWS, dx : dx + RELIEF_BEARINGS] for dy in range(3) for dx in range(3)) / 9).astype(np.uint8)
    distance = np.pad(image[..., 2].astype(np.float64), ((0, 0), (1, 1)), mode="edge")
    image[..., 2] = np.round(sum(distance[:, dx : dx + RELIEF_BEARINGS] for dx in range(3)) / 3).astype(np.uint8)
    return image
